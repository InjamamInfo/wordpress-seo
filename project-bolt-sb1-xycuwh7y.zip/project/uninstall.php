<?php
/**
 * Uninstall script for Autonomous AI SEO
 */

// If uninstall not called from WordPress, then exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Include the main plugin file to access classes
require_once plugin_dir_path(__FILE__) . 'autonomous-ai-seo.php';

// Remove all plugin data
AutonomousAISEO::uninstall();