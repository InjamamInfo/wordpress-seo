<?php
/**
 * Revenue & ROI template for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aaiseo-dashboard">
    <div class="aaiseo-header">
        <div class="aaiseo-header-content">
            <div class="aaiseo-logo">
                <h1><?php _e('Revenue & ROI Dashboard', 'autonomous-ai-seo'); ?></h1>
                <p><?php _e('Track your SEO impact on revenue and calculate ROI', 'autonomous-ai-seo'); ?></p>
            </div>
            <div class="aaiseo-status">
                <div class="date-selector">
                    <select id="date-range">
                        <option value="7"><?php _e('Last 7 days', 'autonomous-ai-seo'); ?></option>
                        <option value="30" selected><?php _e('Last 30 days', 'autonomous-ai-seo'); ?></option>
                        <option value="90"><?php _e('Last 90 days', 'autonomous-ai-seo'); ?></option>
                        <option value="180"><?php _e('Last 6 months', 'autonomous-ai-seo'); ?></option>
                        <option value="365"><?php _e('Last 12 months', 'autonomous-ai-seo'); ?></option>
                        <option value="custom"><?php _e('Custom Range', 'autonomous-ai-seo'); ?></option>
                    </select>
                    <div id="custom-range" style="display: none;">
                        <input type="date" id="start-date" value="<?php echo date('Y-m-d', strtotime('-30 days')); ?>">
                        <input type="date" id="end-date" value="<?php echo date('Y-m-d'); ?>">
                        <button class="button button-secondary" id="apply-date-range"><?php _e('Apply', 'autonomous-ai-seo'); ?></button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ROI Summary -->
    <div class="roi-summary-grid">
        <div class="roi-summary-card">
            <div class="roi-card-header">
                <h2><?php _e('SEO ROI', 'autonomous-ai-seo'); ?></h2>
                <div class="roi-score" id="roi-value">0%</div>
            </div>
            <div class="roi-details">
                <div class="roi-detail-item">
                    <span><?php _e('Total Revenue', 'autonomous-ai-seo'); ?>:</span>
                    <strong id="total-revenue">$0</strong>
                </div>
                <div class="roi-detail-item">
                    <span><?php _e('Total Cost', 'autonomous-ai-seo'); ?>:</span>
                    <strong id="total-cost">$0</strong>
                </div>
                <div class="roi-detail-item">
                    <span><?php _e('Net Profit', 'autonomous-ai-seo'); ?>:</span>
                    <strong id="net-profit">$0</strong>
                </div>
                <div class="roi-detail-item">
                    <span><?php _e('Lead Value', 'autonomous-ai-seo'); ?>:</span>
                    <strong id="lead-value">$0</strong>
                </div>
            </div>
        </div>
        
        <div class="roi-summary-card">
            <div class="roi-card-header">
                <h2><?php _e('Conversion Metrics', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="roi-chart-container">
                <canvas id="conversion-chart" width="300" height="150"></canvas>
            </div>
        </div>
        
        <div class="roi-summary-card">
            <div class="roi-card-header">
                <h2><?php _e('Traffic Value', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="value-details">
                <div class="value-item">
                    <div class="value-label"><?php _e('Revenue Per Visit', 'autonomous-ai-seo'); ?></div>
                    <div class="value-number" id="revenue-per-visit">$0.00</div>
                </div>
                <div class="value-item">
                    <div class="value-label"><?php _e('Value Per Lead', 'autonomous-ai-seo'); ?></div>
                    <div class="value-number" id="value-per-lead">$0.00</div>
                </div>
                <div class="value-item">
                    <div class="value-label"><?php _e('Lead Conversion Rate', 'autonomous-ai-seo'); ?></div>
                    <div class="value-number" id="lead-conversion-rate">0%</div>
                </div>
                <div class="value-item">
                    <div class="value-label"><?php _e('Organic Traffic', 'autonomous-ai-seo'); ?></div>
                    <div class="value-number" id="organic-traffic">0</div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Revenue Chart -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Revenue Tracking', 'autonomous-ai-seo'); ?></h2>
            <div class="chart-controls">
                <button class="button chart-period active" data-period="revenue">
                    <?php _e('Revenue', 'autonomous-ai-seo'); ?>
                </button>
                <button class="button chart-period" data-period="leads">
                    <?php _e('Leads', 'autonomous-ai-seo'); ?>
                </button>
                <button class="button chart-period" data-period="combined">
                    <?php _e('Combined', 'autonomous-ai-seo'); ?>
                </button>
            </div>
        </div>
        <div class="panel-content">
            <div id="revenue-chart-container" class="chart-container">
                <canvas id="revenue-chart"></canvas>
            </div>
        </div>
    </div>

    <div class="aaiseo-dashboard-grid">
        <!-- Revenue Sources -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Revenue Sources', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div id="sources-chart-container" class="chart-container">
                    <canvas id="sources-chart"></canvas>
                </div>
                <div id="sources-breakdown">
                    <div class="loading">
                        <span class="spinner is-active"></span>
                        <span><?php _e('Loading data...', 'autonomous-ai-seo'); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form Conversions -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Lead Sources', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div id="forms-chart-container" class="chart-container">
                    <canvas id="forms-chart"></canvas>
                </div>
                <div id="forms-breakdown">
                    <div class="loading">
                        <span class="spinner is-active"></span>
                        <span><?php _e('Loading data...', 'autonomous-ai-seo'); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Projected ROI Calculator -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('ROI Projection Calculator', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <div class="roi-calculator">
                <div class="roi-calculator-inputs">
                    <div class="calculator-group">
                        <label for="current-traffic"><?php _e('Current Monthly Organic Traffic', 'autonomous-ai-seo'); ?></label>
                        <input type="number" id="current-traffic" value="1000" min="0">
                    </div>
                    
                    <div class="calculator-group">
                        <label for="projected-increase"><?php _e('Projected Traffic Increase (%)', 'autonomous-ai-seo'); ?></label>
                        <input type="number" id="projected-increase" value="25" min="0" max="1000">
                    </div>
                    
                    <div class="calculator-group">
                        <label for="conversion-rate"><?php _e('Conversion Rate (%)', 'autonomous-ai-seo'); ?></label>
                        <input type="number" id="conversion-rate" value="2.5" min="0" max="100" step="0.1">
                    </div>
                    
                    <div class="calculator-group">
                        <label for="average-order"><?php _e('Average Order Value ($)', 'autonomous-ai-seo'); ?></label>
                        <input type="number" id="average-order" value="100" min="0" step="0.01">
                    </div>
                    
                    <div class="calculator-group">
                        <label for="subscription-cost"><?php _e('Monthly Subscription ($)', 'autonomous-ai-seo'); ?></label>
                        <input type="number" id="subscription-cost" value="500" min="0" step="0.01">
                    </div>
                    
                    <div class="calculator-group">
                        <label for="time-cost"><?php _e('Monthly Time Investment ($)', 'autonomous-ai-seo'); ?></label>
                        <input type="number" id="time-cost" value="250" min="0" step="0.01">
                    </div>
                    
                    <div class="calculator-actions">
                        <button id="calculate-roi" class="button button-primary">
                            <?php _e('Calculate ROI', 'autonomous-ai-seo'); ?>
                        </button>
                    </div>
                </div>
                
                <div class="roi-calculator-results">
                    <div class="calculator-result-header">
                        <h3><?php _e('Projected ROI Results', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    
                    <div class="calculator-result-grid">
                        <div class="result-item">
                            <div class="result-label"><?php _e('Current Monthly Revenue', 'autonomous-ai-seo'); ?></div>
                            <div class="result-value" id="calc-current-revenue">$0</div>
                        </div>
                        
                        <div class="result-item">
                            <div class="result-label"><?php _e('Projected Monthly Revenue', 'autonomous-ai-seo'); ?></div>
                            <div class="result-value" id="calc-projected-revenue">$0</div>
                        </div>
                        
                        <div class="result-item">
                            <div class="result-label"><?php _e('Revenue Increase', 'autonomous-ai-seo'); ?></div>
                            <div class="result-value" id="calc-revenue-increase">$0</div>
                        </div>
                        
                        <div class="result-item">
                            <div class="result-label"><?php _e('Monthly Cost', 'autonomous-ai-seo'); ?></div>
                            <div class="result-value" id="calc-monthly-cost">$0</div>
                        </div>
                        
                        <div class="result-item result-highlight">
                            <div class="result-label"><?php _e('ROI', 'autonomous-ai-seo'); ?></div>
                            <div class="result-value" id="calc-roi">0%</div>
                        </div>
                        
                        <div class="result-item result-highlight">
                            <div class="result-label"><?php _e('Break-even Period', 'autonomous-ai-seo'); ?></div>
                            <div class="result-value" id="calc-breakeven">0 months</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.date-selector {
    display: flex;
    gap: 10px;
    align-items: center;
}

#custom-range {
    display: flex;
    gap: 10px;
    align-items: center;
}

.roi-summary-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.roi-summary-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    border: 1px solid #e5e7eb;
    overflow: hidden;
}

.roi-card-header {
    padding: 20px;
    background: #f9fafb;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.roi-card-header h2 {
    margin: 0;
    font-size: 16px;
    color: #1f2937;
}

.roi-score {
    font-size: 24px;
    font-weight: 700;
    color: #10b981;
}

.roi-details {
    padding: 20px;
}

.roi-detail-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    font-size: 14px;
}

.roi-detail-item:last-child {
    margin-bottom: 0;
}

.roi-detail-item span {
    color: #6b7280;
}

.roi-detail-item strong {
    color: #1f2937;
}

.chart-container {
    height: 300px;
    position: relative;
}

.value-details {
    padding: 20px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.value-item {
    text-align: center;
}

.value-label {
    color: #6b7280;
    font-size: 13px;
    margin-bottom: 8px;
}

.value-number {
    font-size: 18px;
    font-weight: 600;
    color: #1f2937;
}

.sources-breakdown, .forms-breakdown {
    margin-top: 20px;
}

.breakdown-header {
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
    margin-bottom: 15px;
}

.breakdown-table {
    width: 100%;
    border-collapse: collapse;
}

.breakdown-table th, .breakdown-table td {
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #e5e7eb;
}

.breakdown-table th {
    font-weight: 600;
    color: #374151;
    font-size: 12px;
}

.breakdown-table td {
    font-size: 13px;
    color: #4b5563;
}

.loading {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 30px;
    color: #6b7280;
}

.loading .spinner {
    float: none;
    margin: 0 10px 0 0;
}

.roi-calculator {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
}

.roi-calculator-inputs {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
}

.calculator-group {
    margin-bottom: 15px;
}

.calculator-group label {
    display: block;
    font-size: 14px;
    font-weight: 500;
    color: #374151;
    margin-bottom: 8px;
}

.calculator-group input {
    width: 100%;
    padding: 10px;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    font-size: 14px;
}

.calculator-actions {
    grid-column: 1 / -1;
    margin-top: 15px;
}

.roi-calculator-results {
    background: #f9fafb;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    overflow: hidden;
}

.calculator-result-header {
    padding: 15px 20px;
    background: #f3f4f6;
    border-bottom: 1px solid #e5e7eb;
}

.calculator-result-header h3 {
    margin: 0;
    font-size: 16px;
    color: #1f2937;
}

.calculator-result-grid {
    padding: 20px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.result-item {
    padding: 15px;
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 6px;
}

.result-label {
    font-size: 13px;
    color: #6b7280;
    margin-bottom: 8px;
}

.result-value {
    font-size: 20px;
    font-weight: 600;
    color: #1f2937;
}

.result-highlight {
    border-color: #bfdbfe;
    background: #f0f9ff;
}

.result-highlight .result-label {
    color: #1e40af;
}

.result-highlight .result-value {
    color: #1e40af;
}

@media (max-width: 768px) {
    .roi-calculator {
        grid-template-columns: 1fr;
    }
    
    .roi-calculator-inputs {
        grid-template-columns: 1fr;
    }
    
    .calculator-result-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Date range selector
    $('#date-range').on('change', function() {
        const range = $(this).val();
        
        if (range === 'custom') {
            $('#custom-range').show();
        } else {
            $('#custom-range').hide();
            loadData(range);
        }
    });
    
    // Apply custom date range
    $('#apply-date-range').on('click', function() {
        const startDate = $('#start-date').val();
        const endDate = $('#end-date').val();
        
        if (!startDate || !endDate) {
            alert('<?php _e('Please select both start and end dates.', 'autonomous-ai-seo'); ?>');
            return;
        }
        
        loadData('custom', startDate, endDate);
    });
    
    // Chart type selector
    $('.chart-period').on('click', function() {
        $('.chart-period').removeClass('active');
        $(this).addClass('active');
        
        updateChartType($(this).data('period'));
    });
    
    // Initialize ROI calculator
    $('#calculate-roi').on('click', calculateROI);
    
    // Initial data load
    loadData(30);
    
    /**
     * Load revenue and ROI data
     */
    function loadData(days, startDate, endDate) {
        // Load revenue data
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_get_revenue_data',
                days: days,
                start_date: startDate,
                end_date: endDate,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    
                    // Update revenue chart
                    createRevenueChart(data);
                    
                    // Update revenue sources
                    createSourcesChart(data.source_breakdown);
                    updateSourcesBreakdown(data.source_breakdown);
                    
                    // Update form conversions
                    createFormsChart(data.form_breakdown);
                    updateFormsBreakdown(data.form_breakdown);
                }
            }
        });
        
        // Load ROI metrics
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_get_roi_metrics',
                days: days,
                start_date: startDate,
                end_date: endDate,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    
                    // Update ROI summary
                    updateROISummary(data);
                    
                    // Update conversion chart
                    createConversionChart(data);
                }
            }
        });
    }
    
    /**
     * Create revenue chart
     */
    function createRevenueChart(data) {
        const ctx = document.getElementById('revenue-chart').getContext('2d');
        
        // Prepare data
        const labels = [];
        const revenueData = [];
        const leadData = [];
        
        // Process revenue data
        const revenueByDate = {};
        data.revenue_data.forEach(item => {
            const date = item.date;
            if (!revenueByDate[date]) {
                revenueByDate[date] = 0;
            }
            revenueByDate[date] += parseFloat(item.revenue);
        });
        
        // Process lead data
        const leadValueByDate = {};
        data.lead_data.forEach(item => {
            const date = item.date;
            if (!leadValueByDate[date]) {
                leadValueByDate[date] = 0;
            }
            leadValueByDate[date] += parseFloat(item.lead_value);
        });
        
        // Create sorted date list
        const dates = Object.keys(revenueByDate).concat(Object.keys(leadValueByDate));
        const uniqueDates = [...new Set(dates)].sort();
        
        // Fill in data arrays
        uniqueDates.forEach(date => {
            labels.push(date);
            revenueData.push(revenueByDate[date] || 0);
            leadData.push(leadValueByDate[date] || 0);
        });
        
        // Destroy existing chart if it exists
        if (window.revenueChart) {
            window.revenueChart.destroy();
        }
        
        // Create new chart
        window.revenueChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Revenue ($)',
                    data: revenueData,
                    backgroundColor: 'rgba(59, 130, 246, 0.8)',
                    borderColor: 'rgba(59, 130, 246, 1)',
                    borderWidth: 1
                }, {
                    label: 'Lead Value ($)',
                    data: leadData,
                    backgroundColor: 'rgba(16, 185, 129, 0.8)',
                    borderColor: 'rgba(16, 185, 129, 1)',
                    borderWidth: 1,
                    hidden: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Amount ($)'
                        },
                        ticks: {
                            callback: function(value) {
                                return '$' + value;
                            }
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Date'
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': $' + context.raw.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
        
        // Save reference to datasets
        window.chartData = {
            labels: labels,
            revenueData: revenueData,
            leadData: leadData
        };
    }
    
    /**
     * Update chart type (revenue, leads, combined)
     */
    function updateChartType(type) {
        if (!window.revenueChart || !window.chartData) {
            return;
        }
        
        const { revenueData, leadData } = window.chartData;
        
        if (type === 'revenue') {
            // Show only revenue
            window.revenueChart.data.datasets[0].hidden = false;
            window.revenueChart.data.datasets[1].hidden = true;
        } else if (type === 'leads') {
            // Show only leads
            window.revenueChart.data.datasets[0].hidden = true;
            window.revenueChart.data.datasets[1].hidden = false;
        } else if (type === 'combined') {
            // Show both
            window.revenueChart.data.datasets[0].hidden = false;
            window.revenueChart.data.datasets[1].hidden = false;
        }
        
        window.revenueChart.update();
    }
    
    /**
     * Create sources chart
     */
    function createSourcesChart(sourceData) {
        const ctx = document.getElementById('sources-chart').getContext('2d');
        
        // Prepare data
        const labels = [];
        const data = [];
        const backgroundColors = [
            'rgba(59, 130, 246, 0.8)', 
            'rgba(16, 185, 129, 0.8)',
            'rgba(245, 158, 11, 0.8)',
            'rgba(239, 68, 68, 0.8)',
            'rgba(139, 92, 246, 0.8)'
        ];
        
        sourceData.forEach((source, index) => {
            labels.push(source.source);
            data.push(parseFloat(source.revenue));
        });
        
        // Destroy existing chart if it exists
        if (window.sourcesChart) {
            window.sourcesChart.destroy();
        }
        
        // Create new chart
        window.sourcesChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: backgroundColors.slice(0, data.length),
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.label + ': $' + context.raw.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
    }
    
    /**
     * Update sources breakdown
     */
    function updateSourcesBreakdown(sourceData) {
        // Create table with source breakdown
        let html = `
            <div class="breakdown-header"><?php _e('Revenue by Source', 'autonomous-ai-seo'); ?></div>
            <table class="breakdown-table">
                <thead>
                    <tr>
                        <th><?php _e('Source', 'autonomous-ai-seo'); ?></th>
                        <th><?php _e('Transactions', 'autonomous-ai-seo'); ?></th>
                        <th><?php _e('Revenue', 'autonomous-ai-seo'); ?></th>
                        <th><?php _e('Percentage', 'autonomous-ai-seo'); ?></th>
                    </tr>
                </thead>
                <tbody>
        `;
        
        // Calculate total
        const total = sourceData.reduce((sum, source) => sum + parseFloat(source.revenue), 0);
        
        // Add each source
        sourceData.forEach(source => {
            const percentage = total > 0 ? ((parseFloat(source.revenue) / total) * 100).toFixed(1) + '%' : '0%';
            
            html += `
                <tr>
                    <td>${source.source}</td>
                    <td>${source.count}</td>
                    <td>$${parseFloat(source.revenue).toFixed(2)}</td>
                    <td>${percentage}</td>
                </tr>
            `;
        });
        
        html += `
                </tbody>
                <tfoot>
                    <tr>
                        <th><?php _e('Total', 'autonomous-ai-seo'); ?></th>
                        <th>${sourceData.reduce((sum, source) => sum + parseInt(source.count), 0)}</th>
                        <th>$${total.toFixed(2)}</th>
                        <th>100%</th>
                    </tr>
                </tfoot>
            </table>
        `;
        
        $('#sources-breakdown').html(html);
    }
    
    /**
     * Create forms chart
     */
    function createFormsChart(formData) {
        const ctx = document.getElementById('forms-chart').getContext('2d');
        
        // Prepare data
        const labels = [];
        const data = [];
        const backgroundColors = [
            'rgba(59, 130, 246, 0.8)', 
            'rgba(16, 185, 129, 0.8)',
            'rgba(245, 158, 11, 0.8)',
            'rgba(239, 68, 68, 0.8)',
            'rgba(139, 92, 246, 0.8)'
        ];
        
        formData.forEach((form, index) => {
            labels.push(form.form_name);
            data.push(parseFloat(form.value));
        });
        
        // Destroy existing chart if it exists
        if (window.formsChart) {
            window.formsChart.destroy();
        }
        
        // Create new chart
        window.formsChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: backgroundColors.slice(0, data.length),
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.label + ': $' + context.raw.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
    }
    
    /**
     * Update forms breakdown
     */
    function updateFormsBreakdown(formData) {
        // Create table with form breakdown
        let html = `
            <div class="breakdown-header"><?php _e('Leads by Form', 'autonomous-ai-seo'); ?></div>
            <table class="breakdown-table">
                <thead>
                    <tr>
                        <th><?php _e('Form', 'autonomous-ai-seo'); ?></th>
                        <th><?php _e('Submissions', 'autonomous-ai-seo'); ?></th>
                        <th><?php _e('Value', 'autonomous-ai-seo'); ?></th>
                        <th><?php _e('Percentage', 'autonomous-ai-seo'); ?></th>
                    </tr>
                </thead>
                <tbody>
        `;
        
        // Calculate total
        const total = formData.reduce((sum, form) => sum + parseFloat(form.value), 0);
        
        // Add each form
        formData.forEach(form => {
            const percentage = total > 0 ? ((parseFloat(form.value) / total) * 100).toFixed(1) + '%' : '0%';
            
            html += `
                <tr>
                    <td>${form.form_name}</td>
                    <td>${form.count}</td>
                    <td>$${parseFloat(form.value).toFixed(2)}</td>
                    <td>${percentage}</td>
                </tr>
            `;
        });
        
        html += `
                </tbody>
                <tfoot>
                    <tr>
                        <th><?php _e('Total', 'autonomous-ai-seo'); ?></th>
                        <th>${formData.reduce((sum, form) => sum + parseInt(form.count), 0)}</th>
                        <th>$${total.toFixed(2)}</th>
                        <th>100%</th>
                    </tr>
                </tfoot>
            </table>
        `;
        
        $('#forms-breakdown').html(html);
    }
    
    /**
     * Create conversion chart
     */
    function createConversionChart(data) {
        const ctx = document.getElementById('conversion-chart').getContext('2d');
        
        // Prepare data
        const conversionRate = parseFloat(data.lead_conversion_rate).toFixed(1);
        
        // Destroy existing chart if it exists
        if (window.conversionChart) {
            window.conversionChart.destroy();
        }
        
        // Create new gauge chart
        window.conversionChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                datasets: [{
                    data: [conversionRate, 100 - conversionRate],
                    backgroundColor: [
                        'rgba(16, 185, 129, 0.8)',
                        'rgba(229, 231, 235, 0.5)'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    tooltip: {
                        enabled: false
                    },
                    legend: {
                        display: false
                    }
                }
            }
        });
        
        // Add center text
        Chart.register({
            id: 'centerText',
            beforeDraw: function(chart) {
                if (chart.config.type === 'doughnut') {
                    const width = chart.width;
                    const height = chart.height;
                    const ctx = chart.ctx;
                    
                    ctx.restore();
                    
                    // Main text
                    const text = conversionRate + '%';
                    ctx.font = 'bold 24px Arial';
                    ctx.textBaseline = 'middle';
                    ctx.textAlign = 'center';
                    ctx.fillStyle = '#1f2937';
                    ctx.fillText(text, width / 2, height / 2);
                    
                    // Subtext
                    const subText = 'Conversion Rate';
                    ctx.font = '12px Arial';
                    ctx.fillStyle = '#6b7280';
                    ctx.fillText(subText, width / 2, height / 2 + 20);
                    
                    ctx.save();
                }
            }
        });
    }
    
    /**
     * Update ROI summary
     */
    function updateROISummary(data) {
        // Get metrics data
        const metrics = data.metrics || {};
        const totalRevenue = metrics.revenue ? parseFloat(metrics.revenue.total) : 0;
        const totalLeadValue = metrics.leads ? parseFloat(metrics.leads.total) : 0;
        const totalCost = parseFloat(data.total_cost);
        
        // Calculate net profit
        const netProfit = totalRevenue - totalCost;
        
        // Format ROI
        const roi = parseFloat(data.roi).toFixed(1);
        $('#roi-value').text(roi + '%');
        
        // Color ROI based on value
        if (roi > 200) {
            $('#roi-value').css('color', '#10b981'); // Green for excellent ROI
        } else if (roi > 100) {
            $('#roi-value').css('color', '#3b82f6'); // Blue for good ROI
        } else if (roi > 0) {
            $('#roi-value').css('color', '#f59e0b'); // Yellow for positive ROI
        } else {
            $('#roi-value').css('color', '#ef4444'); // Red for negative ROI
        }
        
        // Update summary values
        $('#total-revenue').text('$' + totalRevenue.toFixed(2));
        $('#total-cost').text('$' + totalCost.toFixed(2));
        $('#net-profit').text('$' + netProfit.toFixed(2));
        $('#lead-value').text('$' + totalLeadValue.toFixed(2));
        
        // Update traffic value
        $('#revenue-per-visit').text('$' + parseFloat(data.revenue_per_visit).toFixed(2));
        $('#value-per-lead').text('$' + parseFloat(data.value_per_lead).toFixed(2));
        $('#lead-conversion-rate').text(parseFloat(data.lead_conversion_rate).toFixed(2) + '%');
        $('#organic-traffic').text(data.total_traffic.toLocaleString());
    }
    
    /**
     * Calculate ROI from calculator inputs
     */
    function calculateROI() {
        // Get input values
        const currentTraffic = parseInt($('#current-traffic').val());
        const projectedIncrease = parseInt($('#projected-increase').val());
        const conversionRate = parseFloat($('#conversion-rate').val()) / 100; // Convert to decimal
        const averageOrder = parseFloat($('#average-order').val());
        const subscriptionCost = parseFloat($('#subscription-cost').val());
        const timeCost = parseFloat($('#time-cost').val());
        
        // Calculate projected values
        const projectedTraffic = currentTraffic * (1 + (projectedIncrease / 100));
        const trafficIncrease = projectedTraffic - currentTraffic;
        
        // Calculate revenue
        const currentRevenue = currentTraffic * conversionRate * averageOrder;
        const projectedRevenue = projectedTraffic * conversionRate * averageOrder;
        const revenueIncrease = projectedRevenue - currentRevenue;
        
        // Calculate ROI
        const monthlyCost = subscriptionCost + timeCost;
        const roi = (revenueIncrease / monthlyCost) * 100;
        
        // Calculate break-even period
        const breakEven = monthlyCost > 0 ? Math.ceil(monthlyCost / revenueIncrease) : 0;
        
        // Update results
        $('#calc-current-revenue').text('$' + currentRevenue.toFixed(2));
        $('#calc-projected-revenue').text('$' + projectedRevenue.toFixed(2));
        $('#calc-revenue-increase').text('$' + revenueIncrease.toFixed(2));
        $('#calc-monthly-cost').text('$' + monthlyCost.toFixed(2));
        $('#calc-roi').text(roi.toFixed(1) + '%');
        $('#calc-breakeven').text(breakEven + ' months');
    }
});
</script>