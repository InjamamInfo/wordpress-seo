<?php
/**
 * Content Generator template for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aaiseo-dashboard">
    <div class="aaiseo-header">
        <div class="aaiseo-header-content">
            <div class="aaiseo-logo">
                <h1><?php _e('AI Content Generator', 'autonomous-ai-seo'); ?></h1>
                <p><?php _e('Create high-quality, SEO-optimized content powered by AI', 'autonomous-ai-seo'); ?></p>
            </div>
            <div class="aaiseo-status">
                <button class="button button-primary" id="train-brand-voice-btn">
                    <?php _e('Train Brand Voice', 'autonomous-ai-seo'); ?>
                </button>
            </div>
        </div>
    </div>

    <!-- Content Generator Tabs -->
    <div class="aaiseo-tabs">
        <div class="aaiseo-tab-nav">
            <button class="aaiseo-tab-button active" data-tab="article-generator">
                <?php _e('Article Generator', 'autonomous-ai-seo'); ?>
            </button>
            <button class="aaiseo-tab-button" data-tab="product-descriptions">
                <?php _e('Product Descriptions', 'autonomous-ai-seo'); ?>
            </button>
            <button class="aaiseo-tab-button" data-tab="brand-voices">
                <?php _e('Brand Voice Library', 'autonomous-ai-seo'); ?>
            </button>
        </div>
    </div>

    <!-- Article Generator Tab -->
    <div class="aaiseo-tab-content active" id="article-generator">
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Generate Complete Article', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="aaiseo-form-group">
                    <label for="article-title"><?php _e('Article Title', 'autonomous-ai-seo'); ?></label>
                    <input type="text" id="article-title" class="widefat" placeholder="<?php _e('e.g., 10 Effective Ways to Improve Your Website\'s SEO', 'autonomous-ai-seo'); ?>">
                </div>

                <div class="aaiseo-form-group">
                    <label for="article-keywords"><?php _e('Target Keywords (comma separated)', 'autonomous-ai-seo'); ?></label>
                    <input type="text" id="article-keywords" class="widefat" placeholder="<?php _e('e.g., SEO tips, improve website SEO, search engine optimization', 'autonomous-ai-seo'); ?>">
                </div>
                
                <div class="aaiseo-form-row">
                    <div class="aaiseo-form-group">
                        <label for="article-length"><?php _e('Article Length (words)', 'autonomous-ai-seo'); ?></label>
                        <select id="article-length" class="widefat">
                            <option value="500"><?php _e('Short (500 words)', 'autonomous-ai-seo'); ?></option>
                            <option value="1000"><?php _e('Medium (1000 words)', 'autonomous-ai-seo'); ?></option>
                            <option value="1500" selected><?php _e('Standard (1500 words)', 'autonomous-ai-seo'); ?></option>
                            <option value="2000"><?php _e('Long (2000 words)', 'autonomous-ai-seo'); ?></option>
                            <option value="3000"><?php _e('Comprehensive (3000 words)', 'autonomous-ai-seo'); ?></option>
                        </select>
                    </div>

                    <div class="aaiseo-form-group">
                        <label for="article-voice"><?php _e('Brand Voice', 'autonomous-ai-seo'); ?></label>
                        <select id="article-voice" class="widefat">
                            <option value="default"><?php _e('Default', 'autonomous-ai-seo'); ?></option>
                            <?php
                            // Get brand voices
                            $voices = get_option('aaiseo_brand_voices', array());
                            foreach ($voices as $key => $voice) {
                                echo '<option value="' . esc_attr($key) . '">' . esc_html($voice['name']) . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <div class="aaiseo-form-actions">
                    <button class="button button-primary button-large" id="generate-article">
                        <?php _e('Generate Article', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Generated Content -->
        <div class="aaiseo-panel" id="generated-content-panel" style="display: none;">
            <div class="panel-header">
                <h2><?php _e('Generated Content', 'autonomous-ai-seo'); ?></h2>
                <div class="content-info">
                    <span id="content-word-count">0 words</span>
                </div>
            </div>
            <div class="panel-content">
                <div class="content-loading" style="display: none;">
                    <span class="spinner is-active"></span>
                    <span class="loading-text"><?php _e('Generating high-quality content. This may take a minute...', 'autonomous-ai-seo'); ?></span>
                </div>
                
                <div id="generated-content"></div>
                
                <div class="aaiseo-form-actions content-actions" style="display: none;">
                    <button class="button button-primary" id="use-content">
                        <?php _e('Create New Post', 'autonomous-ai-seo'); ?>
                    </button>
                    <button class="button button-secondary" id="copy-content">
                        <?php _e('Copy to Clipboard', 'autonomous-ai-seo'); ?>
                    </button>
                    <button class="button button-secondary" id="check-quality">
                        <?php _e('Check Quality', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Quality Check Results -->
        <div class="aaiseo-panel" id="quality-check-panel" style="display: none;">
            <div class="panel-header">
                <h2><?php _e('Content Quality Analysis', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="quality-loading" style="display: none;">
                    <span class="spinner is-active"></span>
                    <span><?php _e('Analyzing content quality...', 'autonomous-ai-seo'); ?></span>
                </div>
                
                <div id="quality-results"></div>
            </div>
        </div>
    </div>

    <!-- Product Descriptions Tab -->
    <div class="aaiseo-tab-content" id="product-descriptions">
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Generate Product Descriptions', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="aaiseo-form-group">
                    <label for="product-name"><?php _e('Product Name', 'autonomous-ai-seo'); ?></label>
                    <input type="text" id="product-name" class="widefat" placeholder="<?php _e('e.g., Premium Ergonomic Office Chair', 'autonomous-ai-seo'); ?>">
                </div>

                <div class="aaiseo-form-group">
                    <label for="product-features"><?php _e('Key Features (one per line)', 'autonomous-ai-seo'); ?></label>
                    <textarea id="product-features" class="widefat" rows="5" placeholder="<?php _e('e.g., Adjustable lumbar support&#10;Breathable mesh back&#10;360-degree swivel&#10;5-year warranty', 'autonomous-ai-seo'); ?>"></textarea>
                </div>
                
                <div class="aaiseo-form-group">
                    <label for="product-audience"><?php _e('Target Audience', 'autonomous-ai-seo'); ?></label>
                    <input type="text" id="product-audience" class="widefat" placeholder="<?php _e('e.g., Office professionals who work long hours', 'autonomous-ai-seo'); ?>">
                </div>

                <div class="aaiseo-form-group">
                    <label for="product-voice"><?php _e('Brand Voice', 'autonomous-ai-seo'); ?></label>
                    <select id="product-voice" class="widefat">
                        <option value="default"><?php _e('Default', 'autonomous-ai-seo'); ?></option>
                        <?php
                        // Get brand voices
                        $voices = get_option('aaiseo_brand_voices', array());
                        foreach ($voices as $key => $voice) {
                            echo '<option value="' . esc_attr($key) . '">' . esc_html($voice['name']) . '</option>';
                        }
                        ?>
                    </select>
                </div>

                <div class="aaiseo-form-actions">
                    <button class="button button-primary button-large" id="generate-product-description">
                        <?php _e('Generate Description', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Generated Product Description -->
        <div class="aaiseo-panel" id="generated-product-panel" style="display: none;">
            <div class="panel-header">
                <h2><?php _e('Generated Product Description', 'autonomous-ai-seo'); ?></h2>
                <div class="content-info">
                    <span id="product-word-count">0 words</span>
                </div>
            </div>
            <div class="panel-content">
                <div class="product-loading" style="display: none;">
                    <span class="spinner is-active"></span>
                    <span><?php _e('Crafting compelling product description...', 'autonomous-ai-seo'); ?></span>
                </div>
                
                <div id="generated-product-content"></div>
                
                <div class="aaiseo-form-actions product-actions" style="display: none;">
                    <button class="button button-primary" id="use-product-content">
                        <?php _e('Create Product', 'autonomous-ai-seo'); ?>
                    </button>
                    <button class="button button-secondary" id="copy-product-content">
                        <?php _e('Copy to Clipboard', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Brand Voice Library Tab -->
    <div class="aaiseo-tab-content" id="brand-voices">
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Brand Voice Library', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <p class="description">
                    <?php _e('Train your AI content generator to match your brand\'s unique voice and tone. Create and save multiple brand voices for different content types or audiences.', 'autonomous-ai-seo'); ?>
                </p>
                
                <div class="brand-voices-list">
                    <?php
                    $voices = get_option('aaiseo_brand_voices', array());
                    if (!empty($voices)):
                    ?>
                        <table class="widefat striped">
                            <thead>
                                <tr>
                                    <th><?php _e('Voice Name', 'autonomous-ai-seo'); ?></th>
                                    <th><?php _e('Tone', 'autonomous-ai-seo'); ?></th>
                                    <th><?php _e('Style', 'autonomous-ai-seo'); ?></th>
                                    <th><?php _e('Writing Level', 'autonomous-ai-seo'); ?></th>
                                    <th><?php _e('Actions', 'autonomous-ai-seo'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($voices as $key => $voice): ?>
                                <tr>
                                    <td><?php echo esc_html($voice['name']); ?></td>
                                    <td><?php echo esc_html($voice['tone']); ?></td>
                                    <td><?php echo esc_html($voice['style']); ?></td>
                                    <td><?php echo esc_html($voice['writing_level']); ?></td>
                                    <td>
                                        <button class="button button-small edit-voice" data-key="<?php echo esc_attr($key); ?>">
                                            <?php _e('Edit', 'autonomous-ai-seo'); ?>
                                        </button>
                                        <button class="button button-small delete-voice" data-key="<?php echo esc_attr($key); ?>">
                                            <?php _e('Delete', 'autonomous-ai-seo'); ?>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p><?php _e('No brand voices defined yet. Click "Train Brand Voice" to create your first voice.', 'autonomous-ai-seo'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Brand Voice Training Modal -->
    <div id="brand-voice-modal" class="aaiseo-modal">
        <div class="aaiseo-modal-content">
            <div class="aaiseo-modal-header">
                <h2><?php _e('Train Brand Voice', 'autonomous-ai-seo'); ?></h2>
                <span class="aaiseo-modal-close">&times;</span>
            </div>
            <div class="aaiseo-modal-body">
                <p><?php _e('Train the AI to understand and emulate your brand\'s voice by providing a sample of your existing content.', 'autonomous-ai-seo'); ?></p>
                
                <div class="aaiseo-form-group">
                    <label for="voice-name"><?php _e('Voice Name', 'autonomous-ai-seo'); ?></label>
                    <input type="text" id="voice-name" class="widefat" placeholder="<?php _e('e.g., Professional Blog', 'autonomous-ai-seo'); ?>">
                </div>
                
                <div class="aaiseo-form-group">
                    <label for="example-content"><?php _e('Example Content (min. 300 words)', 'autonomous-ai-seo'); ?></label>
                    <textarea id="example-content" class="widefat" rows="10" placeholder="<?php _e('Paste a high-quality example of content written in your brand\'s voice...', 'autonomous-ai-seo'); ?>"></textarea>
                </div>
                
                <div class="voice-analysis-results" style="display: none;">
                    <h3><?php _e('Voice Analysis Results', 'autonomous-ai-seo'); ?></h3>
                    <div id="voice-analysis-content"></div>
                </div>
            </div>
            <div class="aaiseo-modal-footer">
                <button class="button button-secondary" id="cancel-voice-training">
                    <?php _e('Cancel', 'autonomous-ai-seo'); ?>
                </button>
                <button class="button button-primary" id="analyze-voice">
                    <?php _e('Analyze Voice', 'autonomous-ai-seo'); ?>
                </button>
                <button class="button button-primary" id="save-voice" style="display: none;">
                    <?php _e('Save Voice', 'autonomous-ai-seo'); ?>
                </button>
            </div>
        </div>
    </div>
</div>

<style>
.aaiseo-form-row {
    display: flex;
    gap: 20px;
}

.aaiseo-form-row .aaiseo-form-group {
    flex: 1;
}

.aaiseo-form-actions {
    margin-top: 20px;
    display: flex;
    gap: 10px;
}

.aaiseo-modal {
    display: none;
    position: fixed;
    z-index: 100000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    overflow: auto;
}

.aaiseo-modal-content {
    background-color: #fff;
    margin: 5% auto;
    padding: 0;
    border-radius: 8px;
    max-width: 800px;
    width: 90%;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.aaiseo-modal-header {
    padding: 20px 25px;
    border-bottom: 1px solid #e5e7eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.aaiseo-modal-header h2 {
    margin: 0;
    font-size: 20px;
    color: #1f2937;
}

.aaiseo-modal-body {
    padding: 25px;
}

.aaiseo-modal-footer {
    padding: 15px 25px;
    border-top: 1px solid #e5e7eb;
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

.aaiseo-modal-close {
    cursor: pointer;
    font-size: 24px;
    font-weight: 600;
    color: #9ca3af;
}

.content-info {
    background: #f3f4f6;
    padding: 5px 10px;
    border-radius: 4px;
    font-size: 12px;
}

#generated-content {
    max-height: 600px;
    overflow-y: auto;
    padding: 10px;
    background: #f9fafb;
    border-radius: 4px;
    margin-bottom: 20px;
    border: 1px solid #e5e7eb;
}

.voice-analysis-results {
    background: #f0f9ff;
    border: 1px solid #bae6fd;
    border-radius: 8px;
    padding: 15px;
    margin-top: 20px;
}

#voice-analysis-content {
    margin-top: 15px;
}

#voice-analysis-content dl {
    display: grid;
    grid-template-columns: 150px 1fr;
    gap: 10px;
    margin: 0;
}

#voice-analysis-content dt {
    font-weight: 600;
    color: #1f2937;
}

#voice-analysis-content dd {
    margin: 0;
    color: #4b5563;
}

.quality-score-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-bottom: 20px;
}

.quality-score-card {
    background: #f9fafb;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    padding: 15px;
    text-align: center;
}

.score-title {
    font-size: 14px;
    color: #6b7280;
    margin-bottom: 5px;
}

.score-value {
    font-size: 24px;
    font-weight: 600;
    color: #1f2937;
}

.quality-section {
    margin-top: 20px;
}

.quality-section h3 {
    margin: 0 0 15px 0;
    font-size: 16px;
    color: #1f2937;
    padding-bottom: 5px;
    border-bottom: 1px solid #e5e7eb;
}

.quality-list {
    margin: 0;
    padding-left: 20px;
}

.quality-list li {
    margin-bottom: 8px;
}

@media (max-width: 768px) {
    .aaiseo-form-row {
        flex-direction: column;
        gap: 0;
    }
    
    .quality-score-grid {
        grid-template-columns: 1fr 1fr;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Tab functionality
    $('.aaiseo-tab-button').on('click', function() {
        const tabId = $(this).data('tab');
        
        // Update active tab button
        $('.aaiseo-tab-button').removeClass('active');
        $(this).addClass('active');
        
        // Update active tab content
        $('.aaiseo-tab-content').removeClass('active');
        $('#' + tabId).addClass('active');
    });
    
    // Train Brand Voice button
    $('#train-brand-voice-btn').on('click', function() {
        $('#brand-voice-modal').show();
    });
    
    // Close modal
    $('.aaiseo-modal-close, #cancel-voice-training').on('click', function() {
        $('#brand-voice-modal').hide();
        resetVoiceModal();
    });
    
    // Close on outside click
    $(window).on('click', function(event) {
        if ($(event.target).hasClass('aaiseo-modal')) {
            $('.aaiseo-modal').hide();
            resetVoiceModal();
        }
    });
    
    // Reset voice modal
    function resetVoiceModal() {
        $('#voice-name').val('');
        $('#example-content').val('');
        $('.voice-analysis-results').hide();
        $('#analyze-voice').show();
        $('#save-voice').hide();
        $('#voice-analysis-content').empty();
    }
    
    // Analyze voice button
    $('#analyze-voice').on('click', function() {
        const voiceName = $('#voice-name').val();
        const exampleContent = $('#example-content').val();
        
        if (!voiceName) {
            alert('<?php _e('Please enter a name for the brand voice.', 'autonomous-ai-seo'); ?>');
            return;
        }
        
        if (!exampleContent || exampleContent.split(' ').length < 100) {
            alert('<?php _e('Please enter at least 300 words of example content.', 'autonomous-ai-seo'); ?>');
            return;
        }
        
        const button = $(this);
        const originalText = button.text();
        button.prop('disabled', true).text('<?php _e('Analyzing...', 'autonomous-ai-seo'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_train_brand_voice',
                voice_name: voiceName,
                example_content: exampleContent,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    const voice = response.data.voice;
                    let analysisHtml = '<dl>';
                    
                    analysisHtml += `<dt><?php _e('Detected Tone:', 'autonomous-ai-seo'); ?></dt><dd>${voice.tone}</dd>`;
                    analysisHtml += `<dt><?php _e('Writing Style:', 'autonomous-ai-seo'); ?></dt><dd>${voice.style}</dd>`;
                    analysisHtml += `<dt><?php _e('Writing Level:', 'autonomous-ai-seo'); ?></dt><dd>${voice.writing_level}</dd>`;
                    
                    analysisHtml += '</dl>';
                    
                    $('#voice-analysis-content').html(analysisHtml);
                    $('.voice-analysis-results').show();
                    $('#analyze-voice').hide();
                    $('#save-voice').show();
                } else {
                    alert(response.data);
                }
            },
            error: function() {
                alert('<?php _e('Error analyzing voice. Please try again.', 'autonomous-ai-seo'); ?>');
            },
            complete: function() {
                button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    // Save voice button
    $('#save-voice').on('click', function() {
        const voiceName = $('#voice-name').val();
        const exampleContent = $('#example-content').val();
        
        if (!voiceName || !exampleContent) {
            alert('<?php _e('Please enter all required fields.', 'autonomous-ai-seo'); ?>');
            return;
        }
        
        const button = $(this);
        const originalText = button.text();
        button.prop('disabled', true).text('<?php _e('Saving...', 'autonomous-ai-seo'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_train_brand_voice',
                voice_name: voiceName,
                example_content: exampleContent,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('<?php _e('Brand voice saved successfully! Refreshing page...', 'autonomous-ai-seo'); ?>');
                    location.reload();
                } else {
                    alert(response.data);
                }
            },
            error: function() {
                alert('<?php _e('Error saving brand voice. Please try again.', 'autonomous-ai-seo'); ?>');
            },
            complete: function() {
                button.prop('disabled', false).text(originalText);
                $('#brand-voice-modal').hide();
            }
        });
    });
    
    // Generate article button
    $('#generate-article').on('click', function() {
        const title = $('#article-title').val();
        const keywords = $('#article-keywords').val();
        const length = $('#article-length').val();
        const voiceStyle = $('#article-voice').val();
        
        if (!title) {
            alert('<?php _e('Please enter an article title.', 'autonomous-ai-seo'); ?>');
            return;
        }
        
        $('#generated-content-panel').show();
        $('#generated-content').hide();
        $('.content-loading').show();
        $('.content-actions').hide();
        
        const button = $(this);
        const originalText = button.text();
        button.prop('disabled', true).text('<?php _e('Generating...', 'autonomous-ai-seo'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_generate_article',
                operation: 'generate_full',
                title: title,
                keywords: keywords,
                length: length,
                voice_style: voiceStyle,
                nonce: '<?php echo wp_create_nonce('aaiseo_content_nonce'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    $('#generated-content').html(response.data.content).show();
                    $('#content-word-count').text(response.data.word_count + ' words');
                    $('.content-actions').show();
                } else {
                    alert(response.data.message || '<?php _e('Error generating article.', 'autonomous-ai-seo'); ?>');
                }
            },
            error: function() {
                alert('<?php _e('Error communicating with the server.', 'autonomous-ai-seo'); ?>');
            },
            complete: function() {
                $('.content-loading').hide();
                button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    // Create new post button
    $('#use-content').on('click', function() {
        const title = $('#article-title').val();
        const content = $('#generated-content').html();
        
        if (!content) {
            alert('<?php _e('No content to use.', 'autonomous-ai-seo'); ?>');
            return;
        }
        
        const button = $(this);
        const originalText = button.text();
        button.prop('disabled', true).text('<?php _e('Creating post...', 'autonomous-ai-seo'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_create_post',
                title: title,
                content: content,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('<?php _e('Post created successfully!', 'autonomous-ai-seo'); ?>');
                    window.location.href = response.data.edit_url;
                } else {
                    alert(response.data || '<?php _e('Error creating post.', 'autonomous-ai-seo'); ?>');
                }
            },
            error: function() {
                alert('<?php _e('Error communicating with the server.', 'autonomous-ai-seo'); ?>');
            },
            complete: function() {
                button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    // Copy to clipboard button
    $('#copy-content').on('click', function() {
        const content = $('#generated-content').text();
        
        if (!content) {
            alert('<?php _e('No content to copy.', 'autonomous-ai-seo'); ?>');
            return;
        }
        
        // Create temporary textarea to copy from
        const textarea = document.createElement('textarea');
        textarea.value = content;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        
        alert('<?php _e('Content copied to clipboard!', 'autonomous-ai-seo'); ?>');
    });
    
    // Check quality button
    $('#check-quality').on('click', function() {
        const content = $('#generated-content').html();
        
        if (!content) {
            alert('<?php _e('No content to check.', 'autonomous-ai-seo'); ?>');
            return;
        }
        
        $('#quality-check-panel').show();
        $('#quality-results').hide();
        $('.quality-loading').show();
        
        const button = $(this);
        const originalText = button.text();
        button.prop('disabled', true).text('<?php _e('Checking...', 'autonomous-ai-seo'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_check_content_quality',
                content: content,
                nonce: '<?php echo wp_create_nonce('aaiseo_content_nonce'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    displayQualityResults(response.data);
                } else {
                    alert(response.data.message || '<?php _e('Error checking content quality.', 'autonomous-ai-seo'); ?>');
                }
            },
            error: function() {
                alert('<?php _e('Error communicating with the server.', 'autonomous-ai-seo'); ?>');
            },
            complete: function() {
                $('.quality-loading').hide();
                button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    // Display quality check results
    function displayQualityResults(data) {
        let html = `
            <div class="quality-score-grid">
                <div class="quality-score-card">
                    <div class="score-title"><?php _e('Overall Quality', 'autonomous-ai-seo'); ?></div>
                    <div class="score-value">${data.overall_quality_score || data.quality_score || 0}/100</div>
                </div>
                
                <div class="quality-score-card">
                    <div class="score-title"><?php _e('Readability', 'autonomous-ai-seo'); ?></div>
                    <div class="score-value">${data.readability_score || 0}/100</div>
                </div>
                
                <div class="quality-score-card">
                    <div class="score-title"><?php _e('SEO Score', 'autonomous-ai-seo'); ?></div>
                    <div class="score-value">${data.seo_score || 0}/100</div>
                </div>
                
                <div class="quality-score-card">
                    <div class="score-title"><?php _e('Reading Time', 'autonomous-ai-seo'); ?></div>
                    <div class="score-value">${data.estimated_reading_time || 5} min</div>
                </div>
            </div>
        `;
        
        // Add strengths section if available
        if (data.content_strengths || data.strengths) {
            const strengths = data.content_strengths || data.strengths || [];
            html += `
                <div class="quality-section">
                    <h3><?php _e('Content Strengths', 'autonomous-ai-seo'); ?></h3>
                    <ul class="quality-list">
                        ${strengths.map(strength => `<li>${strength}</li>`).join('')}
                    </ul>
                </div>
            `;
        }
        
        // Add improvements section if available
        if (data.areas_for_improvement || data.improvements) {
            const improvements = data.areas_for_improvement || data.improvements || [];
            html += `
                <div class="quality-section">
                    <h3><?php _e('Areas for Improvement', 'autonomous-ai-seo'); ?></h3>
                    <ul class="quality-list">
                        ${improvements.map(improvement => `<li>${improvement}</li>`).join('')}
                    </ul>
                </div>
            `;
        }
        
        // Add keyword analysis if available
        if (data.keyword_analysis) {
            html += `
                <div class="quality-section">
                    <h3><?php _e('Keyword Analysis', 'autonomous-ai-seo'); ?></h3>
                    <ul class="quality-list">
                        ${data.keyword_analysis.map(keyword => `<li>${keyword}</li>`).join('')}
                    </ul>
                </div>
            `;
        }
        
        // Add recommendations if available
        if (data.recommendations) {
            html += `
                <div class="quality-section">
                    <h3><?php _e('Recommendations', 'autonomous-ai-seo'); ?></h3>
                    <ul class="quality-list">
                        ${data.recommendations.map(rec => `<li>${rec}</li>`).join('')}
                    </ul>
                </div>
            `;
        }
        
        $('#quality-results').html(html).show();
    }
    
    // Generate product description
    $('#generate-product-description').on('click', function() {
        const productName = $('#product-name').val();
        const productFeatures = $('#product-features').val();
        const productAudience = $('#product-audience').val();
        const voiceStyle = $('#product-voice').val();
        
        if (!productName) {
            alert('<?php _e('Please enter a product name.', 'autonomous-ai-seo'); ?>');
            return;
        }
        
        $('#generated-product-panel').show();
        $('#generated-product-content').hide();
        $('.product-loading').show();
        $('.product-actions').hide();
        
        const button = $(this);
        const originalText = button.text();
        button.prop('disabled', true).text('<?php _e('Generating...', 'autonomous-ai-seo'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_generate_product_description',
                product_name: productName,
                features: productFeatures,
                target_audience: productAudience,
                voice_style: voiceStyle,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#generated-product-content').html(response.data.content).show();
                    $('#product-word-count').text(response.data.word_count + ' words');
                    $('.product-actions').show();
                } else {
                    alert(response.data || '<?php _e('Error generating product description.', 'autonomous-ai-seo'); ?>');
                }
            },
            error: function() {
                alert('<?php _e('Error communicating with the server.', 'autonomous-ai-seo'); ?>');
            },
            complete: function() {
                $('.product-loading').hide();
                button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    // Copy product description to clipboard
    $('#copy-product-content').on('click', function() {
        const content = $('#generated-product-content').text();
        
        if (!content) {
            alert('<?php _e('No content to copy.', 'autonomous-ai-seo'); ?>');
            return;
        }
        
        // Create temporary textarea to copy from
        const textarea = document.createElement('textarea');
        textarea.value = content;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        
        alert('<?php _e('Product description copied to clipboard!', 'autonomous-ai-seo'); ?>');
    });
    
    // Create product button
    $('#use-product-content').on('click', function() {
        // Check if WooCommerce is active
        if (typeof woocommerce_admin === 'undefined') {
            alert('<?php _e('WooCommerce is not active or not detected. Please copy the content manually.', 'autonomous-ai-seo'); ?>');
            return;
        }
        
        const productName = $('#product-name').val();
        const content = $('#generated-product-content').html();
        
        if (!content) {
            alert('<?php _e('No content to use.', 'autonomous-ai-seo'); ?>');
            return;
        }
        
        const button = $(this);
        const originalText = button.text();
        button.prop('disabled', true).text('<?php _e('Creating product...', 'autonomous-ai-seo'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_create_product',
                product_name: productName,
                description: content,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('<?php _e('Product created successfully!', 'autonomous-ai-seo'); ?>');
                    window.location.href = response.data.edit_url;
                } else {
                    alert(response.data || '<?php _e('Error creating product.', 'autonomous-ai-seo'); ?>');
                }
            },
            error: function() {
                alert('<?php _e('Error communicating with the server.', 'autonomous-ai-seo'); ?>');
            },
            complete: function() {
                button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    // Edit voice button
    $('.edit-voice').on('click', function() {
        const key = $(this).data('key');
        
        // Load voice data and open modal
        // This would typically fetch the voice data from the server
        alert('Edit voice functionality would be implemented here.');
    });
    
    // Delete voice button
    $('.delete-voice').on('click', function() {
        const key = $(this).data('key');
        
        if (confirm('<?php _e('Are you sure you want to delete this brand voice?', 'autonomous-ai-seo'); ?>')) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'aaiseo_delete_brand_voice',
                    voice_key: key,
                    nonce: aaiseo_admin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        alert('<?php _e('Brand voice deleted successfully.', 'autonomous-ai-seo'); ?>');
                        location.reload();
                    } else {
                        alert(response.data || '<?php _e('Error deleting brand voice.', 'autonomous-ai-seo'); ?>');
                    }
                },
                error: function() {
                    alert('<?php _e('Error communicating with the server.', 'autonomous-ai-seo'); ?>');
                }
            });
        }
    });
});
</script>