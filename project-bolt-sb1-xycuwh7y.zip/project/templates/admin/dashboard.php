<?php
/**
 * Dashboard template for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aaiseo-dashboard">
    <div class="aaiseo-header">
        <div class="aaiseo-header-content">
            <div class="aaiseo-logo">
                <h1><?php _e('Autonomous AI SEO Dashboard', 'autonomous-ai-seo'); ?></h1>
                <p><?php _e('AI-powered optimization running in the background', 'autonomous-ai-seo'); ?></p>
            </div>
            <div class="aaiseo-status">
                <div class="aaiseo-status-indicator active">
                    <span class="status-dot"></span>
                    <?php _e('AI Active', 'autonomous-ai-seo'); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="aaiseo-metrics-grid">
        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-chart-line"></span>
            </div>
            <div class="metric-content">
                <h3><?php echo number_format($dashboard_data['metrics']['organic_traffic'] ?? 0); ?></h3>
                <p><?php _e('Organic Traffic', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">+12.5%</span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-search"></span>
            </div>
            <div class="metric-content">
                <h3><?php echo number_format($dashboard_data['keyword_rankings'] ? count($dashboard_data['keyword_rankings']) : 0); ?></h3>
                <p><?php _e('Keywords Ranking', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">+8.2%</span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-visibility"></span>
            </div>
            <div class="metric-content">
                <h3><?php echo number_format($dashboard_data['metrics']['page_views'] ?? 0); ?></h3>
                <p><?php _e('Page Views', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change negative">-2.1%</span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-awards"></span>
            </div>
            <div class="metric-content">
                <h3><?php echo $dashboard_data['seo_score']['overall'] ?? 0; ?>%</h3>
                <p><?php _e('SEO Score', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">+15.3%</span>
            </div>
        </div>
    </div>

    <div class="aaiseo-dashboard-grid">
        <div class="aaiseo-panel aaiseo-seo-score">
            <div class="panel-header">
                <h2><?php _e('Overall SEO Score', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="seo-score-circle">
                    <div class="score-display">
                        <span class="score-number"><?php echo $dashboard_data['seo_score']['overall'] ?? 87; ?></span>
                        <span class="score-label"><?php _e('Good', 'autonomous-ai-seo'); ?></span>
                    </div>
                </div>
                <div class="score-breakdown">
                    <div class="score-item">
                        <span class="score-category"><?php _e('Technical SEO', 'autonomous-ai-seo'); ?></span>
                        <span class="score-value"><?php echo $dashboard_data['seo_score']['breakdown']['technical'] ?? 92; ?>%</span>
                    </div>
                    <div class="score-item">
                        <span class="score-category"><?php _e('Content Quality', 'autonomous-ai-seo'); ?></span>
                        <span class="score-value"><?php echo $dashboard_data['seo_score']['breakdown']['content'] ?? 78; ?>%</span>
                    </div>
                    <div class="score-item">
                        <span class="score-category"><?php _e('User Experience', 'autonomous-ai-seo'); ?></span>
                        <span class="score-value"><?php echo $dashboard_data['seo_score']['breakdown']['user_experience'] ?? 91; ?>%</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="aaiseo-panel aaiseo-activities">
            <div class="panel-header">
                <button class="quick-action-btn" id="view-ab-tests">
                    <span class="dashicons dashicons-randomize"></span>
                    <span><?php _e('A/B Tests', 'autonomous-ai-seo'); ?></span>
                </button>
                <button class="quick-action-btn" id="generate-report" style="display:none;">
                <button class="button button-secondary" id="refresh-activities">
                    <?php _e('Refresh', 'autonomous-ai-seo'); ?>
                </button>
            </div>
            <div class="panel-content">
                <div class="activities-list">
                    <?php if (!empty($activity_log)): ?>
                        <?php foreach ($activity_log as $activity): ?>
                            <div class="activity-item">
                                <div class="activity-icon">
                                    <span class="status-dot <?php echo $this->getActivityStatusClass($activity['activity_type']); ?>"></span>
                                </div>
                                <div class="activity-content">
                                    <p class="activity-description"><?php echo esc_html($activity['description']); ?></p>
                                    <span class="activity-time"><?php echo human_time_diff(strtotime($activity['created_at'])); ?> <?php _e('ago', 'autonomous-ai-seo'); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="no-activities"><?php _e('No recent activities', 'autonomous-ai-seo'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="aaiseo-panel aaiseo-traffic-chart">
        <div class="panel-header">
            <h2><?php _e('Traffic Trends & AI Predictions', 'autonomous-ai-seo'); ?></h2>
            <div class="chart-controls">
                <button class="button chart-period active" data-period="7d">7D</button>
                <button class="button chart-period" data-period="30d">30D</button>
                <button class="button chart-period" data-period="90d">90D</button>
            </div>
        </div>
        <div class="panel-content">
            <div class="chart-container">
                <canvas id="traffic-chart" width="800" height="300"></canvas>
            </div>
            <div class="chart-legend">
                <div class="legend-item">
                    <span class="legend-color actual"></span>
                    <span><?php _e('Actual Traffic', 'autonomous-ai-seo'); ?></span>
                </div>
                <div class="legend-item">
                    <span class="legend-color predicted"></span>
                    <span><?php _e('AI Predictions', 'autonomous-ai-seo'); ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="aaiseo-dashboard-grid">
        <div class="aaiseo-panel aaiseo-quick-actions">
            <div class="panel-header">
                <h2><?php _e('Quick Actions', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="quick-actions-grid">
                    <button class="quick-action-btn" id="run-optimization">
                        <span class="dashicons dashicons-performance"></span>
                        <span><?php _e('Run AI Optimization', 'autonomous-ai-seo'); ?></span>
                    </button>
                    <button class="quick-action-btn" id="analyze-competitors">
                        <span class="dashicons dashicons-chart-bar"></span>
                        <span><?php _e('Analyze Competitors', 'autonomous-ai-seo'); ?></span>
                    </button>
                    <button class="quick-action-btn" id="technical-audit">
                        <span class="dashicons dashicons-admin-tools"></span>
                        <span><?php _e('Technical Audit', 'autonomous-ai-seo'); ?></span>
                    </button>
                    <button class="quick-action-btn" id="generate-report">
                        <span class="dashicons dashicons-media-document"></span>
                        <span><?php _e('Generate Report', 'autonomous-ai-seo'); ?></span>
                    </button>
                </div>
            </div>
        </div>

        <div class="aaiseo-panel aaiseo-top-keywords">
            <div class="panel-header">
                <h2><?php _e('Top Performing Keywords', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="keywords-table">
                    <?php if (!empty($dashboard_data['keyword_rankings'])): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th><?php _e('Keyword', 'autonomous-ai-seo'); ?></th>
                                    <th><?php _e('Position', 'autonomous-ai-seo'); ?></th>
                                    <th><?php _e('Change', 'autonomous-ai-seo'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($dashboard_data['keyword_rankings'], 0, 5) as $keyword): ?>
                                    <tr>
                                        <td><?php echo esc_html($keyword['keyword']); ?></td>
                                        <td><?php echo intval($keyword['current_position']); ?></td>
                                        <td>
                                            <span class="position-change positive">+2</span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="no-data"><?php _e('No keyword data available', 'autonomous-ai-seo'); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Initialize dashboard functionality
    initializeDashboard();
    
    function initializeDashboard() {
        // Quick action handlers
        $('#run-optimization').on('click', function() {
            runOptimization();
        });
        
        $('#analyze-competitors').on('click', function() {
            window.location.href = '<?php echo admin_url('admin.php?page=aaiseo-competitive'); ?>';
        });
        
        $('#technical-audit').on('click', function() {
            window.location.href = '<?php echo admin_url('admin.php?page=aaiseo-technical'); ?>';
        });

        $('#view-ab-tests').on('click', function() {
            window.location.href = '<?php echo admin_url('admin.php?page=aaiseo-optimization&tab=ab-tests'); ?>';
        });
        
        $('#generate-report').on('click', function() {
            generateReport();
        });
        
        // Refresh activities
        $('#refresh-activities').on('click', function() {
            refreshActivities();
        });
        
        // Chart period controls
        $('.chart-period').on('click', function() {
            $('.chart-period').removeClass('active');
            $(this).addClass('active');
            updateChart($(this).data('period'));
        });
        
        // Initialize traffic chart
        initializeTrafficChart();
    }
    
    function runOptimization() {
        const button = $('#run-optimization');
        button.prop('disabled', true).html('<span class="spinner is-active"></span> Running...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_run_optimization',
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data);
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', '<?php _e('An error occurred', 'autonomous-ai-seo'); ?>');
            },
            complete: function() {
                button.prop('disabled', false).html('<span class="dashicons dashicons-performance"></span><span><?php _e('Run AI Optimization', 'autonomous-ai-seo'); ?></span>');
            }
        });
    }
    
    function generateReport() {
        window.open('<?php echo admin_url('admin.php?page=aaiseo-analytics'); ?>', '_blank');
    }
    
    function refreshActivities() {
        location.reload();
    }
    
    function initializeTrafficChart() {
        // This would initialize a chart library like Chart.js
        // For now, just show a placeholder
        const canvas = document.getElementById('traffic-chart');
        if (canvas) {
            const ctx = canvas.getContext('2d');
            ctx.fillStyle = '#f0f0f0';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#666';
            ctx.font = '16px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('Traffic Chart Placeholder', canvas.width / 2, canvas.height / 2);
        }
    }
    
    function updateChart(period) {
        // Update chart based on selected period
        console.log('Updating chart for period:', period);
    }
    
    function showNotice(type, message) {
        const notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
        $('.wrap').prepend(notice);
        
        setTimeout(function() {
            notice.fadeOut();
        }, 5000);
    }
});
</script>

<?php
// Helper method for activity status classes
function getActivityStatusClass($activity_type) {
    $status_classes = array(
        'content_analysis' => 'completed',
        'autonomous_optimization' => 'completed',
        'competitor_change' => 'attention',
        'technical_audit' => 'completed'
    );
    
    return isset($status_classes[$activity_type]) ? $status_classes[$activity_type] : 'pending';
}
?>