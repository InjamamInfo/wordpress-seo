<?php
/**
 * Competitive Intelligence template for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aaiseo-dashboard">
    <div class="aaiseo-header">
        <div class="aaiseo-header-content">
            <div class="aaiseo-logo">
                <h1><?php _e('Competitive Intelligence', 'autonomous-ai-seo'); ?></h1>
                <p><?php _e('Real-time monitoring and strategic insights', 'autonomous-ai-seo'); ?></p>
            </div>
            <div class="aaiseo-status">
                <button class="button button-primary" id="add-competitor-btn">
                    <?php _e('Add Competitor', 'autonomous-ai-seo'); ?>
                </button>
            </div>
        </div>
    </div>

    <!-- Add Competitor Form -->
    <div class="aaiseo-panel" id="add-competitor-panel" style="display: none;">
        <div class="panel-header">
            <h2><?php _e('Add New Competitor', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <div class="competitor-form">
                <div class="form-row">
                    <div class="form-group">
                        <label for="competitor-domain"><?php _e('Competitor Domain', 'autonomous-ai-seo'); ?></label>
                        <input type="text" id="competitor-domain" placeholder="example.com" required>
                    </div>
                    <div class="form-group">
                        <label for="competitor-name"><?php _e('Competitor Name (Optional)', 'autonomous-ai-seo'); ?></label>
                        <input type="text" id="competitor-name" placeholder="Company Name">
                    </div>
                    <div class="form-actions">
                        <button class="button button-primary" id="add-competitor">
                            <?php _e('Add Competitor', 'autonomous-ai-seo'); ?>
                        </button>
                        <button class="button button-secondary" id="cancel-add-competitor">
                            <?php _e('Cancel', 'autonomous-ai-seo'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Competitor Overview -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Competitor Analysis Overview', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <?php if (!empty($competitive_data)): ?>
                <div class="competitors-table">
                    <table>
                        <thead>
                            <tr>
                                <th><?php _e('Competitor', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Domain Authority', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Est. Traffic', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Backlinks', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Keywords', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Last Analyzed', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Threat Level', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Actions', 'autonomous-ai-seo'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($competitive_data as $competitor): ?>
                                <tr>
                                    <td>
                                        <div class="competitor-info">
                                            <strong><?php echo esc_html($competitor['competitor_name'] ?: $competitor['domain']); ?></strong>
                                            <small><?php echo esc_html($competitor['domain']); ?></small>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="authority-score">
                                            <?php echo rand(20, 95); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="traffic-estimate">
                                            <?php echo number_format(rand(5000, 150000)); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="backlinks-count">
                                            <?php echo number_format(rand(500, 50000)); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="keywords-count">
                                            <?php echo number_format(rand(100, 10000)); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php 
                                        $last_analyzed = $competitor['last_analyzed'] ?? date('Y-m-d H:i:s');
                                        echo $last_analyzed ? human_time_diff(strtotime($last_analyzed)) . ' ago' : 'Never';
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $threat_levels = ['High', 'Medium', 'Low'];
                                        $threat = $threat_levels[array_rand($threat_levels)];
                                        $threat_class = strtolower($threat);
                                        ?>
                                        <span class="threat-badge <?php echo $threat_class; ?>">
                                            <?php echo $threat; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <button class="button button-small analyze-competitor" 
                                                    data-id="<?php echo intval($competitor['id']); ?>"
                                                    title="<?php _e('Analyze Competitor', 'autonomous-ai-seo'); ?>">
                                                <span class="dashicons dashicons-search"></span>
                                            </button>
                                            <button class="button button-small view-competitor" 
                                                    data-id="<?php echo intval($competitor['id']); ?>"
                                                    title="<?php _e('View Details', 'autonomous-ai-seo'); ?>">
                                                <span class="dashicons dashicons-visibility"></span>
                                            </button>
                                            <button class="button button-small remove-competitor" 
                                                    data-id="<?php echo intval($competitor['id']); ?>"
                                                    title="<?php _e('Remove Competitor', 'autonomous-ai-seo'); ?>">
                                                <span class="dashicons dashicons-trash"></span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="no-competitors">
                    <div class="no-competitors-icon">
                        <span class="dashicons dashicons-chart-bar"></span>
                    </div>
                    <h3><?php _e('No Competitors Added Yet', 'autonomous-ai-seo'); ?></h3>
                    <p><?php _e('Add your competitors to start monitoring their SEO strategies and identify opportunities.', 'autonomous-ai-seo'); ?></p>
                    <button class="button button-primary" id="add-first-competitor">
                        <?php _e('Add Your First Competitor', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Real-time Alerts -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Real-time Competitive Alerts', 'autonomous-ai-seo'); ?></h2>
            <button class="button button-secondary" id="refresh-alerts">
                <?php _e('Refresh', 'autonomous-ai-seo'); ?>
            </button>
        </div>
        <div class="panel-content">
            <div class="alerts-list">
                <div class="alert-item high-priority">
                    <div class="alert-icon">
                        <span class="dashicons dashicons-warning"></span>
                    </div>
                    <div class="alert-content">
                        <h4><?php _e('Competitor Content Surge', 'autonomous-ai-seo'); ?></h4>
                        <p>competitor1.com published 5 new articles targeting your primary keywords in the last 24 hours.</p>
                        <div class="alert-meta">
                            <span class="alert-time">2 hours ago</span>
                            <span class="alert-priority high"><?php _e('High Priority', 'autonomous-ai-seo'); ?></span>
                        </div>
                    </div>
                    <div class="alert-actions">
                        <button class="button button-small"><?php _e('Analyze', 'autonomous-ai-seo'); ?></button>
                    </div>
                </div>

                <div class="alert-item medium-priority">
                    <div class="alert-icon">
                        <span class="dashicons dashicons-admin-links"></span>
                    </div>
                    <div class="alert-content">
                        <h4><?php _e('New Backlink Acquisition', 'autonomous-ai-seo'); ?></h4>
                        <p>competitor2.com gained 15 high-authority backlinks from industry publications.</p>
                        <div class="alert-meta">
                            <span class="alert-time">1 day ago</span>
                            <span class="alert-priority medium"><?php _e('Medium Priority', 'autonomous-ai-seo'); ?></span>
                        </div>
                    </div>
                    <div class="alert-actions">
                        <button class="button button-small"><?php _e('View Links', 'autonomous-ai-seo'); ?></button>
                    </div>
                </div>

                <div class="alert-item low-priority">
                    <div class="alert-icon">
                        <span class="dashicons dashicons-update"></span>
                    </div>
                    <div class="alert-content">
                        <h4><?php _e('Website Update Detected', 'autonomous-ai-seo'); ?></h4>
                        <p>competitor3.com launched a new content series in your niche area.</p>
                        <div class="alert-meta">
                            <span class="alert-time">3 days ago</span>
                            <span class="alert-priority low"><?php _e('Low Priority', 'autonomous-ai-seo'); ?></span>
                        </div>
                    </div>
                    <div class="alert-actions">
                        <button class="button button-small"><?php _e('Review', 'autonomous-ai-seo'); ?></button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="aaiseo-dashboard-grid">
        <!-- Strategic Opportunities -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Strategic Opportunities', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="opportunities-list">
                    <div class="opportunity-item">
                        <div class="opportunity-type content-gap">Content Gap</div>
                        <h4><?php _e('Voice Search Optimization', 'autonomous-ai-seo'); ?></h4>
                        <p><?php _e('Competitors have minimal voice search content. High opportunity for first-mover advantage.', 'autonomous-ai-seo'); ?></p>
                        <div class="opportunity-stats">
                            <span class="stat">23 keywords</span>
                            <span class="stat">Medium difficulty</span>
                            <span class="potential high"><?php _e('High Potential', 'autonomous-ai-seo'); ?></span>
                        </div>
                        <button class="button button-primary button-small">
                            <?php _e('Implement Strategy', 'autonomous-ai-seo'); ?>
                        </button>
                    </div>

                    <div class="opportunity-item">
                        <div class="opportunity-type backlink-gap">Backlink Gap</div>
                        <h4><?php _e('Industry Publication Links', 'autonomous-ai-seo'); ?></h4>
                        <p><?php _e('Top competitor has 45 links from tech publications you\'re missing.', 'autonomous-ai-seo'); ?></p>
                        <div class="opportunity-stats">
                            <span class="stat">45 link targets</span>
                            <span class="stat">High difficulty</span>
                            <span class="potential high"><?php _e('High Potential', 'autonomous-ai-seo'); ?></span>
                        </div>
                        <button class="button button-primary button-small">
                            <?php _e('Start Outreach', 'autonomous-ai-seo'); ?>
                        </button>
                    </div>

                    <div class="opportunity-item">
                        <div class="opportunity-type keyword-gap">Keyword Gap</div>
                        <h4><?php _e('Long-tail Opportunities', 'autonomous-ai-seo'); ?></h4>
                        <p><?php _e('127 long-tail keywords with low competition and high search volume discovered.', 'autonomous-ai-seo'); ?></p>
                        <div class="opportunity-stats">
                            <span class="stat">127 keywords</span>
                            <span class="stat">Low difficulty</span>
                            <span class="potential medium"><?php _e('Medium Potential', 'autonomous-ai-seo'); ?></span>
                        </div>
                        <button class="button button-primary button-small">
                            <?php _e('Target Keywords', 'autonomous-ai-seo'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Market Position -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Market Position Analysis', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="market-position">
                    <div class="position-item">
                        <div class="position-label"><?php _e('Your Site', 'autonomous-ai-seo'); ?></div>
                        <div class="position-bar">
                            <div class="position-fill your-site" style="width: 75%"></div>
                        </div>
                        <div class="position-score">75%</div>
                    </div>

                    <div class="position-item">
                        <div class="position-label"><?php _e('Top Competitor', 'autonomous-ai-seo'); ?></div>
                        <div class="position-bar">
                            <div class="position-fill competitor" style="width: 95%"></div>
                        </div>
                        <div class="position-score">95%</div>
                    </div>

                    <div class="position-item">
                        <div class="position-label"><?php _e('Market Average', 'autonomous-ai-seo'); ?></div>
                        <div class="position-bar">
                            <div class="position-fill average" style="width: 60%"></div>
                        </div>
                        <div class="position-score">60%</div>
                    </div>
                </div>

                <div class="monitoring-stats">
                    <h4><?php _e('Monitoring Status', 'autonomous-ai-seo'); ?></h4>
                    <div class="stats-grid">
                        <div class="stat-item">
                            <span class="stat-value"><?php echo count($competitive_data ?? []); ?></span>
                            <span class="stat-label"><?php _e('Active Competitors', 'autonomous-ai-seo'); ?></span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value">48</span>
                            <span class="stat-label"><?php _e('Daily Checks', 'autonomous-ai-seo'); ?></span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value">23</span>
                            <span class="stat-label"><?php _e('Alerts This Week', 'autonomous-ai-seo'); ?></span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value">7</span>
                            <span class="stat-label"><?php _e('Opportunities Found', 'autonomous-ai-seo'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.competitor-form {
    background: #f9fafb;
    padding: 20px;
    border-radius: 8px;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr auto;
    gap: 20px;
    align-items: end;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: 500;
    color: #374151;
}

.form-group input {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #d1d5db;
    border-radius: 6px;
}

.competitors-table {
    overflow-x: auto;
}

.competitors-table table {
    width: 100%;
    border-collapse: collapse;
}

.competitors-table th,
.competitors-table td {
    padding: 12px 8px;
    text-align: left;
    border-bottom: 1px solid #f3f4f6;
}

.competitor-info strong {
    display: block;
    font-weight: 600;
}

.competitor-info small {
    color: #6b7280;
    font-size: 12px;
}

.threat-badge {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}

.threat-badge.high {
    background: #fee2e2;
    color: #dc2626;
}

.threat-badge.medium {
    background: #fef3c7;
    color: #d97706;
}

.threat-badge.low {
    background: #dcfce7;
    color: #16a34a;
}

.action-buttons {
    display: flex;
    gap: 5px;
}

.action-buttons .button {
    padding: 4px 8px;
    min-height: auto;
}

.no-competitors {
    text-align: center;
    padding: 60px 20px;
}

.no-competitors-icon {
    font-size: 48px;
    color: #d1d5db;
    margin-bottom: 20px;
}

.alerts-list {
    space-y: 16px;
}

.alert-item {
    display: flex;
    gap: 15px;
    padding: 16px;
    border-radius: 8px;
    border: 1px solid #e5e7eb;
}

.alert-item.high-priority {
    border-left: 4px solid #ef4444;
    background: #fef2f2;
}

.alert-item.medium-priority {
    border-left: 4px solid #f59e0b;
    background: #fffbeb;
}

.alert-item.low-priority {
    border-left: 4px solid #10b981;
    background: #f0fdf4;
}

.alert-icon {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    background: #f3f4f6;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.alert-content {
    flex: 1;
}

.alert-content h4 {
    margin: 0 0 8px 0;
    font-size: 14px;
    font-weight: 600;
}

.alert-content p {
    margin: 0 0 8px 0;
    color: #6b7280;
    font-size: 13px;
}

.alert-meta {
    display: flex;
    gap: 12px;
    align-items: center;
}

.alert-time {
    font-size: 12px;
    color: #9ca3af;
}

.alert-priority {
    padding: 2px 6px;
    border-radius: 8px;
    font-size: 10px;
    font-weight: 600;
    text-transform: uppercase;
}

.alert-priority.high {
    background: #fee2e2;
    color: #dc2626;
}

.alert-priority.medium {
    background: #fef3c7;
    color: #d97706;
}

.alert-priority.low {
    background: #dcfce7;
    color: #16a34a;
}

.opportunities-list {
    space-y: 20px;
}

.opportunity-item {
    padding: 20px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    transition: all 0.2s ease;
}

.opportunity-item:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.opportunity-type {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    margin-bottom: 8px;
}

.opportunity-type.content-gap {
    background: #dbeafe;
    color: #1e40af;
}

.opportunity-type.backlink-gap {
    background: #fecaca;
    color: #dc2626;
}

.opportunity-type.keyword-gap {
    background: #d1fae5;
    color: #065f46;
}

.opportunity-item h4 {
    margin: 0 0 8px 0;
    font-size: 16px;
    font-weight: 600;
}

.opportunity-item p {
    margin: 0 0 12px 0;
    color: #6b7280;
    line-height: 1.5;
}

.opportunity-stats {
    display: flex;
    gap: 12px;
    align-items: center;
    margin-bottom: 16px;
    flex-wrap: wrap;
}

.opportunity-stats .stat {
    padding: 2px 8px;
    background: #f3f4f6;
    border-radius: 12px;
    font-size: 12px;
    color: #6b7280;
}

.potential {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}

.potential.high {
    background: #dcfce7;
    color: #16a34a;
}

.potential.medium {
    background: #fef3c7;
    color: #d97706;
}

.market-position {
    margin-bottom: 30px;
}

.position-item {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 12px;
}

.position-label {
    flex: 0 0 120px;
    font-size: 14px;
    color: #6b7280;
}

.position-bar {
    flex: 1;
    height: 8px;
    background: #e5e7eb;
    border-radius: 4px;
    overflow: hidden;
}

.position-fill {
    height: 100%;
    border-radius: 4px;
}

.position-fill.your-site {
    background: #3b82f6;
}

.position-fill.competitor {
    background: #ef4444;
}

.position-fill.average {
    background: #6b7280;
}

.position-score {
    flex: 0 0 50px;
    text-align: right;
    font-weight: 600;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
}

.stat-item {
    text-align: center;
    padding: 12px;
    background: #f9fafb;
    border-radius: 6px;
}

.stat-value {
    display: block;
    font-size: 20px;
    font-weight: 700;
    color: #1f2937;
}

.stat-label {
    font-size: 12px;
    color: #6b7280;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Add competitor button
    $('#add-competitor-btn, #add-first-competitor').on('click', function() {
        $('#add-competitor-panel').slideDown();
        $('#competitor-domain').focus();
    });
    
    // Cancel add competitor
    $('#cancel-add-competitor').on('click', function() {
        $('#add-competitor-panel').slideUp();
        $('#competitor-domain, #competitor-name').val('');
    });
    
    // Add competitor
    $('#add-competitor').on('click', function() {
        addCompetitor();
    });
    
    // Analyze competitor
    $('.analyze-competitor').on('click', function() {
        const competitorId = $(this).data('id');
        analyzeCompetitor(competitorId);
    });
    
    // Remove competitor
    $('.remove-competitor').on('click', function() {
        const competitorId = $(this).data('id');
        if (confirm('Are you sure you want to remove this competitor?')) {
            removeCompetitor(competitorId);
        }
    });
    
    function addCompetitor() {
        const domain = $('#competitor-domain').val().trim();
        const name = $('#competitor-name').val().trim();
        
        if (!domain) {
            showNotice('error', 'Please enter a competitor domain.');
            return;
        }
        
        const button = $('#add-competitor');
        const originalText = button.text();
        
        button.prop('disabled', true).text('Adding...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_add_competitor',
                domain: domain,
                name: name,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data);
                    $('#competitor-domain, #competitor-name').val('');
                    $('#add-competitor-panel').slideUp();
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'Failed to add competitor.');
            },
            complete: function() {
                button.prop('disabled', false).text(originalText);
            }
        });
    }
    
    function analyzeCompetitor(competitorId) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_analyze_competitor',
                competitor_id: competitorId,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data);
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'Failed to analyze competitor.');
            }
        });
    }
    
    function removeCompetitor(competitorId) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_remove_competitor',
                competitor_id: competitorId,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data);
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'Failed to remove competitor.');
            }
        });
    }
    
    function showNotice(type, message) {
        const notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
        $('.wrap').prepend(notice);
        setTimeout(() => notice.fadeOut(), 5000);
    }
});
</script>