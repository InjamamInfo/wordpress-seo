<?php
/**
 * Analytics template for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aaiseo-dashboard">
    <div class="aaiseo-header">
        <div class="aaiseo-header-content">
            <div class="aaiseo-logo">
                <h1><?php _e('Predictive Analytics & Forecasting', 'autonomous-ai-seo'); ?></h1>
                <p><?php _e('AI-powered insights to stay ahead of the competition', 'autonomous-ai-seo'); ?></p>
            </div>
            <div class="aaiseo-status">
                <button class="button button-primary" id="refresh-analytics">
                    <?php _e('Refresh Data', 'autonomous-ai-seo'); ?>
                </button>
            </div>
        </div>
    </div>

    <!-- Prediction Cards -->
    <div class="aaiseo-metrics-grid">
        <div class="aaiseo-metric-card prediction-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-chart-line"></span>
            </div>
            <div class="metric-content">
                <h3>31,245</h3>
                <p><?php _e('Predicted Traffic', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">+27.2% in 3 months</span>
                <div class="confidence-bar">
                    <div class="confidence-fill" style="width: 89%"></div>
                </div>
                <small>89% confidence</small>
            </div>
        </div>

        <div class="aaiseo-metric-card prediction-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-search"></span>
            </div>
            <div class="metric-content">
                <h3>1,847</h3>
                <p><?php _e('Predicted Keywords', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">+29.2% in 2 months</span>
                <div class="confidence-bar">
                    <div class="confidence-fill" style="width: 92%"></div>
                </div>
                <small>92% confidence</small>
            </div>
        </div>

        <div class="aaiseo-metric-card prediction-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-money-alt"></span>
            </div>
            <div class="metric-content">
                <h3>4.1%</h3>
                <p><?php _e('Predicted Conversion Rate', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">+28.1% in 4 months</span>
                <div class="confidence-bar">
                    <div class="confidence-fill" style="width: 78%"></div>
                </div>
                <small>78% confidence</small>
            </div>
        </div>

        <div class="aaiseo-metric-card prediction-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-performance"></span>
            </div>
            <div class="metric-content">
                <h3>94</h3>
                <p><?php _e('Predicted Page Speed', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">+20.5% in 1 month</span>
                <div class="confidence-bar">
                    <div class="confidence-fill" style="width: 95%"></div>
                </div>
                <small>95% confidence</small>
            </div>
        </div>
    </div>

    <!-- Traffic Forecast Chart -->
    <div class="aaiseo-panel aaiseo-traffic-chart">
        <div class="panel-header">
            <h2><?php _e('Traffic Forecast', 'autonomous-ai-seo'); ?></h2>
            <div class="chart-controls">
                <button class="button chart-period active" data-period="3m">3M</button>
                <button class="button chart-period" data-period="6m">6M</button>
                <button class="button chart-period" data-period="1y">1Y</button>
            </div>
        </div>
        <div class="panel-content">
            <div class="chart-container">
                <canvas id="forecast-chart" width="800" height="300"></canvas>
            </div>
            <div class="chart-legend">
                <div class="legend-item">
                    <span class="legend-color historical"></span>
                    <span><?php _e('Historical Data', 'autonomous-ai-seo'); ?></span>
                </div>
                <div class="legend-item">
                    <span class="legend-color forecast"></span>
                    <span><?php _e('AI Forecast', 'autonomous-ai-seo'); ?></span>
                </div>
                <div class="legend-item">
                    <span class="legend-color confidence"></span>
                    <span><?php _e('Confidence Range', 'autonomous-ai-seo'); ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="aaiseo-dashboard-grid">
        <!-- AI Insights -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('AI Strategic Insights', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="insights-list">
                    <div class="insight-item high-impact">
                        <div class="insight-icon">
                            <span class="dashicons dashicons-chart-line"></span>
                        </div>
                        <div class="insight-content">
                            <h4><?php _e('Seasonal Traffic Surge Expected', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('AI predicts a 40% traffic increase in Q4 based on historical patterns and competitor analysis.', 'autonomous-ai-seo'); ?></p>
                            <div class="insight-meta">
                                <span class="impact-badge high"><?php _e('High Impact', 'autonomous-ai-seo'); ?></span>
                                <span class="date">2024-03-15</span>
                            </div>
                            <div class="insight-action">
                                <strong><?php _e('Action:', 'autonomous-ai-seo'); ?></strong> 
                                <?php _e('Prepare content calendar for holiday season', 'autonomous-ai-seo'); ?>
                            </div>
                        </div>
                    </div>

                    <div class="insight-item low-impact">
                        <div class="insight-icon">
                            <span class="dashicons dashicons-shield"></span>
                        </div>
                        <div class="insight-content">
                            <h4><?php _e('Algorithm Update Impact Forecast', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Low risk detected for upcoming Google algorithm update. Your site is well-positioned.', 'autonomous-ai-seo'); ?></p>
                            <div class="insight-meta">
                                <span class="impact-badge low"><?php _e('Low Impact', 'autonomous-ai-seo'); ?></span>
                                <span class="date">2024-03-12</span>
                            </div>
                            <div class="insight-action">
                                <strong><?php _e('Action:', 'autonomous-ai-seo'); ?></strong> 
                                <?php _e('Continue current optimization strategy', 'autonomous-ai-seo'); ?>
                            </div>
                        </div>
                    </div>

                    <div class="insight-item high-impact">
                        <div class="insight-icon">
                            <span class="dashicons dashicons-megaphone"></span>
                        </div>
                        <div class="insight-content">
                            <h4><?php _e('Competitor Gap Opportunity', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Competitor weakness identified in voice search optimization. Act within 30 days.', 'autonomous-ai-seo'); ?></p>
                            <div class="insight-meta">
                                <span class="impact-badge high"><?php _e('High Impact', 'autonomous-ai-seo'); ?></span>
                                <span class="date">2024-03-10</span>
                            </div>
                            <div class="insight-action">
                                <strong><?php _e('Action:', 'autonomous-ai-seo'); ?></strong> 
                                <?php _e('Implement voice search optimization', 'autonomous-ai-seo'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Performance Metrics -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Prediction Accuracy', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="accuracy-metrics">
                    <div class="accuracy-item">
                        <div class="accuracy-label"><?php _e('Traffic Predictions', 'autonomous-ai-seo'); ?></div>
                        <div class="accuracy-bar">
                            <div class="accuracy-fill" style="width: 94%"></div>
                        </div>
                        <div class="accuracy-value">94% accurate</div>
                    </div>

                    <div class="accuracy-item">
                        <div class="accuracy-label"><?php _e('Ranking Forecasts', 'autonomous-ai-seo'); ?></div>
                        <div class="accuracy-bar">
                            <div class="accuracy-fill" style="width: 89%"></div>
                        </div>
                        <div class="accuracy-value">89% accurate</div>
                    </div>

                    <div class="accuracy-item">
                        <div class="accuracy-label"><?php _e('Algorithm Impact', 'autonomous-ai-seo'); ?></div>
                        <div class="accuracy-bar">
                            <div class="accuracy-fill" style="width: 91%"></div>
                        </div>
                        <div class="accuracy-value">91% accurate</div>
                    </div>

                    <div class="accuracy-item">
                        <div class="accuracy-label"><?php _e('Content Performance', 'autonomous-ai-seo'); ?></div>
                        <div class="accuracy-bar">
                            <div class="accuracy-fill" style="width: 87%"></div>
                        </div>
                        <div class="accuracy-value">87% accurate</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ROI Forecast -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('ROI Forecast & Business Impact', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <div class="roi-dashboard">
                <div class="roi-highlight">
                    <div class="roi-amount">$47,230</div>
                    <div class="roi-description"><?php _e('Projected revenue increase (6 months)', 'autonomous-ai-seo'); ?></div>
                    <div class="roi-percentage">284% ROI projected</div>
                </div>

                <div class="roi-breakdown">
                    <div class="roi-item">
                        <span class="roi-label"><?php _e('Traffic Value Increase', 'autonomous-ai-seo'); ?></span>
                        <span class="roi-value">$28,450</span>
                    </div>
                    <div class="roi-item">
                        <span class="roi-label"><?php _e('Conversion Rate Improvement', 'autonomous-ai-seo'); ?></span>
                        <span class="roi-value">$12,890</span>
                    </div>
                    <div class="roi-item">
                        <span class="roi-label"><?php _e('Cost Per Acquisition Reduction', 'autonomous-ai-seo'); ?></span>
                        <span class="roi-value">$5,890</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Export Options -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Export Analytics Report', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <div class="export-options">
                <div class="export-controls">
                    <label for="report-period"><?php _e('Time Period:', 'autonomous-ai-seo'); ?></label>
                    <select id="report-period">
                        <option value="30days"><?php _e('Last 30 Days', 'autonomous-ai-seo'); ?></option>
                        <option value="90days"><?php _e('Last 90 Days', 'autonomous-ai-seo'); ?></option>
                        <option value="6months"><?php _e('Last 6 Months', 'autonomous-ai-seo'); ?></option>
                        <option value="1year"><?php _e('Last Year', 'autonomous-ai-seo'); ?></option>
                    </select>

                    <label for="report-format"><?php _e('Format:', 'autonomous-ai-seo'); ?></label>
                    <select id="report-format">
                        <option value="html"><?php _e('HTML', 'autonomous-ai-seo'); ?></option>
                        <option value="pdf"><?php _e('PDF', 'autonomous-ai-seo'); ?></option>
                        <option value="csv"><?php _e('CSV', 'autonomous-ai-seo'); ?></option>
                    </select>

                    <button class="button button-primary" id="export-report">
                        <?php _e('Export Report', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.prediction-card {
    position: relative;
    overflow: hidden;
}

.prediction-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
}

.confidence-bar {
    width: 100%;
    height: 4px;
    background: #e5e7eb;
    border-radius: 2px;
    margin: 8px 0 4px 0;
    overflow: hidden;
}

.confidence-fill {
    height: 100%;
    background: linear-gradient(90deg, #10b981 0%, #059669 100%);
    border-radius: 2px;
    transition: width 0.3s ease;
}

.insights-list {
    space-y: 20px;
}

.insight-item {
    display: flex;
    gap: 15px;
    padding: 20px;
    border-radius: 12px;
    border: 1px solid #e5e7eb;
    transition: all 0.2s ease;
}

.insight-item:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    transform: translateY(-2px);
}

.insight-item.high-impact {
    border-left: 4px solid #ef4444;
    background: #fef2f2;
}

.insight-item.medium-impact {
    border-left: 4px solid #f59e0b;
    background: #fffbeb;
}

.insight-item.low-impact {
    border-left: 4px solid #10b981;
    background: #f0fdf4;
}

.insight-icon {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    background: #f3f4f6;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.insight-content h4 {
    margin: 0 0 8px 0;
    font-size: 16px;
    font-weight: 600;
    color: #1f2937;
}

.insight-content p {
    margin: 0 0 12px 0;
    color: #6b7280;
    line-height: 1.5;
}

.insight-meta {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 8px;
}

.impact-badge {
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}

.impact-badge.high {
    background: #fee2e2;
    color: #dc2626;
}

.impact-badge.medium {
    background: #fef3c7;
    color: #d97706;
}

.impact-badge.low {
    background: #dcfce7;
    color: #16a34a;
}

.insight-action {
    font-size: 14px;
    color: #374151;
}

.accuracy-metrics {
    space-y: 16px;
}

.accuracy-item {
    display: flex;
    align-items: center;
    gap: 12px;
}

.accuracy-label {
    flex: 0 0 140px;
    font-size: 14px;
    color: #6b7280;
}

.accuracy-bar {
    flex: 1;
    height: 8px;
    background: #e5e7eb;
    border-radius: 4px;
    overflow: hidden;
}

.accuracy-fill {
    height: 100%;
    background: linear-gradient(90deg, #10b981 0%, #059669 100%);
    border-radius: 4px;
}

.accuracy-value {
    flex: 0 0 80px;
    text-align: right;
    font-size: 14px;
    font-weight: 600;
    color: #059669;
}

.roi-dashboard {
    display: grid;
    grid-template-columns: 1fr 2fr;
    gap: 30px;
    align-items: center;
}

.roi-highlight {
    text-align: center;
    padding: 30px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 12px;
    color: white;
}

.roi-amount {
    font-size: 36px;
    font-weight: 700;
    margin-bottom: 8px;
}

.roi-description {
    font-size: 14px;
    opacity: 0.9;
    margin-bottom: 8px;
}

.roi-percentage {
    font-size: 18px;
    font-weight: 600;
}

.roi-breakdown {
    space-y: 12px;
}

.roi-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid #f3f4f6;
}

.roi-label {
    color: #6b7280;
}

.roi-value {
    font-weight: 600;
    color: #059669;
    font-size: 16px;
}

.export-controls {
    display: flex;
    align-items: center;
    gap: 15px;
    flex-wrap: wrap;
}

.export-controls label {
    font-weight: 500;
    color: #374151;
}

.export-controls select {
    padding: 8px 12px;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    background: white;
}

.chart-container {
    height: 300px;
    position: relative;
}

.legend-color.historical {
    background: #667eea;
}

.legend-color.forecast {
    background: #f59e0b;
}

.legend-color.confidence {
    background: rgba(102, 126, 234, 0.2);
}
</style>

<script>
jQuery(document).ready(function($) {
    // Initialize forecast chart
    initializeForecastChart();
    
    // Chart period controls
    $('.chart-period').on('click', function() {
        $('.chart-period').removeClass('active');
        $(this).addClass('active');
        updateForecastChart($(this).data('period'));
    });
    
    // Export report
    $('#export-report').on('click', function() {
        const period = $('#report-period').val();
        const format = $('#report-format').val();
        exportReport(period, format);
    });
    
    // Refresh analytics
    $('#refresh-analytics').on('click', function() {
        refreshAnalytics();
    });
    
    function initializeForecastChart() {
        const ctx = document.getElementById('forecast-chart');
        if (!ctx) return;
        
        // Generate sample data
        const labels = [];
        const historicalData = [];
        const forecastData = [];
        
        for (let i = 30; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
            historicalData.push(Math.floor(Math.random() * 1000) + 800);
        }
        
        for (let i = 1; i <= 90; i++) {
            const date = new Date();
            date.setDate(date.getDate() + i);
            labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
            forecastData.push(Math.floor(Math.random() * 1200) + 900);
        }
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Historical Traffic',
                    data: historicalData.concat(Array(90).fill(null)),
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4,
                    fill: false
                }, {
                    label: 'Predicted Traffic',
                    data: Array(31).fill(null).concat(forecastData),
                    borderColor: '#f59e0b',
                    backgroundColor: 'rgba(245, 158, 11, 0.1)',
                    borderDash: [5, 5],
                    tension: 0.4,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
                        grid: {
                            color: '#f3f4f6'
                        }
                    },
                    x: {
                        grid: {
                            color: '#f3f4f6'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                interaction: {
                    mode: 'nearest',
                    axis: 'x',
                    intersect: false
                }
            }
        });
    }
    
    function updateForecastChart(period) {
        // Update chart based on selected period
        console.log('Updating forecast chart for period:', period);
    }
    
    function exportReport(period, format) {
        const button = $('#export-report');
        const originalText = button.text();
        
        button.prop('disabled', true).text('Exporting...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_export_report',
                period: period,
                format: format,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    if (format === 'html') {
                        const reportWindow = window.open('', '_blank');
                        reportWindow.document.write(response.data.report);
                        reportWindow.document.close();
                    } else {
                        // Download file
                        downloadFile(response.data.report, 'aaiseo-analytics-report.' + format);
                    }
                    showNotice('success', 'Report exported successfully');
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'Failed to export report');
            },
            complete: function() {
                button.prop('disabled', false).text(originalText);
            }
        });
    }
    
    function refreshAnalytics() {
        const button = $('#refresh-analytics');
        const originalText = button.text();
        
        button.prop('disabled', true).text('Refreshing...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_refresh_analytics',
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', 'Analytics refreshed successfully');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'Failed to refresh analytics');
            },
            complete: function() {
                button.prop('disabled', false).text(originalText);
            }
        });
    }
    
    function downloadFile(content, filename) {
        const element = document.createElement('a');
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(content));
        element.setAttribute('download', filename);
        element.style.display = 'none';
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
    }
    
    function showNotice(type, message) {
        const notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
        $('.wrap').prepend(notice);
        setTimeout(() => notice.fadeOut(), 5000);
    }
});
</script>