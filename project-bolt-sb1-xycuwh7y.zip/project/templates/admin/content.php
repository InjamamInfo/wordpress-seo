<?php
/**
 * Content Strategy template for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aaiseo-dashboard">
    <div class="aaiseo-header">
        <div class="aaiseo-header-content">
            <div class="aaiseo-logo">
                <h1><?php _e('AI-Driven Content Strategy', 'autonomous-ai-seo'); ?></h1>
                <p><?php _e('Discover content gaps and optimize your content strategy', 'autonomous-ai-seo'); ?></p>
            </div>
            <div class="aaiseo-status">
                <button class="button button-primary" id="generate-content-ideas">
                    <?php _e('Generate Content Ideas', 'autonomous-ai-seo'); ?>
                </button>
            </div>
        </div>
    </div>

    <!-- Content Performance Overview -->
    <div class="aaiseo-metrics-grid">
        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-edit"></span>
            </div>
            <div class="metric-content">
                <h3><?php echo wp_count_posts()->publish; ?></h3>
                <p><?php _e('Published Articles', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">+12%</span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-search"></span>
            </div>
            <div class="metric-content">
                <h3>1,429</h3>
                <p><?php _e('Ranking Keywords', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">+8%</span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-groups"></span>
            </div>
            <div class="metric-content">
                <h3>89.4K</h3>
                <p><?php _e('Monthly Visitors', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">+23%</span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-clock"></span>
            </div>
            <div class="metric-content">
                <h3>4.2</h3>
                <p><?php _e('Avg. Time on Page', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">+15%</span>
            </div>
        </div>
    </div>

    <!-- Content Gap Analysis -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('AI-Identified Content Gaps', 'autonomous-ai-seo'); ?></h2>
            <button class="button button-secondary" id="refresh-gaps">
                <?php _e('Refresh Analysis', 'autonomous-ai-seo'); ?>
            </button>
        </div>
        <div class="panel-content">
            <?php
            $content_gaps = array(
                array(
                    'topic' => 'Voice Search Optimization',
                    'keywords' => 23,
                    'difficulty' => 'Medium',
                    'volume' => '12K',
                    'opportunity' => 'High',
                    'competitors' => 2
                ),
                array(
                    'topic' => 'AI Content Marketing',
                    'keywords' => 18,
                    'difficulty' => 'High',
                    'volume' => '8.5K',
                    'opportunity' => 'High',
                    'competitors' => 5
                ),
                array(
                    'topic' => 'Local SEO Strategies',
                    'keywords' => 31,
                    'difficulty' => 'Low',
                    'volume' => '15K',
                    'opportunity' => 'Medium',
                    'competitors' => 3
                )
            );
            ?>
            
            <div class="content-gaps-table">
                <table>
                    <thead>
                        <tr>
                            <th><?php _e('Topic', 'autonomous-ai-seo'); ?></th>
                            <th><?php _e('Keywords', 'autonomous-ai-seo'); ?></th>
                            <th><?php _e('Difficulty', 'autonomous-ai-seo'); ?></th>
                            <th><?php _e('Search Volume', 'autonomous-ai-seo'); ?></th>
                            <th><?php _e('Opportunity', 'autonomous-ai-seo'); ?></th>
                            <th><?php _e('Competitors', 'autonomous-ai-seo'); ?></th>
                            <th><?php _e('Action', 'autonomous-ai-seo'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($content_gaps as $gap): ?>
                        <tr>
                            <td><strong><?php echo esc_html($gap['topic']); ?></strong></td>
                            <td><?php echo intval($gap['keywords']); ?></td>
                            <td>
                                <span class="difficulty-badge <?php echo strtolower($gap['difficulty']); ?>">
                                    <?php echo esc_html($gap['difficulty']); ?>
                                </span>
                            </td>
                            <td><?php echo esc_html($gap['volume']); ?>/mo</td>
                            <td>
                                <span class="opportunity-badge <?php echo strtolower($gap['opportunity']); ?>">
                                    <?php echo esc_html($gap['opportunity']); ?>
                                </span>
                            </td>
                            <td><?php echo intval($gap['competitors']); ?></td>
                            <td>
                                <button class="button button-primary button-small create-brief" 
                                        data-topic="<?php echo esc_attr($gap['topic']); ?>">
                                    <?php _e('Create Brief', 'autonomous-ai-seo'); ?>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- AI-Generated Content Ideas -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('AI-Generated Content Ideas', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <?php
            $content_ideas = array(
                array(
                    'title' => 'The Complete Guide to Voice Search SEO in 2024',
                    'type' => 'Pillar Content',
                    'keywords' => array('voice search', 'SEO optimization', 'voice queries'),
                    'estimated_traffic' => '2.3K',
                    'difficulty' => 'Medium',
                    'priority' => 'High'
                ),
                array(
                    'title' => '15 AI Tools That Will Transform Your Content Marketing',
                    'type' => 'Listicle',
                    'keywords' => array('AI tools', 'content marketing', 'automation'),
                    'estimated_traffic' => '1.8K',
                    'difficulty' => 'Low',
                    'priority' => 'High'
                ),
                array(
                    'title' => 'How to Optimize Your Local Business for Voice Search',
                    'type' => 'How-to Guide',
                    'keywords' => array('local SEO', 'voice search', 'local business'),
                    'estimated_traffic' => '1.2K',
                    'difficulty' => 'Low',
                    'priority' => 'Medium'
                )
            );
            ?>
            
            <div class="content-ideas-list">
                <?php foreach ($content_ideas as $idea): ?>
                <div class="content-idea-item">
                    <div class="idea-header">
                        <h4><?php echo esc_html($idea['title']); ?></h4>
                        <div class="idea-badges">
                            <span class="content-type-badge"><?php echo esc_html($idea['type']); ?></span>
                            <span class="priority-badge <?php echo strtolower($idea['priority']); ?>">
                                <?php echo esc_html($idea['priority']); ?> Priority
                            </span>
                        </div>
                    </div>
                    
                    <div class="idea-meta">
                        <span class="meta-item">Est. Traffic: <?php echo esc_html($idea['estimated_traffic']); ?>/mo</span>
                        <span class="meta-item">Difficulty: <?php echo esc_html($idea['difficulty']); ?></span>
                    </div>
                    
                    <div class="idea-keywords">
                        <?php foreach ($idea['keywords'] as $keyword): ?>
                            <span class="keyword-tag"><?php echo esc_html($keyword); ?></span>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="idea-actions">
                        <button class="button button-primary generate-draft" 
                                data-title="<?php echo esc_attr($idea['title']); ?>">
                            <?php _e('Generate Draft', 'autonomous-ai-seo'); ?>
                        </button>
                        <button class="button button-secondary add-to-calendar" 
                                data-title="<?php echo esc_attr($idea['title']); ?>">
                            <?php _e('Add to Calendar', 'autonomous-ai-seo'); ?>
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div class="aaiseo-dashboard-grid">
        <!-- Topic Clusters -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Content Topic Clusters', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <?php
                $topic_clusters = array(
                    array(
                        'pillar' => 'SEO Fundamentals',
                        'articles' => 12,
                        'traffic' => '45K',
                        'keywords' => 234,
                        'status' => 'Active'
                    ),
                    array(
                        'pillar' => 'Content Marketing',
                        'articles' => 8,
                        'traffic' => '32K',
                        'keywords' => 189,
                        'status' => 'Growing'
                    ),
                    array(
                        'pillar' => 'Technical SEO',
                        'articles' => 15,
                        'traffic' => '28K',
                        'keywords' => 156,
                        'status' => 'Mature'
                    )
                );
                ?>
                
                <div class="topic-clusters-grid">
                    <?php foreach ($topic_clusters as $cluster): ?>
                    <div class="cluster-card">
                        <div class="cluster-header">
                            <h4><?php echo esc_html($cluster['pillar']); ?></h4>
                            <span class="cluster-status <?php echo strtolower($cluster['status']); ?>">
                                <?php echo esc_html($cluster['status']); ?>
                            </span>
                        </div>
                        
                        <div class="cluster-stats">
                            <div class="stat-row">
                                <span class="stat-label"><?php _e('Articles:', 'autonomous-ai-seo'); ?></span>
                                <span class="stat-value"><?php echo intval($cluster['articles']); ?></span>
                            </div>
                            <div class="stat-row">
                                <span class="stat-label"><?php _e('Traffic:', 'autonomous-ai-seo'); ?></span>
                                <span class="stat-value"><?php echo esc_html($cluster['traffic']); ?>/mo</span>
                            </div>
                            <div class="stat-row">
                                <span class="stat-label"><?php _e('Keywords:', 'autonomous-ai-seo'); ?></span>
                                <span class="stat-value"><?php echo intval($cluster['keywords']); ?></span>
                            </div>
                        </div>
                        
                        <button class="button button-secondary button-small expand-cluster" 
                                data-cluster="<?php echo esc_attr($cluster['pillar']); ?>">
                            <?php _e('Expand Cluster', 'autonomous-ai-seo'); ?>
                        </button>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Content Calendar -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('AI-Optimized Content Calendar', 'autonomous-ai-seo'); ?></h2>
                <button class="button button-primary" id="generate-calendar">
                    <?php _e('Generate Calendar', 'autonomous-ai-seo'); ?>
                </button>
            </div>
            <div class="panel-content">
                <div class="calendar-grid">
                    <?php
                    $days = array('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun');
                    foreach ($days as $day):
                    ?>
                    <div class="calendar-day">
                        <h5><?php echo $day; ?></h5>
                        <div class="day-content">
                            <?php if (in_array($day, array('Mon', 'Wed', 'Fri'))): ?>
                                <div class="content-block blog-post">
                                    <span class="content-type">Blog Post</span>
                                </div>
                            <?php endif; ?>
                            <?php if (in_array($day, array('Tue', 'Thu'))): ?>
                                <div class="content-block social-media">
                                    <span class="content-type">Social Media</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Content Performance Analysis -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Content Performance Analysis', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <div class="performance-chart-container">
                <canvas id="content-performance-chart" width="800" height="300"></canvas>
            </div>
            
            <div class="performance-insights">
                <div class="insight-item">
                    <div class="insight-icon">
                        <span class="dashicons dashicons-chart-line"></span>
                    </div>
                    <div class="insight-content">
                        <h4><?php _e('Top Performing Content Type', 'autonomous-ai-seo'); ?></h4>
                        <p><?php _e('How-to guides generate 3x more engagement than other content types', 'autonomous-ai-seo'); ?></p>
                    </div>
                </div>
                
                <div class="insight-item">
                    <div class="insight-icon">
                        <span class="dashicons dashicons-clock"></span>
                    </div>
                    <div class="insight-content">
                        <h4><?php _e('Optimal Publishing Time', 'autonomous-ai-seo'); ?></h4>
                        <p><?php _e('Tuesday at 10 AM shows highest engagement rates for your audience', 'autonomous-ai-seo'); ?></p>
                    </div>
                </div>
                
                <div class="insight-item">
                    <div class="insight-icon">
                        <span class="dashicons dashicons-editor-alignleft"></span>
                    </div>
                    <div class="insight-content">
                        <h4><?php _e('Content Length Sweet Spot', 'autonomous-ai-seo'); ?></h4>
                        <p><?php _e('Articles between 1,500-2,500 words perform best for your niche', 'autonomous-ai-seo'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.content-gaps-table {
    overflow-x: auto;
}

.content-gaps-table table {
    width: 100%;
    border-collapse: collapse;
}

.content-gaps-table th,
.content-gaps-table td {
    padding: 12px 8px;
    text-align: left;
    border-bottom: 1px solid #f3f4f6;
}

.difficulty-badge,
.opportunity-badge {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}

.difficulty-badge.low,
.opportunity-badge.high {
    background: #dcfce7;
    color: #16a34a;
}

.difficulty-badge.medium,
.opportunity-badge.medium {
    background: #fef3c7;
    color: #d97706;
}

.difficulty-badge.high,
.opportunity-badge.low {
    background: #fee2e2;
    color: #dc2626;
}

.content-ideas-list {
    space-y: 20px;
}

.content-idea-item {
    padding: 20px;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    transition: all 0.2s ease;
    margin-bottom: 20px;
}

.content-idea-item:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    transform: translateY(-2px);
}

.idea-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 12px;
}

.idea-header h4 {
    margin: 0;
    font-size: 16px;
    font-weight: 600;
    color: #1f2937;
    flex: 1;
    margin-right: 16px;
}

.idea-badges {
    display: flex;
    gap: 8px;
    flex-shrink: 0;
}

.content-type-badge {
    padding: 4px 8px;
    background: #e0e7ff;
    color: #3730a3;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
}

.priority-badge {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}

.priority-badge.high {
    background: #fee2e2;
    color: #dc2626;
}

.priority-badge.medium {
    background: #fef3c7;
    color: #d97706;
}

.priority-badge.low {
    background: #dcfce7;
    color: #16a34a;
}

.idea-meta {
    display: flex;
    gap: 16px;
    margin-bottom: 12px;
    font-size: 13px;
    color: #6b7280;
}

.idea-keywords {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    margin-bottom: 16px;
}

.keyword-tag {
    padding: 2px 8px;
    background: #f3f4f6;
    color: #6b7280;
    border-radius: 12px;
    font-size: 12px;
}

.idea-actions {
    display: flex;
    gap: 8px;
}

.topic-clusters-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 16px;
}

.cluster-card {
    padding: 16px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    background: #f9fafb;
}

.cluster-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
}

.cluster-header h4 {
    margin: 0;
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
}

.cluster-status {
    padding: 2px 6px;
    border-radius: 8px;
    font-size: 10px;
    font-weight: 600;
    text-transform: uppercase;
}

.cluster-status.active {
    background: #dcfce7;
    color: #16a34a;
}

.cluster-status.growing {
    background: #dbeafe;
    color: #1e40af;
}

.cluster-status.mature {
    background: #f3f4f6;
    color: #6b7280;
}

.cluster-stats {
    margin-bottom: 12px;
}

.stat-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 4px;
    font-size: 12px;
}

.stat-label {
    color: #6b7280;
}

.stat-value {
    font-weight: 600;
    color: #1f2937;
}

.calendar-grid {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 8px;
}

.calendar-day {
    border: 1px solid #e5e7eb;
    border-radius: 6px;
    padding: 8px;
    min-height: 80px;
}

.calendar-day h5 {
    margin: 0 0 8px 0;
    font-size: 12px;
    font-weight: 600;
    color: #6b7280;
    text-align: center;
}

.day-content {
    space-y: 4px;
}

.content-block {
    padding: 4px 6px;
    border-radius: 4px;
    font-size: 10px;
    text-align: center;
}

.content-block.blog-post {
    background: #dbeafe;
    color: #1e40af;
}

.content-block.social-media {
    background: #fecaca;
    color: #dc2626;
}

.performance-chart-container {
    height: 300px;
    margin-bottom: 20px;
}

.performance-insights {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 16px;
}

.insight-item {
    display: flex;
    gap: 12px;
    padding: 16px;
    background: #f9fafb;
    border-radius: 8px;
}

.insight-icon {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    background: #e0e7ff;
    color: #3730a3;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.insight-content h4 {
    margin: 0 0 4px 0;
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
}

.insight-content p {
    margin: 0;
    font-size: 12px;
    color: #6b7280;
    line-height: 1.4;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Initialize content performance chart
    initializeContentChart();
    
    // Generate content ideas
    $('#generate-content-ideas').on('click', function() {
        generateContentIdeas();
    });
    
    // Create content brief
    $('.create-brief').on('click', function() {
        const topic = $(this).data('topic');
        createContentBrief(topic);
    });
    
    // Generate draft
    $('.generate-draft').on('click', function() {
        const title = $(this).data('title');
        generateContentDraft(title);
    });
    
    // Add to calendar
    $('.add-to-calendar').on('click', function() {
        const title = $(this).data('title');
        addToCalendar(title);
    });
    
    // Expand cluster
    $('.expand-cluster').on('click', function() {
        const cluster = $(this).data('cluster');
        expandCluster(cluster);
    });
    
    // Generate calendar
    $('#generate-calendar').on('click', function() {
        generateContentCalendar();
    });
    
    function initializeContentChart() {
        const ctx = document.getElementById('content-performance-chart');
        if (!ctx) return;
        
        // Generate sample data
        const labels = [];
        const trafficData = [];
        const engagementData = [];
        
        for (let i = 29; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
            trafficData.push(Math.floor(Math.random() * 1000) + 500);
            engagementData.push(Math.floor(Math.random() * 100) + 50);
        }
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Content Traffic',
                    data: trafficData,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y'
                }, {
                    label: 'Engagement Rate',
                    data: engagementData,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y1'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Traffic'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Engagement %'
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom'
                    }
                }
            }
        });
    }
    
    function generateContentIdeas() {
        const button = $('#generate-content-ideas');
        const originalText = button.text();
        
        button.prop('disabled', true).text('Generating Ideas...');
        
        // Simulate AI generation
        setTimeout(function() {
            showNotice('success', 'New content ideas generated successfully!');
            button.prop('disabled', false).text(originalText);
        }, 2000);
    }
    
    function createContentBrief(topic) {
        showNotice('info', 'Creating content brief for: ' + topic);
        
        // This would typically open a modal or redirect to a content brief creation page
        setTimeout(function() {
            showNotice('success', 'Content brief created for: ' + topic);
        }, 1000);
    }
    
    function generateContentDraft(title) {
        showNotice('info', 'Generating AI draft for: ' + title);
        
        // This would typically call the AI engine to generate content
        setTimeout(function() {
            showNotice('success', 'Draft generated successfully! Check your drafts folder.');
        }, 3000);
    }
    
    function addToCalendar(title) {
        showNotice('success', 'Added to content calendar: ' + title);
    }
    
    function expandCluster(cluster) {
        showNotice('info', 'Expanding cluster: ' + cluster);
        
        // This would show more detailed cluster information
        setTimeout(function() {
            showNotice('success', 'Cluster expanded with new content suggestions');
        }, 1000);
    }
    
    function generateContentCalendar() {
        const button = $('#generate-calendar');
        const originalText = button.text();
        
        button.prop('disabled', true).text('Generating...');
        
        setTimeout(function() {
            showNotice('success', 'Content calendar generated for next 30 days');
            button.prop('disabled', false).text(originalText);
            
            // Add more content blocks to calendar
            $('.calendar-day').each(function() {
                if (Math.random() > 0.7) {
                    $(this).find('.day-content').append('<div class="content-block blog-post"><span class="content-type">New Post</span></div>');
                }
            });
        }, 2000);
    }
    
    function showNotice(type, message) {
        const notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
        $('.wrap').prepend(notice);
        setTimeout(() => notice.fadeOut(), 5000);
    }
});
</script>