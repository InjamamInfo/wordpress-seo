<?php
/**
 * Core Web Vitals template for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aaiseo-dashboard">
    <div class="aaiseo-header">
        <div class="aaiseo-header-content">
            <div class="aaiseo-logo">
                <h1><?php _e('Core Web Vitals Optimization', 'autonomous-ai-seo'); ?></h1>
                <p><?php _e('Real-time performance monitoring and automated improvements', 'autonomous-ai-seo'); ?></p>
            </div>
            <div class="aaiseo-status">
                <button class="button button-primary" id="run-vitals-audit">
                    <?php _e('Run Performance Audit', 'autonomous-ai-seo'); ?>
                </button>
            </div>
        </div>
    </div>

    <!-- Overall Performance Score -->
    <div class="aaiseo-panel vitals-overview">
        <div class="panel-header">
            <h2><?php _e('Overall Performance Score', 'autonomous-ai-seo'); ?></h2>
            <div class="score-display">
                <div class="score-circle">
                    <span class="score-number">87</span>
                    <span class="score-label"><?php _e('Good', 'autonomous-ai-seo'); ?></span>
                </div>
            </div>
        </div>
        <div class="panel-content">
            <div class="vitals-grid">
                <?php
                $vitals = array(
                    array(
                        'name' => 'Largest Contentful Paint (LCP)',
                        'value' => '2.1s',
                        'threshold' => '2.5s',
                        'status' => 'good',
                        'description' => 'Measures loading performance'
                    ),
                    array(
                        'name' => 'First Input Delay (FID)',
                        'value' => '85ms',
                        'threshold' => '100ms',
                        'status' => 'good',
                        'description' => 'Measures interactivity'
                    ),
                    array(
                        'name' => 'Cumulative Layout Shift (CLS)',
                        'value' => '0.08',
                        'threshold' => '0.1',
                        'status' => 'needs-improvement',
                        'description' => 'Measures visual stability'
                    )
                );
                
                foreach ($vitals as $vital):
                ?>
                <div class="vital-card <?php echo $vital['status']; ?>">
                    <div class="vital-header">
                        <div class="vital-icon">
                            <?php if ($vital['status'] === 'good'): ?>
                                <span class="dashicons dashicons-yes-alt"></span>
                            <?php elseif ($vital['status'] === 'needs-improvement'): ?>
                                <span class="dashicons dashicons-warning"></span>
                            <?php else: ?>
                                <span class="dashicons dashicons-dismiss"></span>
                            <?php endif; ?>
                        </div>
                        <span class="vital-status <?php echo $vital['status']; ?>">
                            <?php echo ucwords(str_replace('-', ' ', $vital['status'])); ?>
                        </span>
                    </div>
                    
                    <h3><?php echo esc_html($vital['name']); ?></h3>
                    <p class="vital-description"><?php echo esc_html($vital['description']); ?></p>
                    
                    <div class="vital-metrics">
                        <div class="current-value">
                            <strong><?php echo esc_html($vital['value']); ?></strong>
                        </div>
                        <div class="target-value">
                            Target: &lt; <?php echo esc_html($vital['threshold']); ?>
                        </div>
                    </div>
                    
                    <div class="vital-progress">
                        <?php 
                        $percentage = 75; // This would be calculated based on actual values
                        if ($vital['status'] === 'good') $percentage = 85;
                        if ($vital['status'] === 'needs-improvement') $percentage = 65;
                        if ($vital['status'] === 'poor') $percentage = 35;
                        ?>
                        <div class="progress-bar">
                            <div class="progress-fill <?php echo $vital['status']; ?>" style="width: <?php echo $percentage; ?>%"></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Automated Optimizations -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Automated Optimizations', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <?php
            $optimizations = array(
                array(
                    'title' => 'Image Optimization',
                    'description' => 'Convert 34 images to WebP format and implement lazy loading',
                    'impact' => 'Reduce LCP by 0.8s',
                    'status' => 'completed',
                    'savings' => '1.2MB'
                ),
                array(
                    'title' => 'JavaScript Bundle Splitting',
                    'description' => 'Split large JS bundles and defer non-critical scripts',
                    'impact' => 'Improve FID by 15ms',
                    'status' => 'in-progress',
                    'savings' => '320KB'
                ),
                array(
                    'title' => 'Font Loading Optimization',
                    'description' => 'Implement font-display: swap and preload critical fonts',
                    'impact' => 'Reduce CLS by 0.03',
                    'status' => 'pending',
                    'savings' => '0.5s'
                ),
                array(
                    'title' => 'Critical CSS Inlining',
                    'description' => 'Inline above-the-fold CSS and defer non-critical styles',
                    'impact' => 'Improve LCP by 0.4s',
                    'status' => 'completed',
                    'savings' => '180KB'
                )
            );
            ?>
            
            <div class="optimizations-list">
                <?php foreach ($optimizations as $optimization): ?>
                <div class="optimization-item <?php echo $optimization['status']; ?>">
                    <div class="optimization-status">
                        <?php if ($optimization['status'] === 'completed'): ?>
                            <span class="dashicons dashicons-yes-alt"></span>
                        <?php elseif ($optimization['status'] === 'in-progress'): ?>
                            <span class="dashicons dashicons-update spin"></span>
                        <?php else: ?>
                            <span class="dashicons dashicons-clock"></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="optimization-content">
                        <h4><?php echo esc_html($optimization['title']); ?></h4>
                        <p><?php echo esc_html($optimization['description']); ?></p>
                        <div class="optimization-metrics">
                            <span class="impact"><?php echo esc_html($optimization['impact']); ?></span>
                            <span class="savings">Saved: <?php echo esc_html($optimization['savings']); ?></span>
                        </div>
                    </div>
                    
                    <div class="optimization-badge">
                        <span class="status-badge <?php echo $optimization['status']; ?>">
                            <?php echo ucwords(str_replace('-', ' ', $optimization['status'])); ?>
                        </span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div class="aaiseo-dashboard-grid">
        <!-- Performance Trends -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Performance Trends', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="chart-container">
                    <canvas id="performance-chart" width="400" height="200"></canvas>
                </div>
                <div class="trend-summary">
                    <div class="trend-item">
                        <span class="trend-label"><?php _e('LCP Improvement', 'autonomous-ai-seo'); ?></span>
                        <span class="trend-value positive">-0.8s</span>
                    </div>
                    <div class="trend-item">
                        <span class="trend-label"><?php _e('FID Improvement', 'autonomous-ai-seo'); ?></span>
                        <span class="trend-value positive">-25ms</span>
                    </div>
                    <div class="trend-item">
                        <span class="trend-label"><?php _e('CLS Improvement', 'autonomous-ai-seo'); ?></span>
                        <span class="trend-value positive">-0.05</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Optimization Impact -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Optimization Impact', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="impact-metrics">
                    <div class="impact-item">
                        <div class="impact-icon">
                            <span class="dashicons dashicons-performance"></span>
                        </div>
                        <div class="impact-content">
                            <span class="impact-value">+34%</span>
                            <span class="impact-label"><?php _e('Faster Page Load', 'autonomous-ai-seo'); ?></span>
                        </div>
                    </div>

                    <div class="impact-item">
                        <div class="impact-icon">
                            <span class="dashicons dashicons-star-filled"></span>
                        </div>
                        <div class="impact-content">
                            <span class="impact-value">+28</span>
                            <span class="impact-label"><?php _e('UX Score Points', 'autonomous-ai-seo'); ?></span>
                        </div>
                    </div>

                    <div class="impact-item">
                        <div class="impact-icon">
                            <span class="dashicons dashicons-chart-line"></span>
                        </div>
                        <div class="impact-content">
                            <span class="impact-value">-15%</span>
                            <span class="impact-label"><?php _e('Lower Bounce Rate', 'autonomous-ai-seo'); ?></span>
                        </div>
                    </div>

                    <div class="impact-item">
                        <div class="impact-icon">
                            <span class="dashicons dashicons-search"></span>
                        </div>
                        <div class="impact-content">
                            <span class="impact-value">+12</span>
                            <span class="impact-label"><?php _e('SEO Score Points', 'autonomous-ai-seo'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Monitoring & Alerts -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Monitoring & Alerts', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <?php $settings = get_option('aaiseo_settings', array()); ?>
            <div class="monitoring-controls">
                <div class="control-item">
                    <label class="aaiseo-toggle">
                        <input type="checkbox" checked data-setting="real_time_monitoring">
                        <span class="aaiseo-toggle-slider"></span>
                    </label>
                    <div class="control-info">
                        <h4><?php _e('Real-time Monitoring', 'autonomous-ai-seo'); ?></h4>
                        <p><?php _e('Continuously monitor Core Web Vitals performance', 'autonomous-ai-seo'); ?></p>
                    </div>
                </div>

                <div class="control-item">
                    <label class="aaiseo-toggle">
                        <input type="checkbox" checked data-setting="auto_optimization">
                        <span class="aaiseo-toggle-slider"></span>
                    </label>
                    <div class="control-info">
                        <h4><?php _e('Auto-Optimization', 'autonomous-ai-seo'); ?></h4>
                        <p><?php _e('Automatically apply performance optimizations', 'autonomous-ai-seo'); ?></p>
                    </div>
                </div>

                <div class="control-item">
                    <label class="aaiseo-toggle">
                        <input type="checkbox" checked data-setting="performance_alerts">
                        <span class="aaiseo-toggle-slider"></span>
                    </label>
                    <div class="control-info">
                        <h4><?php _e('Performance Alerts', 'autonomous-ai-seo'); ?></h4>
                        <p><?php _e('Get notified when performance degrades', 'autonomous-ai-seo'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.vitals-overview .panel-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.score-circle {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: conic-gradient(#10b981 0deg 313deg, #e5e7eb 313deg 360deg);
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
}

.score-circle::before {
    content: '';
    width: 60px;
    height: 60px;
    background: white;
    border-radius: 50%;
    position: absolute;
}

.score-number {
    position: relative;
    z-index: 1;
    font-size: 18px;
    font-weight: 700;
    color: #1f2937;
    line-height: 1;
}

.score-label {
    position: absolute;
    bottom: 8px;
    font-size: 10px;
    color: #6b7280;
    z-index: 1;
}

.vitals-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

.vital-card {
    padding: 20px;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    transition: all 0.2s ease;
}

.vital-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.vital-card.good {
    border-left: 4px solid #10b981;
    background: #f0fdf4;
}

.vital-card.needs-improvement {
    border-left: 4px solid #f59e0b;
    background: #fffbeb;
}

.vital-card.poor {
    border-left: 4px solid #ef4444;
    background: #fef2f2;
}

.vital-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
}

.vital-icon {
    width: 32px;
    height: 32px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.vital-card.good .vital-icon {
    background: #dcfce7;
    color: #16a34a;
}

.vital-card.needs-improvement .vital-icon {
    background: #fef3c7;
    color: #d97706;
}

.vital-card.poor .vital-icon {
    background: #fee2e2;
    color: #dc2626;
}

.vital-status {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}

.vital-status.good {
    background: #dcfce7;
    color: #16a34a;
}

.vital-status.needs-improvement {
    background: #fef3c7;
    color: #d97706;
}

.vital-status.poor {
    background: #fee2e2;
    color: #dc2626;
}

.vital-card h3 {
    margin: 0 0 8px 0;
    font-size: 16px;
    font-weight: 600;
    color: #1f2937;
}

.vital-description {
    margin: 0 0 16px 0;
    color: #6b7280;
    font-size: 14px;
}

.vital-metrics {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
}

.current-value {
    font-size: 24px;
    font-weight: 700;
    color: #1f2937;
}

.target-value {
    font-size: 12px;
    color: #6b7280;
}

.vital-progress {
    width: 100%;
}

.progress-bar {
    width: 100%;
    height: 8px;
    background: #e5e7eb;
    border-radius: 4px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    border-radius: 4px;
    transition: width 0.3s ease;
}

.progress-fill.good {
    background: #10b981;
}

.progress-fill.needs-improvement {
    background: #f59e0b;
}

.progress-fill.poor {
    background: #ef4444;
}

.optimizations-list {
    space-y: 16px;
}

.optimization-item {
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 16px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    transition: all 0.2s ease;
}

.optimization-item:hover {
    background: #f9fafb;
}

.optimization-item.completed {
    background: #f0fdf4;
    border-color: #bbf7d0;
}

.optimization-item.in-progress {
    background: #fffbeb;
    border-color: #fed7aa;
}

.optimization-status {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.optimization-item.completed .optimization-status {
    background: #dcfce7;
    color: #16a34a;
}

.optimization-item.in-progress .optimization-status {
    background: #fef3c7;
    color: #d97706;
}

.optimization-item.pending .optimization-status {
    background: #f3f4f6;
    color: #6b7280;
}

.optimization-content {
    flex: 1;
}

.optimization-content h4 {
    margin: 0 0 4px 0;
    font-size: 16px;
    font-weight: 600;
    color: #1f2937;
}

.optimization-content p {
    margin: 0 0 8px 0;
    color: #6b7280;
    font-size: 14px;
}

.optimization-metrics {
    display: flex;
    gap: 16px;
    font-size: 12px;
}

.impact {
    color: #16a34a;
    font-weight: 600;
}

.savings {
    color: #3b82f6;
    font-weight: 600;
}

.status-badge {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: capitalize;
}

.status-badge.completed {
    background: #dcfce7;
    color: #16a34a;
}

.status-badge.in-progress {
    background: #fef3c7;
    color: #d97706;
}

.status-badge.pending {
    background: #f3f4f6;
    color: #6b7280;
}

.chart-container {
    height: 200px;
    margin-bottom: 20px;
}

.trend-summary {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
}

.trend-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 12px;
    background: #f9fafb;
    border-radius: 6px;
}

.trend-label {
    font-size: 12px;
    color: #6b7280;
}

.trend-value {
    font-weight: 600;
    font-size: 14px;
}

.trend-value.positive {
    color: #16a34a;
}

.trend-value.negative {
    color: #dc2626;
}

.impact-metrics {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
}

.impact-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 16px;
    background: #f9fafb;
    border-radius: 8px;
}

.impact-icon {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    background: #e0e7ff;
    color: #3730a3;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.impact-value {
    display: block;
    font-size: 20px;
    font-weight: 700;
    color: #16a34a;
    line-height: 1;
}

.impact-label {
    font-size: 12px;
    color: #6b7280;
}

.monitoring-controls {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

.control-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 20px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    background: #f9fafb;
}

.control-info h4 {
    margin: 0 0 4px 0;
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
}

.control-info p {
    margin: 0;
    font-size: 12px;
    color: #6b7280;
}

.spin {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Initialize performance chart
    initializePerformanceChart();
    
    // Run vitals audit
    $('#run-vitals-audit').on('click', function() {
        runVitalsAudit();
    });
    
    // Settings toggles
    $('input[data-setting]').on('change', function() {
        const setting = $(this).data('setting');
        const value = $(this).is(':checked');
        saveSetting(setting, value);
    });
    
    function initializePerformanceChart() {
        const ctx = document.getElementById('performance-chart');
        if (!ctx) return;
        
        // Generate sample performance data
        const labels = [];
        const lcpData = [];
        const fidData = [];
        const clsData = [];
        
        for (let i = 29; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
            
            lcpData.push((Math.random() * 1 + 1.5).toFixed(1));
            fidData.push(Math.floor(Math.random() * 50 + 50));
            clsData.push((Math.random() * 0.1 + 0.05).toFixed(2));
        }
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'LCP (seconds)',
                    data: lcpData,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y'
                }, {
                    label: 'FID (ms)',
                    data: fidData,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y1'
                }, {
                    label: 'CLS',
                    data: clsData,
                    borderColor: '#f59e0b',
                    backgroundColor: 'rgba(245, 158, 11, 0.1)',
                    tension: 0.4,
                    yAxisID: 'y2'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'LCP (seconds)'
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: false,
                        position: 'right'
                    },
                    y2: {
                        type: 'linear',
                        display: false,
                        position: 'right'
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom'
                    }
                }
            }
        });
    }
    
    function runVitalsAudit() {
        const button = $('#run-vitals-audit');
        const originalText = button.text();
        
        button.prop('disabled', true).text('Running Audit...');
        
        // Simulate audit process
        setTimeout(function() {
            showNotice('success', 'Performance audit completed successfully');
            button.prop('disabled', false).text(originalText);
            
            // Simulate some improvements
            $('.vital-card.needs-improvement').removeClass('needs-improvement').addClass('good');
            $('.vital-status.needs-improvement').removeClass('needs-improvement').addClass('good').text('Good');
            $('.progress-fill.needs-improvement').removeClass('needs-improvement').addClass('good').css('width', '85%');
        }, 3000);
    }
    
    function saveSetting(name, value) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_save_setting',
                setting_name: name,
                setting_value: value,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', 'Setting saved successfully');
                }
            }
        });
    }
    
    function showNotice(type, message) {
        const notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
        $('.wrap').prepend(notice);
        setTimeout(() => notice.fadeOut(), 5000);
    }
});
</script>