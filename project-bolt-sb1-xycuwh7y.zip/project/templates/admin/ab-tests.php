<?php
/**
 * A/B Tests template for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get A/B tests
$ab_testing = AAISEO_AB_Testing::getInstance();
$active_tests = array();
$completed_tests = array();

global $wpdb;
$table_name = $wpdb->prefix . 'aaiseo_ab_tests';

$tests = $wpdb->get_results(
    "SELECT t.*, p.post_title 
    FROM $table_name t
    LEFT JOIN {$wpdb->posts} p ON t.post_id = p.ID
    ORDER BY t.created_at DESC",
    ARRAY_A
);

if ($tests) {
    foreach ($tests as $test) {
        if ($test['status'] === 'active') {
            $active_tests[] = $test;
        } else {
            $completed_tests[] = $test;
        }
    }
}
?>

<div class="wrap aaiseo-dashboard">
    <div class="aaiseo-header">
        <div class="aaiseo-header-content">
            <div class="aaiseo-logo">
                <h1><?php _e('A/B Testing Dashboard', 'autonomous-ai-seo'); ?></h1>
                <p><?php _e('Test different content variations to optimize conversions', 'autonomous-ai-seo'); ?></p>
            </div>
        </div>
    </div>

    <!-- Summary Metrics -->
    <div class="aaiseo-metrics-grid">
        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-chart-bar"></span>
            </div>
            <div class="metric-content">
                <h3><?php echo count($active_tests); ?></h3>
                <p><?php _e('Active Tests', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive"><?php echo count($active_tests) > 0 ? 'Running' : 'None'; ?></span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-yes-alt"></span>
            </div>
            <div class="metric-content">
                <h3><?php echo count($completed_tests); ?></h3>
                <p><?php _e('Completed Tests', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change"><?php echo count($completed_tests) > 0 ? 'Successful' : 'None'; ?></span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-chart-area"></span>
            </div>
            <div class="metric-content">
                <h3><?php echo count($active_tests) + count($completed_tests); ?></h3>
                <p><?php _e('Total Tests', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">Data-driven optimization</span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-admin-tools"></span>
            </div>
            <div class="metric-content">
                <h3><?php 
                    $improvement = 0;
                    foreach ($completed_tests as $test) {
                        if (!empty($test['winning_variation']) && $test['winning_variation'] > 0) {
                            $improvement++;
                        }
                    }
                    echo $improvement > 0 ? '+' . $improvement : '0';
                ?></h3>
                <p><?php _e('Improvements Made', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">Optimized content</span>
            </div>
        </div>
    </div>

    <!-- Active Tests -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Active A/B Tests', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <?php if (!empty($active_tests)): ?>
                <div class="ab-tests-table">
                    <table>
                        <thead>
                            <tr>
                                <th><?php _e('Post/Page', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Element Type', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Start Date', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Impressions', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Duration', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Status', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Actions', 'autonomous-ai-seo'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($active_tests as $test): 
                                $test_id = $test['id'];
                                $impressions = $wpdb->get_var(
                                    $wpdb->prepare(
                                        "SELECT SUM(impressions) FROM {$wpdb->prefix}aaiseo_ab_test_results WHERE test_id = %d",
                                        $test_id
                                    )
                                );
                                $duration = human_time_diff(strtotime($test['start_date']), current_time('timestamp'));
                            ?>
                                <tr>
                                    <td><?php echo esc_html($test['post_title']); ?></td>
                                    <td>
                                        <span class="element-type-badge">
                                            <?php echo esc_html(ucwords(str_replace('_', ' ', $test['element_type']))); ?>
                                        </span>
                                    </td>
                                    <td><?php echo esc_html(date('M j, Y', strtotime($test['start_date']))); ?></td>
                                    <td><?php echo intval($impressions); ?></td>
                                    <td><?php echo esc_html($duration); ?></td>
                                    <td>
                                        <span class="ab-test-status active">
                                            <?php _e('Running', 'autonomous-ai-seo'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="button button-primary button-small view-ab-test" 
                                                data-test-id="<?php echo intval($test_id); ?>">
                                            <?php _e('View Results', 'autonomous-ai-seo'); ?>
                                        </button>
                                        <button class="button button-secondary button-small stop-ab-test" 
                                                data-test-id="<?php echo intval($test_id); ?>">
                                            <?php _e('Stop Test', 'autonomous-ai-seo'); ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="no-data"><?php _e('No active A/B tests. Create a test to optimize your content.', 'autonomous-ai-seo'); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Completed Tests -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Completed A/B Tests', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <?php if (!empty($completed_tests)): ?>
                <div class="ab-tests-table">
                    <table>
                        <thead>
                            <tr>
                                <th><?php _e('Post/Page', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Element Type', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Duration', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Total Impressions', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Winning Variation', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Improvement', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Actions', 'autonomous-ai-seo'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($completed_tests as $test): 
                                $test_id = $test['id'];
                                $winning_variation = $test['winning_variation'] ?? 0;
                                $impressions = $wpdb->get_var(
                                    $wpdb->prepare(
                                        "SELECT SUM(impressions) FROM {$wpdb->prefix}aaiseo_ab_test_results WHERE test_id = %d",
                                        $test_id
                                    )
                                );
                                $duration = '';
                                if (!empty($test['start_date']) && !empty($test['end_date'])) {
                                    $start = strtotime($test['start_date']);
                                    $end = strtotime($test['end_date']);
                                    $duration = human_time_diff($start, $end);
                                }
                                
                                // Calculate improvement percentage
                                $improvement = '0%';
                                if (!empty($winning_variation) && $winning_variation > 0) {
                                    $results = $wpdb->get_results(
                                        $wpdb->prepare(
                                            "SELECT * FROM {$wpdb->prefix}aaiseo_ab_test_results WHERE test_id = %d",
                                            $test_id
                                        ),
                                        ARRAY_A
                                    );
                                    
                                    if (!empty($results)) {
                                        $original = array_filter($results, function($result) {
                                            return $result['variation_id'] == 0;
                                        });
                                        
                                        $winner = array_filter($results, function($result) use ($winning_variation) {
                                            return $result['variation_id'] == $winning_variation;
                                        });
                                        
                                        if (!empty($original) && !empty($winner)) {
                                            $original = reset($original);
                                            $winner = reset($winner);
                                            
                                            if (!empty($original['impressions']) && !empty($winner['impressions'])) {
                                                $original_ctr = ($original['clicks'] / $original['impressions']) * 100;
                                                $winner_ctr = ($winner['clicks'] / $winner['impressions']) * 100;
                                                
                                                if ($original_ctr > 0) {
                                                    $improvement_pct = (($winner_ctr - $original_ctr) / $original_ctr) * 100;
                                                    $improvement = round($improvement_pct, 1) . '%';
                                                }
                                            }
                                        }
                                    }
                                }
                            ?>
                                <tr>
                                    <td><?php echo esc_html($test['post_title']); ?></td>
                                    <td>
                                        <span class="element-type-badge">
                                            <?php echo esc_html(ucwords(str_replace('_', ' ', $test['element_type']))); ?>
                                        </span>
                                    </td>
                                    <td><?php echo esc_html($duration); ?></td>
                                    <td><?php echo intval($impressions); ?></td>
                                    <td>
                                        <?php if (!empty($winning_variation)): ?>
                                            <span class="winning-variation">
                                                <?php echo $winning_variation === 0 ? __('Original', 'autonomous-ai-seo') : __('Variation', 'autonomous-ai-seo') . ' ' . $winning_variation; ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="no-winner">
                                                <?php _e('No clear winner', 'autonomous-ai-seo'); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="improvement <?php echo strpos($improvement, '-') !== false ? 'negative' : 'positive'; ?>">
                                            <?php echo esc_html($improvement); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="button button-primary button-small view-ab-test-results" 
                                                data-test-id="<?php echo intval($test_id); ?>">
                                            <?php _e('View Report', 'autonomous-ai-seo'); ?>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="no-data"><?php _e('No completed A/B tests yet. Tests will appear here once completed.', 'autonomous-ai-seo'); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <!-- A/B Test Results Modal -->
    <div id="ab-test-results-modal" class="ab-test-modal">
        <div class="ab-test-modal-content">
            <div class="ab-test-modal-header">
                <h2><?php _e('A/B Test Results', 'autonomous-ai-seo'); ?></h2>
                <span class="ab-test-modal-close">&times;</span>
            </div>
            <div id="ab-test-results-content">
                <div class="loading">
                    <span class="spinner is-active"></span>
                    <span><?php _e('Loading test results...', 'autonomous-ai-seo'); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* A/B Testing Styles */
.ab-tests-table {
    overflow-x: auto;
}

.ab-tests-table table {
    width: 100%;
    border-collapse: collapse;
}

.ab-tests-table th,
.ab-tests-table td {
    padding: 12px 8px;
    text-align: left;
    border-bottom: 1px solid #f3f4f6;
}

.element-type-badge {
    padding: 4px 8px;
    background: #e0e7ff;
    color: #3730a3;
    border-radius: 8px;
    font-size: 12px;
}

.ab-test-status {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
    text-transform: capitalize;
}

.ab-test-status.active {
    background: #dcfce7;
    color: #16a34a;
}

.ab-test-status.completed {
    background: #f3f4f6;
    color: #6b7280;
}

.winning-variation {
    font-weight: 600;
    color: #16a34a;
}

.no-winner {
    color: #6b7280;
    font-style: italic;
}

.improvement {
    font-weight: 600;
}

.improvement.positive {
    color: #16a34a;
}

.improvement.negative {
    color: #dc2626;
}

.ab-test-modal {
    display: none;
    position: fixed;
    z-index: 9999;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    overflow: auto;
}

.ab-test-modal-content {
    background: white;
    margin: 5% auto;
    padding: 20px;
    border-radius: 12px;
    max-width: 800px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
    position: relative;
}

.ab-test-modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    border-bottom: 1px solid #e5e7eb;
    padding-bottom: 15px;
}

.ab-test-modal-header h2 {
    margin: 0;
    font-size: 18px;
}

.ab-test-modal-close {
    cursor: pointer;
    font-size: 22px;
    font-weight: 700;
    color: #6b7280;
}

.ab-test-results-summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-bottom: 20px;
}

.result-card {
    padding: 15px;
    border-radius: 8px;
    background: #f9fafb;
    border: 1px solid #e5e7eb;
}

.result-card-title {
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 5px;
    color: #1f2937;
}

.result-card-value {
    font-size: 24px;
    font-weight: 700;
    color: #1f2937;
}

.result-card-meta {
    font-size: 12px;
    color: #6b7280;
    margin-top: 5px;
}

.results-chart-container {
    height: 300px;
    margin-bottom: 20px;
}

.variations-results {
    margin-top: 20px;
}

.variation-result {
    margin-bottom: 15px;
    padding: 15px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
}

.variation-result.winner {
    border-color: #16a34a;
    background: #f0fdf4;
}

.variation-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.variation-title {
    font-weight: 600;
    color: #1f2937;
}

.winner-badge {
    padding: 4px 8px;
    background: #dcfce7;
    color: #16a34a;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
}

.variation-content {
    padding: 10px;
    background: #f9fafb;
    border-radius: 4px;
    margin-bottom: 10px;
}

.variation-metrics {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
}

.metric {
    text-align: center;
}

.metric-label {
    font-size: 12px;
    color: #6b7280;
    margin-bottom: 4px;
}

.metric-value {
    font-weight: 600;
    color: #1f2937;
}

.loading {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    padding: 20px;
}

.spinner {
    float: none;
    margin: 0;
}

@media (max-width: 768px) {
    .ab-test-results-summary,
    .variation-metrics {
        grid-template-columns: 1fr 1fr;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // View A/B test results
    $('.view-ab-test, .view-ab-test-results').on('click', function() {
        const testId = $(this).data('test-id');
        viewABTestResults(testId);
    });
    
    // Stop A/B test
    $('.stop-ab-test').on('click', function() {
        const testId = $(this).data('test-id');
        if (confirm('Are you sure you want to stop this A/B test? This will determine a winner and apply the changes.')) {
            stopABTest(testId);
        }
    });
    
    function viewABTestResults(testId) {
        $('#ab-test-results-modal').show();
        $('#ab-test-results-content').html('<div class="loading"><span class="spinner is-active"></span><span>Loading test results...</span></div>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_get_ab_test_results',
                test_id: testId,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    renderTestResults(response.data, testId);
                } else {
                    $('#ab-test-results-content').html('<p>Failed to load test results.</p>');
                }
            },
            error: function() {
                $('#ab-test-results-content').html('<p>An error occurred while loading test results.</p>');
            }
        });
    }
    
    function renderTestResults(results, testId) {
        const resultsContent = $('#ab-test-results-content');
        
        // Determine if there's a clear winner
        let winner = null;
        let highestCTR = 0;
        
        results.forEach(variation => {
            const ctr = variation.impressions > 0 ? (variation.clicks / variation.impressions * 100) : 0;
            if (ctr > highestCTR) {
                highestCTR = ctr;
                winner = variation;
            }
        });
        
        // Calculate confidence and significance
        const hasSignificance = results.some(variation => variation.is_significant);
        
        // Create summary HTML
        const totalImpressions = results.reduce((sum, variation) => sum + variation.impressions, 0);
        const totalClicks = results.reduce((sum, variation) => sum + variation.clicks, 0);
        const averageCTR = totalImpressions > 0 ? (totalClicks / totalImpressions * 100).toFixed(2) : '0';
        
        let html = `
            <div class="ab-test-results-summary">
                <div class="result-card">
                    <div class="result-card-title">${results.length} Variations</div>
                    <div class="result-card-value">${totalImpressions}</div>
                    <div class="result-card-meta">Total Impressions</div>
                </div>
                
                <div class="result-card">
                    <div class="result-card-title">Overall Engagement</div>
                    <div class="result-card-value">${totalClicks}</div>
                    <div class="result-card-meta">Total Clicks</div>
                </div>
                
                <div class="result-card">
                    <div class="result-card-title">Average CTR</div>
                    <div class="result-card-value">${averageCTR}%</div>
                    <div class="result-card-meta">Click-through Rate</div>
                </div>
                
                <div class="result-card">
                    <div class="result-card-title">Statistical Confidence</div>
                    <div class="result-card-value">${hasSignificance ? 'High' : 'Low'}</div>
                    <div class="result-card-meta">${hasSignificance ? 'Significant Results' : 'More data needed'}</div>
                </div>
            </div>
            
            <div class="results-chart-container">
                <canvas id="results-chart"></canvas>
            </div>
            
            <h3>Variation Performance</h3>
            <div class="variations-results">
        `;
        
        // Add each variation
        results.forEach(variation => {
            const isWinner = winner && variation.variation_id === winner.variation_id;
            const ctr = variation.impressions > 0 ? (variation.clicks / variation.impressions * 100).toFixed(2) : '0';
            const conversionRate = variation.clicks > 0 ? (variation.conversions / variation.clicks * 100).toFixed(2) : '0';
            
            html += `
                <div class="variation-result ${isWinner ? 'winner' : ''}">
                    <div class="variation-header">
                        <div class="variation-title">
                            ${variation.variation_id === 0 ? 'Original' : 'Variation ' + variation.variation_id}
                        </div>
                        ${isWinner ? '<div class="winner-badge">Winner</div>' : ''}
                    </div>
                    
                    <div class="variation-content">
                        ${variation.variation_content || 'Original content'}
                    </div>
                    
                    <div class="variation-metrics">
                        <div class="metric">
                            <div class="metric-label">Impressions</div>
                            <div class="metric-value">${variation.impressions}</div>
                        </div>
                        
                        <div class="metric">
                            <div class="metric-label">Clicks</div>
                            <div class="metric-value">${variation.clicks}</div>
                        </div>
                        
                        <div class="metric">
                            <div class="metric-label">CTR</div>
                            <div class="metric-value">${ctr}%</div>
                        </div>
                        
                        <div class="metric">
                            <div class="metric-label">Conversions</div>
                            <div class="metric-value">${variation.conversions} (${conversionRate}%)</div>
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += `
            </div>
            
            <div class="ab-test-controls">
                ${results[0].status !== 'completed' ? `
                <button class="button button-primary stop-test-from-modal" data-test-id="${testId}">
                    ${winner ? 'End Test & Apply Winner' : 'End Test'}
                </button>
                ` : ''}
            </div>
        `;
        
        resultsContent.html(html);
        
        // Initialize chart
        initializeResultsChart(results);
        
        // Add event handlers
        $('.stop-test-from-modal').on('click', function() {
            const testId = $(this).data('test-id');
            const winningVariationId = winner ? winner.variation_id : null;
            
            stopABTest(testId, winningVariationId);
        });
    }
    
    function initializeResultsChart(results) {
        const ctx = document.getElementById('results-chart');
        if (!ctx) return;
        
        const labels = results.map(variation => 
            variation.variation_id === 0 ? 'Original' : 'Variation ' + variation.variation_id
        );
        
        const ctrData = results.map(variation => 
            variation.impressions > 0 ? (variation.clicks / variation.impressions * 100).toFixed(2) : 0
        );
        
        const colors = results.map((variation, index) => {
            if (index === 0) return 'rgba(156, 163, 175, 0.8)'; // Original in gray
            return `rgba(${59 + index * 20}, ${130 - index * 10}, 246, 0.8)`; // Variations in blue shades
        });
        
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Click-Through Rate (%)',
                    data: ctrData,
                    backgroundColor: colors,
                    borderColor: colors.map(color => color.replace('0.8', '1')),
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'CTR (%)'
                        }
                    }
                }
            }
        });
    }
    
    function stopABTest(testId, winningVariationId = null) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_stop_ab_test',
                test_id: testId,
                winning_variation: winningVariationId,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data);
                    
                    // Close modal if open
                    $('#ab-test-results-modal').hide();
                    
                    // Refresh the page after a delay
                    setTimeout(() => location.reload(), 2000);
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'An error occurred while stopping the A/B test.');
            }
        });
    }
    
    // Close modal
    $('.ab-test-modal-close').on('click', function() {
        $('#ab-test-results-modal').hide();
    });
    
    // Outside click to close modal
    $(window).on('click', function(event) {
        if ($(event.target).hasClass('ab-test-modal')) {
            $('.ab-test-modal').hide();
        }
    });
    
    function showNotice(type, message) {
        const notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
        $('.wrap').prepend(notice);
        setTimeout(() => notice.fadeOut(), 5000);
    }
});
</script>