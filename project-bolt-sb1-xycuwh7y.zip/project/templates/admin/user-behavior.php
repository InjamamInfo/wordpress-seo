<?php
/**
 * User Behavior tracking template for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get user tracking class
$user_tracking = AAISEO_User_Tracking::getInstance();

// Get pages with behavior data
$pages = $user_tracking->getPagesWithBehaviorData();

?>

<div class="wrap aaiseo-dashboard">
    <div class="aaiseo-header">
        <div class="aaiseo-header-content">
            <div class="aaiseo-logo">
                <h1><?php _e('User Behavior Analysis', 'autonomous-ai-seo'); ?></h1>
                <p><?php _e('Analyze user behavior and optimize for conversions', 'autonomous-ai-seo'); ?></p>
            </div>
            <div class="aaiseo-status">
                <button class="button button-primary" id="generate-insights">
                    <?php _e('Generate AI Insights', 'autonomous-ai-seo'); ?>
                </button>
            </div>
        </div>
    </div>

    <!-- Page Selection -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Select Page to Analyze', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <?php if (!empty($pages)): ?>
                <select id="page-selector" class="widefat">
                    <option value=""><?php _e('-- Select a page --', 'autonomous-ai-seo'); ?></option>
                    <?php foreach ($pages as $page): ?>
                        <option value="<?php echo intval($page['ID']); ?>" data-views="<?php echo intval($page['view_count']); ?>">
                            <?php echo esc_html($page['post_title']); ?> (<?php echo intval($page['view_count']); ?> views)
                        </option>
                    <?php endforeach; ?>
                </select>
            <?php else: ?>
                <p class="no-data"><?php _e('No pages with user behavior data found. Please wait for more data to be collected.', 'autonomous-ai-seo'); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Behavior Metrics -->
    <div id="behavior-metrics" class="aaiseo-metrics-grid" style="display: none;">
        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-visibility"></span>
            </div>
            <div class="metric-content">
                <h3 id="metric-views">0</h3>
                <p><?php _e('Page Views', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change"></span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-admin-site"></span>
            </div>
            <div class="metric-content">
                <h3 id="metric-time">0s</h3>
                <p><?php _e('Avg. Time on Page', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change"></span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-arrow-down-alt"></span>
            </div>
            <div class="metric-content">
                <h3 id="metric-scroll">0%</h3>
                <p><?php _e('Avg. Scroll Depth', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change"></span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-chart-bar"></span>
            </div>
            <div class="metric-content">
                <h3 id="metric-engagement">0</h3>
                <p><?php _e('Engagement Score', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change"></span>
            </div>
        </div>
    </div>

    <div class="aaiseo-dashboard-grid" id="behavior-grid" style="display: none;">
        <!-- Heatmap -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Click Heatmap', 'autonomous-ai-seo'); ?></h2>
                <div class="view-controls">
                    <select id="heatmap-period">
                        <option value="7"><?php _e('Last 7 Days', 'autonomous-ai-seo'); ?></option>
                        <option value="30" selected><?php _e('Last 30 Days', 'autonomous-ai-seo'); ?></option>
                        <option value="90"><?php _e('Last 90 Days', 'autonomous-ai-seo'); ?></option>
                    </select>
                </div>
            </div>
            <div class="panel-content">
                <div class="heatmap-container">
                    <div id="heatmap-placeholder" class="placeholder-content">
                        <p><?php _e('Select a page to view heatmap data.', 'autonomous-ai-seo'); ?></p>
                    </div>
                    <div id="heatmap-wrapper" style="display: none;">
                        <div id="heatmap-overlay"></div>
                        <iframe id="page-iframe" src="" frameborder="0"></iframe>
                    </div>
                    <div id="heatmap-loading" style="display: none;">
                        <span class="spinner is-active"></span>
                        <span><?php _e('Loading heatmap data...', 'autonomous-ai-seo'); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- User Journey -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('User Engagement', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="engagement-charts">
                    <div class="chart-container">
                        <canvas id="scroll-chart" width="400" height="200"></canvas>
                    </div>
                    <div class="chart-container">
                        <canvas id="time-chart" width="400" height="200"></canvas>
                    </div>
                </div>
                <div class="engagement-insights">
                    <h3><?php _e('Key Insights', 'autonomous-ai-seo'); ?></h3>
                    <div id="engagement-insights-content">
                        <p class="placeholder-text"><?php _e('Select a page to view engagement insights.', 'autonomous-ai-seo'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Conversion Opportunities -->
    <div class="aaiseo-panel" id="conversion-opportunities" style="display: none;">
        <div class="panel-header">
            <h2><?php _e('AI-Powered Conversion Opportunities', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <div id="ai-recommendations">
                <div class="loading-recommendations" style="display: none;">
                    <span class="spinner is-active"></span>
                    <span><?php _e('Generating AI recommendations...', 'autonomous-ai-seo'); ?></span>
                </div>
                <div id="recommendation-placeholder" class="placeholder-content">
                    <p><?php _e('Click "Generate AI Insights" to get personalized recommendations for improving conversions.', 'autonomous-ai-seo'); ?></p>
                </div>
                <div id="recommendations-content"></div>
            </div>
        </div>
    </div>
</div>

<style>
.heatmap-container {
    position: relative;
    width: 100%;
    height: 600px;
    background: #f9fafb;
    border-radius: 8px;
    overflow: hidden;
}

.placeholder-content {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    flex-direction: column;
    color: #6b7280;
}

#page-iframe {
    width: 100%;
    height: 600px;
}

#heatmap-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 100;
}

#heatmap-loading {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 101;
}

.engagement-charts {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    margin-bottom: 30px;
}

.chart-container {
    flex: 1;
    min-width: 300px;
    height: 250px;
}

.engagement-insights {
    background: #f9fafb;
    padding: 20px;
    border-radius: 8px;
}

.engagement-insights h3 {
    margin-top: 0;
    margin-bottom: 15px;
    font-size: 16px;
    color: #1f2937;
}

.insight-item {
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 1px solid #e5e7eb;
}

.insight-item:last-child {
    margin-bottom: 0;
    padding-bottom: 0;
    border-bottom: none;
}

.insight-title {
    font-weight: 600;
    color: #1f2937;
    margin-bottom: 5px;
}

.insight-description {
    color: #6b7280;
    font-size: 14px;
    line-height: 1.5;
}

.insight-priority {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
    margin-left: 8px;
}

.insight-priority.high {
    background: #fee2e2;
    color: #dc2626;
}

.insight-priority.medium {
    background: #fef3c7;
    color: #d97706;
}

.insight-priority.low {
    background: #dcfce7;
    color: #16a34a;
}

.ai-recommendation {
    background: #f0f9ff;
    border: 1px solid #bae6fd;
    border-left: 4px solid #0ea5e9;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    position: relative;
}

.ai-recommendation:last-child {
    margin-bottom: 0;
}

.ai-recommendation-title {
    font-size: 16px;
    font-weight: 600;
    color: #1f2937;
    margin-bottom: 10px;
}

.ai-recommendation-content {
    color: #6b7280;
    margin-bottom: 15px;
    line-height: 1.5;
}

.ai-recommendation-actions {
    display: flex;
    gap: 10px;
}

.ai-badge {
    position: absolute;
    top: 15px;
    right: 15px;
    background: #0ea5e9;
    color: white;
    font-size: 10px;
    font-weight: 600;
    padding: 2px 6px;
    border-radius: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

@media (max-width: 768px) {
    .engagement-charts {
        flex-direction: column;
    }
    
    .chart-container {
        width: 100%;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Page selector change
    $('#page-selector').on('change', function() {
        const pageId = $(this).val();
        
        if (!pageId) {
            $('#behavior-metrics, #behavior-grid, #conversion-opportunities').hide();
            return;
        }
        
        $('#behavior-metrics, #behavior-grid, #conversion-opportunities').show();
        
        // Update metrics
        loadPageMetrics(pageId);
        
        // Load heatmap
        loadHeatmap(pageId);
        
        // Load engagement charts
        loadEngagementCharts(pageId);
        
        // Load insights
        loadEngagementInsights(pageId);
    });
    
    // Generate insights button
    $('#generate-insights').on('click', function() {
        const pageId = $('#page-selector').val();
        
        if (!pageId) {
            alert('<?php _e('Please select a page first.', 'autonomous-ai-seo'); ?>');
            return;
        }
        
        generateAIRecommendations(pageId);
    });
    
    // Heatmap period change
    $('#heatmap-period').on('change', function() {
        const pageId = $('#page-selector').val();
        if (pageId) {
            loadHeatmap(pageId);
        }
    });
    
    /**
     * Load page metrics
     */
    function loadPageMetrics(pageId) {
        // Show loading state
        $('#metric-views').text('-');
        $('#metric-time').text('-');
        $('#metric-scroll').text('-');
        $('#metric-engagement').text('-');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_get_page_metrics',
                page_id: pageId,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    
                    // Update metrics
                    $('#metric-views').text(data.scroll_data.view_count);
                    
                    // Format time
                    const time = parseInt(data.scroll_data.avg_time_on_page);
                    if (time < 60) {
                        $('#metric-time').text(time + 's');
                    } else {
                        const minutes = Math.floor(time / 60);
                        const seconds = time % 60;
                        $('#metric-time').text(minutes + 'm ' + seconds + 's');
                    }
                    
                    // Format scroll depth
                    $('#metric-scroll').text(Math.round(data.scroll_data.avg_scroll_depth) + '%');
                    
                    // Format engagement score
                    $('#metric-engagement').text(data.engagement_score);
                    
                    // Add indicators for metrics
                    addMetricIndicators(data);
                } else {
                    // Handle error
                    $('#metric-views').text('0');
                    $('#metric-time').text('0s');
                    $('#metric-scroll').text('0%');
                    $('#metric-engagement').text('0');
                }
            },
            error: function() {
                // Handle error
                $('#metric-views').text('Error');
                $('#metric-time').text('Error');
                $('#metric-scroll').text('Error');
                $('#metric-engagement').text('Error');
            }
        });
    }
    
    /**
     * Add metric indicators
     */
    function addMetricIndicators(data) {
        // Time on page indicator
        const avgTime = parseInt(data.scroll_data.avg_time_on_page);
        let timeIndicator = '';
        
        if (avgTime > 180) { // More than 3 minutes is great
            timeIndicator = '<span class="metric-change positive">Excellent</span>';
        } else if (avgTime > 90) { // More than 1.5 minutes is good
            timeIndicator = '<span class="metric-change positive">Good</span>';
        } else if (avgTime > 30) { // More than 30 seconds is ok
            timeIndicator = '<span class="metric-change">Average</span>';
        } else { // Less than 30 seconds needs improvement
            timeIndicator = '<span class="metric-change negative">Needs Improvement</span>';
        }
        
        $('#metric-time').next().next().html(timeIndicator);
        
        // Scroll depth indicator
        const avgScroll = parseFloat(data.scroll_data.avg_scroll_depth);
        let scrollIndicator = '';
        
        if (avgScroll > 80) { // More than 80% is great
            scrollIndicator = '<span class="metric-change positive">Excellent</span>';
        } else if (avgScroll > 60) { // More than 60% is good
            scrollIndicator = '<span class="metric-change positive">Good</span>';
        } else if (avgScroll > 40) { // More than 40% is ok
            scrollIndicator = '<span class="metric-change">Average</span>';
        } else { // Less than 40% needs improvement
            scrollIndicator = '<span class="metric-change negative">Needs Improvement</span>';
        }
        
        $('#metric-scroll').next().next().html(scrollIndicator);
        
        // Engagement score indicator
        const engScore = parseInt(data.engagement_score);
        let engIndicator = '';
        
        if (engScore > 80) { // More than 80 is great
            engIndicator = '<span class="metric-change positive">Excellent</span>';
        } else if (engScore > 60) { // More than 60 is good
            engIndicator = '<span class="metric-change positive">Good</span>';
        } else if (engScore > 40) { // More than 40 is ok
            engIndicator = '<span class="metric-change">Average</span>';
        } else { // Less than 40 needs improvement
            engIndicator = '<span class="metric-change negative">Needs Improvement</span>';
        }
        
        $('#metric-engagement').next().next().html(engIndicator);
    }
    
    /**
     * Load heatmap
     */
    function loadHeatmap(pageId) {
        const days = $('#heatmap-period').val();
        
        // Show loading
        $('#heatmap-placeholder').hide();
        $('#heatmap-wrapper').hide();
        $('#heatmap-loading').show();
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_get_heatmap_data',
                page_id: pageId,
                days: days,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success && response.data.length > 0) {
                    // Load page in iframe
                    const pageUrl = '<?php echo home_url(); ?>?p=' + pageId;
                    $('#page-iframe').attr('src', pageUrl);
                    
                    // Show iframe when loaded
                    $('#page-iframe').on('load', function() {
                        // Create heatmap
                        createHeatmap(response.data);
                        
                        // Show heatmap
                        $('#heatmap-loading').hide();
                        $('#heatmap-wrapper').show();
                    });
                } else {
                    // No data
                    $('#heatmap-loading').hide();
                    $('#heatmap-placeholder').show().html('<p><?php _e('No click data available for this page in the selected period.', 'autonomous-ai-seo'); ?></p>');
                }
            },
            error: function() {
                // Handle error
                $('#heatmap-loading').hide();
                $('#heatmap-placeholder').show().html('<p><?php _e('Error loading heatmap data.', 'autonomous-ai-seo'); ?></p>');
            }
        });
    }
    
    /**
     * Create heatmap visualization
     */
    function createHeatmap(clickData) {
        // Clear previous heatmap
        $('#heatmap-overlay').empty();
        
        // Process click data
        clickData.forEach(function(click) {
            const { x_position, y_position, viewport_width, viewport_height, click_count } = click;
            
            // Scale coordinates to match iframe dimensions
            const iframeWidth = $('#page-iframe').width();
            const iframeHeight = $('#page-iframe').height();
            
            const xScale = iframeWidth / viewport_width;
            const yScale = iframeHeight / viewport_height;
            
            const xPos = x_position * xScale;
            const yPos = y_position * yScale;
            
            // Create click point with intensity based on click count
            const intensity = Math.min(1, click_count / 10); // Max intensity at 10 clicks
            const size = 10 + (click_count * 2); // Size based on click count
            const opacity = 0.3 + (intensity * 0.5); // Opacity based on intensity
            
            const clickPoint = $('<div class="click-point"></div>').css({
                position: 'absolute',
                left: xPos + 'px',
                top: yPos + 'px',
                width: size + 'px',
                height: size + 'px',
                borderRadius: '50%',
                backgroundColor: `rgba(255, 99, 71, ${opacity})`,
                boxShadow: `0 0 ${size/2}px rgba(255, 99, 71, ${opacity*0.8})`,
                transform: 'translate(-50%, -50%)',
                zIndex: 2000
            });
            
            $('#heatmap-overlay').append(clickPoint);
        });
    }
    
    /**
     * Load engagement charts
     */
    function loadEngagementCharts(pageId) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_get_page_metrics',
                page_id: pageId,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    
                    // Create scroll depth chart
                    createScrollDepthChart(data);
                    
                    // Create time on page chart
                    createTimeOnPageChart(data);
                }
            }
        });
    }
    
    /**
     * Create scroll depth chart
     */
    function createScrollDepthChart(data) {
        const ctx = document.getElementById('scroll-chart').getContext('2d');
        
        // Get timestamp 30 days ago
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        
        // Generate date labels for last 30 days
        const labels = [];
        for (let i = 0; i < 30; i++) {
            const date = new Date();
            date.setDate(date.getDate() - 29 + i);
            labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
        }
        
        // Generate sample scroll depth data (this would be replaced with real data from database)
        const scrollData = [];
        for (let i = 0; i < 30; i++) {
            const baseValue = parseFloat(data.scroll_data.avg_scroll_depth);
            const randomVariation = Math.random() * 20 - 10; // Random variation between -10 and 10
            scrollData.push(Math.max(0, Math.min(100, baseValue + randomVariation)));
        }
        
        // Create chart
        if (window.scrollDepthChart) {
            window.scrollDepthChart.destroy();
        }
        
        window.scrollDepthChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Scroll Depth (%)',
                    data: scrollData,
                    borderColor: 'rgba(59, 130, 246, 1)',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'Scroll Depth (%)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Date'
                        }
                    }
                },
                plugins: {
                    title: {
                        display: true,
                        text: 'Scroll Depth Trend',
                        font: {
                            size: 16,
                            weight: 'bold'
                        }
                    }
                }
            }
        });
    }
    
    /**
     * Create time on page chart
     */
    function createTimeOnPageChart(data) {
        const ctx = document.getElementById('time-chart').getContext('2d');
        
        // Generate date labels for last 30 days
        const labels = [];
        for (let i = 0; i < 30; i++) {
            const date = new Date();
            date.setDate(date.getDate() - 29 + i);
            labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
        }
        
        // Generate sample time on page data (this would be replaced with real data from database)
        const timeData = [];
        for (let i = 0; i < 30; i++) {
            const baseValue = parseFloat(data.scroll_data.avg_time_on_page);
            const randomVariation = Math.random() * 30 - 15; // Random variation between -15 and 15
            timeData.push(Math.max(0, baseValue + randomVariation));
        }
        
        // Create chart
        if (window.timeOnPageChart) {
            window.timeOnPageChart.destroy();
        }
        
        window.timeOnPageChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Time on Page (seconds)',
                    data: timeData,
                    borderColor: 'rgba(16, 185, 129, 1)',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Time (seconds)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Date'
                        }
                    }
                },
                plugins: {
                    title: {
                        display: true,
                        text: 'Time on Page Trend',
                        font: {
                            size: 16,
                            weight: 'bold'
                        }
                    }
                }
            }
        });
    }
    
    /**
     * Load engagement insights
     */
    function loadEngagementInsights(pageId) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_get_behavior_insights',
                page_id: pageId,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success && response.data.length > 0) {
                    const insights = response.data;
                    let insightsHtml = '';
                    
                    insights.forEach(function(insight) {
                        const priorityClass = insight.priority ? insight.priority : 'medium';
                        
                        insightsHtml += `
                            <div class="insight-item">
                                <div class="insight-title">
                                    ${insight.title}
                                    <span class="insight-priority ${priorityClass}">${insight.priority}</span>
                                </div>
                                <div class="insight-description">${insight.description}</div>
                            </div>
                        `;
                    });
                    
                    $('#engagement-insights-content').html(insightsHtml);
                } else {
                    $('#engagement-insights-content').html('<p class="placeholder-text"><?php _e('No insights available for this page yet.', 'autonomous-ai-seo'); ?></p>');
                }
            },
            error: function() {
                $('#engagement-insights-content').html('<p class="placeholder-text"><?php _e('Error loading insights.', 'autonomous-ai-seo'); ?></p>');
            }
        });
    }
    
    /**
     * Generate AI recommendations
     */
    function generateAIRecommendations(pageId) {
        // Show loading
        $('#recommendation-placeholder').hide();
        $('.loading-recommendations').show();
        $('#recommendations-content').hide();
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_get_ai_recommendations',
                page_id: pageId,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                $('.loading-recommendations').hide();
                
                if (response.success && response.data.length > 0) {
                    const recommendations = response.data;
                    let recommendationsHtml = '';
                    
                    recommendations.forEach(function(rec, index) {
                        recommendationsHtml += `
                            <div class="ai-recommendation">
                                <div class="ai-badge">AI</div>
                                <div class="ai-recommendation-title">${rec.title}</div>
                                <div class="ai-recommendation-content">${rec.description}</div>
                                <div class="ai-recommendation-actions">
                                    <button class="button button-primary implement-recommendation" data-index="${index}">
                                        <?php _e('Implement', 'autonomous-ai-seo'); ?>
                                    </button>
                                    <button class="button button-secondary save-recommendation" data-index="${index}">
                                        <?php _e('Save for Later', 'autonomous-ai-seo'); ?>
                                    </button>
                                </div>
                            </div>
                        `;
                    });
                    
                    $('#recommendations-content').html(recommendationsHtml).show();
                    
                    // Add event handlers
                    $('.implement-recommendation').on('click', function() {
                        alert('This feature will create and apply the suggested changes.');
                    });
                    
                    $('.save-recommendation').on('click', function() {
                        alert('Recommendation saved to your task list.');
                    });
                } else {
                    $('#recommendation-placeholder').html('<p><?php _e('No AI recommendations available for this page.', 'autonomous-ai-seo'); ?></p>').show();
                }
            },
            error: function() {
                $('.loading-recommendations').hide();
                $('#recommendation-placeholder').html('<p><?php _e('Error generating AI recommendations.', 'autonomous-ai-seo'); ?></p>').show();
            }
        });
    }
});
</script>