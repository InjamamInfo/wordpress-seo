<?php
/**
 * Optimization template for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aaiseo-dashboard">
    <div class="aaiseo-header">
        <div class="aaiseo-header-content">
            <div class="aaiseo-logo">
                <h1><?php _e('AI Optimization Center', 'autonomous-ai-seo'); ?> 
                    <?php 
                    $ai_engine = AAISEO_AI_Engine::getInstance();
                    $provider_status = $ai_engine->getAPIProviderStatus();
                    $active_provider = $provider_status['active_provider'];
                    $provider_name = $provider_status['providers'][$active_provider]['name'];
                    ?>
                    <span class="active-provider-badge"><?php echo $provider_name; ?></span>
                </h1>
                <p><?php _e('Autonomous content and technical optimization powered by AI', 'autonomous-ai-seo'); ?></p>
            </div>
            <div class="aaiseo-status">
                <div class="aaiseo-status-indicator active">
                    <span class="status-dot"></span>
                    <?php _e('AI Running', 'autonomous-ai-seo'); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Optimization Controls -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Optimization Controls', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <div class="quick-actions-grid">
                <button class="quick-action-btn" id="run-full-optimization">
                    <span class="dashicons dashicons-performance"></span>
                    <span><?php _e('Run Full Optimization', 'autonomous-ai-seo'); ?></span>
                </button>
                <button class="quick-action-btn" id="content-optimization">
                    <span class="dashicons dashicons-edit"></span>
                    <span><?php _e('Content Optimization', 'autonomous-ai-seo'); ?></span>
                </button>
                <button class="quick-action-btn" id="technical-optimization">
                    <span class="dashicons dashicons-admin-tools"></span>
                    <span><?php _e('Technical Optimization', 'autonomous-ai-seo'); ?></span>
                </button>
                <button class="quick-action-btn" id="meta-optimization">
                    <span class="dashicons dashicons-tag"></span>
                    <span><?php _e('Meta Tag Optimization', 'autonomous-ai-seo'); ?></span>
                </button>
            </div>
        </div>
    </div>

    <!-- Optimization Status -->
    <?php if (!empty($optimization_data['stats'])): ?>
    <div class="aaiseo-metrics-grid">
        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-yes-alt"></span>
            </div>
            <div class="metric-content">
                <h3><?php echo intval($optimization_data['stats']['applied'] ?? 0); ?></h3>
                <p><?php _e('Applied Optimizations', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">+<?php echo intval($optimization_data['stats']['applied'] ?? 0); ?></span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-clock"></span>
            </div>
            <div class="metric-content">
                <h3><?php echo intval($optimization_data['stats']['pending'] ?? 0); ?></h3>
                <p><?php _e('Pending Review', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change"><?php echo intval($optimization_data['stats']['pending'] ?? 0); ?> waiting</span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-chart-line"></span>
            </div>
            <div class="metric-content">
                <h3><?php echo round($optimization_data['stats']['avg_confidence'] ?? 0, 1); ?>%</h3>
                <p><?php _e('Avg AI Confidence', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">High accuracy</span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-star-filled"></span>
            </div>
            <div class="metric-content">
                <h3><?php echo round($optimization_data['stats']['avg_impact'] ?? 0, 1); ?></h3>
                <p><?php _e('Avg Impact Score', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">Strong impact</span>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Recent Optimizations -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Recent Optimizations', 'autonomous-ai-seo'); ?></h2>
            <button class="button button-secondary" id="refresh-optimizations">
                <?php _e('Refresh', 'autonomous-ai-seo'); ?>
            </button>
        </div>
        <div class="panel-content">
            <?php if (!empty($optimization_data['recent'])): ?>
                <div class="optimizations-table">
                    <table>
                        <thead>
                            <tr>
                                <th><?php _e('Post/Page', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Optimization Type', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Status', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Confidence', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Impact', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Date', 'autonomous-ai-seo'); ?></th>
                                <th><?php _e('Actions', 'autonomous-ai-seo'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($optimization_data['recent'] as $optimization): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo esc_html($optimization['post_title'] ?? 'Unknown'); ?></strong>
                                    </td>
                                    <td>
                                        <span class="optimization-type">
                                            <?php echo esc_html(ucwords(str_replace('_', ' ', $optimization['optimization_type']))); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo esc_attr($optimization['status']); ?>">
                                            <?php echo esc_html(ucwords($optimization['status'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="confidence-score">
                                            <?php echo round($optimization['ai_confidence'], 1); ?>%
                                        </span>
                                    </td>
                                    <td>
                                        <span class="impact-score">
                                            <?php echo round($optimization['impact_score'], 1); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php echo esc_html(date('M j, Y', strtotime($optimization['created_at']))); ?>
                                    </td>
                                    <td>
                                        <?php if ($optimization['status'] === 'pending'): ?>
                                            <button class="button button-primary button-small apply-optimization" 
                                                    data-id="<?php echo intval($optimization['id']); ?>">
                                                <?php _e('Apply', 'autonomous-ai-seo'); ?>
                                            </button>
                                            <button class="button button-secondary button-small reject-optimization" 
                                                    data-id="<?php echo intval($optimization['id']); ?>">
                                                <?php _e('Reject', 'autonomous-ai-seo'); ?>
                                            </button>
                                           <button class="button button-tertiary button-small create-ab-test" 
                                                   data-id="<?php echo intval($optimization['id']); ?>"
                                                   data-post="<?php echo intval($optimization['post_id']); ?>"
                                                   data-type="<?php echo esc_attr($optimization['optimization_type']); ?>"
                                                   data-original="<?php echo esc_attr($optimization['original_content']); ?>">
                                               <?php _e('A/B Test', 'autonomous-ai-seo'); ?>
                                           </button>
                                        <?php else: ?>
                                            <span class="applied-status">
                                                <?php echo $optimization['status'] === 'applied' ? __('Applied', 'autonomous-ai-seo') : __('Rejected', 'autonomous-ai-seo'); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="no-data"><?php _e('No optimizations found. Run an optimization to get started.', 'autonomous-ai-seo'); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Settings -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Optimization Settings', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <?php $settings = get_option('aaiseo_settings', array()); ?>
            <div class="settings-grid">
                <div class="setting-item">
                    <label class="aaiseo-toggle">
                        <input type="checkbox" name="auto_optimization_enabled" 
                               <?php checked(!empty($settings['auto_optimization_enabled'])); ?>
                               data-setting="auto_optimization_enabled">
                        <span class="aaiseo-toggle-slider"></span>
                    </label>
                    <div class="setting-info">
                        <h4><?php _e('Auto Optimization', 'autonomous-ai-seo'); ?></h4>
                        <p><?php _e('Automatically apply high-confidence optimizations', 'autonomous-ai-seo'); ?></p>
                    </div>
                </div>

                <div class="setting-item">
                    <label class="aaiseo-toggle">
                        <input type="checkbox" name="content_enhancement_enabled" 
                               <?php checked(!empty($settings['content_enhancement_enabled'])); ?>
                               data-setting="content_enhancement_enabled">
                        <span class="aaiseo-toggle-slider"></span>
                    </label>
                    <div class="setting-info">
                        <h4><?php _e('Content Enhancement', 'autonomous-ai-seo'); ?></h4>
                        <p><?php _e('AI-powered content improvement suggestions', 'autonomous-ai-seo'); ?></p>
                    </div>
                </div>

                <div class="setting-item">
                    <label class="aaiseo-toggle">
                        <input type="checkbox" name="technical_fixes_enabled" 
                               <?php checked(!empty($settings['technical_fixes_enabled'])); ?>
                               data-setting="technical_fixes_enabled">
                        <span class="aaiseo-toggle-slider"></span>
                    </label>
                    <div class="setting-info">
                        <h4><?php _e('Technical Fixes', 'autonomous-ai-seo'); ?></h4>
                        <p><?php _e('Automatically fix technical SEO issues', 'autonomous-ai-seo'); ?></p>
                    </div>
                </div>

                <div class="setting-item">
                    <label class="aaiseo-toggle">
                        <input type="checkbox" name="ai_suggestions_auto_apply" 
                               <?php checked(!empty($settings['ai_suggestions_auto_apply'])); ?>
                               data-setting="ai_suggestions_auto_apply">
                        <span class="aaiseo-toggle-slider"></span>
                    </label>
                    <div class="setting-info">
                        <h4><?php _e('Auto-Apply AI Suggestions', 'autonomous-ai-seo'); ?></h4>
                        <p><?php _e('Automatically apply AI suggestions with confidence > 90%', 'autonomous-ai-seo'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.optimizations-table {
    overflow-x: auto;
}

.optimizations-table table {
    width: 100%;
    border-collapse: collapse;
}

.optimizations-table th,
.optimizations-table td {
    padding: 12px 8px;
    text-align: left;
    border-bottom: 1px solid #f3f4f6;
}

.optimizations-table th {
    font-weight: 600;
    color: #374151;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.status-badge {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
    text-transform: capitalize;
}

.status-badge.pending {
    background: #fef3c7;
    color: #92400e;
}

.status-badge.applied {
    background: #d1fae5;
    color: #065f46;
}

.status-badge.rejected {
    background: #fee2e2;
    color: #991b1b;
}

.confidence-score,
.impact-score {
    font-weight: 600;
    color: #059669;
}

.optimization-type {
    background: #e0e7ff;
    color: #3730a3;
    padding: 2px 8px;
    border-radius: 8px;
    font-size: 12px;
}

.settings-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

.setting-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 20px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
}

.setting-info h4 {
    margin: 0 0 5px 0;
    font-size: 14px;
    font-weight: 600;
}

.setting-info p {
    margin: 0;
    font-size: 12px;
    color: #6b7280;
}

/* A/B Testing Modal Styles */
.ab-test-modal {
    display: none;
    position: fixed;
    z-index: 9999;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    overflow: auto;
}

.ab-test-modal-content {
    background: white;
    margin: 5% auto;
    padding: 20px;
    border-radius: 12px;
    max-width: 800px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
    position: relative;
}

.ab-test-modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    border-bottom: 1px solid #e5e7eb;
    padding-bottom: 15px;
}

.ab-test-modal-header h2 {
    margin: 0;
    font-size: 18px;
}

.ab-test-modal-close {
    cursor: pointer;
    font-size: 22px;
    font-weight: 700;
    color: #6b7280;
}

.ab-test-variations {
    margin-bottom: 20px;
}

.ab-test-variation {
    padding: 15px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    margin-bottom: 15px;
}

.ab-test-variation-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
}

.ab-test-variation-title {
    font-weight: 600;
    color: #1f2937;
}

.ab-test-variation-content {
    margin-bottom: 10px;
    padding: 10px;
    background: #f9fafb;
    border-radius: 4px;
}

.ab-test-controls {
    text-align: right;
}

.button-tertiary {
    color: #3b82f6;
    background: transparent;
    border-color: transparent;
}

.button-tertiary:hover {
    color: #1d4ed8;
    background: #f3f4f6;
}

.active-provider-badge {
    font-size: 12px;
    font-weight: normal;
    padding: 4px 8px;
    background: #e0f2fe;
    color: #0369a1;
    border-radius: 12px;
    margin-left: 10px;
    vertical-align: middle;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Optimization controls
    $('#run-full-optimization').on('click', function() {
        runOptimization('full');
    });
    
    $('#content-optimization').on('click', function() {
        runOptimization('content');
    });
    
    $('#technical-optimization').on('click', function() {
        runOptimization('technical');
    });
    
    $('#meta-optimization').on('click', function() {
        runOptimization('meta');
    });
    
    // Apply/Reject optimizations
    $('.apply-optimization').on('click', function() {
        const optimizationId = $(this).data('id');
        applyOptimization(optimizationId);
    });
    
    $('.reject-optimization').on('click', function() {
        const optimizationId = $(this).data('id');
        rejectOptimization(optimizationId);
    });
    
    // Settings toggles
    $('input[data-setting]').on('change', function() {
        const setting = $(this).data('setting');
        const value = $(this).is(':checked');
        saveSetting(setting, value);
    });
    
    // A/B Test Modal
    let abTestModal = $(`
        <div class="ab-test-modal">
            <div class="ab-test-modal-content">
                <div class="ab-test-modal-header">
                    <h2>Create A/B Test</h2>
                    <span class="ab-test-modal-close">&times;</span>
                </div>
                <p>Create an A/B test to compare the original content with AI-optimized variations.</p>
                <div class="ab-test-info">
                    <p><strong>Element Type:</strong> <span id="ab-test-element-type"></span></p>
                    <p><strong>Post/Page:</strong> <span id="ab-test-post-title"></span></p>
                </div>
                <div class="ab-test-variations">
                    <h3>Variations</h3>
                    <div id="ab-test-variations-container"></div>
                </div>
                <div class="ab-test-controls">
                    <button class="button button-secondary ab-test-cancel">Cancel</button>
                    <button class="button button-primary ab-test-create">Create A/B Test</button>
                </div>
            </div>
        </div>
    `).appendTo('body');
    
    // Create A/B Test button
    $('.create-ab-test').on('click', function() {
        const postId = $(this).data('post');
        const elementType = $(this).data('type');
        const originalContent = $(this).data('original');
        const optimizedContent = $(this).closest('tr').find('.optimization-content').text();
        
        // Set modal content
        $('#ab-test-element-type').text(elementType.replace('_', ' '));
        $('#ab-test-post-title').text($(this).closest('tr').find('td:first strong').text());
        
        // Set variations
        const variationsContainer = $('#ab-test-variations-container');
        variationsContainer.empty();
        
        // Add original variation
        variationsContainer.append(`
            <div class="ab-test-variation">
                <div class="ab-test-variation-header">
                    <span class="ab-test-variation-title">Original</span>
                </div>
                <div class="ab-test-variation-content">${originalContent}</div>
            </div>
        `);
        
        // Show the modal
        $('.ab-test-modal').show();
        
        // Store data for the test
        $('.ab-test-create').data({
            'post-id': postId,
            'element-type': elementType,
            'original-content': originalContent
        });
    });
    
    // Close modal
    $('.ab-test-modal-close, .ab-test-cancel').on('click', function() {
        $('.ab-test-modal').hide();
    });
    
    // Create A/B Test
    $('.ab-test-create').on('click', function() {
        const button = $(this);
        const originalText = button.text();
        
        button.prop('disabled', true).text('Creating...');
        
        const postId = button.data('post-id');
        const elementType = button.data('element-type');
        const originalContent = button.data('original-content');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_create_ab_test',
                post_id: postId,
                element_type: elementType,
                original_content: originalContent,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data.message);
                    $('.ab-test-modal').hide();
                    
                    // Refresh the page after a delay to show updated status
                    setTimeout(() => location.reload(), 2000);
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'An error occurred while creating the A/B test.');
            },
            complete: function() {
                button.prop('disabled', false).text(originalText);
            }
        });
    });
    
    // Outside click to close modal
    $(window).on('click', function(event) {
        if ($(event.target).hasClass('ab-test-modal')) {
            $('.ab-test-modal').hide();
        }
    });
    
    function runOptimization(type) {
        const button = $('#run-' + type + '-optimization');
        const originalText = button.html();
        
        button.prop('disabled', true).html('<span class="spinner is-active"></span> Running...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_run_optimization',
                optimization_type: type,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data);
                    setTimeout(() => location.reload(), 2000);
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'An error occurred while running optimization.');
            },
            complete: function() {
                button.prop('disabled', false).html(originalText);
            }
        });
    }
    
    function applyOptimization(optimizationId) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_apply_optimization',
                optimization_id: optimizationId,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data);
                    location.reload();
                } else {
                    showNotice('error', response.data);
                }
            }
        });
    }
    
    function rejectOptimization(optimizationId) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_reject_optimization',
                optimization_id: optimizationId,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data);
                    location.reload();
                } else {
                    showNotice('error', response.data);
                }
            }
        });
    }
    
    function saveSetting(name, value) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_save_setting',
                setting_name: name,
                setting_value: value,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', 'Setting saved successfully');
                }
            }
        });
    }
    
    function showNotice(type, message) {
        const notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
        $('.wrap').prepend(notice);
        setTimeout(() => notice.fadeOut(), 5000);
    }
});
</script>