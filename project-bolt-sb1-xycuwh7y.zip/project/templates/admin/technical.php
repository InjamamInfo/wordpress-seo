<?php
/**
 * Technical SEO template for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aaiseo-dashboard">
    <div class="aaiseo-header">
        <div class="aaiseo-header-content">
            <div class="aaiseo-logo">
                <h1><?php _e('Technical SEO Automation', 'autonomous-ai-seo'); ?></h1>
                <p><?php _e('Automated technical optimization and issue resolution', 'autonomous-ai-seo'); ?></p>
            </div>
            <div class="aaiseo-status">
                <button class="button button-primary" id="run-technical-audit">
                    <?php _e('Run Technical Audit', 'autonomous-ai-seo'); ?>
                </button>
            </div>
        </div>
    </div>

    <!-- Health Overview -->
    <div class="aaiseo-metrics-grid">
        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-admin-site-alt3"></span>
            </div>
            <div class="metric-content">
                <h3>94%</h3>
                <p><?php _e('Site Health Score', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change positive">+15%</span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-yes-alt"></span>
            </div>
            <div class="metric-content">
                <h3>23</h3>
                <p><?php _e('Issues Resolved', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change">Fixed</span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-update"></span>
            </div>
            <div class="metric-content">
                <h3>8</h3>
                <p><?php _e('Active Optimizations', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change">In Progress</span>
            </div>
        </div>

        <div class="aaiseo-metric-card">
            <div class="metric-icon">
                <span class="dashicons dashicons-warning"></span>
            </div>
            <div class="metric-content">
                <h3>12</h3>
                <p><?php _e('Issues to Review', 'autonomous-ai-seo'); ?></p>
                <span class="metric-change negative">Pending</span>
            </div>
        </div>
    </div>

    <!-- Technical Issues by Category -->
    <?php
    $technical_categories = array(
        'Crawling & Indexing' => array(
            array('name' => 'Missing XML Sitemap', 'severity' => 'high', 'status' => 'fixed', 'pages' => 1),
            array('name' => 'Robots.txt Blocking Important Pages', 'severity' => 'high', 'status' => 'pending', 'pages' => 3),
            array('name' => 'Orphaned Pages Found', 'severity' => 'medium', 'status' => 'in-progress', 'pages' => 12),
            array('name' => 'Duplicate Meta Descriptions', 'severity' => 'medium', 'status' => 'fixed', 'pages' => 23)
        ),
        'Page Structure' => array(
            array('name' => 'Missing H1 Tags', 'severity' => 'high', 'status' => 'fixed', 'pages' => 5),
            array('name' => 'Multiple H1 Tags', 'severity' => 'medium', 'status' => 'in-progress', 'pages' => 8),
            array('name' => 'Missing Alt Attributes', 'severity' => 'medium', 'status' => 'fixed', 'pages' => 34),
            array('name' => 'Long Title Tags', 'severity' => 'low', 'status' => 'pending', 'pages' => 15)
        ),
        'Performance' => array(
            array('name' => 'Large Image Files', 'severity' => 'high', 'status' => 'fixed', 'pages' => 28),
            array('name' => 'Unoptimized JavaScript', 'severity' => 'medium', 'status' => 'in-progress', 'pages' => 6),
            array('name' => 'Missing Gzip Compression', 'severity' => 'high', 'status' => 'fixed', 'pages' => 1),
            array('name' => 'Render-Blocking Resources', 'severity' => 'medium', 'status' => 'pending', 'pages' => 4)
        )
    );
    ?>

    <?php foreach ($technical_categories as $category_name => $issues): ?>
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php echo esc_html($category_name); ?></h2>
            <span class="issues-count"><?php echo count($issues); ?> issues</span>
        </div>
        <div class="panel-content">
            <div class="technical-issues-list">
                <?php foreach ($issues as $issue): ?>
                <div class="technical-issue-item <?php echo $issue['status']; ?>">
                    <div class="issue-severity">
                        <?php if ($issue['severity'] === 'high'): ?>
                            <span class="dashicons dashicons-dismiss severity-high"></span>
                        <?php elseif ($issue['severity'] === 'medium'): ?>
                            <span class="dashicons dashicons-warning severity-medium"></span>
                        <?php else: ?>
                            <span class="dashicons dashicons-info severity-low"></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="issue-content">
                        <h4><?php echo esc_html($issue['name']); ?></h4>
                        <p><?php echo intval($issue['pages']); ?> pages affected</p>
                    </div>
                    
                    <div class="issue-badges">
                        <span class="severity-badge <?php echo $issue['severity']; ?>">
                            <?php echo ucfirst($issue['severity']); ?>
                        </span>
                        
                        <div class="status-indicator">
                            <?php if ($issue['status'] === 'fixed'): ?>
                                <span class="dashicons dashicons-yes-alt status-icon"></span>
                                <span class="status-text">Fixed</span>
                            <?php elseif ($issue['status'] === 'in-progress'): ?>
                                <span class="dashicons dashicons-update status-icon spin"></span>
                                <span class="status-text">In Progress</span>
                            <?php else: ?>
                                <span class="dashicons dashicons-clock status-icon"></span>
                                <span class="status-text">Pending</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="issue-actions">
                        <?php if ($issue['status'] === 'pending'): ?>
                            <button class="button button-primary button-small fix-issue" 
                                    data-issue="<?php echo esc_attr($issue['name']); ?>">
                                <?php _e('Fix Now', 'autonomous-ai-seo'); ?>
                            </button>
                        <?php endif; ?>
                        <button class="button button-secondary button-small view-details" 
                                data-issue="<?php echo esc_attr($issue['name']); ?>">
                            <?php _e('Details', 'autonomous-ai-seo'); ?>
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>

    <!-- Automated Fixes Log -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Recent Automated Fixes', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <?php
            $automated_fixes = array(
                array(
                    'title' => 'XML Sitemap Generation',
                    'description' => 'Automatically generated and submitted XML sitemap to search engines',
                    'impact' => 'Improved crawling efficiency',
                    'timestamp' => '2 hours ago'
                ),
                array(
                    'title' => 'Schema Markup Implementation',
                    'description' => 'Added structured data for articles, products, and local business',
                    'impact' => 'Enhanced search result appearance',
                    'timestamp' => '4 hours ago'
                ),
                array(
                    'title' => 'Canonical URL Optimization',
                    'description' => 'Implemented proper canonical tags to prevent duplicate content issues',
                    'impact' => 'Resolved duplicate content problems',
                    'timestamp' => '6 hours ago'
                ),
                array(
                    'title' => '301 Redirect Management',
                    'description' => 'Created redirects for broken internal links and outdated URLs',
                    'impact' => 'Preserved link equity and user experience',
                    'timestamp' => '8 hours ago'
                )
            );
            ?>
            
            <div class="automated-fixes-list">
                <?php foreach ($automated_fixes as $fix): ?>
                <div class="automated-fix-item">
                    <div class="fix-icon">
                        <span class="dashicons dashicons-yes-alt"></span>
                    </div>
                    <div class="fix-content">
                        <h4><?php echo esc_html($fix['title']); ?></h4>
                        <p><?php echo esc_html($fix['description']); ?></p>
                        <div class="fix-impact">
                            <strong><?php _e('Impact:', 'autonomous-ai-seo'); ?></strong> 
                            <?php echo esc_html($fix['impact']); ?>
                        </div>
                    </div>
                    <div class="fix-timestamp">
                        <?php echo esc_html($fix['timestamp']); ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Configuration Panel -->
    <div class="aaiseo-panel">
        <div class="panel-header">
            <h2><?php _e('Automation Settings', 'autonomous-ai-seo'); ?></h2>
        </div>
        <div class="panel-content">
            <?php $settings = get_option('aaiseo_settings', array()); ?>
            <div class="automation-settings-grid">
                <div class="setting-group">
                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" checked data-setting="auto_fix_technical">
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Auto-fix Technical Issues', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Automatically resolve common technical SEO problems', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>

                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" checked data-setting="schema_automation">
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Schema Markup Automation', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Automatically add structured data to pages', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>

                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" checked data-setting="image_optimization">
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Image Optimization', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Automatically optimize images on upload', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>
                </div>

                <div class="setting-group">
                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" checked data-setting="sitemap_auto_update">
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Sitemap Auto-Update', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Keep XML sitemap updated automatically', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>

                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" checked data-setting="redirect_management">
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Redirect Management', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Automatically create 301 redirects for broken links', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>

                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" checked data-setting="performance_monitoring">
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Performance Monitoring', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Monitor and alert on performance issues', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.issues-count {
    background: #f3f4f6;
    color: #6b7280;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
}

.technical-issues-list {
    space-y: 12px;
}

.technical-issue-item {
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 16px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    transition: all 0.2s ease;
}

.technical-issue-item:hover {
    background: #f9fafb;
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.technical-issue-item.fixed {
    background: #f0fdf4;
    border-color: #bbf7d0;
}

.technical-issue-item.in-progress {
    background: #fffbeb;
    border-color: #fed7aa;
}

.issue-severity {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.severity-high {
    color: #dc2626;
    background: #fee2e2;
}

.severity-medium {
    color: #d97706;
    background: #fef3c7;
}

.severity-low {
    color: #2563eb;
    background: #dbeafe;
}

.issue-content {
    flex: 1;
}

.issue-content h4 {
    margin: 0 0 4px 0;
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
}

.issue-content p {
    margin: 0;
    font-size: 12px;
    color: #6b7280;
}

.issue-badges {
    display: flex;
    align-items: center;
    gap: 12px;
}

.severity-badge {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
}

.severity-badge.high {
    background: #fee2e2;
    color: #dc2626;
}

.severity-badge.medium {
    background: #fef3c7;
    color: #d97706;
}

.severity-badge.low {
    background: #dbeafe;
    color: #2563eb;
}

.status-indicator {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 12px;
    color: #6b7280;
}

.status-icon {
    font-size: 14px;
}

.technical-issue-item.fixed .status-icon {
    color: #16a34a;
}

.technical-issue-item.in-progress .status-icon {
    color: #d97706;
}

.issue-actions {
    display: flex;
    gap: 6px;
}

.automated-fixes-list {
    space-y: 16px;
}

.automated-fix-item {
    display: flex;
    gap: 16px;
    padding: 16px;
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: 8px;
}

.fix-icon {
    width: 40px;
    height: 40px;
    border-radius: 8px;
    background: #dcfce7;
    color: #16a34a;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.fix-content {
    flex: 1;
}

.fix-content h4 {
    margin: 0 0 4px 0;
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
}

.fix-content p {
    margin: 0 0 8px 0;
    font-size: 13px;
    color: #6b7280;
    line-height: 1.4;
}

.fix-impact {
    font-size: 12px;
    color: #16a34a;
}

.fix-timestamp {
    font-size: 12px;
    color: #9ca3af;
    flex-shrink: 0;
}

.automation-settings-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
}

.setting-group {
    space-y: 20px;
}

.setting-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 20px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    background: #f9fafb;
}

.setting-info h4 {
    margin: 0 0 4px 0;
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
}

.setting-info p {
    margin: 0;
    font-size: 12px;
    color: #6b7280;
    line-height: 1.4;
}

.spin {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

@media (max-width: 768px) {
    .automation-settings-grid {
        grid-template-columns: 1fr;
    }
    
    .technical-issue-item {
        flex-direction: column;
        align-items: flex-start;
        gap: 12px;
    }
    
    .issue-badges {
        align-self: stretch;
        justify-content: space-between;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Run technical audit
    $('#run-technical-audit').on('click', function() {
        runTechnicalAudit();
    });
    
    // Fix individual issues
    $('.fix-issue').on('click', function() {
        const issue = $(this).data('issue');
        fixIssue(issue, $(this));
    });
    
    // View issue details
    $('.view-details').on('click', function() {
        const issue = $(this).data('issue');
        viewIssueDetails(issue);
    });
    
    // Settings toggles
    $('input[data-setting]').on('change', function() {
        const setting = $(this).data('setting');
        const value = $(this).is(':checked');
        saveSetting(setting, value);
    });
    
    function runTechnicalAudit() {
        const button = $('#run-technical-audit');
        const originalText = button.text();
        
        button.prop('disabled', true).text('Running Audit...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_run_technical_audit',
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', 'Technical audit completed successfully');
                    setTimeout(() => location.reload(), 2000);
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'Failed to run technical audit');
            },
            complete: function() {
                button.prop('disabled', false).text(originalText);
            }
        });
    }
    
    function fixIssue(issue, button) {
        const originalText = button.text();
        
        button.prop('disabled', true).text('Fixing...');
        
        // Simulate fixing process
        setTimeout(function() {
            const issueItem = button.closest('.technical-issue-item');
            
            // Update status to fixed
            issueItem.removeClass('pending in-progress').addClass('fixed');
            issueItem.find('.status-icon').removeClass('dashicons-clock dashicons-update')
                     .addClass('dashicons-yes-alt').css('color', '#16a34a');
            issueItem.find('.status-text').text('Fixed');
            
            // Remove fix button
            button.remove();
            
            showNotice('success', 'Issue fixed: ' + issue);
        }, 2000);
    }
    
    function viewIssueDetails(issue) {
        // This would typically open a modal with detailed information
        showNotice('info', 'Viewing details for: ' + issue);
    }
    
    function saveSetting(name, value) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_save_setting',
                setting_name: name,
                setting_value: value,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', 'Setting saved successfully');
                }
            }
        });
    }
    
    function showNotice(type, message) {
        const notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
        $('.wrap').prepend(notice);
        setTimeout(() => notice.fadeOut(), 5000);
    }
});
</script>