<?php
/**
 * Settings template for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('aaiseo_settings', array());
?>

<div class="wrap aaiseo-dashboard">
    <div class="aaiseo-header">
        <div class="aaiseo-header-content">
            <div class="aaiseo-logo">
                <h1><?php _e('Plugin Settings', 'autonomous-ai-seo'); ?></h1>
                <p><?php _e('Configure your AI-powered SEO optimization settings', 'autonomous-ai-seo'); ?></p>
            </div>
            <div class="aaiseo-status">
                <button class="button button-primary" id="save-all-settings">
                    <?php _e('Save All Settings', 'autonomous-ai-seo'); ?>
                </button>
            </div>
        </div>
    </div>

    <form method="post" action="options.php" id="aaiseo-settings-form">
        <?php settings_fields('aaiseo_settings'); ?>
        
        <!-- API Configuration -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('API Configuration', 'autonomous-ai-seo'); ?></h2>
                <p><?php _e('Configure external API connections for AI and analytics features', 'autonomous-ai-seo'); ?></p>
            </div>
            <div class="panel-content">
                <div class="settings-grid">
                    <div class="aaiseo-form-group">
                        <label for="openai_api_key"><?php _e('OpenAI API Key', 'autonomous-ai-seo'); ?></label>
                        <input type="password" id="openai_api_key" name="aaiseo_settings[openai_api_key]" 
                               value="<?php echo esc_attr($settings['openai_api_key'] ?? ''); ?>" 
                               placeholder="sk-..." class="regular-text">
                        <p class="description">
                            <?php _e('Required for AI-powered content analysis and optimization. Get your key from', 'autonomous-ai-seo'); ?>
                            <a href="https://platform.openai.com/api-keys" target="_blank">OpenAI Platform</a>
                        </p>
                        <button type="button" class="button button-secondary test-api-key" data-api="openai">
                            <?php _e('Test Connection', 'autonomous-ai-seo'); ?>
                        </button>
                    </div>

                    <div class="aaiseo-form-group">
                        <label for="google_api_key"><?php _e('Google API Key', 'autonomous-ai-seo'); ?></label>
                        <input type="password" id="google_api_key" name="aaiseo_settings[google_api_key]" 
                               value="<?php echo esc_attr($settings['google_api_key'] ?? ''); ?>" 
                               placeholder="AIza..." class="regular-text">
                        <p class="description">
                            <?php _e('Required for Google Analytics, Search Console, and PageSpeed Insights integration. Get your key from', 'autonomous-ai-seo'); ?>
                            <a href="https://console.cloud.google.com/apis/credentials" target="_blank">Google Cloud Console</a>
                        </p>
                        <button type="button" class="button button-secondary test-api-key" data-api="google">
                            <?php _e('Test Connection', 'autonomous-ai-seo'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- AI Provider Settings -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('AI Provider Configuration', 'autonomous-ai-seo'); ?></h2>
                <p><?php _e('Configure additional AI providers for enhanced capabilities', 'autonomous-ai-seo'); ?></p>
            </div>
            <div class="panel-content">
                <div class="aaiseo-form-group">
                    <label for="preferred_ai_provider"><?php _e('Preferred AI Provider', 'autonomous-ai-seo'); ?></label>
                    <select id="preferred_ai_provider" name="aaiseo_settings[preferred_ai_provider]">
                        <option value="openai" <?php selected($settings['preferred_ai_provider'] ?? 'openai', 'openai'); ?>>
                            <?php _e('OpenAI (GPT)', 'autonomous-ai-seo'); ?>
                        </option>
                        <option value="grok" <?php selected($settings['preferred_ai_provider'] ?? '', 'grok'); ?>>
                            <?php _e('Grok', 'autonomous-ai-seo'); ?>
                        </option>
                        <option value="gemini" <?php selected($settings['preferred_ai_provider'] ?? '', 'gemini'); ?>>
                            <?php _e('Google Gemini', 'autonomous-ai-seo'); ?>
                        </option>
                        <option value="deepseek" <?php selected($settings['preferred_ai_provider'] ?? '', 'deepseek'); ?>>
                            <?php _e('DeepSeek', 'autonomous-ai-seo'); ?>
                        </option>
                        <option value="internal" <?php selected($settings['preferred_ai_provider'] ?? '', 'internal'); ?>>
                            <?php _e('Internal AI (No external API)', 'autonomous-ai-seo'); ?>
                        </option>
                    </select>
                    <p class="description"><?php _e('Select which AI provider to use for content analysis and generation. If the preferred provider is not configured, the plugin will fall back to available providers.', 'autonomous-ai-seo'); ?></p>
                </div>
                
                <div class="settings-grid">
                    <div class="aaiseo-form-group">
                        <label for="grok_api_key"><?php _e('Grok API Key', 'autonomous-ai-seo'); ?></label>
                        <input type="password" id="grok_api_key" name="aaiseo_settings[grok_api_key]" 
                               value="<?php echo esc_attr($settings['grok_api_key'] ?? ''); ?>" 
                               placeholder="grok_..." class="regular-text">
                        <p class="description">
                            <?php _e('Required for Grok AI features. Get your key from', 'autonomous-ai-seo'); ?>
                            <a href="https://grok.x.ai" target="_blank">Grok</a>
                        </p>
                        <button type="button" class="button button-secondary test-api-key" data-api="grok">
                            <?php _e('Test Connection', 'autonomous-ai-seo'); ?>
                        </button>
                    </div>

                    <div class="aaiseo-form-group">
                        <label for="gemini_api_key"><?php _e('Google Gemini API Key', 'autonomous-ai-seo'); ?></label>
                        <input type="password" id="gemini_api_key" name="aaiseo_settings[gemini_api_key]" 
                               value="<?php echo esc_attr($settings['gemini_api_key'] ?? ''); ?>" 
                               placeholder="AI..." class="regular-text">
                        <p class="description">
                            <?php _e('Required for Google Gemini AI features. Get your key from', 'autonomous-ai-seo'); ?>
                            <a href="https://ai.google.dev/" target="_blank">Google AI Studio</a>
                        </p>
                        <button type="button" class="button button-secondary test-api-key" data-api="gemini">
                            <?php _e('Test Connection', 'autonomous-ai-seo'); ?>
                        </button>
                    </div>

                    <div class="aaiseo-form-group">
                        <label for="deepseek_api_key"><?php _e('DeepSeek API Key', 'autonomous-ai-seo'); ?></label>
                        <input type="password" id="deepseek_api_key" name="aaiseo_settings[deepseek_api_key]" 
                               value="<?php echo esc_attr($settings['deepseek_api_key'] ?? ''); ?>" 
                               placeholder="dsk_..." class="regular-text">
                        <p class="description">
                            <?php _e('Required for DeepSeek AI features. Get your key from', 'autonomous-ai-seo'); ?>
                            <a href="https://platform.deepseek.com" target="_blank">DeepSeek Platform</a>
                        </p>
                        <button type="button" class="button button-secondary test-api-key" data-api="deepseek">
                            <?php _e('Test Connection', 'autonomous-ai-seo'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- General Settings -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('General Settings', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="settings-grid">
                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" name="aaiseo_settings[auto_optimization_enabled]" 
                                   <?php checked(!empty($settings['auto_optimization_enabled'])); ?>>
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Enable Auto-Optimization', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Allow the AI to automatically apply high-confidence optimizations', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>

                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" name="aaiseo_settings[content_enhancement_enabled]" 
                                   <?php checked(!empty($settings['content_enhancement_enabled'])); ?>>
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Content Enhancement', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Enable AI-powered content improvement suggestions', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>

                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" name="aaiseo_settings[technical_fixes_enabled]" 
                                   <?php checked(!empty($settings['technical_fixes_enabled'])); ?>>
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Technical Fixes', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Automatically fix common technical SEO issues', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>

                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" name="aaiseo_settings[competitive_monitoring_enabled]" 
                                   <?php checked(!empty($settings['competitive_monitoring_enabled'])); ?>>
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Competitive Monitoring', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Monitor competitors and identify opportunities', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>

                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" name="aaiseo_settings[tracking_enabled]" 
                                   <?php checked(!empty($settings['tracking_enabled'])); ?>>
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Performance Tracking', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Track Core Web Vitals and performance metrics', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>

                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" name="aaiseo_settings[auto_internal_linking]" 
                                   <?php checked(!empty($settings['auto_internal_linking'])); ?>>
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Auto Internal Linking', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Automatically create relevant internal links', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- AI Configuration -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('AI Configuration', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="settings-grid">
                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" name="aaiseo_settings[ai_suggestions_auto_apply]" 
                                   <?php checked(!empty($settings['ai_suggestions_auto_apply'])); ?>>
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Auto-Apply AI Suggestions', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Automatically apply AI suggestions with confidence > 90%', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>

                    <div class="aaiseo-form-group">
                        <label for="performance_threshold"><?php _e('Performance Threshold', 'autonomous-ai-seo'); ?></label>
                        <input type="number" id="performance_threshold" name="aaiseo_settings[performance_threshold]" 
                               value="<?php echo intval($settings['performance_threshold'] ?? 80); ?>" 
                               min="0" max="100" class="small-text">
                        <p class="description"><?php _e('Minimum performance score before triggering optimizations (0-100)', 'autonomous-ai-seo'); ?></p>
                    </div>

                    <div class="aaiseo-form-group">
                        <label for="optimization_frequency"><?php _e('Optimization Frequency', 'autonomous-ai-seo'); ?></label>
                        <select id="optimization_frequency" name="aaiseo_settings[optimization_frequency]">
                            <option value="hourly" <?php selected($settings['optimization_frequency'] ?? '', 'hourly'); ?>>
                                <?php _e('Hourly', 'autonomous-ai-seo'); ?>
                            </option>
                            <option value="daily" <?php selected($settings['optimization_frequency'] ?? 'daily', 'daily'); ?>>
                                <?php _e('Daily', 'autonomous-ai-seo'); ?>
                            </option>
                            <option value="weekly" <?php selected($settings['optimization_frequency'] ?? '', 'weekly'); ?>>
                                <?php _e('Weekly', 'autonomous-ai-seo'); ?>
                            </option>
                        </select>
                        <p class="description"><?php _e('How often the AI should run optimization checks', 'autonomous-ai-seo'); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Notifications -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Notifications', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="settings-grid">
                    <div class="aaiseo-form-group">
                        <label for="notification_email"><?php _e('Notification Email', 'autonomous-ai-seo'); ?></label>
                        <input type="email" id="notification_email" name="aaiseo_settings[notification_email]" 
                               value="<?php echo esc_attr($settings['notification_email'] ?? get_option('admin_email')); ?>" 
                               class="regular-text">
                        <p class="description"><?php _e('Email address for optimization reports and alerts', 'autonomous-ai-seo'); ?></p>
                    </div>

                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" name="aaiseo_settings[competitor_notifications]" 
                                   <?php checked(!empty($settings['competitor_notifications'])); ?>>
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Competitor Alerts', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Get notified when competitors make significant changes', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Advanced Settings -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('Advanced Settings', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="settings-grid">
                    <div class="setting-item">
                        <label class="aaiseo-toggle">
                            <input type="checkbox" name="aaiseo_settings[auto_image_optimization]" 
                                   <?php checked(!empty($settings['auto_image_optimization'])); ?>>
                            <span class="aaiseo-toggle-slider"></span>
                        </label>
                        <div class="setting-info">
                            <h4><?php _e('Auto Image Optimization', 'autonomous-ai-seo'); ?></h4>
                            <p><?php _e('Automatically optimize images on upload (WebP conversion, compression)', 'autonomous-ai-seo'); ?></p>
                        </div>
                    </div>

                    <div class="aaiseo-form-group">
                        <label for="debug_mode"><?php _e('Debug Mode', 'autonomous-ai-seo'); ?></label>
                        <select id="debug_mode" name="aaiseo_settings[debug_mode]">
                            <option value="0" <?php selected($settings['debug_mode'] ?? '0', '0'); ?>>
                                <?php _e('Disabled', 'autonomous-ai-seo'); ?>
                            </option>
                            <option value="1" <?php selected($settings['debug_mode'] ?? '', '1'); ?>>
                                <?php _e('Enabled', 'autonomous-ai-seo'); ?>
                            </option>
                        </select>
                        <p class="description"><?php _e('Enable debug logging for troubleshooting', 'autonomous-ai-seo'); ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- System Status -->
        <div class="aaiseo-panel">
            <div class="panel-header">
                <h2><?php _e('System Status', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="panel-content">
                <div class="system-status-grid">
                    <div class="status-item">
                        <div class="status-label"><?php _e('WordPress Version', 'autonomous-ai-seo'); ?></div>
                        <div class="status-value">
                            <?php echo get_bloginfo('version'); ?>
                            <span class="status-indicator good">✓</span>
                        </div>
                    </div>

                    <div class="status-item">
                        <div class="status-label"><?php _e('PHP Version', 'autonomous-ai-seo'); ?></div>
                        <div class="status-value">
                            <?php echo PHP_VERSION; ?>
                            <?php if (version_compare(PHP_VERSION, '7.4', '>=')): ?>
                                <span class="status-indicator good">✓</span>
                            <?php else: ?>
                                <span class="status-indicator warning">⚠</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="status-item">
                        <div class="status-label"><?php _e('cURL Extension', 'autonomous-ai-seo'); ?></div>
                        <div class="status-value">
                            <?php if (function_exists('curl_init')): ?>
                                <?php _e('Available', 'autonomous-ai-seo'); ?>
                                <span class="status-indicator good">✓</span>
                            <?php else: ?>
                                <?php _e('Not Available', 'autonomous-ai-seo'); ?>
                                <span class="status-indicator error">✗</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="status-item">
                        <div class="status-label"><?php _e('OpenAI API', 'autonomous-ai-seo'); ?></div>
                        <div class="status-value" id="openai-status">
                            <?php if (!empty($settings['openai_api_key'])): ?>
                                <?php if ($settings['preferred_ai_provider'] ?? 'openai' === 'openai'): ?>
                                    <span class="checking active-provider"><?php _e('Checking... (Active Provider)', 'autonomous-ai-seo'); ?></span>
                                <?php else: ?>
                                    <span class="checking"><?php _e('Checking...', 'autonomous-ai-seo'); ?></span>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php _e('Not Configured', 'autonomous-ai-seo'); ?>
                                <span class="status-indicator warning">⚠</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="status-item">
                        <div class="status-label"><?php _e('Grok API', 'autonomous-ai-seo'); ?></div>
                        <div class="status-value" id="grok-status">
                            <?php if (!empty($settings['grok_api_key'])): ?>
                                <?php if (($settings['preferred_ai_provider'] ?? 'openai') === 'grok'): ?>
                                    <span class="checking active-provider"><?php _e('Checking... (Active Provider)', 'autonomous-ai-seo'); ?></span>
                                <?php else: ?>
                                    <span class="checking"><?php _e('Checking...', 'autonomous-ai-seo'); ?></span>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php _e('Not Configured', 'autonomous-ai-seo'); ?>
                                <span class="status-indicator info">i</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="status-item">
                        <div class="status-label"><?php _e('Gemini API', 'autonomous-ai-seo'); ?></div>
                        <div class="status-value" id="gemini-status">
                            <?php if (!empty($settings['gemini_api_key'])): ?>
                                <?php if (($settings['preferred_ai_provider'] ?? 'openai') === 'gemini'): ?>
                                    <span class="checking active-provider"><?php _e('Checking... (Active Provider)', 'autonomous-ai-seo'); ?></span>
                                <?php else: ?>
                                    <span class="checking"><?php _e('Checking...', 'autonomous-ai-seo'); ?></span>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php _e('Not Configured', 'autonomous-ai-seo'); ?>
                                <span class="status-indicator info">i</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="status-item">
                        <div class="status-label"><?php _e('DeepSeek API', 'autonomous-ai-seo'); ?></div>
                        <div class="status-value" id="deepseek-status">
                            <?php if (!empty($settings['deepseek_api_key'])): ?>
                                <?php if (($settings['preferred_ai_provider'] ?? 'openai') === 'deepseek'): ?>
                                    <span class="checking active-provider"><?php _e('Checking... (Active Provider)', 'autonomous-ai-seo'); ?></span>
                                <?php else: ?>
                                    <span class="checking"><?php _e('Checking...', 'autonomous-ai-seo'); ?></span>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php _e('Not Configured', 'autonomous-ai-seo'); ?>
                                <span class="status-indicator info">i</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="status-item">
                        <div class="status-label"><?php _e('Internal AI Engine', 'autonomous-ai-seo'); ?></div>
                        <div class="status-value">
                            <?php if (($settings['preferred_ai_provider'] ?? 'openai') === 'internal'): ?>
                                <?php _e('Active (Primary)', 'autonomous-ai-seo'); ?>
                            <?php else: ?>
                                <?php _e('Available (Fallback)', 'autonomous-ai-seo'); ?>
                            <?php endif; ?>
                            <span class="status-indicator good">✓</span>
                        </div>
                    </div>

                    <div class="status-item">
                        <div class="status-label"><?php _e('Google Analytics API', 'autonomous-ai-seo'); ?></div>
                        <div class="status-value" id="google-status">
                            <?php if (!empty($settings['google_api_key'])): ?>
                                <span class="checking"><?php _e('Checking...', 'autonomous-ai-seo'); ?></span>
                            <?php else: ?>
                                <?php _e('Not Configured', 'autonomous-ai-seo'); ?>
                                <span class="status-indicator warning">⚠</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="status-item">
                        <div class="status-label"><?php _e('Database Tables', 'autonomous-ai-seo'); ?></div>
                        <div class="status-value">
                            <?php _e('All Created', 'autonomous-ai-seo'); ?>
                            <span class="status-indicator good">✓</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="aaiseo-panel">
            <div class="panel-content">
                <div class="action-buttons">
                    <?php submit_button(__('Save Settings', 'autonomous-ai-seo'), 'primary', 'submit', false); ?>
                    <button type="button" class="button button-secondary" id="reset-settings">
                        <?php _e('Reset to Defaults', 'autonomous-ai-seo'); ?>
                    </button>
                    <button type="button" class="button button-secondary" id="export-settings">
                        <?php _e('Export Settings', 'autonomous-ai-seo'); ?>
                    </button>
                    <button type="button" class="button button-secondary" id="import-settings">
                        <?php _e('Import Settings', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

<style>
.settings-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 20px;
}

.setting-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 20px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    background: #f9fafb;
}

.setting-info h4 {
    margin: 0 0 4px 0;
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
}

.setting-info p {
    margin: 0;
    font-size: 12px;
    color: #6b7280;
    line-height: 1.4;
}

.system-status-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 16px;
}

.status-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 16px;
    background: #f9fafb;
    border: 1px solid #e5e7eb;
    border-radius: 6px;
}

.status-label {
    font-weight: 500;
    color: #374151;
}

.status-value {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    color: #6b7280;
}

.status-indicator {
    font-size: 16px;
    font-weight: bold;
}

.status-indicator.good {
    color: #16a34a;
}

.status-indicator.warning {
    color: #d97706;
}

.status-indicator.error {
    color: #dc2626;
}

.status-indicator.info {
    color: #3b82f6;
}

.checking.active-provider {
    color: #16a34a;
    font-weight: bold;
}

.action-buttons {
    display: flex;
    gap: 12px;
    align-items: center;
}

.test-api-key {
    margin-top: 8px;
}

.checking {
    color: #6b7280;
    font-style: italic;
}

@media (max-width: 768px) {
    .settings-grid {
        grid-template-columns: 1fr;
    }
    
    .system-status-grid {
        grid-template-columns: 1fr;
    }
    
    .action-buttons {
        flex-direction: column;
        align-items: stretch;
    }
    
    .action-buttons .button {
        width: 100%;
        text-align: center;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Test API connections
    $('.test-api-key').on('click', function() {
        const apiType = $(this).data('api');
        testApiConnection(apiType, $(this));
    });
    
    // Reset settings
    $('#reset-settings').on('click', function() {
        if (confirm('Are you sure you want to reset all settings to defaults? This cannot be undone.')) {
            resetSettings();
        }
    });
    
    // Export settings
    $('#export-settings').on('click', function() {
        exportSettings();
    });
    
    // Import settings
    $('#import-settings').on('click', function() {
        importSettings();
    });
    
    // Check API status on page load
    checkApiStatus();
    
    function testApiConnection(apiType, button) {
        const originalText = button.text();
        button.prop('disabled', true).text('Testing...');
        
        let apiKey;
        switch (apiType) {
            case 'openai':
                apiType = 'OpenAI';
                break;
            case 'grok':
                apiType = 'Grok';
                break;
            case 'gemini':
                apiType = 'Gemini';
                break;
            case 'deepseek':
                apiType = 'DeepSeek';
                break;
            case 'google':
                apiType = 'Google';
                break;
        }
        
        apiKey = apiType === 'openai' ? $('#openai_api_key').val() : $('#google_api_key').val();
        
        if (!apiKey) {
            showNotice('error', 'Please enter an API key first');
            button.prop('disabled', false).text(originalText);
            return;
        }
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_test_api_connection',
                api_type: apiType,
                api_key: apiKey,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', apiType.toUpperCase() + ' API connection successful');
                } else {
                    showNotice('error', 'API connection failed: ' + response.data);
                }
            },
            error: function() {
                showNotice('error', 'Failed to test API connection');
            },
            complete: function() {
                button.prop('disabled', false).text(originalText);
            }
        });
    }
    
    function checkApiStatus() {
        // Check OpenAI API status
        checkApiStatus('openai');
        checkApiStatus('grok');
        checkApiStatus('gemini');
        checkApiStatus('deepseek');
        checkApiStatus('google');
    }
    
    function checkApiStatus(apiType) {
        const apiKeyField = $(`#${apiType}_api_key`);
        if (!apiKeyField.length) return;
        
        const apiKey = apiKeyField.val();
        if (!apiKey) return;
        
        const statusField = $(`#${apiType}-status`);
        if (!statusField.length) return;
        
        // Check if this is the active provider
        const isActive = statusField.find('.active-provider').length > 0;
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_test_api_connection',
                api_type: apiType,
                api_key: apiKey,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                const statusText = response.success ? 'Connected' : 'Connection Failed';
                const statusIcon = response.success ? 
                    '<span class="status-indicator good">✓</span>' : 
                    '<span class="status-indicator error">✗</span>';
                
                const activeText = isActive ? ' (Active Provider)' : '';
                const status = `${statusText}${activeText} ${statusIcon}`;
                
                statusField.html(status);
            },
            error: function() {
                statusField.html('Connection Error <span class="status-indicator error">✗</span>');
            }
        });
    }
    
    // Update provider status when preferred provider changes
    $('#preferred_ai_provider').on('change', function() {
        const newProvider = $(this).val();
        
        // Remove active provider indicator from all status elements
        $('.checking.active-provider').removeClass('active-provider').text('Checking...');
        
        // Add active provider indicator to selected provider
        if (newProvider !== 'internal') {
            $(`#${newProvider}-status .checking`).addClass('active-provider').text('Checking... (Active Provider)');
        }
    });
    
    function resetSettings() {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_reset_settings',
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', 'Settings reset to defaults');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showNotice('error', 'Failed to reset settings');
                }
            }
        });
    }
    
    function exportSettings() {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_export_settings',
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    downloadFile(response.data, 'aaiseo-settings.json');
                    showNotice('success', 'Settings exported successfully');
                } else {
                    showNotice('error', 'Failed to export settings');
                }
            }
        });
    }
    
    function importSettings() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        
        input.onchange = function(e) {
            const file = e.target.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const settings = JSON.parse(e.target.result);
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'aaiseo_import_settings',
                            settings: JSON.stringify(settings),
                            nonce: aaiseo_admin.nonce
                        },
                        success: function(response) {
                            if (response.success) {
                                showNotice('success', 'Settings imported successfully');
                                setTimeout(() => location.reload(), 1000);
                            } else {
                                showNotice('error', 'Failed to import settings');
                            }
                        }
                    });
                } catch (error) {
                    showNotice('error', 'Invalid settings file');
                }
            };
            reader.readAsText(file);
        };
        
        input.click();
    }
    
    function downloadFile(content, filename) {
        const element = document.createElement('a');
        element.setAttribute('href', 'data:application/json;charset=utf-8,' + encodeURIComponent(content));
        element.setAttribute('download', filename);
        element.style.display = 'none';
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
    }
    
    function showNotice(type, message) {
        const notice = $('<div class="notice notice-' + type + ' is-dismissible"><p>' + message + '</p></div>');
        $('.wrap').prepend(notice);
        setTimeout(() => notice.fadeOut(), 5000);
    }
    
    function validateSettings($input) {
        $sanitized = array();

        // Sanitize provider selection
        $sanitized['preferred_ai_provider'] = isset($input['preferred_ai_provider']) ? 
            sanitize_text_field($input['preferred_ai_provider']) : 'openai';
        
        // Sanitize boolean values
        $boolean_fields = array(
            'auto_optimization_enabled',
            'content_enhancement_enabled',
            'technical_fixes_enabled',
            'competitive_monitoring_enabled',
            'tracking_enabled',
            'auto_internal_linking',
            'ai_suggestions_auto_apply',
            'competitor_notifications',
            'auto_image_optimization'
        );
        
        // Sanitize text fields
        $text_fields = array(
            'notification_email',
            'optimization_frequency',
            'google_api_key',
            'openai_api_key',
            'grok_api_key',
            'gemini_api_key',
            'deepseek_api_key'
        );
    }
});
</script>