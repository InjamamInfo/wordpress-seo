/**
 * Autonomous AI SEO Frontend JavaScript
 */

(function() {
    'use strict';

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeAAISEO);
    } else {
        initializeAAISEO();
    }

    function initializeAAISEO() {
        // Initialize performance tracking
        initializePerformanceTracking();
        
        // Initialize lazy loading
        initializeLazyLoading();
        
        // Initialize image optimization
        initializeImageOptimization();
        
        // Initialize internal link enhancements
        initializeInternalLinks();
        
        // Initialize accessibility enhancements
        initializeAccessibility();
        
        // Initialize Core Web Vitals tracking
        initializeCoreWebVitals();
        
       // Initialize A/B test tracking
       initializeABTestTracking();
       
        // Initialize social sharing
        initializeSocialSharing();
        
        // Initialize table of contents
        initializeTableOfContents();
    }

    /**
     * Initialize performance tracking
     */
    function initializePerformanceTracking() {
        // Track page load performance
        window.addEventListener('load', function() {
            if ('performance' in window) {
                const perfData = performance.getEntriesByType('navigation')[0];
                
                // Send performance data to analytics
                sendPerformanceData({
                    loadTime: perfData.loadEventEnd - perfData.loadEventStart,
                    domContentLoaded: perfData.domContentLoadedEventEnd - perfData.domContentLoadedEventStart,
                    firstPaint: getFirstPaint(),
                    firstContentfulPaint: getFirstContentfulPaint()
                });
            }
        });
    }

    /**
     * Get First Paint timing
     */
    function getFirstPaint() {
        const paintEntries = performance.getEntriesByType('paint');
        const firstPaint = paintEntries.find(entry => entry.name === 'first-paint');
        return firstPaint ? firstPaint.startTime : 0;
    }

    /**
     * Get First Contentful Paint timing
     */
    function getFirstContentfulPaint() {
        const paintEntries = performance.getEntriesByType('paint');
        const firstContentfulPaint = paintEntries.find(entry => entry.name === 'first-contentful-paint');
        return firstContentfulPaint ? firstContentfulPaint.startTime : 0;
    }

    /**
     * Initialize Core Web Vitals tracking
     */
    function initializeCoreWebVitals() {
        if ('PerformanceObserver' in window) {
            // Track Largest Contentful Paint (LCP)
            new PerformanceObserver((entryList) => {
                const entries = entryList.getEntries();
                const lastEntry = entries[entries.length - 1];
                
                sendVitalData('LCP', lastEntry.startTime);
            }).observe({ entryTypes: ['largest-contentful-paint'] });

            // Track First Input Delay (FID)
            new PerformanceObserver((entryList) => {
                const entries = entryList.getEntries();
                entries.forEach((entry) => {
                    const fid = entry.processingStart - entry.startTime;
                    sendVitalData('FID', fid);
                });
            }).observe({ entryTypes: ['first-input'] });

            // Track Cumulative Layout Shift (CLS)
            let clsValue = 0;
            new PerformanceObserver((entryList) => {
                for (const entry of entryList.getEntries()) {
                    if (!entry.hadRecentInput) {
                        clsValue += entry.value;
                    }
                }
                sendVitalData('CLS', clsValue);
            }).observe({ entryTypes: ['layout-shift'] });
        }
    }

    /**
     * Initialize lazy loading for images
     */
    function initializeLazyLoading() {
        if ('IntersectionObserver' in window) {
            const lazyImages = document.querySelectorAll('.aaiseo-lazy');
            
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        
                        if (img.dataset.src) {
                            img.src = img.dataset.src;
                            img.classList.remove('aaiseo-lazy');
                            img.classList.add('loaded');
                            observer.unobserve(img);
                        }
                    }
                });
            });

            lazyImages.forEach(img => imageObserver.observe(img));
        } else {
            // Fallback for browsers without IntersectionObserver
            const lazyImages = document.querySelectorAll('.aaiseo-lazy');
            lazyImages.forEach(img => {
                if (img.dataset.src) {
                    img.src = img.dataset.src;
                    img.classList.remove('aaiseo-lazy');
                    img.classList.add('loaded');
                }
            });
        }
    }

    /**
     * Initialize image optimization
     */
    function initializeImageOptimization() {
        // Check for WebP support
        const webpSupported = checkWebPSupport();
        
        if (webpSupported) {
            document.documentElement.classList.add('webp');
        } else {
            document.documentElement.classList.add('no-webp');
        }

        // Optimize image loading
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            // Add loading attribute for native lazy loading
            if (!img.hasAttribute('loading')) {
                img.setAttribute('loading', 'lazy');
            }

            // Add responsive image classes
            img.classList.add('aaiseo-responsive-image');

            // Track image load performance
            img.addEventListener('load', function() {
                this.classList.add('aaiseo-optimized-image');
            });
        });
    }

    /**
     * Check WebP support
     */
    function checkWebPSupport() {
        return new Promise((resolve) => {
            const webP = new Image();
            webP.onload = webP.onerror = function() {
                resolve(webP.height === 2);
            };
            webP.src = 'data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACyAgCdASoCAAIALmk0mk0iIiIiIgBoSygABc6WWgAA/veff/0PP8bA//LwYAAA';
        });
    }

    /**
     * Initialize internal link enhancements
     */
    function initializeInternalLinks() {
        const internalLinks = document.querySelectorAll('a[href^="/"], a[href^="' + window.location.origin + '"]');
        
        internalLinks.forEach(link => {
            link.classList.add('aaiseo-internal-link');
            
            // Add smooth scrolling for anchor links
            if (link.hash) {
                link.addEventListener('click', function(e) {
                    const target = document.querySelector(this.hash);
                    if (target) {
                        e.preventDefault();
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                        
                        // Update URL without jumping
                        history.pushState(null, null, this.hash);
                    }
                });
            }

            // Track internal link clicks
            link.addEventListener('click', function() {
                sendAnalyticsEvent('internal_link_click', {
                    url: this.href,
                    text: this.textContent.trim()
                });
            });
        });
    }

    /**
     * Initialize accessibility enhancements
     */
    function initializeAccessibility() {
        // Add skip links
        addSkipLinks();
        
        // Enhance focus indicators
        enhanceFocusIndicators();
        
        // Add ARIA labels where missing
        addMissingAriaLabels();
        
        // Improve keyboard navigation
        improveKeyboardNavigation();
    }

    /**
     * Add skip links for accessibility
     */
    function addSkipLinks() {
        const skipLink = document.createElement('a');
        skipLink.href = '#main';
        skipLink.textContent = 'Skip to main content';
        skipLink.className = 'aaiseo-skip-link';
        
        document.body.insertBefore(skipLink, document.body.firstChild);
    }

    /**
     * Enhance focus indicators
     */
    function enhanceFocusIndicators() {
        const focusableElements = document.querySelectorAll(
            'a, button, input, textarea, select, [tabindex]:not([tabindex="-1"])'
        );
        
        focusableElements.forEach(element => {
            element.classList.add('aaiseo-focus-indicator');
        });
    }

    /**
     * Add missing ARIA labels
     */
    function addMissingAriaLabels() {
        // Add labels to images without alt text
        const images = document.querySelectorAll('img:not([alt])');
        images.forEach(img => {
            img.setAttribute('alt', '');
            img.setAttribute('role', 'presentation');
        });

        // Add labels to form inputs without labels
        const inputs = document.querySelectorAll('input:not([aria-label]):not([aria-labelledby])');
        inputs.forEach(input => {
            if (input.placeholder) {
                input.setAttribute('aria-label', input.placeholder);
            }
        });
    }

    /**
     * Improve keyboard navigation
     */
    function improveKeyboardNavigation() {
        // Add keyboard support for custom interactive elements
        const customButtons = document.querySelectorAll('[role="button"]:not(button)');
        
        customButtons.forEach(button => {
            if (!button.hasAttribute('tabindex')) {
                button.setAttribute('tabindex', '0');
            }
            
            button.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.click();
                }
            });
        });
    }

    /**
     * Initialize social sharing
     */
    function initializeSocialSharing() {
        const shareButtons = document.querySelectorAll('.aaiseo-social-share-button');
        
        shareButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                const platform = this.dataset.platform;
                const url = encodeURIComponent(window.location.href);
                const title = encodeURIComponent(document.title);
                
                let shareUrl = '';
                
                switch (platform) {
                    case 'facebook':
                        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
                        break;
                    case 'twitter':
                        shareUrl = `https://twitter.com/intent/tweet?url=${url}&text=${title}`;
                        break;
                    case 'linkedin':
                        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${url}`;
                        break;
                }
                
                if (shareUrl) {
                    window.open(shareUrl, 'share', 'width=600,height=400');
                    
                    // Track social share
                    sendAnalyticsEvent('social_share', {
                        platform: platform,
                        url: window.location.href
                    });
                }
            });
        });
    }

    /**
     * Initialize A/B test tracking
     */
    function initializeABTestTracking() {
        // Track clicks on elements being tested
        document.addEventListener('click', function(e) {
            // Track clicks for title tests
            if (e.target.matches('h1, .entry-title, .post-title')) {
                trackABTestClick('title');
            }
            
            // Track clicks for CTA buttons
            if (e.target.matches('.cta, .button, .btn')) {
                trackABTestClick('cta');
                
                // If this is a form submission or checkout button, track as conversion
                if (e.target.matches('.checkout-button, .add-to-cart, form[action*="checkout"] button, .woocommerce-checkout button[type="submit"]')) {
                    trackABTestConversion('cta');
                }
            }
            
            // Track link clicks for internal link enhancements
            if (e.target.matches('a.aaiseo-internal-link')) {
                trackABTestClick('internal_link');
            }
        });

        // Track form submissions
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function() {
                trackABTestConversion('form');
            });
        });
    }
    
    /**
     * Track A/B test click
     */
    function trackABTestClick(elementType) {
        if (!document.body.dataset.postId) return;
        
        const postId = document.body.dataset.postId;
        
        fetch(window.aaiseo_data?.ajax_url || '/wp-admin/admin-ajax.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                action: 'aaiseo_track_ab_click',
                post_id: postId,
                element_type: elementType,
                nonce: window.aaiseo_data?.nonce || ''
            })
        }).catch(error => {
            console.log('AB test click tracking error:', error);
        });
    }
    
    /**
     * Track A/B test conversion
     */
    function trackABTestConversion(elementType) {
        if (!document.body.dataset.postId) return;
        
        const postId = document.body.dataset.postId;
        
        fetch(window.aaiseo_data?.ajax_url || '/wp-admin/admin-ajax.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                action: 'aaiseo_track_ab_conversion',
                post_id: postId,
                element_type: elementType,
                nonce: window.aaiseo_data?.nonce || ''
            })
        }).catch(error => {
            console.log('AB test conversion tracking error:', error);
        });
    }
    
    /**
     * Initialize table of contents
     */
    function initializeTableOfContents() {
        const headings = document.querySelectorAll('h2, h3, h4, h5, h6');
        
        if (headings.length > 3) {
            const toc = generateTableOfContents(headings);
            insertTableOfContents(toc);
        }
    }

    /**
     * Generate table of contents
     */
    function generateTableOfContents(headings) {
        const toc = document.createElement('div');
        toc.className = 'aaiseo-toc';
        
        const title = document.createElement('h3');
        title.textContent = 'Table of Contents';
        toc.appendChild(title);
        
        const list = document.createElement('ul');
        
        headings.forEach((heading, index) => {
            // Add ID to heading if it doesn't have one
            if (!heading.id) {
                heading.id = 'heading-' + index;
            }
            
            const listItem = document.createElement('li');
            const link = document.createElement('a');
            link.href = '#' + heading.id;
            link.textContent = heading.textContent;
            
            // Add smooth scrolling
            link.addEventListener('click', function(e) {
                e.preventDefault();
                heading.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            });
            
            listItem.appendChild(link);
            list.appendChild(listItem);
        });
        
        toc.appendChild(list);
        return toc;
    }

    /**
     * Insert table of contents
     */
    function insertTableOfContents(toc) {
        const content = document.querySelector('.entry-content, .post-content, main, article');
        
        if (content) {
            const firstHeading = content.querySelector('h2, h3');
            if (firstHeading) {
                firstHeading.parentNode.insertBefore(toc, firstHeading);
            } else {
                content.insertBefore(toc, content.firstChild);
            }
        }
    }

    /**
     * Send performance data to analytics
     */
    function sendPerformanceData(data) {
        // Send to WordPress admin via AJAX
        if (typeof ajaxurl !== 'undefined') {
            fetch(ajaxurl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'aaiseo_track_performance',
                    data: JSON.stringify(data),
                    url: window.location.href
                })
            }).catch(error => {
                console.log('Performance tracking error:', error);
            });
        }
    }

    /**
     * Send Core Web Vitals data
     */
    function sendVitalData(metric, value) {
        if (typeof ajaxurl !== 'undefined') {
            fetch(ajaxurl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'aaiseo_track_vitals',
                    metric: metric,
                    value: value,
                    url: window.location.href
                })
            }).catch(error => {
                console.log('Vitals tracking error:', error);
            });
        }
    }

    /**
     * Send analytics event
     */
    function sendAnalyticsEvent(event, data) {
        if (typeof ajaxurl !== 'undefined') {
            fetch(ajaxurl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'aaiseo_track_event',
                    event: event,
                    data: JSON.stringify(data),
                    url: window.location.href
                })
            }).catch(error => {
                console.log('Event tracking error:', error);
            });
        }
    }

    /**
     * Utility function to debounce function calls
     */
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    /**
     * Utility function to throttle function calls
     */
    function throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }

    /**
     * Initialize reading time calculation
     */
    function initializeReadingTime() {
        const content = document.querySelector('.entry-content, .post-content, main article');
        
        if (content) {
            const text = content.textContent || content.innerText || '';
            const wordsPerMinute = 200;
            const wordCount = text.trim().split(/\s+/).length;
            const readingTime = Math.ceil(wordCount / wordsPerMinute);
            
            const readingTimeElement = document.createElement('div');
            readingTimeElement.className = 'aaiseo-reading-time';
            readingTimeElement.textContent = `${readingTime} min read`;
            
            // Insert reading time before content
            content.parentNode.insertBefore(readingTimeElement, content);
        }
    }

    /**
     * Initialize breadcrumb navigation
     */
    function initializeBreadcrumbs() {
        const breadcrumbContainer = document.querySelector('.aaiseo-breadcrumb');
        
        if (breadcrumbContainer) {
            const breadcrumbs = generateBreadcrumbs();
            breadcrumbContainer.innerHTML = breadcrumbs;
        }
    }

    /**
     * Generate breadcrumb navigation
     */
    function generateBreadcrumbs() {
        const path = window.location.pathname;
        const segments = path.split('/').filter(segment => segment);
        
        let breadcrumbs = '<a href="/">Home</a>';
        let currentPath = '';
        
        segments.forEach((segment, index) => {
            currentPath += '/' + segment;
            const isLast = index === segments.length - 1;
            const title = segment.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            
            breadcrumbs += '<span class="aaiseo-breadcrumb-separator">›</span>';
            
            if (isLast) {
                breadcrumbs += `<span>${title}</span>`;
            } else {
                breadcrumbs += `<a href="${currentPath}">${title}</a>`;
            }
        });
        
        return breadcrumbs;
    }

    // Initialize additional features
    initializeReadingTime();
    initializeBreadcrumbs();

    // Expose utility functions globally for other scripts
    window.AAISEO = {
        debounce: debounce,
        throttle: throttle,
        sendAnalyticsEvent: sendAnalyticsEvent,
        sendPerformanceData: sendPerformanceData
    };

})();