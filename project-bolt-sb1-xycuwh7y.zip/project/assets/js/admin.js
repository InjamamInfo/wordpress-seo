/**
 * Autonomous AI SEO Admin JavaScript
 */

(function($) {
    'use strict';

    // Initialize when document is ready
    $(document).ready(function() {
        initializeAAISEO();
    });

    function initializeAAISEO() {
        // Initialize tabs
        initializeTabs();
        
        // Initialize toggles
        initializeToggles();
        
        // Initialize AJAX handlers
        initializeAjaxHandlers();
        
       // Initialize real-time updates
       initializeRealTimeUpdates();
        
       // Initialize AI provider status
       initializeAIProviderStatus();
        
        // Initialize charts
        initializeCharts();
    }

    /**
     * Initialize tab functionality
     */
    function initializeTabs() {
        $('.aaiseo-tab-button').on('click', function(e) {
            e.preventDefault();
            
            const tabId = $(this).data('tab');
            const tabContainer = $(this).closest('.aaiseo-tabs');
            
            // Update active tab button
            tabContainer.find('.aaiseo-tab-button').removeClass('active');
            $(this).addClass('active');
            
            // Update active tab content
            tabContainer.siblings('.aaiseo-tab-content').removeClass('active');
            $('#' + tabId).addClass('active');
        });
    }

    /**
     * Initialize toggle switches
     */
    function initializeToggles() {
        $('.aaiseo-toggle input').on('change', function() {
            const settingName = $(this).data('setting');
            const isEnabled = $(this).is(':checked');
            
            // Save setting via AJAX
            saveSetting(settingName, isEnabled);
        });
    }

    /**
     * Initialize AJAX handlers
     */
    function initializeAjaxHandlers() {
        // Run optimization
        $(document).on('click', '#run-optimization', function(e) {
            e.preventDefault();
            runOptimization();
        });
        
        // Refresh analytics
        $(document).on('click', '#refresh-analytics', function(e) {
            e.preventDefault();
            refreshAnalytics();
        });
        
        // Add competitor
        $(document).on('click', '#add-competitor', function(e) {
            e.preventDefault();
            addCompetitor();
        });
        
        // Remove competitor
        $(document).on('click', '.remove-competitor', function(e) {
            e.preventDefault();
            removeCompetitor($(this).data('competitor-id'));
        });
        
        // Apply optimization
        $(document).on('click', '.apply-optimization', function(e) {
            e.preventDefault();
            applyOptimization($(this).data('optimization-id'));
        });
        
        // Reject optimization
        $(document).on('click', '.reject-optimization', function(e) {
            e.preventDefault();
            rejectOptimization($(this).data('optimization-id'));
        });
        
        // Export report
        $(document).on('click', '#export-report', function(e) {
            e.preventDefault();
            exportReport();
        });
    }

    /**
     * Initialize real-time updates
     */
    function initializeRealTimeUpdates() {
        // Update metrics every 5 minutes
        setInterval(function() {
            updateMetrics();
        }, 300000);
        
        // Update activities every 2 minutes
        setInterval(function() {
            updateActivities();
        }, 120000);
    }

    /**
     * Initialize AI provider status
     */
    function initializeAIProviderStatus() {
        // Update provider badge when provider selection changes
        $(document).on('change', '#preferred_ai_provider', function() {
            const provider = $(this).val();
            let providerName = 'Unknown';
            
            switch(provider) {
                case 'openai':
                    providerName = 'OpenAI (GPT)';
                    break;
                case 'grok':
                    providerName = 'Grok';
                    break;
                case 'gemini':
                    providerName = 'Google Gemini';
                    break;
                case 'deepseek':
                    providerName = 'DeepSeek';
                    break;
                case 'internal':
                    providerName = 'Internal AI';
                    break;
            }
            
            $('.active-provider-badge').text(providerName);
        });
    }

    /**
     * Initialize charts
     */
    function initializeCharts() {
        // Initialize traffic chart if Chart.js is available
        if (typeof Chart !== 'undefined') {
            initializeTrafficChart();
            initializeKeywordChart();
            initializePerformanceChart();
        }
    }

    /**
     * Run AI optimization
     */
    function runOptimization() {
        const button = $('#run-optimization');
        const originalText = button.html();
        
        button.prop('disabled', true).html('<span class="spinner is-active"></span> Running...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_run_optimization',
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data);
                    updateMetrics();
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'An error occurred while running optimization.');
            },
            complete: function() {
                button.prop('disabled', false).html(originalText);
            }
        });
    }

    /**
     * Refresh analytics data
     */
    function refreshAnalytics() {
        const button = $('#refresh-analytics');
        const originalText = button.html();
        
        button.prop('disabled', true).html('<span class="spinner is-active"></span> Refreshing...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_refresh_analytics',
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', 'Analytics data refreshed successfully.');
                    location.reload();
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'An error occurred while refreshing analytics.');
            },
            complete: function() {
                button.prop('disabled', false).html(originalText);
            }
        });
    }

    /**
     * Add competitor
     */
    function addCompetitor() {
        const domain = $('#competitor-domain').val();
        const name = $('#competitor-name').val();
        
        if (!domain) {
            showNotice('error', 'Please enter a competitor domain.');
            return;
        }
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_add_competitor',
                domain: domain,
                name: name,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data);
                    $('#competitor-domain').val('');
                    $('#competitor-name').val('');
                    location.reload();
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'An error occurred while adding competitor.');
            }
        });
    }

    /**
     * Remove competitor
     */
    function removeCompetitor(competitorId) {
        if (!confirm('Are you sure you want to remove this competitor?')) {
            return;
        }
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_remove_competitor',
                competitor_id: competitorId,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data);
                    location.reload();
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'An error occurred while removing competitor.');
            }
        });
    }

    /**
     * Apply optimization
     */
    function applyOptimization(optimizationId) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_apply_optimization',
                optimization_id: optimizationId,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data);
                    location.reload();
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'An error occurred while applying optimization.');
            }
        });
    }

    /**
     * Reject optimization
     */
    function rejectOptimization(optimizationId) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_reject_optimization',
                optimization_id: optimizationId,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice('success', response.data);
                    location.reload();
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'An error occurred while rejecting optimization.');
            }
        });
    }

    /**
     * Export report
     */
    function exportReport() {
        const period = $('#report-period').val() || '30days';
        const format = $('#report-format').val() || 'html';
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_export_report',
                period: period,
                format: format,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    if (format === 'html') {
                        // Open report in new window
                        const reportWindow = window.open('', '_blank');
                        reportWindow.document.write(response.data.report);
                        reportWindow.document.close();
                    } else {
                        // Download file
                        downloadFile(response.data.report, 'aaiseo-report.' + format);
                    }
                } else {
                    showNotice('error', response.data);
                }
            },
            error: function() {
                showNotice('error', 'An error occurred while exporting report.');
            }
        });
    }

    /**
     * Save setting
     */
    function saveSetting(settingName, value) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_save_setting',
                setting_name: settingName,
                setting_value: value,
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (!response.success) {
                    showNotice('error', 'Failed to save setting.');
                }
            },
            error: function() {
                showNotice('error', 'An error occurred while saving setting.');
            }
        });
    }

    /**
     * Update metrics
     */
    function updateMetrics() {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_get_analytics',
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    updateMetricsDisplay(response.data);
                }
            }
        });
    }

    /**
     * Update activities
     */
    function updateActivities() {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'aaiseo_get_activities',
                nonce: aaiseo_admin.nonce
            },
            success: function(response) {
                if (response.success) {
                    updateActivitiesDisplay(response.data);
                }
            }
        });
    }

    /**
     * Update metrics display
     */
    function updateMetricsDisplay(data) {
        // Update metric cards
        if (data.metrics) {
            $('.metric-card[data-metric="organic_traffic"] .metric-value').text(
                formatNumber(data.metrics.organic_traffic)
            );
            $('.metric-card[data-metric="page_views"] .metric-value').text(
                formatNumber(data.metrics.page_views)
            );
            // Update other metrics...
        }
        
        // Update SEO score
        if (data.seo_score) {
            $('.score-number').text(data.seo_score.overall + '%');
            updateSEOScoreCircle(data.seo_score.overall);
        }
    }

    /**
     * Update activities display
     */
    function updateActivitiesDisplay(activities) {
        const activitiesList = $('.activities-list');
        activitiesList.empty();
        
        if (activities.length === 0) {
            activitiesList.html('<p class="no-activities">No recent activities</p>');
            return;
        }
        
        activities.forEach(function(activity) {
            const activityHtml = `
                <div class="activity-item">
                    <div class="activity-icon">
                        <span class="status-dot ${getActivityStatusClass(activity.activity_type)}"></span>
                    </div>
                    <div class="activity-content">
                        <p class="activity-description">${activity.description}</p>
                        <span class="activity-time">${formatTimeAgo(activity.created_at)}</span>
                    </div>
                </div>
            `;
            activitiesList.append(activityHtml);
        });
    }

    /**
     * Initialize traffic chart
     */
    function initializeTrafficChart() {
        const ctx = document.getElementById('traffic-chart');
        if (!ctx) return;
        
        // Sample data - replace with actual data
        const data = {
            labels: generateDateLabels(30),
            datasets: [{
                label: 'Organic Traffic',
                data: generateSampleData(30, 800, 1200),
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                tension: 0.4
            }, {
                label: 'Predicted Traffic',
                data: generateSampleData(30, 900, 1300),
                borderColor: '#fbbf24',
                backgroundColor: 'rgba(251, 191, 36, 0.1)',
                borderDash: [5, 5],
                tension: 0.4
            }]
        };
        
        new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }

    /**
     * Initialize keyword chart
     */
    function initializeKeywordChart() {
        const ctx = document.getElementById('keyword-chart');
        if (!ctx) return;
        
        // Implementation for keyword ranking chart
    }

    /**
     * Initialize performance chart
     */
    function initializePerformanceChart() {
        const ctx = document.getElementById('performance-chart');
        if (!ctx) return;
        
        // Implementation for performance metrics chart
    }

    /**
     * Update SEO score circle
     */
    function updateSEOScoreCircle(score) {
        const circle = $('.seo-score-circle');
        const percentage = score / 100;
        const degrees = percentage * 360;
        
        circle.css('background', `conic-gradient(#4ade80 0deg ${degrees}deg, #e5e7eb ${degrees}deg 360deg)`);
    }

    /**
     * Show notice
     */
    function showNotice(type, message) {
        const notice = $(`
            <div class="notice notice-${type} is-dismissible">
                <p>${message}</p>
                <button type="button" class="notice-dismiss">
                    <span class="screen-reader-text">Dismiss this notice.</span>
                </button>
            </div>
        `);
        
        $('.wrap').prepend(notice);
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            notice.fadeOut(function() {
                notice.remove();
            });
        }, 5000);
        
        // Manual dismiss
        notice.find('.notice-dismiss').on('click', function() {
            notice.fadeOut(function() {
                notice.remove();
            });
        });
    }

    /**
     * Download file
     */
    function downloadFile(content, filename) {
        const element = document.createElement('a');
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(content));
        element.setAttribute('download', filename);
        element.style.display = 'none';
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
    }

    /**
     * Format number with commas
     */
    function formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }

    /**
     * Format time ago
     */
    function formatTimeAgo(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffInSeconds = Math.floor((now - date) / 1000);
        
        if (diffInSeconds < 60) {
            return 'just now';
        } else if (diffInSeconds < 3600) {
            const minutes = Math.floor(diffInSeconds / 60);
            return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
        } else if (diffInSeconds < 86400) {
            const hours = Math.floor(diffInSeconds / 3600);
            return `${hours} hour${hours > 1 ? 's' : ''} ago`;
        } else {
            const days = Math.floor(diffInSeconds / 86400);
            return `${days} day${days > 1 ? 's' : ''} ago`;
        }
    }

    /**
     * Get activity status class
     */
    function getActivityStatusClass(activityType) {
        const statusClasses = {
            'content_analysis': 'completed',
            'autonomous_optimization': 'completed',
            'competitor_change': 'attention',
            'technical_audit': 'completed'
        };
        
        return statusClasses[activityType] || 'pending';
    }

    /**
     * Generate date labels for charts
     */
    function generateDateLabels(days) {
        const labels = [];
        for (let i = days - 1; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
        }
        return labels;
    }

    /**
     * Generate sample data for charts
     */
    function generateSampleData(points, min, max) {
        const data = [];
        for (let i = 0; i < points; i++) {
            data.push(Math.floor(Math.random() * (max - min + 1)) + min);
        }
        return data;
    }

})(jQuery);