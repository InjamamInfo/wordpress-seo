import React from 'react';
import { PenTool, Lightbulb, TrendingUp, FileText, Target, Users, Calendar, Star } from 'lucide-react';

const ContentStrategy: React.FC = () => {
  const contentGaps = [
    {
      topic: 'Voice Search Optimization',
      keywords: 23,
      difficulty: 'Medium',
      volume: '12K',
      opportunity: 'High',
      competitors: 2
    },
    {
      topic: 'AI Content Marketing',
      keywords: 18,
      difficulty: 'High',
      volume: '8.5K',
      opportunity: 'High',
      competitors: 5
    },
    {
      topic: 'Local SEO Strategies',
      keywords: 31,
      difficulty: 'Low',
      volume: '15K',
      opportunity: 'Medium',
      competitors: 3
    }
  ];

  const contentIdeas = [
    {
      title: 'The Complete Guide to Voice Search SEO in 2024',
      type: 'Pillar Content',
      keywords: ['voice search', 'SEO optimization', 'voice queries'],
      estimatedTraffic: '2.3K',
      difficulty: 'Medium',
      priority: 'High'
    },
    {
      title: '15 AI Tools That Will Transform Your Content Marketing',
      type: 'Listicle',
      keywords: ['AI tools', 'content marketing', 'automation'],
      estimatedTraffic: '1.8K',
      difficulty: 'Low',
      priority: 'High'
    },
    {
      title: 'How to Optimize Your Local Business for Voice Search',
      type: 'How-to Guide',
      keywords: ['local SEO', 'voice search', 'local business'],
      estimatedTraffic: '1.2K',
      difficulty: 'Low',
      priority: 'Medium'
    }
  ];

  const topicClusters = [
    {
      pillar: 'SEO Fundamentals',
      articles: 12,
      traffic: '45K',
      keywords: 234,
      status: 'Active'
    },
    {
      pillar: 'Content Marketing',
      articles: 8,
      traffic: '32K',
      keywords: 189,
      status: 'Growing'
    },
    {
      pillar: 'Technical SEO',
      articles: 15,
      traffic: '28K',
      keywords: 156,
      status: 'Mature'
    }
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High':
        return 'text-red-700 bg-red-100';
      case 'Medium':
        return 'text-yellow-700 bg-yellow-100';
      case 'Low':
        return 'text-green-700 bg-green-100';
      default:
        return 'text-gray-700 bg-gray-100';
    }
  };

  const getOpportunityColor = (opportunity: string) => {
    switch (opportunity) {
      case 'High':
        return 'text-green-700 bg-green-100';
      case 'Medium':
        return 'text-yellow-700 bg-yellow-100';
      case 'Low':
        return 'text-gray-700 bg-gray-100';
      default:
        return 'text-gray-700 bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-xl p-6">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center">
            <PenTool className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">AI-Driven Content Strategy</h2>
            <p className="text-gray-600">Discover content gaps and optimize your content strategy</p>
          </div>
        </div>
      </div>

      {/* Content Performance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <FileText className="w-8 h-8 text-blue-600" />
            <span className="text-sm font-medium text-green-600">+12%</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">247</div>
          <p className="text-sm text-gray-600">Published Articles</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <Target className="w-8 h-8 text-green-600" />
            <span className="text-sm font-medium text-green-600">+8%</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">1,429</div>
          <p className="text-sm text-gray-600">Ranking Keywords</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <Users className="w-8 h-8 text-purple-600" />
            <span className="text-sm font-medium text-green-600">+23%</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">89.4K</div>
          <p className="text-sm text-gray-600">Monthly Visitors</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="w-8 h-8 text-orange-600" />
            <span className="text-sm font-medium text-green-600">+15%</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">4.2</div>
          <p className="text-sm text-gray-600">Avg. Time on Page</p>
        </div>
      </div>

      {/* Content Gap Analysis */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">AI-Identified Content Gaps</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-700">Topic</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Keywords</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Difficulty</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Search Volume</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Opportunity</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Competitors</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Action</th>
              </tr>
            </thead>
            <tbody>
              {contentGaps.map((gap, index) => (
                <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-gray-900">{gap.topic}</td>
                  <td className="py-3 px-4 text-gray-600">{gap.keywords}</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      gap.difficulty === 'Low' ? 'bg-green-100 text-green-700' :
                      gap.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {gap.difficulty}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-600">{gap.volume}/mo</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getOpportunityColor(gap.opportunity)}`}>
                      {gap.opportunity}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-600">{gap.competitors}</td>
                  <td className="py-3 px-4">
                    <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                      Create Brief
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* AI Content Ideas */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">AI-Generated Content Ideas</h3>
        <div className="space-y-4">
          {contentIdeas.map((idea, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900 mb-2">{idea.title}</h4>
                  <div className="flex items-center space-x-3 text-sm text-gray-600 mb-2">
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">
                      {idea.type}
                    </span>
                    <span>Est. Traffic: {idea.estimatedTraffic}/mo</span>
                    <span>Difficulty: {idea.difficulty}</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {idea.keywords.map((keyword, keyIndex) => (
                      <span key={keyIndex} className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">
                        {keyword}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="ml-4 text-right">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getPriorityColor(idea.priority)}`}>
                    {idea.priority} Priority
                  </span>
                  <div className="mt-2">
                    <button className="px-3 py-1 bg-purple-600 text-white rounded text-sm font-medium hover:bg-purple-700 transition-colors">
                      Generate Draft
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Topic Clusters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Content Topic Clusters</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {topicClusters.map((cluster, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-gray-900">{cluster.pillar}</h4>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  cluster.status === 'Active' ? 'bg-green-100 text-green-700' :
                  cluster.status === 'Growing' ? 'bg-blue-100 text-blue-700' :
                  'bg-gray-100 text-gray-700'
                }`}>
                  {cluster.status}
                </span>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Articles:</span>
                  <span className="font-medium text-gray-900">{cluster.articles}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Traffic:</span>
                  <span className="font-medium text-gray-900">{cluster.traffic}/mo</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Keywords:</span>
                  <span className="font-medium text-gray-900">{cluster.keywords}</span>
                </div>
              </div>
              
              <button className="w-full mt-3 px-3 py-2 text-sm font-medium text-purple-600 border border-purple-600 rounded hover:bg-purple-50 transition-colors">
                Expand Cluster
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Content Calendar */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">AI-Optimized Content Calendar</h3>
          <button className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700 transition-colors">
            Generate Calendar
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day) => (
            <div key={day} className="border border-gray-200 rounded-lg p-3">
              <h4 className="font-medium text-gray-900 mb-2">{day}</h4>
              <div className="space-y-1">
                <div className="w-full h-2 bg-blue-100 rounded"></div>
                <div className="w-2/3 h-2 bg-purple-100 rounded"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ContentStrategy;