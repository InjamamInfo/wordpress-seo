import React from 'react';
import { TrendingUp, Brain, Calendar, Target, BarChart3, LineChart } from 'lucide-react';

const PredictiveAnalytics: React.FC = () => {
  const predictions = [
    {
      metric: 'Organic Traffic',
      current: '24,567',
      predicted: '31,245',
      change: '+27.2%',
      confidence: 89,
      timeframe: '3 months'
    },
    {
      metric: 'Keyword Rankings',
      current: '1,429',
      predicted: '1,847',
      change: '+29.2%',
      confidence: 92,
      timeframe: '2 months'
    },
    {
      metric: 'Conversion Rate',
      current: '3.2%',
      predicted: '4.1%',
      change: '+28.1%',
      confidence: 78,
      timeframe: '4 months'
    },
    {
      metric: 'Page Speed Score',
      current: '78',
      predicted: '94',
      change: '+20.5%',
      confidence: 95,
      timeframe: '1 month'
    }
  ];

  const insights = [
    {
      title: 'Seasonal Traffic Surge Expected',
      description: 'AI predicts a 40% traffic increase in Q4 based on historical patterns and competitor analysis.',
      impact: 'High',
      action: 'Prepare content calendar for holiday season',
      date: '2024-03-15'
    },
    {
      title: 'Algorithm Update Impact Forecast',
      description: 'Low risk detected for upcoming Google algorithm update. Your site is well-positioned.',
      impact: 'Low',
      action: 'Continue current optimization strategy',
      date: '2024-03-12'
    },
    {
      title: 'Competitor Gap Opportunity',
      description: 'Competitor weakness identified in voice search optimization. Act within 30 days.',
      impact: 'High',
      action: 'Implement voice search optimization',
      date: '2024-03-10'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 rounded-xl p-6">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Predictive Analytics & Forecasting</h2>
            <p className="text-gray-600">AI-powered predictions to stay ahead of the competition</p>
          </div>
        </div>
      </div>

      {/* Prediction Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {predictions.map((prediction, index) => (
          <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">{prediction.metric}</h3>
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            
            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-500">Current</p>
                <p className="text-xl font-bold text-gray-900">{prediction.current}</p>
              </div>
              
              <div>
                <p className="text-sm text-gray-500">Predicted ({prediction.timeframe})</p>
                <p className="text-xl font-bold text-indigo-600">{prediction.predicted}</p>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-green-600">{prediction.change}</span>
                <span className="text-xs text-gray-500">{prediction.confidence}% confidence</span>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-indigo-600 h-2 rounded-full" 
                  style={{ width: `${prediction.confidence}%` }}
                ></div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Forecast Chart */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Traffic Forecast</h3>
          <div className="flex space-x-2">
            <button className="px-3 py-1 text-sm bg-indigo-100 text-indigo-700 rounded-md">3M</button>
            <button className="px-3 py-1 text-sm text-gray-600 hover:bg-gray-100 rounded-md">6M</button>
            <button className="px-3 py-1 text-sm text-gray-600 hover:bg-gray-100 rounded-md">1Y</button>
          </div>
        </div>
        
        <div className="h-64 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg flex items-center justify-center">
          <div className="text-center">
            <LineChart className="w-12 h-12 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-500">Interactive forecast chart would display here</p>
            <p className="text-sm text-gray-400">Historical data with AI predictions</p>
          </div>
        </div>
      </div>

      {/* AI Insights */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">AI Strategic Insights</h3>
        <div className="space-y-4">
          {insights.map((insight, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h4 className="font-medium text-gray-900">{insight.title}</h4>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      insight.impact === 'High' 
                        ? 'bg-red-100 text-red-700' 
                        : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {insight.impact} Impact
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{insight.description}</p>
                  <p className="text-sm font-medium text-indigo-600">{insight.action}</p>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <Calendar className="w-4 h-4" />
                  <span>{insight.date}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Prediction Accuracy</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Traffic Predictions</span>
              <span className="text-sm font-medium text-green-600">94% accurate</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Ranking Forecasts</span>
              <span className="text-sm font-medium text-green-600">89% accurate</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Algorithm Impact</span>
              <span className="text-sm font-medium text-green-600">91% accurate</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">ROI Forecast</h3>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-600 mb-2">$47,230</div>
            <p className="text-sm text-gray-600 mb-4">Projected revenue increase (6 months)</p>
            <div className="flex items-center justify-center space-x-2 text-sm text-green-600">
              <Target className="w-4 h-4" />
              <span>284% ROI projected</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PredictiveAnalytics;