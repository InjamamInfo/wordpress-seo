import React from 'react';
import { TrendingUp, TrendingDown, Activity, Users, Eye, Target, Bot, AlertTriangle } from 'lucide-react';
import MetricCard from './MetricCard';
import ProgressRing from './ProgressRing';

const Dashboard: React.FC = () => {
  const metrics = [
    {
      title: 'Organic Traffic',
      value: '24,567',
      change: '+12.5%',
      changeType: 'positive' as const,
      icon: Users,
      period: 'vs last month'
    },
    {
      title: 'Keywords Ranking',
      value: '1,429',
      change: '+8.2%',
      changeType: 'positive' as const,
      icon: Target,
      period: 'top 10 positions'
    },
    {
      title: 'Page Views',
      value: '89,432',
      change: '-2.1%',
      changeType: 'negative' as const,
      icon: Eye,
      period: 'last 30 days'
    },
    {
      title: 'Avg. Position',
      value: '8.7',
      change: '+15.3%',
      changeType: 'positive' as const,
      icon: TrendingUp,
      period: 'improvement'
    }
  ];

  const aiActivities = [
    { action: 'Optimized 12 pages for Core Web Vitals', time: '2 hours ago', status: 'completed' },
    { action: 'Generated internal links for "Digital Marketing" cluster', time: '4 hours ago', status: 'completed' },
    { action: 'Identified 3 new competitor strategies', time: '6 hours ago', status: 'pending' },
    { action: 'Updated meta descriptions for 18 pages', time: '8 hours ago', status: 'completed' },
    { action: 'Detected algorithm change impact', time: '12 hours ago', status: 'attention' }
  ];

  return (
    <div className="space-y-6">
      {/* AI Status Alert */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">AI Autonomous Mode: Active</h3>
              <p className="text-gray-600">Your SEO is being optimized continuously in the background</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium text-green-700">Running</span>
          </div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => (
          <MetricCard key={index} {...metric} />
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* SEO Score */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Overall SEO Score</h3>
          <div className="flex items-center justify-center mb-4">
            <ProgressRing progress={87} size={120} strokeWidth={8} />
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Technical SEO</span>
              <span className="text-sm font-medium text-green-600">92%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Content Quality</span>
              <span className="text-sm font-medium text-yellow-600">78%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">User Experience</span>
              <span className="text-sm font-medium text-green-600">91%</span>
            </div>
          </div>
        </div>

        {/* Recent AI Activities */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent AI Activities</h3>
          <div className="space-y-4">
            {aiActivities.map((activity, index) => (
              <div key={index} className="flex items-center space-x-4 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                <div className={`w-3 h-3 rounded-full ${
                  activity.status === 'completed' ? 'bg-green-500' :
                  activity.status === 'pending' ? 'bg-yellow-500' : 'bg-red-500'
                }`}></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{activity.action}</p>
                  <p className="text-xs text-gray-500">{activity.time}</p>
                </div>
                {activity.status === 'attention' && (
                  <AlertTriangle className="w-4 h-4 text-red-500" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Traffic Trend Chart */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Traffic Trend & Predictions</h3>
        <div className="h-64 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg flex items-center justify-center">
          <div className="text-center">
            <Activity className="w-12 h-12 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-500">Interactive chart would display here</p>
            <p className="text-sm text-gray-400">Real-time traffic data with AI predictions</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;