import React from 'react';
import { Gauge, Zap, Clock, Eye, CheckCircle, AlertTriangle, XCircle } from 'lucide-react';

const CoreWebVitals: React.FC = () => {
  const vitals = [
    {
      name: 'Largest Contentful Paint (LCP)',
      score: 2.1,
      threshold: 2.5,
      status: 'good',
      description: 'Measures loading performance',
      impact: 'Page loading feels fast to users'
    },
    {
      name: 'First Input Delay (FID)',
      score: 85,
      threshold: 100,
      status: 'good',
      description: 'Measures interactivity',
      impact: 'Users can interact immediately'
    },
    {
      name: 'Cumulative Layout Shift (CLS)',
      score: 0.08,
      threshold: 0.1,
      status: 'needs-improvement',
      description: 'Measures visual stability',
      impact: 'Some unexpected layout shifts occur'
    }
  ];

  const optimizations = [
    {
      title: 'Image Optimization',
      description: 'Convert 34 images to WebP format and implement lazy loading',
      impact: 'Reduce LCP by 0.8s',
      status: 'completed',
      savings: '1.2MB'
    },
    {
      title: 'JavaScript Bundle Splitting',
      description: 'Split large JS bundles and defer non-critical scripts',
      impact: 'Improve FID by 15ms',
      status: 'in-progress',
      savings: '320KB'
    },
    {
      title: 'Font Loading Optimization',
      description: 'Implement font-display: swap and preload critical fonts',
      impact: 'Reduce CLS by 0.03',
      status: 'pending',
      savings: '0.5s'
    },
    {
      title: 'Critical CSS Inlining',
      description: 'Inline above-the-fold CSS and defer non-critical styles',
      impact: 'Improve LCP by 0.4s',
      status: 'completed',
      savings: '180KB'
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'good':
        return <CheckCircle className="w-6 h-6 text-green-500" />;
      case 'needs-improvement':
        return <AlertTriangle className="w-6 h-6 text-yellow-500" />;
      case 'poor':
        return <XCircle className="w-6 h-6 text-red-500" />;
      default:
        return <AlertTriangle className="w-6 h-6 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good':
        return 'text-green-700 bg-green-100';
      case 'needs-improvement':
        return 'text-yellow-700 bg-yellow-100';
      case 'poor':
        return 'text-red-700 bg-red-100';
      default:
        return 'text-gray-700 bg-gray-100';
    }
  };

  const getOptimizationStatus = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'in-progress':
        return <Clock className="w-5 h-5 text-yellow-500 animate-spin" />;
      case 'pending':
        return <AlertTriangle className="w-5 h-5 text-gray-400" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-gray-400" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-xl p-6">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center">
            <Gauge className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Core Web Vitals Optimization</h2>
            <p className="text-gray-600">Real-time performance monitoring and automated improvements</p>
          </div>
        </div>
      </div>

      {/* Overall Score */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Overall Performance Score</h3>
          <div className="text-right">
            <div className="text-3xl font-bold text-green-600">87</div>
            <p className="text-sm text-gray-500">Good Performance</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {vitals.map((vital, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                {getStatusIcon(vital.status)}
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(vital.status)}`}>
                  {vital.status.replace('-', ' ')}
                </span>
              </div>
              
              <h4 className="font-medium text-gray-900 mb-1">{vital.name}</h4>
              <p className="text-sm text-gray-600 mb-2">{vital.description}</p>
              
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium text-gray-900">
                  {vital.name.includes('FID') ? `${vital.score}ms` : 
                   vital.name.includes('CLS') ? vital.score : `${vital.score}s`}
                </span>
                <span className="text-gray-500">
                  Target: {vital.name.includes('FID') ? `< ${vital.threshold}ms` : 
                          vital.name.includes('CLS') ? `< ${vital.threshold}` : `< ${vital.threshold}s`}
                </span>
              </div>
              
              <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full ${
                    vital.status === 'good' ? 'bg-green-500' : 
                    vital.status === 'needs-improvement' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ 
                    width: `${Math.min((vital.threshold - vital.score) / vital.threshold * 100, 100)}%` 
                  }}
                ></div>
              </div>
              
              <p className="text-xs text-gray-500 mt-2">{vital.impact}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Optimization Actions */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Automated Optimizations</h3>
        <div className="space-y-4">
          {optimizations.map((optimization, index) => (
            <div key={index} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              {getOptimizationStatus(optimization.status)}
              <div className="flex-1">
                <h4 className="font-medium text-gray-900">{optimization.title}</h4>
                <p className="text-sm text-gray-600">{optimization.description}</p>
                <div className="flex items-center space-x-4 mt-1">
                  <span className="text-xs text-green-600 font-medium">{optimization.impact}</span>
                  <span className="text-xs text-blue-600">Saved: {optimization.savings}</span>
                </div>
              </div>
              <div className="text-right">
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  optimization.status === 'completed' ? 'bg-green-100 text-green-700' :
                  optimization.status === 'in-progress' ? 'bg-yellow-100 text-yellow-700' :
                  'bg-gray-100 text-gray-700'
                }`}>
                  {optimization.status.replace('-', ' ')}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Performance Trends */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Trends</h3>
          <div className="h-48 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <Zap className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">Performance trend chart</p>
              <p className="text-sm text-gray-400">30-day history</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Optimization Impact</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Page Load Speed</span>
              <span className="font-medium text-green-600">+34% faster</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">User Experience Score</span>
              <span className="font-medium text-green-600">+28 points</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Bounce Rate</span>
              <span className="font-medium text-green-600">-15% lower</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">SEO Score Impact</span>
              <span className="font-medium text-green-600">+12 points</span>
            </div>
          </div>
        </div>
      </div>

      {/* Monitoring Settings */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Monitoring & Alerts</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
            <div>
              <p className="font-medium text-green-900">Real-time Monitoring</p>
              <p className="text-sm text-green-600">Active</p>
            </div>
            <div className="w-12 h-6 bg-green-500 rounded-full flex items-center justify-end px-1">
              <div className="w-4 h-4 bg-white rounded-full"></div>
            </div>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div>
              <p className="font-medium text-blue-900">Auto-Optimization</p>
              <p className="text-sm text-blue-600">Enabled</p>
            </div>
            <div className="w-12 h-6 bg-blue-500 rounded-full flex items-center justify-end px-1">
              <div className="w-4 h-4 bg-white rounded-full"></div>
            </div>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg border border-purple-200">
            <div>
              <p className="font-medium text-purple-900">Performance Alerts</p>
              <p className="text-sm text-purple-600">Email & Dashboard</p>
            </div>
            <div className="w-12 h-6 bg-purple-500 rounded-full flex items-center justify-end px-1">
              <div className="w-4 h-4 bg-white rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CoreWebVitals;