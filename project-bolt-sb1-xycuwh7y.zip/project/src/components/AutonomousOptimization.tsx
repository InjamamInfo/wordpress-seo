import React from 'react';
import { Bot, CheckCircle, Clock, AlertCircle, Zap, FileText, Link, Image } from 'lucide-react';

const AutonomousOptimization: React.FC = () => {
  const optimizationTasks = [
    {
      category: 'Content Enhancement',
      icon: FileText,
      tasks: [
        { name: 'SEO Meta Description Optimization', status: 'completed', impact: 'High', pages: 23 },
        { name: 'Header Structure Improvement', status: 'running', impact: 'Medium', pages: 12 },
        { name: 'Content Length Optimization', status: 'pending', impact: 'High', pages: 8 }
      ]
    },
    {
      category: 'Internal Linking',
      icon: Link,
      tasks: [
        { name: 'Contextual Link Insertion', status: 'completed', impact: 'High', pages: 45 },
        { name: 'Anchor Text Optimization', status: 'running', impact: 'Medium', pages: 18 },
        { name: 'Link Structure Analysis', status: 'pending', impact: 'Medium', pages: 32 }
      ]
    },
    {
      category: 'Image Optimization',
      icon: Image,
      tasks: [
        { name: 'Alt Text Generation', status: 'completed', impact: 'Medium', pages: 67 },
        { name: 'WebP Conversion', status: 'running', impact: 'High', pages: 34 },
        { name: 'Image Compression', status: 'completed', impact: 'High', pages: 89 }
      ]
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'running':
        return <Clock className="w-5 h-5 text-yellow-500 animate-spin" />;
      case 'pending':
        return <AlertCircle className="w-5 h-5 text-gray-400" />;
      default:
        return <AlertCircle className="w-5 h-5 text-gray-400" />;
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'High':
        return 'text-red-600 bg-red-50';
      case 'Medium':
        return 'text-yellow-600 bg-yellow-50';
      case 'Low':
        return 'text-green-600 bg-green-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-xl p-6">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Autonomous AI Optimization</h2>
            <p className="text-gray-600">AI is continuously optimizing your site in the background</p>
          </div>
        </div>
      </div>

      {/* Control Panel */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Optimization Controls</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
            <div>
              <p className="font-medium text-green-900">Auto-Optimization</p>
              <p className="text-sm text-green-600">Currently Active</p>
            </div>
            <div className="w-12 h-6 bg-green-500 rounded-full flex items-center justify-end px-1">
              <div className="w-4 h-4 bg-white rounded-full"></div>
            </div>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div>
              <p className="font-medium text-blue-900">Content Enhancement</p>
              <p className="text-sm text-blue-600">Enabled</p>
            </div>
            <div className="w-12 h-6 bg-blue-500 rounded-full flex items-center justify-end px-1">
              <div className="w-4 h-4 bg-white rounded-full"></div>
            </div>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg border border-purple-200">
            <div>
              <p className="font-medium text-purple-900">Technical Fixes</p>
              <p className="text-sm text-purple-600">Auto-Apply</p>
            </div>
            <div className="w-12 h-6 bg-purple-500 rounded-full flex items-center justify-end px-1">
              <div className="w-4 h-4 bg-white rounded-full"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Optimization Categories */}
      <div className="space-y-6">
        {optimizationTasks.map((category, categoryIndex) => {
          const Icon = category.icon;
          return (
            <div key={categoryIndex} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Icon className="w-6 h-6 text-blue-600" />
                <h3 className="text-lg font-semibold text-gray-900">{category.category}</h3>
              </div>
              
              <div className="space-y-3">
                {category.tasks.map((task, taskIndex) => (
                  <div key={taskIndex} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                    <div className="flex items-center space-x-4">
                      {getStatusIcon(task.status)}
                      <div>
                        <p className="font-medium text-gray-900">{task.name}</p>
                        <p className="text-sm text-gray-500">{task.pages} pages affected</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getImpactColor(task.impact)}`}>
                        {task.impact} Impact
                      </span>
                      <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                        View Details
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Performance Impact */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Optimization Impact</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <Zap className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-green-900">+23%</p>
            <p className="text-sm text-green-600">Page Speed</p>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <Zap className="w-8 h-8 text-blue-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-blue-900">+15%</p>
            <p className="text-sm text-blue-600">Organic Traffic</p>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <Zap className="w-8 h-8 text-purple-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-purple-900">+31%</p>
            <p className="text-sm text-purple-600">Click-Through Rate</p>
          </div>
          <div className="text-center p-4 bg-orange-50 rounded-lg">
            <Zap className="w-8 h-8 text-orange-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-orange-900">+18%</p>
            <p className="text-sm text-orange-600">Ranking Positions</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AutonomousOptimization;