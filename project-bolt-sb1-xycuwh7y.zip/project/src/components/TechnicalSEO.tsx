import React from 'react';
import { Settings, CheckCircle, AlertTriangle, XCircle, ExternalLink, Globe, Shield, Zap } from 'lucide-react';

const TechnicalSEO: React.FC = () => {
  const technicalIssues = [
    {
      category: 'Crawling & Indexing',
      issues: [
        { name: 'Missing XML Sitemap', severity: 'high', status: 'fixed', pages: 1 },
        { name: 'Robots.txt Blocking Important Pages', severity: 'high', status: 'pending', pages: 3 },
        { name: 'Orphaned Pages Found', severity: 'medium', status: 'in-progress', pages: 12 },
        { name: 'Duplicate Meta Descriptions', severity: 'medium', status: 'fixed', pages: 23 }
      ]
    },
    {
      category: 'Page Structure',
      issues: [
        { name: 'Missing H1 Tags', severity: 'high', status: 'fixed', pages: 5 },
        { name: 'Multiple H1 Tags', severity: 'medium', status: 'in-progress', pages: 8 },
        { name: 'Missing Alt Attributes', severity: 'medium', status: 'fixed', pages: 34 },
        { name: 'Long Title Tags', severity: 'low', status: 'pending', pages: 15 }
      ]
    },
    {
      category: 'Performance',
      issues: [
        { name: 'Large Image Files', severity: 'high', status: 'fixed', pages: 28 },
        { name: 'Unoptimized JavaScript', severity: 'medium', status: 'in-progress', pages: 6 },
        { name: 'Missing Gzip Compression', severity: 'high', status: 'fixed', pages: 1 },
        { name: 'Render-Blocking Resources', severity: 'medium', status: 'pending', pages: 4 }
      ]
    }
  ];

  const automatedFixes = [
    {
      title: 'XML Sitemap Generation',
      description: 'Automatically generated and submitted XML sitemap to search engines',
      impact: 'Improved crawling efficiency',
      timestamp: '2 hours ago'
    },
    {
      title: 'Schema Markup Implementation',
      description: 'Added structured data for articles, products, and local business',
      impact: 'Enhanced search result appearance',
      timestamp: '4 hours ago'
    },
    {
      title: 'Canonical URL Optimization',
      description: 'Implemented proper canonical tags to prevent duplicate content issues',
      impact: 'Resolved duplicate content problems',
      timestamp: '6 hours ago'
    },
    {
      title: '301 Redirect Management',
      description: 'Created redirects for broken internal links and outdated URLs',
      impact: 'Preserved link equity and user experience',
      timestamp: '8 hours ago'
    }
  ];

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'medium':
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'low':
        return <AlertTriangle className="w-5 h-5 text-blue-500" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'fixed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'in-progress':
        return <div className="w-4 h-4 border-2 border-yellow-500 border-t-transparent rounded-full animate-spin"></div>;
      case 'pending':
        return <div className="w-4 h-4 bg-gray-300 rounded-full"></div>;
      default:
        return <div className="w-4 h-4 bg-gray-300 rounded-full"></div>;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'text-red-700 bg-red-100';
      case 'medium':
        return 'text-yellow-700 bg-yellow-100';
      case 'low':
        return 'text-blue-700 bg-blue-100';
      default:
        return 'text-gray-700 bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-gray-50 to-blue-50 border border-gray-200 rounded-xl p-6">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-gray-600 rounded-full flex items-center justify-center">
            <Settings className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Technical SEO Automation</h2>
            <p className="text-gray-600">Automated technical optimization and issue resolution</p>
          </div>
        </div>
      </div>

      {/* Health Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <Globe className="w-8 h-8 text-green-600" />
            <span className="text-sm font-medium text-green-600">+15%</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">94%</div>
          <p className="text-sm text-gray-600">Site Health Score</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <Shield className="w-8 h-8 text-blue-600" />
            <span className="text-sm font-medium text-green-600">Fixed</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">23</div>
          <p className="text-sm text-gray-600">Issues Resolved</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <Zap className="w-8 h-8 text-purple-600" />
            <span className="text-sm font-medium text-yellow-600">In Progress</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">8</div>
          <p className="text-sm text-gray-600">Active Optimizations</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <ExternalLink className="w-8 h-8 text-orange-600" />
            <span className="text-sm font-medium text-red-600">Pending</span>
          </div>
          <div className="text-2xl font-bold text-gray-900 mb-1">12</div>
          <p className="text-sm text-gray-600">Issues to Review</p>
        </div>
      </div>

      {/* Technical Issues by Category */}
      <div className="space-y-6">
        {technicalIssues.map((category, categoryIndex) => (
          <div key={categoryIndex} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">{category.category}</h3>
            
            <div className="space-y-3">
              {category.issues.map((issue, issueIndex) => (
                <div key={issueIndex} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div className="flex items-center space-x-4">
                    {getSeverityIcon(issue.severity)}
                    <div>
                      <p className="font-medium text-gray-900">{issue.name}</p>
                      <p className="text-sm text-gray-500">{issue.pages} pages affected</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getSeverityColor(issue.severity)}`}>
                      {issue.severity}
                    </span>
                    
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(issue.status)}
                      <span className="text-sm text-gray-600 capitalize">{issue.status.replace('-', ' ')}</span>
                    </div>
                    
                    <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                      Details
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Automated Fixes Log */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Automated Fixes</h3>
        <div className="space-y-4">
          {automatedFixes.map((fix, index) => (
            <div key={index} className="flex items-start space-x-4 p-4 bg-green-50 border border-green-200 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-500 mt-0.5" />
              <div className="flex-1">
                <h4 className="font-medium text-gray-900 mb-1">{fix.title}</h4>
                <p className="text-sm text-gray-600 mb-2">{fix.description}</p>
                <p className="text-sm font-medium text-green-700">{fix.impact}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-500">{fix.timestamp}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Configuration Panel */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Automation Settings</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">Auto-fix Technical Issues</p>
                <p className="text-sm text-gray-600">Automatically resolve common technical SEO problems</p>
              </div>
              <div className="w-12 h-6 bg-green-500 rounded-full flex items-center justify-end px-1">
                <div className="w-4 h-4 bg-white rounded-full"></div>
              </div>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">Schema Markup Automation</p>
                <p className="text-sm text-gray-600">Automatically add structured data to pages</p>
              </div>
              <div className="w-12 h-6 bg-blue-500 rounded-full flex items-center justify-end px-1">
                <div className="w-4 h-4 bg-white rounded-full"></div>
              </div>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">Image Optimization</p>
                <p className="text-sm text-gray-600">Automatically optimize images on upload</p>
              </div>
              <div className="w-12 h-6 bg-purple-500 rounded-full flex items-center justify-end px-1">
                <div className="w-4 h-4 bg-white rounded-full"></div>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">Sitemap Auto-Update</p>
                <p className="text-sm text-gray-600">Keep XML sitemap updated automatically</p>
              </div>
              <div className="w-12 h-6 bg-green-500 rounded-full flex items-center justify-end px-1">
                <div className="w-4 h-4 bg-white rounded-full"></div>
              </div>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">Redirect Management</p>
                <p className="text-sm text-gray-600">Automatically create 301 redirects for broken links</p>
              </div>
              <div className="w-12 h-6 bg-orange-500 rounded-full flex items-center justify-end px-1">
                <div className="w-4 h-4 bg-white rounded-full"></div>
              </div>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">Performance Monitoring</p>
                <p className="text-sm text-gray-600">Monitor and alert on performance issues</p>
              </div>
              <div className="w-12 h-6 bg-indigo-500 rounded-full flex items-center justify-end px-1">
                <div className="w-4 h-4 bg-white rounded-full"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TechnicalSEO;