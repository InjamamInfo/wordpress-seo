import React from 'react';
import { Target, TrendingUp, AlertTriangle, Eye, ExternalLink, Users } from 'lucide-react';

const CompetitiveIntelligence: React.FC = () => {
  const competitors = [
    {
      name: 'competitor1.com',
      rank: 1,
      traffic: '124K',
      change: '+12%',
      keywords: 2847,
      backlinks: '12.4K',
      threat: 'High'
    },
    {
      name: 'competitor2.com',
      rank: 2,
      traffic: '89K',
      change: '+8%',
      keywords: 1923,
      backlinks: '8.7K',
      threat: 'Medium'
    },
    {
      name: 'competitor3.com',
      rank: 3,
      traffic: '67K',
      change: '-3%',
      keywords: 1456,
      backlinks: '6.2K',
      threat: 'Low'
    }
  ];

  const opportunities = [
    {
      type: 'Content Gap',
      title: 'Voice Search Optimization',
      description: 'Competitors have minimal voice search content. High opportunity for first-mover advantage.',
      keywords: 23,
      difficulty: 'Medium',
      potential: 'High'
    },
    {
      type: 'Backlink Gap',
      title: 'Industry Publication Links',
      description: 'Top competitor has 45 links from tech publications you\'re missing.',
      keywords: 12,
      difficulty: 'High',
      potential: 'High'
    },
    {
      type: 'Keyword Gap',
      title: 'Long-tail Opportunities',
      description: 'Discovered 127 long-tail keywords with low competition and high search volume.',
      keywords: 127,
      difficulty: 'Low',
      potential: 'Medium'
    }
  ];

  const alerts = [
    {
      competitor: 'competitor1.com',
      alert: 'Published 3 new articles targeting your primary keywords',
      time: '2 hours ago',
      severity: 'high'
    },
    {
      competitor: 'competitor2.com',
      alert: 'Gained 12 new high-authority backlinks',
      time: '1 day ago',
      severity: 'medium'
    },
    {
      competitor: 'competitor3.com',
      alert: 'Launched new content series in your niche',
      time: '3 days ago',
      severity: 'low'
    }
  ];

  const getThreatColor = (threat: string) => {
    switch (threat) {
      case 'High':
        return 'text-red-700 bg-red-100';
      case 'Medium':
        return 'text-yellow-700 bg-yellow-100';
      case 'Low':
        return 'text-green-700 bg-green-100';
      default:
        return 'text-gray-700 bg-gray-100';
    }
  };

  const getPotentialColor = (potential: string) => {
    switch (potential) {
      case 'High':
        return 'text-green-700 bg-green-100';
      case 'Medium':
        return 'text-yellow-700 bg-yellow-100';
      case 'Low':
        return 'text-gray-700 bg-gray-100';
      default:
        return 'text-gray-700 bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-50 to-orange-50 border border-red-200 rounded-xl p-6">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center">
            <Target className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Competitive Intelligence</h2>
            <p className="text-gray-600">Real-time monitoring and strategic insights</p>
          </div>
        </div>
      </div>

      {/* Competitor Overview */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Competitors Analysis</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-700">Competitor</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Rank</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Traffic</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Change</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Keywords</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Backlinks</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Threat Level</th>
                <th className="text-left py-3 px-4 font-medium text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              {competitors.map((competitor, index) => (
                <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <Users className="w-4 h-4 text-blue-600" />
                      </div>
                      <span className="font-medium text-gray-900">{competitor.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-gray-600">#{competitor.rank}</td>
                  <td className="py-3 px-4 font-medium text-gray-900">{competitor.traffic}</td>
                  <td className="py-3 px-4">
                    <span className={`font-medium ${
                      competitor.change.startsWith('+') ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {competitor.change}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-600">{competitor.keywords.toLocaleString()}</td>
                  <td className="py-3 px-4 text-gray-600">{competitor.backlinks}</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getThreatColor(competitor.threat)}`}>
                      {competitor.threat}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <button className="text-blue-600 hover:text-blue-800">
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Real-time Alerts */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Real-time Competitive Alerts</h3>
        <div className="space-y-3">
          {alerts.map((alert, index) => (
            <div key={index} className={`flex items-center space-x-4 p-4 rounded-lg border ${
              alert.severity === 'high' ? 'bg-red-50 border-red-200' :
              alert.severity === 'medium' ? 'bg-yellow-50 border-yellow-200' :
              'bg-blue-50 border-blue-200'
            }`}>
              <AlertTriangle className={`w-5 h-5 ${
                alert.severity === 'high' ? 'text-red-500' :
                alert.severity === 'medium' ? 'text-yellow-500' :
                'text-blue-500'
              }`} />
              <div className="flex-1">
                <p className="font-medium text-gray-900">{alert.competitor}</p>
                <p className="text-sm text-gray-600">{alert.alert}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-500">{alert.time}</p>
                <button className="text-sm text-blue-600 hover:text-blue-800 font-medium">
                  Analyze
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Opportunities */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Strategic Opportunities</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {opportunities.map((opportunity, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-700 rounded-full">
                  {opportunity.type}
                </span>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${getPotentialColor(opportunity.potential)}`}>
                  {opportunity.potential} Potential
                </span>
              </div>
              
              <h4 className="font-medium text-gray-900 mb-2">{opportunity.title}</h4>
              <p className="text-sm text-gray-600 mb-3">{opportunity.description}</p>
              
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">{opportunity.keywords} keywords</span>
                <span className="text-gray-500">{opportunity.difficulty} difficulty</span>
              </div>
              
              <button className="w-full mt-3 px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 transition-colors">
                Implement Strategy
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Performance Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Market Position</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Your Site</span>
              <div className="flex items-center space-x-2">
                <div className="w-24 bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full" style={{ width: '75%' }}></div>
                </div>
                <span className="text-sm font-medium text-blue-600">75%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Top Competitor</span>
              <div className="flex items-center space-x-2">
                <div className="w-24 bg-gray-200 rounded-full h-2">
                  <div className="bg-red-500 h-2 rounded-full" style={{ width: '95%' }}></div>
                </div>
                <span className="text-sm font-medium text-red-600">95%</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Market Average</span>
              <div className="flex items-center space-x-2">
                <div className="w-24 bg-gray-200 rounded-full h-2">
                  <div className="bg-gray-400 h-2 rounded-full" style={{ width: '60%' }}></div>
                </div>
                <span className="text-sm font-medium text-gray-600">60%</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Monitoring Status</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Active Competitors</span>
              <span className="font-medium text-gray-900">12</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Daily Checks</span>
              <span className="font-medium text-gray-900">48</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Alerts This Week</span>
              <span className="font-medium text-red-600">23</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Opportunities Found</span>
              <span className="font-medium text-green-600">7</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompetitiveIntelligence;