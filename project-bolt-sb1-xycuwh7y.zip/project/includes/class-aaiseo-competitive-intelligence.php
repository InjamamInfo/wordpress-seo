<?php
/**
 * Competitive Intelligence for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Competitive_Intelligence {
    
    private static $instance = null;
    private $database;
    private $ai_engine;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->database = AAISEO_Database::getInstance();
        $this->ai_engine = AAISEO_AI_Engine::getInstance();
        
        $this->initHooks();
    }
    
    private function initHooks() {
        add_action('wp_ajax_aaiseo_add_competitor', array($this, 'addCompetitorAjax'));
        add_action('wp_ajax_aaiseo_remove_competitor', array($this, 'removeCompetitorAjax'));
        add_action('wp_ajax_aaiseo_analyze_competitor', array($this, 'analyzeCompetitorAjax'));
    }
    
    /**
     * Monitor competitors for changes
     */
    public function monitorCompetitors() {
        $competitors = $this->getActiveCompetitors();
        
        foreach ($competitors as $competitor) {
            $this->analyzeCompetitor($competitor['id'], $competitor['domain']);
        }
    }
    
    /**
     * Get active competitors
     */
    private function getActiveCompetitors() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_competitors';
        
        return $wpdb->get_results(
            "SELECT * FROM $table_name WHERE tracking_enabled = 1",
            ARRAY_A
        );
    }
    
    /**
     * Analyze specific competitor
     */
    public function analyzeCompetitor($competitor_id, $domain) {
        // Fetch competitor data
        $competitor_data = $this->fetchCompetitorData($domain);
        
        if (is_wp_error($competitor_data)) {
            return $competitor_data;
        }
        
        // Store analysis
        $this->storeCompetitorAnalysis($competitor_id, $competitor_data);
        
        // Generate insights using AI
        $your_data = $this->getYourSiteData();
        $insights = $this->ai_engine->analyzeCompetitor($competitor_data, $your_data);
        
        if (!is_wp_error($insights)) {
            $this->storeCompetitorInsights($competitor_id, $insights);
        }
        
        // Check for significant changes
        $this->checkForSignificantChanges($competitor_id, $competitor_data);
        
        // Update last analyzed timestamp
        $this->updateLastAnalyzed($competitor_id);
        
        return $competitor_data;
    }
    
    /**
     * Fetch competitor data from various sources
     */
    private function fetchCompetitorData($domain) {
        $data = array();
        
        // Basic website analysis
        $data['basic'] = $this->analyzeWebsite($domain);
        
        // Content analysis
        $data['content'] = $this->analyzeCompetitorContent($domain);
        
        // Technical SEO analysis
        $data['technical'] = $this->analyzeCompetitorTechnical($domain);
        
        // Social media presence
        $data['social'] = $this->analyzeCompetitorSocial($domain);
        
        return $data;
    }
    
    /**
     * Analyze competitor website basics
     */
    private function analyzeWebsite($domain) {
        $url = 'https://' . $domain;
        
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'user-agent' => 'AAISEO-Bot/1.0'
        ));
        
        if (is_wp_error($response)) {
            return array('error' => $response->get_error_message());
        }
        
        $html = wp_remote_retrieve_body($response);
        $headers = wp_remote_retrieve_headers($response);
        
        $analysis = array(
            'response_time' => $this->measureResponseTime($url),
            'page_size' => strlen($html),
            'title' => $this->extractTitle($html),
            'meta_description' => $this->extractMetaDescription($html),
            'h1_tags' => $this->extractH1Tags($html),
            'images_count' => $this->countImages($html),
            'links_count' => $this->countLinks($html),
            'server_info' => $headers->offsetGet('server') ?: '',
            'https_enabled' => strpos($url, 'https://') === 0,
            'mobile_friendly' => $this->checkMobileFriendly($html)
        );
        
        return $analysis;
    }
    
    /**
     * Measure response time
     */
    private function measureResponseTime($url) {
        $start_time = microtime(true);
        
        wp_remote_get($url, array('timeout' => 10));
        
        $end_time = microtime(true);
        
        return round(($end_time - $start_time) * 1000, 2); // milliseconds
    }
    
    /**
     * Extract title from HTML
     */
    private function extractTitle($html) {
        if (preg_match('/<title[^>]*>(.*?)<\/title>/i', $html, $matches)) {
            return trim(html_entity_decode($matches[1]));
        }
        return '';
    }
    
    /**
     * Extract meta description
     */
    private function extractMetaDescription($html) {
        if (preg_match('/<meta[^>]*name=[\'"]description[\'"][^>]*content=[\'"]([^\'"]*)[\'"][^>]*>/i', $html, $matches)) {
            return trim(html_entity_decode($matches[1]));
        }
        return '';
    }
    
    /**
     * Extract H1 tags
     */
    private function extractH1Tags($html) {
        $h1_tags = array();
        if (preg_match_all('/<h1[^>]*>(.*?)<\/h1>/i', $html, $matches)) {
            foreach ($matches[1] as $h1) {
                $h1_tags[] = trim(strip_tags($h1));
            }
        }
        return $h1_tags;
    }
    
    /**
     * Count images
     */
    private function countImages($html) {
        return preg_match_all('/<img[^>]*>/i', $html);
    }
    
    /**
     * Count links
     */
    private function countLinks($html) {
        return preg_match_all('/<a[^>]*href=[\'"][^\'"]*[\'"][^>]*>/i', $html);
    }
    
    /**
     * Check mobile friendliness
     */
    private function checkMobileFriendly($html) {
        // Check for viewport meta tag
        $has_viewport = preg_match('/<meta[^>]*name=[\'"]viewport[\'"][^>]*>/i', $html);
        
        // Check for responsive framework indicators
        $has_bootstrap = strpos($html, 'bootstrap') !== false;
        $has_responsive_css = preg_match('/@media[^{]*\([^)]*max-width[^)]*\)/i', $html);
        
        return $has_viewport && ($has_bootstrap || $has_responsive_css);
    }
    
    /**
     * Analyze competitor content
     */
    private function analyzeCompetitorContent($domain) {
        $content_analysis = array();
        
        // Analyze blog/news section
        $blog_data = $this->analyzeCompetitorBlog($domain);
        $content_analysis['blog'] = $blog_data;
        
        // Analyze main content pages
        $pages_data = $this->analyzeCompetitorPages($domain);
        $content_analysis['pages'] = $pages_data;
        
        return $content_analysis;
    }
    
    /**
     * Analyze competitor blog
     */
    private function analyzeCompetitorBlog($domain) {
        // This would typically involve:
        // 1. Finding the blog/news section
        // 2. Analyzing recent posts
        // 3. Identifying content themes and keywords
        // 4. Measuring posting frequency
        
        return array(
            'recent_posts' => $this->getRecentBlogPosts($domain),
            'posting_frequency' => $this->calculatePostingFrequency($domain),
            'content_themes' => $this->identifyContentThemes($domain)
        );
    }
    
    /**
     * Get recent blog posts
     */
    private function getRecentBlogPosts($domain) {
        // Simplified implementation - would need more sophisticated crawling
        $posts = array();
        
        $common_blog_paths = array('/blog/', '/news/', '/articles/', '/insights/');
        
        foreach ($common_blog_paths as $path) {
            $url = 'https://' . $domain . $path;
            $response = wp_remote_get($url, array('timeout' => 15));
            
            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                $html = wp_remote_retrieve_body($response);
                $post_links = $this->extractBlogPostLinks($html, $domain);
                $posts = array_merge($posts, $post_links);
                break; // Found blog section
            }
        }
        
        return array_slice($posts, 0, 10); // Limit to recent posts
    }
    
    /**
     * Extract blog post links
     */
    private function extractBlogPostLinks($html, $domain) {
        $posts = array();
        
        // Look for common blog post patterns
        $patterns = array(
            '/<article[^>]*>.*?<a[^>]*href=[\'"]([^\'"]*)[\'"][^>]*>(.*?)<\/a>.*?<\/article>/is',
            '/<div[^>]*class=[\'"][^\'\"]*post[^\'\"]*[\'"][^>]*>.*?<a[^>]*href=[\'"]([^\'"]*)[\'"][^>]*>(.*?)<\/a>.*?<\/div>/is'
        );
        
        foreach ($patterns as $pattern) {
            if (preg_match_all($pattern, $html, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $match) {
                    $url = $match[1];
                    $title = strip_tags($match[2]);
                    
                    // Make URL absolute if relative
                    if (strpos($url, 'http') !== 0) {
                        $url = 'https://' . $domain . $url;
                    }
                    
                    $posts[] = array(
                        'url' => $url,
                        'title' => trim($title)
                    );
                }
            }
        }
        
        return $posts;
    }
    
    /**
     * Calculate posting frequency
     */
    private function calculatePostingFrequency($domain) {
        // This would analyze timestamps of recent posts
        // For now, return estimated frequency
        return array(
            'posts_per_week' => 2.5,
            'consistency' => 'moderate'
        );
    }
    
    /**
     * Identify content themes
     */
    private function identifyContentThemes($domain) {
        // This would use NLP to analyze content themes
        // For now, return sample data
        return array(
            'digital marketing', 'SEO', 'content strategy', 'social media'
        );
    }
    
    /**
     * Analyze competitor pages
     */
    private function analyzeCompetitorPages($domain) {
        // Analyze key pages like homepage, about, services, etc.
        $key_pages = array('/', '/about', '/services', '/products', '/contact');
        $pages_analysis = array();
        
        foreach ($key_pages as $page) {
            $url = 'https://' . $domain . $page;
            $response = wp_remote_get($url, array('timeout' => 15));
            
            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                $html = wp_remote_retrieve_body($response);
                
                $pages_analysis[$page] = array(
                    'word_count' => $this->calculateWordCount($html),
                    'keywords' => $this->extractKeywords($html),
                    'headings' => $this->extractHeadings($html),
                    'images' => $this->countImages($html)
                );
            }
        }
        
        return $pages_analysis;
    }
    
    /**
     * Calculate word count
     */
    private function calculateWordCount($html) {
        $text = strip_tags($html);
        $text = preg_replace('/\s+/', ' ', $text);
        return str_word_count($text);
    }
    
    /**
     * Extract keywords (simplified)
     */
    private function extractKeywords($html) {
        $text = strip_tags($html);
        $words = str_word_count(strtolower($text), 1);
        
        // Remove common stop words
        $stop_words = array('the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should');
        $words = array_diff($words, $stop_words);
        
        // Get word frequency
        $word_freq = array_count_values($words);
        arsort($word_freq);
        
        return array_slice(array_keys($word_freq), 0, 20);
    }
    
    /**
     * Extract headings
     */
    private function extractHeadings($html) {
        $headings = array();
        
        for ($i = 1; $i <= 6; $i++) {
            if (preg_match_all("/<h{$i}[^>]*>(.*?)<\/h{$i}>/i", $html, $matches)) {
                foreach ($matches[1] as $heading) {
                    $headings["h{$i}"][] = trim(strip_tags($heading));
                }
            }
        }
        
        return $headings;
    }
    
    /**
     * Analyze competitor technical SEO
     */
    private function analyzeCompetitorTechnical($domain) {
        $technical_analysis = array();
        
        // Check robots.txt
        $robots_url = 'https://' . $domain . '/robots.txt';
        $robots_response = wp_remote_get($robots_url);
        $technical_analysis['robots_txt'] = !is_wp_error($robots_response) && wp_remote_retrieve_response_code($robots_response) === 200;
        
        // Check sitemap
        $sitemap_url = 'https://' . $domain . '/sitemap.xml';
        $sitemap_response = wp_remote_get($sitemap_url);
        $technical_analysis['sitemap'] = !is_wp_error($sitemap_response) && wp_remote_retrieve_response_code($sitemap_response) === 200;
        
        // Check SSL
        $technical_analysis['ssl_enabled'] = strpos($domain, 'https://') === 0;
        
        // Check page speed (simplified)
        $technical_analysis['response_time'] = $this->measureResponseTime('https://' . $domain);
        
        return $technical_analysis;
    }
    
    /**
     * Analyze competitor social media
     */
    private function analyzeCompetitorSocial($domain) {
        // This would check for social media links and presence
        // For now, return basic structure
        return array(
            'facebook' => $this->checkSocialPresence($domain, 'facebook'),
            'twitter' => $this->checkSocialPresence($domain, 'twitter'),
            'linkedin' => $this->checkSocialPresence($domain, 'linkedin'),
            'instagram' => $this->checkSocialPresence($domain, 'instagram')
        );
    }
    
    /**
     * Check social media presence
     */
    private function checkSocialPresence($domain, $platform) {
        // Simplified check - would need more sophisticated analysis
        $homepage_url = 'https://' . $domain;
        $response = wp_remote_get($homepage_url);
        
        if (!is_wp_error($response)) {
            $html = wp_remote_retrieve_body($response);
            return strpos($html, $platform . '.com') !== false;
        }
        
        return false;
    }
    
    /**
     * Get your site data for comparison
     */
    private function getYourSiteData() {
        return array(
            'domain' => parse_url(home_url(), PHP_URL_HOST),
            'posts_count' => wp_count_posts()->publish,
            'pages_count' => wp_count_posts('page')->publish,
            'categories_count' => wp_count_terms('category'),
            'tags_count' => wp_count_terms('post_tag')
        );
    }
    
    /**
     * Store competitor analysis
     */
    private function storeCompetitorAnalysis($competitor_id, $data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_competitor_data';
        
        $wpdb->insert(
            $table_name,
            array(
                'competitor_id' => intval($competitor_id),
                'analysis_type' => 'full_analysis',
                'data' => json_encode($data)
            ),
            array('%d', '%s', '%s')
        );
    }
    
    /**
     * Store competitor insights
     */
    private function storeCompetitorInsights($competitor_id, $insights) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_competitor_data';
        
        $wpdb->insert(
            $table_name,
            array(
                'competitor_id' => intval($competitor_id),
                'analysis_type' => 'ai_insights',
                'data' => json_encode($insights)
            ),
            array('%d', '%s', '%s')
        );
    }
    
    /**
     * Check for significant changes
     */
    private function checkForSignificantChanges($competitor_id, $current_data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_competitor_data';
        
        // Get previous analysis
        $previous_data = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT data FROM $table_name 
                WHERE competitor_id = %d 
                AND analysis_type = 'full_analysis' 
                ORDER BY analyzed_at DESC 
                LIMIT 1 OFFSET 1",
                $competitor_id
            )
        );
        
        if ($previous_data) {
            $previous_data = json_decode($previous_data, true);
            $changes = $this->detectChanges($previous_data, $current_data);
            
            if (!empty($changes)) {
                $this->notifyOfChanges($competitor_id, $changes);
            }
        }
    }
    
    /**
     * Detect changes between analyses
     */
    private function detectChanges($previous, $current) {
        $changes = array();
        
        // Check for new blog posts
        if (isset($previous['content']['blog']['recent_posts']) && isset($current['content']['blog']['recent_posts'])) {
            $prev_posts = $previous['content']['blog']['recent_posts'];
            $curr_posts = $current['content']['blog']['recent_posts'];
            
            $new_posts = array_udiff($curr_posts, $prev_posts, function($a, $b) {
                return strcmp($a['url'], $b['url']);
            });
            
            if (!empty($new_posts)) {
                $changes[] = array(
                    'type' => 'new_content',
                    'description' => sprintf(__('%d new blog posts published', 'autonomous-ai-seo'), count($new_posts)),
                    'data' => $new_posts
                );
            }
        }
        
        // Check for technical changes
        if (isset($previous['technical']) && isset($current['technical'])) {
            $prev_tech = $previous['technical'];
            $curr_tech = $current['technical'];
            
            if ($prev_tech['response_time'] && $curr_tech['response_time']) {
                $speed_change = $curr_tech['response_time'] - $prev_tech['response_time'];
                if (abs($speed_change) > 500) { // 500ms threshold
                    $changes[] = array(
                        'type' => 'performance_change',
                        'description' => sprintf(__('Page speed changed by %dms', 'autonomous-ai-seo'), $speed_change),
                        'data' => array('change' => $speed_change)
                    );
                }
            }
        }
        
        return $changes;
    }
    
    /**
     * Notify of competitor changes
     */
    private function notifyOfChanges($competitor_id, $changes) {
        // Log activity
        AAISEO_Core::getInstance()->logActivity(
            'competitor_change',
            sprintf(__('Detected %d changes in competitor analysis', 'autonomous-ai-seo'), count($changes)),
            array('competitor_id' => $competitor_id, 'changes' => $changes)
        );
        
        // Send email notification if enabled
        $settings = get_option('aaiseo_settings', array());
        if (!empty($settings['competitor_notifications']) && !empty($settings['notification_email'])) {
            $this->sendChangeNotification($competitor_id, $changes, $settings['notification_email']);
        }
    }
    
    /**
     * Send change notification email
     */
    private function sendChangeNotification($competitor_id, $changes, $email) {
        global $wpdb;
        
        $competitor = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}aaiseo_competitors WHERE id = %d",
                $competitor_id
            ),
            ARRAY_A
        );
        
        if (!$competitor) return;
        
        $subject = sprintf(__('Competitor Changes Detected: %s', 'autonomous-ai-seo'), $competitor['domain']);
        
        $message = sprintf(__('We detected the following changes for competitor %s:', 'autonomous-ai-seo'), $competitor['domain']) . "\n\n";
        
        foreach ($changes as $change) {
            $message .= "• " . $change['description'] . "\n";
        }
        
        $message .= "\n" . __('View full analysis in your WordPress admin dashboard.', 'autonomous-ai-seo');
        
        wp_mail($email, $subject, $message);
    }
    
    /**
     * Update last analyzed timestamp
     */
    private function updateLastAnalyzed($competitor_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_competitors';
        
        $wpdb->update(
            $table_name,
            array('last_analyzed' => current_time('mysql')),
            array('id' => intval($competitor_id)),
            array('%s'),
            array('%d')
        );
    }
    
    /**
     * Get competitor data for admin interface
     */
    public function getCompetitorData() {
        global $wpdb;
        
        $competitors_table = $wpdb->prefix . 'aaiseo_competitors';
        $data_table = $wpdb->prefix . 'aaiseo_competitor_data';
        
        $competitors = $wpdb->get_results(
            "SELECT * FROM $competitors_table ORDER BY created_at DESC",
            ARRAY_A
        );
        
        $competitor_data = array();
        
        foreach ($competitors as $competitor) {
            $latest_analysis = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT * FROM $data_table 
                    WHERE competitor_id = %d 
                    AND analysis_type = 'full_analysis' 
                    ORDER BY analyzed_at DESC 
                    LIMIT 1",
                    $competitor['id']
                ),
                ARRAY_A
            );
            
            $competitor['latest_analysis'] = $latest_analysis ? json_decode($latest_analysis['data'], true) : null;
            $competitor_data[] = $competitor;
        }
        
        return $competitor_data;
    }
    
    /**
     * Add competitor via AJAX
     */
    public function addCompetitorAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $domain = sanitize_text_field($_POST['domain']);
        $name = sanitize_text_field($_POST['name']);
        
        if (empty($domain)) {
            wp_send_json_error(__('Domain is required', 'autonomous-ai-seo'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_competitors';
        
        $result = $wpdb->insert(
            $table_name,
            array(
                'domain' => $domain,
                'competitor_name' => $name,
                'tracking_enabled' => 1
            ),
            array('%s', '%s', '%d')
        );
        
        if ($result) {
            $competitor_id = $wpdb->insert_id;
            
            // Schedule initial analysis
            wp_schedule_single_event(time() + 60, 'aaiseo_analyze_competitor', array($competitor_id, $domain));
            
            wp_send_json_success(__('Competitor added successfully', 'autonomous-ai-seo'));
        } else {
            wp_send_json_error(__('Failed to add competitor', 'autonomous-ai-seo'));
        }
    }
    
    /**
     * Remove competitor via AJAX
     */
    public function removeCompetitorAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $competitor_id = intval($_POST['competitor_id']);
        
        global $wpdb;
        
        // Remove competitor data
        $wpdb->delete(
            $wpdb->prefix . 'aaiseo_competitor_data',
            array('competitor_id' => $competitor_id),
            array('%d')
        );
        
        // Remove competitor
        $result = $wpdb->delete(
            $wpdb->prefix . 'aaiseo_competitors',
            array('id' => $competitor_id),
            array('%d')
        );
        
        if ($result) {
            wp_send_json_success(__('Competitor removed successfully', 'autonomous-ai-seo'));
        } else {
            wp_send_json_error(__('Failed to remove competitor', 'autonomous-ai-seo'));
        }
    }
    
    /**
     * Analyze competitor via AJAX
     */
    public function analyzeCompetitorAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $competitor_id = intval($_POST['competitor_id']);
        
        global $wpdb;
        $competitor = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}aaiseo_competitors WHERE id = %d",
                $competitor_id
            ),
            ARRAY_A
        );
        
        if (!$competitor) {
            wp_send_json_error(__('Competitor not found', 'autonomous-ai-seo'));
        }
        
        $result = $this->analyzeCompetitor($competitor_id, $competitor['domain']);
        
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        } else {
            wp_send_json_success(__('Competitor analysis completed', 'autonomous-ai-seo'));
        }
    }
}