<?php
/**
 * Admin interface for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Admin {
    
    private static $instance = null;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_menu', array($this, 'addAdminMenus'));
        add_action('admin_init', array($this, 'initSettings'));
        add_action('admin_notices', array($this, 'adminNotices'));
    }
    
    public function addAdminMenus() {
        // Main menu page
        add_menu_page(
            __('Autonomous AI SEO', 'autonomous-ai-seo'),
            __('AI SEO', 'autonomous-ai-seo'),
            'manage_options',
            'autonomous-ai-seo',
            array($this, 'renderDashboardPage'),
            'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>'),
            30
        );
        
        // Submenu pages
        add_submenu_page(
            'autonomous-ai-seo',
            __('Dashboard', 'autonomous-ai-seo'),
            __('Dashboard', 'autonomous-ai-seo'),
            'manage_options',
            'autonomous-ai-seo',
            array($this, 'renderDashboardPage')
        );
        
        add_submenu_page(
            'autonomous-ai-seo',
            __('AI Optimization', 'autonomous-ai-seo'),
            __('AI Optimization', 'autonomous-ai-seo'),
            'manage_options',
            'aaiseo-optimization',
            array($this, 'renderOptimizationPage')
        );
        
        add_submenu_page(
            'autonomous-ai-seo',
            __('Predictive Analytics', 'autonomous-ai-seo'),
            __('Analytics', 'autonomous-ai-seo'),
            'manage_options',
            'aaiseo-analytics',
            array($this, 'renderAnalyticsPage')
        );
        
        add_submenu_page(
            'autonomous-ai-seo',
            __('Competitive Intelligence', 'autonomous-ai-seo'),
            __('Competitive Intel', 'autonomous-ai-seo'),
            'manage_options',
            'aaiseo-competitive',
            array($this, 'renderCompetitivePage')
        );
        
        add_submenu_page(
            'autonomous-ai-seo',
            __('Core Web Vitals', 'autonomous-ai-seo'),
            __('Web Vitals', 'autonomous-ai-seo'),
            'manage_options',
            'aaiseo-web-vitals',
            array($this, 'renderWebVitalsPage')
        );
        
        add_submenu_page(
            'autonomous-ai-seo',
            __('Content Strategy', 'autonomous-ai-seo'),
            __('Content Strategy', 'autonomous-ai-seo'),
            'manage_options',
            'aaiseo-content',
            array($this, 'renderContentPage')
        );
        
        add_submenu_page(
            'autonomous-ai-seo',
            __('Technical SEO', 'autonomous-ai-seo'),
            __('Technical SEO', 'autonomous-ai-seo'),
            'manage_options',
            'aaiseo-technical',
            array($this, 'renderTechnicalPage')
        );
        
        add_submenu_page(
            'autonomous-ai-seo',
            __('Settings', 'autonomous-ai-seo'),
            __('Settings', 'autonomous-ai-seo'),
            'manage_options',
            'aaiseo-settings',
            array($this, 'renderSettingsPage')
        );
    }
    
    public function initSettings() {
        register_setting('aaiseo_settings', 'aaiseo_settings', array($this, 'validateSettings'));
        
        // General Settings Section
        add_settings_section(
            'aaiseo_general',
            __('General Settings', 'autonomous-ai-seo'),
            array($this, 'renderGeneralSection'),
            'aaiseo_settings'
        );
        
        // AI Settings Section
        add_settings_section(
            'aaiseo_ai',
            __('AI Configuration', 'autonomous-ai-seo'),
            array($this, 'renderAISection'),
            'aaiseo_settings'
        );
        
        // API Settings Section
        add_settings_section(
            'aaiseo_api',
            __('API Configuration', 'autonomous-ai-seo'),
            array($this, 'renderAPISection'),
            'aaiseo_settings'
        );
    }
    
    public function renderDashboardPage() {
        $analytics = AAISEO_Analytics::getInstance();
        $dashboard_data = $analytics->getDashboardData();
        $activity_log = AAISEO_Core::getInstance()->getActivityLog(10);
        
        include AAISEO_PLUGIN_PATH . 'templates/admin/dashboard.php';
    }
    
    public function renderOptimizationPage() {
        $optimizer = AAISEO_Content_Optimizer::getInstance();
        $optimization_data = $optimizer->getOptimizationStatus();

        $tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'optimizations';

        if ($tab === 'ab-tests') {
            include AAISEO_PLUGIN_PATH . 'templates/admin/ab-tests.php';
        } else {
            include AAISEO_PLUGIN_PATH . 'templates/admin/optimization.php';
        }
    }
    
    public function renderAnalyticsPage() {
        $analytics = AAISEO_Analytics::getInstance();
        $analytics_data = $analytics->getPredictiveAnalytics();
        
        include AAISEO_PLUGIN_PATH . 'templates/admin/analytics.php';
    }
    
    public function renderCompetitivePage() {
        $competitive = AAISEO_Competitive_Intelligence::getInstance();
        $competitive_data = $competitive->getCompetitorData();
        
        include AAISEO_PLUGIN_PATH . 'templates/admin/competitive.php';
    }
    
    public function renderWebVitalsPage() {
        $technical = AAISEO_Technical_SEO::getInstance();
        $vitals_data = $technical->getCoreWebVitals();
        
        include AAISEO_PLUGIN_PATH . 'templates/admin/web-vitals.php';
    }
    
    public function renderContentPage() {
        $content = AAISEO_Content_Optimizer::getInstance();
        $content_data = $content->getContentStrategy();
        
        include AAISEO_PLUGIN_PATH . 'templates/admin/content.php';
    }
    
    public function renderTechnicalPage() {
        $technical = AAISEO_Technical_SEO::getInstance();
        $technical_data = $technical->getTechnicalAudit();
        
        include AAISEO_PLUGIN_PATH . 'templates/admin/technical.php';
    }
    
    public function renderSettingsPage() {
        $settings = get_option('aaiseo_settings', array());
        include AAISEO_PLUGIN_PATH . 'templates/admin/settings.php';
    }
    
    public function renderGeneralSection() {
        echo '<p>' . __('Configure general plugin settings.', 'autonomous-ai-seo') . '</p>';
    }
    
    public function renderAISection() {
        echo '<p>' . __('Configure AI engine settings and automation preferences.', 'autonomous-ai-seo') . '</p>';
    }
    
    public function renderAPISection() {
        echo '<p>' . __('Configure external API connections.', 'autonomous-ai-seo') . '</p>';
    }
    
    public function validateSettings($input) {
        $sanitized = array();
        
        // Sanitize boolean values
        $boolean_fields = array(
            'auto_optimization_enabled',
            'content_enhancement_enabled',
            'technical_fixes_enabled',
            'competitive_monitoring_enabled',
            'ai_suggestions_auto_apply',
            'tracking_enabled'
        );
        
        foreach ($boolean_fields as $field) {
            $sanitized[$field] = !empty($input[$field]);
        }
        
        // Sanitize text fields
        $text_fields = array(
            'notification_email',
            'optimization_frequency',
            'google_api_key',
            'openai_api_key',
            'grok_api_key',
            'gemini_api_key',
            'deepseek_api_key',
            'preferred_ai_provider'
        );
        
        foreach ($text_fields as $field) {
            if (isset($input[$field])) {
                $sanitized[$field] = sanitize_text_field($input[$field]);
            }
        }
        
        // Sanitize numeric fields
        if (isset($input['performance_threshold'])) {
            $sanitized['performance_threshold'] = absint($input['performance_threshold']);
        }
        
        return $sanitized;
    }
    
    public function adminNotices() {
        $settings = get_option('aaiseo_settings', array());
        
        // Check if API keys are configured
        if (empty($settings['google_api_key']) || empty($settings['openai_api_key'])) {
            ?>
            <div class="notice notice-warning is-dismissible">
                <p>
                    <?php _e('Autonomous AI SEO requires API keys to function properly.', 'autonomous-ai-seo'); ?>
                    <a href="<?php echo admin_url('admin.php?page=aaiseo-settings'); ?>">
                        <?php _e('Configure API keys', 'autonomous-ai-seo'); ?>
                    </a>
                </p>
            </div>
            <?php
        }
        
        // Show optimization status
        if (!empty($_GET['aaiseo_optimization_complete'])) {
            ?>
            <div class="notice notice-success is-dismissible">
                <p><?php _e('AI optimization completed successfully!', 'autonomous-ai-seo'); ?></p>
            </div>
            <?php
        }
    }
}