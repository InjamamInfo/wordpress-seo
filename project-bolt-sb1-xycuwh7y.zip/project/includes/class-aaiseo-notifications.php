<?php
/**
 * In-app Notifications for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Notifications {
    
    private static $instance = null;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->initHooks();
    }
    
    private function initHooks() {
        add_action('wp_ajax_aaiseo_get_notifications', array($this, 'getNotificationsAjax'));
        add_action('wp_ajax_aaiseo_mark_notification_read', array($this, 'markNotificationReadAjax'));
        add_action('wp_ajax_aaiseo_dismiss_notification', array($this, 'dismissNotificationAjax'));
        add_action('wp_ajax_aaiseo_mark_all_read', array($this, 'markAllReadAjax'));
        add_action('admin_footer', array($this, 'renderNotificationCenter'));
    }
    
    /**
     * Create a new notification
     */
    public function createNotification($type, $title, $message, $data = array(), $user_id = null) {
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_notifications';
        
        $notification_data = array(
            'user_id' => $user_id,
            'type' => $type,
            'title' => $title,
            'message' => $message,
            'data' => json_encode($data),
            'priority' => $this->getNotificationPriority($type),
            'is_read' => 0,
            'is_dismissed' => 0,
            'created_at' => current_time('mysql')
        );
        
        $result = $wpdb->insert($table_name, $notification_data, array(
            '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s'
        ));
        
        if ($result) {
            $notification_id = $wpdb->insert_id;
            
            // Send real-time notification if user is online
            $this->sendRealTimeNotification($user_id, $notification_id, $notification_data);
            
            return $notification_id;
        }
        
        return false;
    }
    
    /**
     * Get notification priority based on type
     */
    private function getNotificationPriority($type) {
        $priorities = array(
            'system_error' => 'high',
            'security_alert' => 'high',
            'optimization_complete' => 'medium',
            'competitor_alert' => 'medium',
            'ab_test_complete' => 'medium',
            'content_suggestion' => 'low',
            'tip' => 'low',
            'update_available' => 'low'
        );
        
        return isset($priorities[$type]) ? $priorities[$type] : 'medium';
    }
    
    /**
     * Send real-time notification
     */
    private function sendRealTimeNotification($user_id, $notification_id, $notification_data) {
        // Store in transient for real-time delivery
        $transient_key = 'aaiseo_realtime_notification_' . $user_id;
        $current_notifications = get_transient($transient_key) ?: array();
        
        $current_notifications[] = array(
            'id' => $notification_id,
            'type' => $notification_data['type'],
            'title' => $notification_data['title'],
            'message' => $notification_data['message'],
            'priority' => $notification_data['priority'],
            'timestamp' => $notification_data['created_at']
        );
        
        set_transient($transient_key, $current_notifications, 300); // 5 minutes
    }
    
    /**
     * Get notifications for user
     */
    public function getNotifications($user_id = null, $limit = 50, $unread_only = false) {
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_notifications';
        
        $where_clause = "WHERE user_id = %d AND is_dismissed = 0";
        $query_params = array($user_id);
        
        if ($unread_only) {
            $where_clause .= " AND is_read = 0";
        }
        
        $notifications = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table_name 
                $where_clause 
                ORDER BY created_at DESC 
                LIMIT %d",
                ...$query_params,
                $limit
            ),
            ARRAY_A
        );
        
        // Decode data field
        foreach ($notifications as &$notification) {
            $notification['data'] = json_decode($notification['data'], true);
            $notification['time_ago'] = human_time_diff(strtotime($notification['created_at']));
        }
        
        return $notifications;
    }
    
    /**
     * Get unread notification count
     */
    public function getUnreadCount($user_id = null) {
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_notifications';
        
        return $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name 
                WHERE user_id = %d AND is_read = 0 AND is_dismissed = 0",
                $user_id
            )
        );
    }
    
    /**
     * Mark notification as read
     */
    public function markAsRead($notification_id, $user_id = null) {
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_notifications';
        
        return $wpdb->update(
            $table_name,
            array('is_read' => 1, 'read_at' => current_time('mysql')),
            array('id' => $notification_id, 'user_id' => $user_id),
            array('%d', '%s'),
            array('%d', '%d')
        );
    }
    
    /**
     * Dismiss notification
     */
    public function dismissNotification($notification_id, $user_id = null) {
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_notifications';
        
        return $wpdb->update(
            $table_name,
            array('is_dismissed' => 1, 'dismissed_at' => current_time('mysql')),
            array('id' => $notification_id, 'user_id' => $user_id),
            array('%d', '%s'),
            array('%d', '%d')
        );
    }
    
    /**
     * Mark all notifications as read
     */
    public function markAllAsRead($user_id = null) {
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_notifications';
        
        return $wpdb->update(
            $table_name,
            array('is_read' => 1, 'read_at' => current_time('mysql')),
            array('user_id' => $user_id, 'is_read' => 0),
            array('%d', '%s'),
            array('%d', '%d')
        );
    }
    
    /**
     * Clean up old notifications
     */
    public function cleanupOldNotifications($days = 30) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_notifications';
        
        $cutoff_date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        return $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM $table_name 
                WHERE (is_dismissed = 1 OR is_read = 1) 
                AND created_at < %s",
                $cutoff_date
            )
        );
    }
    
    /**
     * Create system notifications for common events
     */
    public function notifyOptimizationComplete($post_id, $optimization_count) {
        $post_title = get_the_title($post_id);
        
        $this->createNotification(
            'optimization_complete',
            __('Optimization Complete', 'autonomous-ai-seo'),
            sprintf(
                __('%d optimizations applied to "%s"', 'autonomous-ai-seo'),
                $optimization_count,
                $post_title
            ),
            array(
                'post_id' => $post_id,
                'optimization_count' => $optimization_count,
                'action_url' => admin_url('post.php?post=' . $post_id . '&action=edit')
            )
        );
    }
    
    public function notifyCompetitorAlert($competitor_domain, $alert_type, $details) {
        $this->createNotification(
            'competitor_alert',
            __('Competitor Alert', 'autonomous-ai-seo'),
            sprintf(
                __('%s: %s', 'autonomous-ai-seo'),
                $competitor_domain,
                $details
            ),
            array(
                'competitor_domain' => $competitor_domain,
                'alert_type' => $alert_type,
                'action_url' => admin_url('admin.php?page=aaiseo-competitive')
            )
        );
    }
    
    public function notifyABTestComplete($test_id, $winning_variation) {
        $this->createNotification(
            'ab_test_complete',
            __('A/B Test Complete', 'autonomous-ai-seo'),
            sprintf(
                __('Test #%d completed. Variation %d is the winner!', 'autonomous-ai-seo'),
                $test_id,
                $winning_variation
            ),
            array(
                'test_id' => $test_id,
                'winning_variation' => $winning_variation,
                'action_url' => admin_url('admin.php?page=aaiseo-optimization&test_id=' . $test_id)
            )
        );
    }
    
    public function notifyTechnicalIssue($issue_type, $severity, $description) {
        $this->createNotification(
            $severity === 'high' ? 'system_error' : 'content_suggestion',
            __('Technical Issue Detected', 'autonomous-ai-seo'),
            sprintf(
                __('%s: %s', 'autonomous-ai-seo'),
                ucwords(str_replace('_', ' ', $issue_type)),
                $description
            ),
            array(
                'issue_type' => $issue_type,
                'severity' => $severity,
                'action_url' => admin_url('admin.php?page=aaiseo-technical')
            )
        );
    }
    
    public function notifyContentSuggestion($topic, $opportunity_score) {
        $this->createNotification(
            'content_suggestion',
            __('Content Opportunity', 'autonomous-ai-seo'),
            sprintf(
                __('High-opportunity topic identified: %s (Score: %d)', 'autonomous-ai-seo'),
                $topic,
                $opportunity_score
            ),
            array(
                'topic' => $topic,
                'opportunity_score' => $opportunity_score,
                'action_url' => admin_url('admin.php?page=aaiseo-content')
            )
        );
    }
    
    /**
     * Render notification center HTML
     */
    public function renderNotificationCenter() {
        // Only show on AAISEO admin pages
        $screen = get_current_screen();
        if (!$screen || strpos($screen->id, 'aaiseo') === false) {
            return;
        }
        
        ?>
        <div id="aaiseo-notification-center" class="aaiseo-notification-center">
            <div class="notification-header">
                <h3><?php _e('Notifications', 'autonomous-ai-seo'); ?></h3>
                <div class="notification-actions">
                    <button id="mark-all-read" class="button button-secondary">
                        <?php _e('Mark All Read', 'autonomous-ai-seo'); ?>
                    </button>
                    <button id="close-notifications" class="button">×</button>
                </div>
            </div>
            <div class="notification-list" id="notification-list">
                <div class="loading-notifications">
                    <span class="spinner is-active"></span>
                    <?php _e('Loading notifications...', ''); ?>
                </div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Notification center toggle
            $('.aaiseo-notification-toggle').on('click', function(e) {
                e.preventDefault();
                $('#aaiseo-notification-center').toggleClass('open');
                
                if ($('#aaiseo-notification-center').hasClass('open')) {
                    loadNotifications();
                }
            });
            
            // Close notification center
            $('#close-notifications').on('click', function() {
                $('#aaiseo-notification-center').removeClass('open');
            });
            
            // Mark all as read
            $('#mark-all-read').on('click', function() {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'aaiseo_mark_all_read',
                        nonce: aaiseo_admin.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            loadNotifications();
                            updateNotificationCount(0);
                        }
                    }
                });
            });
            
            // Load notifications
            function loadNotifications() {
                $('#notification-list').html('<div class="loading-notifications"><span class="spinner is-active"></span> Loading notifications...</div>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'aaiseo_get_notifications',
                        nonce: aaiseo_admin.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            renderNotifications(response.data.notifications);
                            updateNotificationCount(response.data.unread_count);
                        } else {
                            $('#notification-list').html('<div class="no-notifications">Failed to load notifications</div>');
                        }
                    },
                    error: function() {
                        $('#notification-list').html('<div class="no-notifications">Failed to load notifications</div>');
                    }
                });
            }
            
            // Render notifications
            function renderNotifications(notifications) {
                if (notifications.length === 0) {
                    $('#notification-list').html('<div class="no-notifications">No notifications</div>');
                    return;
                }
                
                let html = '';
                
                notifications.forEach(function(notification) {
                    const priorityClass = notification.priority;
                    const readClass = notification.is_read ? 'read' : 'unread';
                    
                    html += `
                        <div class="notification-item ${readClass} ${priorityClass}" data-id="${notification.id}">
                            <div class="notification-content">
                                <h4 class="notification-title">${notification.title}</h4>
                                <p class="notification-message">${notification.message}</p>
                                <div class="notification-meta">
                                    <span class="notification-time">${notification.time_ago} ago</span>
                                    ${notification.data.action_url ? `<a href="${notification.data.action_url}" class="notification-action">View</a>` : ''}
                                </div>
                            </div>
                            <div class="notification-actions">
                                ${!notification.is_read ? `<button class="mark-read" data-id="${notification.id}">Mark Read</button>` : ''}
                                <button class="dismiss" data-id="${notification.id}">Dismiss</button>
                            </div>
                        </div>
                    `;
                });
                
                $('#notification-list').html(html);
                
                // Attach event handlers
                $('.notification-item .mark-read').on('click', function() {
                    const id = $(this).data('id');
                    markNotificationRead(id);
                });
                
                $('.notification-item .dismiss').on('click', function() {
                    const id = $(this).data('id');
                    dismissNotification(id);
                });
                
                // Mark as read when clicked
                $('.notification-item.unread').on('click', function(e) {
                    if (!$(e.target).hasClass('dismiss') && !$(e.target).hasClass('mark-read')) {
                        const id = $(this).data('id');
                        markNotificationRead(id);
                    }
                });
            }
            
            // Mark notification as read
            function markNotificationRead(id) {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'aaiseo_mark_notification_read',
                        notification_id: id,
                        nonce: aaiseo_admin.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            $(`.notification-item[data-id="${id}"]`).removeClass('unread').addClass('read');
                            $(`.notification-item[data-id="${id}"] .mark-read`).remove();
                            
                            // Update unread count
                            const currentCount = parseInt($('.aaiseo-notification-count').text());
                            updateNotificationCount(Math.max(0, currentCount - 1));
                        }
                    }
                });
            }
            
            // Dismiss notification
            function dismissNotification(id) {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'aaiseo_dismiss_notification',
                        notification_id: id,
                        nonce: aaiseo_admin.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            $(`.notification-item[data-id="${id}"]`).slideUp(function() {
                                $(this).remove();
                                
                                if ($('.notification-item').length === 0) {
                                    $('#notification-list').html('<div class="no-notifications">No notifications</div>');
                                }
                            });
                            
                            // Update unread count if it was unread
                            if ($(`.notification-item[data-id="${id}"]`).hasClass('unread')) {
                                const currentCount = parseInt($('.aaiseo-notification-count').text());
                                updateNotificationCount(Math.max(0, currentCount - 1));
                            }
                        }
                    }
                });
            }
            
            // Update notification count
            function updateNotificationCount(count) {
                $('.aaiseo-notification-count').text(count);
                
                if (count > 0) {
                    $('.aaiseo-notification-count').show();
                } else {
                    $('.aaiseo-notification-count').hide();
                }
            }
            
            // Check for new notifications periodically
            setInterval(function() {
                if ($('#aaiseo-notification-center').hasClass('open')) {
                    loadNotifications();
                } else {
                    checkNewNotifications();
                }
            }, 60000); // Every minute
            
            // Check for new notifications without opening the panel
            function checkNewNotifications() {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'aaiseo_get_notifications',
                        unread_only: true,
                        nonce: aaiseo_admin.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            updateNotificationCount(response.data.unread_count);
                        }
                    }
                });
            }
            
            // Initial check
            checkNewNotifications();
        });
        </script>
        
        <style>
        .aaiseo-notification-center {
            position: fixed;
            top: 32px;
            right: -400px;
            width: 380px;
            height: calc(100vh - 32px);
            background: white;
            box-shadow: -2px 0 10px rgba(0, 0, 0, 0.1);
            z-index: 9999;
            transition: right 0.3s ease;
            display: flex;
            flex-direction: column;
        }
        
        .aaiseo-notification-center.open {
            right: 0;
        }
        
        .notification-header {
            padding: 15px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .notification-header h3 {
            margin: 0;
            font-size: 16px;
        }
        
        .notification-actions {
            display: flex;
            gap: 8px;
        }
        
        #close-notifications {
            font-size: 18px;
            line-height: 1;
            padding: 0 5px;
        }
        
        .notification-list {
            flex: 1;
            overflow-y: auto;
            padding: 15px;
        }
        
        .notification-item {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 10px;
            border-left: 3px solid #e5e7eb;
            background: #f9fafb;
            transition: all 0.2s ease;
        }
        
        .notification-item.unread {
            background: #f0f9ff;
            border-left-color: #3b82f6;
        }
        
        .notification-item.high {
            border-left-color: #ef4444;
        }
        
        .notification-item.medium {
            border-left-color: #f59e0b;
        }
        
        .notification-item.low {
            border-left-color: #10b981;
        }
        
        .notification-title {
            margin: 0 0 5px 0;
            font-size: 14px;
            font-weight: 600;
        }
        
        .notification-message {
            margin: 0 0 10px 0;
            font-size: 13px;
            color: #6b7280;
        }
        
        .notification-meta {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #9ca3af;
        }
        
        .notification-action {
            color: #3b82f6;
            text-decoration: none;
        }
        
        .notification-actions {
            display: flex;
            gap: 8px;
            margin-top: 10px;
        }
        
        .notification-actions button {
            background: none;
            border: none;
            font-size: 12px;
            color: #6b7280;
            cursor: pointer;
            padding: 0;
            text-decoration: underline;
        }
        
        .notification-actions button:hover {
            color: #3b82f6;
        }
        
        .no-notifications,
        .loading-notifications {
            padding: 20px;
            text-align: center;
            color: #6b7280;
        }
        
        .aaiseo-notification-count {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 18px;
            height: 18px;
            background: #ef4444;
            color: white;
            border-radius: 50%;
            font-size: 11px;
            position: absolute;
            top: -5px;
            right: -5px;
        }
        </style>
        <?php
    }
    
    /**
     * AJAX handlers
     */
    public function getNotificationsAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $unread_only = isset($_POST['unread_only']) && $_POST['unread_only'] === 'true';
        $limit = isset($_POST['limit']) ? intval($_POST['limit']) : 50;
        
        $notifications = $this->getNotifications(null, $limit, $unread_only);
        $unread_count = $this->getUnreadCount();
        
        wp_send_json_success(array(
            'notifications' => $notifications,
            'unread_count' => $unread_count
        ));
    }
    
    public function markNotificationReadAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $notification_id = intval($_POST['notification_id']);
        
        if ($this->markAsRead($notification_id)) {
            wp_send_json_success(__('Notification marked as read', 'autonomous-ai-seo'));
        } else {
            wp_send_json_error(__('Failed to mark notification as read', 'autonomous-ai-seo'));
        }
    }
    
    public function dismissNotificationAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $notification_id = intval($_POST['notification_id']);
        
        if ($this->dismissNotification($notification_id)) {
            wp_send_json_success(__('Notification dismissed', 'autonomous-ai-seo'));
        } else {
            wp_send_json_error(__('Failed to dismiss notification', 'autonomous-ai-seo'));
        }
    }
    
    public function markAllReadAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        if ($this->markAllAsRead()) {
            wp_send_json_success(__('All notifications marked as read', 'autonomous-ai-seo'));
        } else {
            wp_send_json_error(__('Failed to mark all notifications as read', 'autonomous-ai-seo'));
        }
    }
}