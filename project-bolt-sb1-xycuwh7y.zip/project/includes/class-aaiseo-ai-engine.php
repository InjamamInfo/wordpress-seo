<?php
/**
 * Enhanced AI Engine for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_AI_Engine {
    
    private static $instance = null;
    private $settings;
    private $grok_api_key = '';
    private $gemini_api_key = '';
    private $deepseek_api_key = '';
    private $preferred_provider = 'openai';
    private $api_base_url = 'https://api.openai.com/v1/';
    private $cache_duration = 3600; // 1 hour cache
    private $preferred_provider = 'openai';
    private $api_keys = array();
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $settings = get_option('aaiseo_settings', array());
        $this->settings = $settings;
        $this->preferred_provider = !empty($settings['preferred_ai_provider']) ? $settings['preferred_ai_provider'] : 'openai';
        
        // Initialize API keys
        $this->api_keys = array(
            'openai' => !empty($settings['openai_api_key']) ? $settings['openai_api_key'] : '',
            'grok' => !empty($settings['grok_api_key']) ? $settings['grok_api_key'] : '',
            'gemini' => !empty($settings['gemini_api_key']) ? $settings['gemini_api_key'] : '',
            'deepseek' => !empty($settings['deepseek_api_key']) ? $settings['deepseek_api_key'] : ''
        );
    }
    
    /**
     * Get API provider status
     */
    public function getAPIProviderStatus() {
        $providers = array(
            'openai' => array(
                'name' => 'OpenAI (GPT)',
                'available' => !empty($this->api_keys['openai']),
                'is_active' => $this->preferred_provider === 'openai'
            ),
            'grok' => array(
                'name' => 'Grok',
                'available' => !empty($this->api_keys['grok']),
                'is_active' => $this->preferred_provider === 'grok'
            ),
            'gemini' => array(
                'name' => 'Google Gemini',
                'available' => !empty($this->api_keys['gemini']),
                'is_active' => $this->preferred_provider === 'gemini'
            ),
            'deepseek' => array(
                'name' => 'DeepSeek',
                'available' => !empty($this->api_keys['deepseek']),
                'is_active' => $this->preferred_provider === 'deepseek'
            ),
            'internal' => array(
                'name' => 'Internal AI (Fallback)',
                'available' => true,
                'is_active' => $this->preferred_provider === 'internal'
            )
        );
        
        // Determine active provider - use preferred if available, otherwise fallback
        $active_provider = $this->preferred_provider;
        
        if ($active_provider !== 'internal' && (!isset($providers[$active_provider]) || !$providers[$active_provider]['available'])) {
            // Fallback to available provider
            foreach (['openai', 'gemini', 'grok', 'deepseek'] as $provider) {
                if ($providers[$provider]['available']) {
                    $active_provider = $provider;
                    break;
                }
            }
            
            // If no API keys available, use internal
            if (!$providers[$active_provider]['available']) {
                $active_provider = 'internal';
            }
        }
        
        return array(
            'providers' => $providers,
            'active_provider' => $active_provider
        );
        $this->grok_api_key = !empty($settings['grok_api_key']) ? $settings['grok_api_key'] : '';
        $this->gemini_api_key = !empty($settings['gemini_api_key']) ? $settings['gemini_api_key'] : '';
        $this->deepseek_api_key = !empty($settings['deepseek_api_key']) ? $settings['deepseek_api_key'] : '';
        $this->preferred_provider = !empty($settings['preferred_ai_provider']) ? $settings['preferred_ai_provider'] : 'openai';
    }
    
    /**
     * Select the appropriate AI provider based on settings and available API keys
     */
    private function selectAIProvider($provider = null) {
        // If no provider specified, use the preferred provider
        if (!$provider) {
            $provider = $this->preferred_provider;
        }
        
        // Check if the selected provider is available
        switch ($provider) {
            case 'grok':
                if (!empty($this->grok_api_key)) {
                    return 'grok';
                }
                break;
            case 'gemini':
                if (!empty($this->gemini_api_key)) {
                    return 'gemini';
                }
                break;
            case 'deepseek':
                if (!empty($this->deepseek_api_key)) {
                    return 'deepseek';
                }
                break;
            case 'openai':
                if (!empty($this->openai_api_key)) {
                    return 'openai';
                }
                break;
            case 'internal':
                return 'internal';
        }
        
        // If the selected provider is not available, fall back to any available provider
        if (!empty($this->openai_api_key)) return 'openai';
        if (!empty($this->grok_api_key)) return 'grok';
        if (!empty($this->gemini_api_key)) return 'gemini';
        if (!empty($this->deepseek_api_key)) return 'deepseek';
        
        // If no external provider is available, fall back to internal methods
        return 'internal';
    }
    
    /**
     * Make a request to the appropriate AI provider
     */
    private function makeAIRequest($prompt, $system_prompt = '', $provider = null) {
        $selected_provider = $this->selectAIProvider($provider);
        
        switch ($selected_provider) {
            case 'openai':
                $messages = [];
                if (!empty($system_prompt)) {
                    $messages[] = [
                        'role' => 'system',
                        'content' => $system_prompt
                    ];
                }
                $messages[] = [
                    'role' => 'user',
                    'content' => $prompt
                ];
                
                $response = $this->makeOpenAIRequest('chat/completions', array(
                    'model' => 'gpt-3.5-turbo',
                    'messages' => $messages,
                    'max_tokens' => 3000,
                    'temperature' => 0.3
                ));
                
                if (is_wp_error($response)) {
                    return $response;
                }
                
                $result = json_decode($response, true);
                
                if (isset($result['choices'][0]['message']['content'])) {
                    return $result['choices'][0]['message']['content'];
                }
                
                return new WP_Error('invalid_response', __('Invalid OpenAI response', 'autonomous-ai-seo'));
                
            case 'grok':
                return $this->makeGrokRequest($prompt, $system_prompt);
                
            case 'gemini':
                return $this->makeGeminiRequest($prompt);
                
            case 'deepseek':
                return $this->makeDeepSeekRequest($prompt, $system_prompt);
                
            case 'internal':
                return $this->generateInternalResponse($prompt);
                
            default:
                return new WP_Error('invalid_provider', __('Invalid AI provider', 'autonomous-ai-seo'));
        }
    }
    
    /**
     * Make a request to the Grok API
     */
    private function makeGrokRequest($prompt, $system_prompt = '', $retry_count = 0) {
        if (empty($this->grok_api_key)) {
            return new WP_Error('no_api_key', __('Grok API key not configured', 'autonomous-ai-seo'));
        }
        
        // Construct the API URL (placeholder)
        $url = 'https://api.grok.x/v1/chat/completions';
        
        // Prepare the messages array
        $messages = [];
        if (!empty($system_prompt)) {
            $messages[] = [
                'role' => 'system',
                'content' => $system_prompt
            ];
        }
        $messages[] = [
            'role' => 'user',
            'content' => $prompt
        ];
        
        $args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->grok_api_key
            ),
            'body' => json_encode(array(
                'messages' => $messages,
                'temperature' => 0.7,
                'max_tokens' => 3000
            )),
            'timeout' => 60
        );
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            // Retry up to 3 times for network errors
            if ($retry_count < 3) {
                sleep(1); // Wait 1 second before retry
                return $this->makeGrokRequest($prompt, $system_prompt, $retry_count + 1);
            }
            return $response;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200) {
            $error_data = json_decode($response_body, true);
            $error_message = isset($error_data['error']['message']) ? $error_data['error']['message'] : 'API request failed';
            return new WP_Error('api_error', $error_message);
        }
        
        // Parse the response and extract the content
        $result = json_decode($response_body, true);
        
        if (isset($result['choices'][0]['message']['content'])) {
            return $result['choices'][0]['message']['content'];
        }
        
        return new WP_Error('invalid_response', __('Invalid Grok API response', 'autonomous-ai-seo'));
    }
    
    /**
     * Make a request to the Google Gemini API
     */
    private function makeGeminiRequest($prompt, $retry_count = 0) {
        if (empty($this->gemini_api_key)) {
            return new WP_Error('no_api_key', __('Gemini API key not configured', 'autonomous-ai-seo'));
        }
        
        // Construct the API URL
        $url = 'https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key=' . $this->gemini_api_key;
        
        $args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'contents' => array(
                    array(
                        'parts' => array(
                            array(
                                'text' => $prompt
                            )
                        )
                    )
                ),
                'generationConfig' => array(
                    'temperature' => 0.7,
                    'topK' => 40,
                    'topP' => 0.95,
                    'maxOutputTokens' => 8192,
                )
            )),
            'timeout' => 60
        );
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            // Retry up to 3 times for network errors
            if ($retry_count < 3) {
                sleep(1); // Wait 1 second before retry
                return $this->makeGeminiRequest($prompt, $retry_count + 1);
            }
            return $response;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200) {
            $error_data = json_decode($response_body, true);
            $error_message = isset($error_data['error']['message']) ? $error_data['error']['message'] : 'API request failed';
            return new WP_Error('api_error', $error_message);
        }
        
        // Parse the response and extract the content
        $result = json_decode($response_body, true);
        
        if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
            return $result['candidates'][0]['content']['parts'][0]['text'];
        }
        
        return new WP_Error('invalid_response', __('Invalid Gemini API response', 'autonomous-ai-seo'));
    }
    
    /**
     * Make a request to the DeepSeek API
     */
    private function makeDeepSeekRequest($prompt, $system_prompt = '', $retry_count = 0) {
        if (empty($this->deepseek_api_key)) {
            return new WP_Error('no_api_key', __('DeepSeek API key not configured', 'autonomous-ai-seo'));
        }
        
        // Construct the API URL (placeholder)
        $url = 'https://api.deepseek.com/v1/chat/completions';
        
        // Prepare the messages array
        $messages = [];
        if (!empty($system_prompt)) {
            $messages[] = [
                'role' => 'system',
                'content' => $system_prompt
            ];
        }
        $messages[] = [
            'role' => 'user',
            'content' => $prompt
        ];
        
        $args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->deepseek_api_key
            ),
            'body' => json_encode(array(
                'messages' => $messages,
                'model' => 'deepseek-chat',
                'temperature' => 0.7,
                'max_tokens' => 3000
            )),
            'timeout' => 60
        );
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            // Retry up to 3 times for network errors
            if ($retry_count < 3) {
                sleep(1); // Wait 1 second before retry
                return $this->makeDeepSeekRequest($prompt, $system_prompt, $retry_count + 1);
            }
            return $response;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200) {
            $error_data = json_decode($response_body, true);
            $error_message = isset($error_data['error']['message']) ? $error_data['error']['message'] : 'API request failed';
            return new WP_Error('api_error', $error_message);
        }
        
        // Parse the response and extract the content
        $result = json_decode($response_body, true);
        
        if (isset($result['choices'][0]['message']['content'])) {
            return $result['choices'][0]['message']['content'];
        }
        
        return new WP_Error('invalid_response', __('Invalid DeepSeek API response', 'autonomous-ai-seo'));
    }
    
    /**
     * Generate a response without external AI using internal algorithms
     */
    private function generateInternalResponse($prompt) {
        // Parse the prompt to determine the type of analysis needed
        if (strpos($prompt, 'content') !== false && strpos($prompt, 'analyze') !== false) {
            return $this->generateInternalContentAnalysis($prompt);
        } elseif (strpos($prompt, 'technical') !== false) {
            return $this->generateInternalTechnicalRecommendations($prompt);
        } elseif (strpos($prompt, 'keyword') !== false) {
            return $this->generateInternalKeywordSuggestions($prompt);
        } else {
            // Default response
            return json_encode([
                'message' => 'Generated using internal algorithms. For more advanced analysis, please configure an external AI provider.',
                'recommendations' => [
                    'Add more detailed content to improve depth',
                    'Include relevant keywords naturally throughout the text',
                    'Ensure proper heading structure (H2, H3) for better organization'
                ]
            ]);
        }
    }
    
    /**
     * Generate content analysis using internal algorithms without external AI
     */
    private function generateInternalContentAnalysis($prompt) {
        // Extract content from the prompt
        preg_match('/Content:(.*?)(?:\n\n|$)/s', $prompt, $matches);
        $content = isset($matches[1]) ? trim($matches[1]) : '';
        
        if (empty($content)) {
            return json_encode([
                'error' => 'No content found for analysis'
            ]);
        }
        
        // Basic content metrics
        $word_count = str_word_count(strip_tags($content));
        $sentences = preg_split('/[.!?]+/', $content, -1, PREG_SPLIT_NO_EMPTY);
        $sentence_count = count($sentences);
        $avg_sentence_length = $sentence_count > 0 ? $word_count / $sentence_count : 0;
        
        // Basic keyword analysis
        $words = str_word_count(strtolower(strip_tags($content)), 1);
        $word_freq = array_count_values($words);
        arsort($word_freq);
        $top_keywords = array_slice($word_freq, 0, 10, true);
        
        // Calculate scores
        $seo_score = $this->calculateBasicSeoScore($word_count, $avg_sentence_length, $content);
        $readability_score = $this->calculateReadabilityScore($content);
        
        // Generate suggestions
        $suggestions = $this->generateBasicSuggestions($word_count, $avg_sentence_length, $content);
        
        // Return results in expected format
        return json_encode([
            'seo_score' => $seo_score,
            'content_quality' => [
                'readability_score' => $readability_score,
                'word_count' => $word_count,
                'avg_sentence_length' => round($avg_sentence_length, 1),
                'content_depth' => $word_count > 1000 ? 85 : ($word_count > 500 ? 65 : 40)
            ],
            'top_keywords' => array_keys($top_keywords),
            'improvement_suggestions' => $suggestions
        ]);
    }
    
    /**
     * Calculate a basic SEO score based on content metrics
     */
    private function calculateBasicSeoScore($word_count, $avg_sentence_length, $content) {
        $score = 50; // Base score
        
        // Word count factor (up to 30 points)
        if ($word_count < 300) {
            $score -= 10; // Too short
        } elseif ($word_count >= 300 && $word_count < 600) {
            $score += 10;
        } elseif ($word_count >= 600 && $word_count < 1000) {
            $score += 15;
        } elseif ($word_count >= 1000 && $word_count < 1500) {
            $score += 20;
        } elseif ($word_count >= 1500) {
            $score += 25;
        }
        
        // Sentence length factor (up to 10 points)
        if ($avg_sentence_length > 30) {
            $score -= 10; // Sentences too long
        } elseif ($avg_sentence_length > 25) {
            $score -= 5; // Sentences a bit long
        } elseif ($avg_sentence_length >= 15 && $avg_sentence_length <= 20) {
            $score += 10; // Ideal range
        }
        
        // Structure factor (up to 20 points)
        if (strpos($content, '<h2') !== false || strpos($content, '<h3') !== false) {
            $score += 10; // Has subheadings
        }
        if (strpos($content, '<ul') !== false || strpos($content, '<ol') !== false) {
            $score += 5; // Has lists
        }
        if (strpos($content, '<img') !== false) {
            $score += 5; // Has images
        }
        
        return min(100, max(0, $score));
    }
    
    /**
     * Calculate readability score
     */
    private function calculateReadabilityScore($content) {
        // Simplified readability calculation
        $text = strip_tags($content);
        $words = str_word_count($text);
        $sentences = count(preg_split('/[.!?]+/', $text, -1, PREG_SPLIT_NO_EMPTY));
        
        if ($sentences == 0) return 0;
        
        $avg_words_per_sentence = $words / $sentences;
        
        // Very simple scoring
        if ($avg_words_per_sentence > 30) {
            return 30; // Very difficult
        } elseif ($avg_words_per_sentence > 25) {
            return 45; // Difficult
        } elseif ($avg_words_per_sentence > 20) {
            return 60; // Moderately difficult
        } elseif ($avg_words_per_sentence > 15) {
            return 75; // Standard
        } elseif ($avg_words_per_sentence > 10) {
            return 85; // Fairly easy
        } else {
            return 95; // Very easy
        }
    }
    
    /**
     * Generate basic improvement suggestions
     */
    private function generateBasicSuggestions($word_count, $avg_sentence_length, $content) {
        $suggestions = [];
        
        // Word count suggestions
        if ($word_count < 300) {
            $suggestions[] = "Increase content length to at least 300 words for better SEO performance.";
        }
        
        // Sentence length suggestions
        if ($avg_sentence_length > 25) {
            $suggestions[] = "Break down longer sentences to improve readability. Aim for an average of 15-20 words per sentence.";
        }
        
        // Structure suggestions
        if (strpos($content, '<h2') === false && strpos($content, '<h3') === false) {
            $suggestions[] = "Add subheadings (H2, H3) to structure your content and improve readability.";
        }
        
        if (strpos($content, '<ul') === false && strpos($content, '<ol') === false) {
            $suggestions[] = "Include bullet points or numbered lists to break up text and highlight important information.";
        }
        
        if (strpos($content, '<img') === false) {
            $suggestions[] = "Add relevant images with descriptive alt text to enhance engagement and accessibility.";
        }
        
        // Add some standard suggestions
        $suggestions[] = "Ensure your primary keyword appears in the title, first paragraph, and at least one subheading.";
        $suggestions[] = "Include a clear call-to-action (CTA) at the end of your content.";
        $suggestions[] = "Add internal links to other relevant content on your website.";
        
        return array_slice($suggestions, 0, 5); // Return top 5 suggestions
    }
    
    /**
     * Generate internal technical recommendations
     */
    private function generateInternalTechnicalRecommendations($prompt) {
        // This would analyze technical audit data and generate recommendations
        // For now, return some standard recommendations
        return json_encode([
            'critical_fixes' => [
                [
                    'issue' => 'Missing meta descriptions',
                    'solution' => 'Add unique meta descriptions to all pages',
                    'impact' => 'Improved click-through rates from search results'
                ],
                [
                    'issue' => 'Slow page load speed',
                    'solution' => 'Optimize images and enable browser caching',
                    'impact' => 'Better user experience and improved Core Web Vitals'
                ]
            ],
            'htaccess_rules' => [
                'Enable browser caching for static resources',
                'Enable GZIP compression'
            ],
            'schema_markup' => [
                'recommended_types' => ['Article', 'FAQPage', 'Organization']
            ]
        ]);
    }
    
    /**
     * Generate internal keyword suggestions
     */
    private function generateInternalKeywordSuggestions($prompt) {
        // Extract primary keyword if present
        preg_match('/keyword[s]?:?\s*([^\n]+)/i', $prompt, $matches);
        $primary_keyword = isset($matches[1]) ? trim($matches[1]) : '';
        
        if (empty($primary_keyword)) {
            $primary_keyword = 'SEO';
        }
        
        // Generate variations
        $variations = [
            $primary_keyword . ' tips',
            $primary_keyword . ' guide',
            'best ' . $primary_keyword,
            'how to ' . $primary_keyword,
            $primary_keyword . ' examples',
            $primary_keyword . ' strategies',
            $primary_keyword . ' tools',
            'improve ' . $primary_keyword,
            $primary_keyword . ' benefits',
            $primary_keyword . ' vs traditional methods'
        ];
        
        return json_encode([
            'primary_keyword' => $primary_keyword,
            'semantic_keywords' => array_slice($variations, 0, 5),
            'long_tail_variations' => array_slice($variations, 5)
        ]);
    }
    
    /**
     * Enhanced content analysis with sentiment and plagiarism checking
     */
    public function analyzeContent($content, $target_keywords = array(), $context = array(), $provider = null) {
        // Get active provider
        $provider_status = $this->getAPIProviderStatus();
        $provider = $provider_status['active_provider'];
        
        // If using internal, use simplified analysis
        if ($provider === 'internal') {
            return $this->performInternalAnalysis($content, $target_keywords, $context);
        // Check cache first regardless of provider
        $cache_key = 'aaiseo_content_analysis_' . md5($content . serialize($target_keywords) . $selected_provider);
        $cached_result = get_transient($cache_key);
        
        if ($cached_result !== false) {
            return $cached_result;
        }
        
        // If using internal analysis, don't use external AI
        if ($selected_provider === 'internal') {
            $analysis = $this->generateInternalContentAnalysis($content);
            
            // Cache the result
            set_transient($cache_key, $analysis, $this->cache_duration);
            
            return $analysis;
        }
        
        $prompt = $this->buildEnhancedContentAnalysisPrompt($content, $target_keywords, $context);
        $system_prompt = 'You are an expert SEO analyst with expertise in content optimization, sentiment analysis, and plagiarism detection. Provide comprehensive analysis in JSON format.';
        $response = $this->makeAIRequest(
            $provider, 
            $prompt, 
            'You are an expert SEO analyst with expertise in content optimization, sentiment analysis, and plagiarism detection. Provide comprehensive analysis in JSON format.',
            3000,
            0.3
        );
    }
    
    /**
     * Perform internal content analysis (fallback when no API keys are available)
     */
    private function performInternalAnalysis($content, $target_keywords = array(), $context = array()) {
        $word_count = str_word_count(strip_tags($content));
        $text_length = strlen(strip_tags($content));
        $avg_word_length = $word_count > 0 ? $text_length / $word_count : 0;
        
        // Calculate readability score (simplified Flesch-Kincaid)
        $sentences = preg_split('/[.!?]+/', $content);
        $sentence_count = count(array_filter($sentences));
        
        $readability_score = 0;
        if ($sentence_count > 0 && $word_count > 0) {
            $words_per_sentence = $word_count / $sentence_count;
            // Simple readability formula
            $readability_score = 206.835 - (1.015 * $words_per_sentence) - (84.6 * $avg_word_length / 5);
            $readability_score = min(100, max(0, $readability_score));
        }
        
        // Check keyword density
        $keyword_density = array();
        foreach ($target_keywords as $keyword) {
            $keyword = strtolower($keyword);
            $count = substr_count(strtolower($content), $keyword);
            $density = $word_count > 0 ? ($count / $word_count) * 100 : 0;
            $keyword_density[$keyword] = round($density, 2) . '%';
        }
        
        // Basic SEO score calculation
        $seo_score = 0;
        
        // Add points for content length
        if ($word_count >= 1500) {
            $seo_score += 25;
        } elseif ($word_count >= 1000) {
            $seo_score += 20;
        } elseif ($word_count >= 700) {
            $seo_score += 15;
        } elseif ($word_count >= 300) {
            $seo_score += 10;
        }
        
        // Add points for keyword presence
        $keyword_points = 0;
        foreach ($target_keywords as $keyword) {
            if (stripos($content, $keyword) !== false) {
                $keyword_points += 5;
            }
        }
        $seo_score += min(25, $keyword_points);
        
        // Add points for readability
        if ($readability_score >= 60) {
            $seo_score += 25;
        } elseif ($readability_score >= 50) {
            $seo_score += 20;
        } elseif ($readability_score >= 40) {
            $seo_score += 15;
        }
        
        // Add points for headings
        $has_h2 = preg_match('/<h2[^>]*>.*?<\/h2>/is', $content);
        $has_h3 = preg_match('/<h3[^>]*>.*?<\/h3>/is', $content);
        
        if ($has_h2) $seo_score += 15;
        if ($has_h3) $seo_score += 10;
        
        // Generate basic recommendations
        $recommendations = array();
        
        if ($word_count < 300) {
            $recommendations[] = 'Increase content length to at least 300 words for better SEO performance';
        }
        
        if (count($target_keywords) > 0) {
            $keywords_found = 0;
            foreach ($target_keywords as $keyword) {
                if (stripos($content, $keyword) !== false) {
                    $keywords_found++;
                }
            }
            
            if ($keywords_found < count($target_keywords)) {
                $recommendations[] = 'Include all target keywords in your content';
            }
        }
        
        if (!$has_h2) {
            $recommendations[] = 'Add H2 headings to structure your content';
        }
        
        if (!$has_h3 && $word_count > 500) {
            $recommendations[] = 'Consider adding H3 subheadings for longer content';
        }
        
        return array(
            'seo_score' => $seo_score,
            'readability_score' => round($readability_score),
            'word_count' => $word_count,
            'keyword_density' => $keyword_density,
            'recommendations' => $recommendations,
            'analysis_note' => 'Analysis performed using internal engine (API-free)'
        );
    }

    /**
     * Make an AI request using the preferred/available provider
     */
    private function makeAIRequest($provider, $prompt, $system_prompt = '', $max_tokens = 2000, $temperature = 0.7) {
        switch ($provider) {
            case 'openai':
                return $this->makeOpenAIRequest('chat/completions', array(
                    'model' => 'gpt-4',
                    'messages' => array(
                        array(
                            'role' => 'system',
                            'content' => $system_prompt
                        ),
                        array(
                            'role' => 'user',
                            'content' => $prompt
                        )
                    ),
                    'max_tokens' => $max_tokens,
                    'temperature' => $temperature
                ));
                
            case 'gemini':
                return $this->makeGeminiRequest($prompt, $system_prompt, $max_tokens, $temperature);
                
            case 'grok':
                return $this->makeGrokRequest($prompt, $system_prompt, $max_tokens, $temperature);
                
            case 'deepseek':
                return $this->makeDeepSeekRequest($prompt, $system_prompt, $max_tokens, $temperature);
                
            case 'internal':
                return $this->makeInternalRequest($prompt, $system_prompt);
                
            default:
                // Fallback to OpenAI if available
                if (!empty($this->api_keys['openai'])) {
                    return $this->makeOpenAIRequest('chat/completions', array(
                        'model' => 'gpt-4',
                        'messages' => array(
                            array(
                                'role' => 'system',
                                'content' => $system_prompt
                            ),
                            array(
                                'role' => 'user',
                                'content' => $prompt
                            )
                        ),
                        'max_tokens' => $max_tokens,
                        'temperature' => $temperature
                    ));
                } else {
                    return $this->makeInternalRequest($prompt, $system_prompt);
                }
        }
    }

    /**
     * Build enhanced content analysis prompt
     */
    private function buildEnhancedContentAnalysisPrompt($content, $target_keywords, $context) {
        $keywords_text = !empty($target_keywords) ? 'Target keywords: ' . implode(', ', $target_keywords) . "\n" : '';
        $context_text = !empty($context) ? 'Context: ' . json_encode($context) . "\n" : '';
        
        return "Analyze this content comprehensively and provide results in JSON format:

{$keywords_text}{$context_text}
Content:
{$content}

Please provide analysis in the following JSON structure:
{
  \"seo_score\": 0-100,
  \"sentiment_analysis\": {
    \"tone\": \"positive/neutral/negative\",
    \"emotion\": \"primary emotion detected\",
    \"confidence\": 0-1,
    \"recommendations\": \"suggestions for tone improvement\"
  },
  \"content_quality\": {
    \"readability_score\": 0-100,
    \"keyword_density\": \"percentage for each keyword\",
    \"semantic_relevance\": 0-100,
    \"content_depth\": 0-100
  },
  \"plagiarism_indicators\": {
    \"uniqueness_score\": 0-100,
    \"potential_issues\": \"areas that might need attention\"
  },
  \"technical_seo\": {
    \"header_structure\": \"analysis of H1-H6 usage\",
    \"meta_opportunities\": \"suggestions for meta tags\",
    \"internal_linking\": \"opportunities for internal links\"
  },
  \"improvement_suggestions\": [
    \"specific actionable recommendations\"
  ],
  \"content_gaps\": [
    \"topics or keywords missing\"
  ]
}";
    }
    
    /**
     * Generate technical SEO recommendations with code snippets
     */
    public function generateTechnicalSEORecommendations($audit_results, $site_context = array(), $provider = null) {
        $prompt = "Based on the following technical SEO audit results, provide specific code snippets and configuration recommendations:

Audit Results:
" . json_encode($audit_results, JSON_PRETTY_PRINT) . "

Site Context:
" . json_encode($site_context, JSON_PRETTY_PRINT) . "

Please provide responses in JSON format with:
{
  \"critical_fixes\": [
    {
      \"issue\": \"description\",
      \"solution\": \"explanation\",
      \"code_snippet\": \"actual code to implement\",
      \"file_location\": \"where to place the code\",
      \"impact\": \"expected improvement\"
    }
  ],
  \"htaccess_rules\": [
    \"specific .htaccess rules\"
  ],
  \"robots_txt_suggestions\": \"optimized robots.txt content\",
  \"schema_markup\": {
    \"recommended_types\": [\"schema types to implement\"],
    \"code_examples\": \"JSON-LD examples\"
  },
  \"performance_optimizations\": [
    {
      \"technique\": \"name\",
      \"implementation\": \"how to implement\",
      \"expected_gain\": \"performance improvement\"
    }
  ]
}";
        
        $system_prompt = 'You are a technical SEO expert who provides specific, actionable code solutions for WordPress websites.';
        
        $selected_provider = $this->selectAIProvider($provider);
        
        // If using internal analysis or AI request fails, use internal method
        if ($selected_provider === 'internal') {
            return $this->generateInternalTechnicalRecommendations($prompt);
        }
        
        $response = $this->makeAIRequest($prompt, $system_prompt, $selected_provider);
        
        if (is_wp_error($response)) {
            // Fall back to internal recommendations
            return $this->generateInternalTechnicalRecommendations($prompt);
        }
        
        // Try to parse as JSON
        $result = json_decode($response, true);
        
        // If direct parsing fails, try to extract JSON from the response
        if (!$result) {
            preg_match('/```json\s*(.*?)\s*```/s', $response, $matches);
            if (!empty($matches[1])) {
                $result = json_decode($matches[1], true);
            }
            
            if (!$result) {
                // Fall back to internal recommendations
                return $this->generateInternalTechnicalRecommendations($prompt);
            }
        }
        
        return $result;
    }
    
    /**
     * Generate A/B test variations for content elements
     */
    public function generateABTestVariations($element_type, $original_content, $target_keywords = array(), $variations = 3, $provider = null) {
        $prompt = "Create {$variations} different variations for A/B testing of this {$element_type}:

Original: {$original_content}
Target Keywords: " . implode(', ', $target_keywords) . "

Requirements:
- Each variation should test different approaches (emotional, logical, urgency, etc.)
- Maintain SEO optimization
- Keep similar length
- Provide rationale for each variation

Return JSON format:
{
  \"variations\": [
    {
      \"content\": \"variation text\",
      \"approach\": \"strategy used\",
      \"rationale\": \"why this might work better\",
      \"seo_score\": 0-100
    }
  ]
}";
        
        $system_prompt = 'You are a conversion optimization expert specializing in A/B testing and SEO.';
        
        $selected_provider = $this->selectAIProvider($provider);
        
        // For A/B testing, we need structured data, so internal method should return valid JSON
        $response = $this->makeAIRequest($prompt, $system_prompt, $selected_provider);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        // Try to parse as JSON
        $parsed = json_decode($response, true);
        
        // If direct parsing fails, try to extract JSON from the response
        if (!$parsed) {
            preg_match('/```json\s*(.*?)\s*```/s', $response, $matches);
            if (!empty($matches[1])) {
                $parsed = json_decode($matches[1], true);
            }
        }
        
        // If we still don't have valid JSON, generate a fallback
        if (!$parsed) {
            // Generate basic A/B test variations
            $parsed = [
                'variations' => []
            ];
            
            for ($i = 0; $i < $variations; $i++) {
                // Generate a simple variation based on the original
                $variation = $this->generateSimpleVariation($original_content, $element_type, $i+1);
                
                $parsed['variations'][] = [
                    'content' => $variation,
                    'approach' => $i == 0 ? 'emotional' : ($i == 1 ? 'logical' : 'urgency'),
                    'rationale' => 'Generated using internal algorithm',
                    'seo_score' => 75
                ];
            }
        }
        
        return $parsed;
    }
    
    /**
     * Generate a simple variation of content without AI
     */
    private function generateSimpleVariation($content, $element_type, $variation_number) {
        // For titles
        if ($element_type === 'title') {
            $prefixes = ['Ultimate Guide: ', 'How To: ', 'Top Tips: ', 'The Complete ', 'Essential '];
            $suffixes = [' - Complete Guide', ' (Updated Guide)', ' You Need to Know', ' for Beginners', ' That Work'];
            
            if ($variation_number % 2 === 0) {
                return $prefixes[array_rand($prefixes)] . $content;
            } else {
                return $content . $suffixes[array_rand($suffixes)];
            }
        }
        
        // For meta descriptions
        if ($element_type === 'meta_description') {
            $prefixes = [
                'Discover ', 
                'Learn about ', 
                'Find out why ', 
                'Explore ', 
                'Want to improve '
            ];
            
            return $prefixes[array_rand($prefixes)] . $content;
        }
        
        // Default - just return original with small change
        return $content . ' (Variation ' . $variation_number . ')';
    }
    
    /**
     * Analyze content for semantic keyword opportunities
     */
    public function analyzeSemanticKeywords($content, $primary_keyword, $provider = null) {
        $prompt = "Analyze this content for semantic keyword opportunities:

Primary Keyword: {$primary_keyword}
Content: {$content}

Identify:
1. Related semantic keywords that should be included
2. LSI (Latent Semantic Indexing) keywords
3. Question-based keywords for featured snippets
4. Long-tail variations
5. Entity relationships

Return JSON format:
{
  \"semantic_keywords\": [\"keyword1\", \"keyword2\"],
  \"lsi_keywords\": [\"lsi1\", \"lsi2\"],
  \"question_keywords\": [\"what is\", \"how to\"],
  \"long_tail_variations\": [\"specific phrase\"],
  \"entities\": [\"people\", \"places\", \"things\"],
  \"content_suggestions\": [\"where to naturally include keywords\"]
}";
        
        $system_prompt = 'You are a semantic SEO expert who understands entity relationships and keyword associations.';
        
        $selected_provider = $this->selectAIProvider($provider);
        
        // If using internal analysis or AI request fails, use internal method
        if ($selected_provider === 'internal') {
            return $this->generateInternalKeywordSuggestions($primary_keyword);
        }
        
        $response = $this->makeAIRequest($prompt, $system_prompt, $selected_provider);
        
        if (is_wp_error($response)) {
            // Fall back to internal keyword suggestions
            return $this->generateInternalKeywordSuggestions($primary_keyword);
        }
        
        // Try to parse as JSON
        $parsed = json_decode($response, true);
        
        // If direct parsing fails, try to extract JSON from the response
        if (!$parsed) {
            preg_match('/```json\s*(.*?)\s*```/s', $response, $matches);
            if (!empty($matches[1])) {
                $parsed = json_decode($matches[1], true);
            }
            
            if (!$parsed) {
                // Fall back to internal keyword suggestions
                return $this->generateInternalKeywordSuggestions($primary_keyword);
            }
        }
        
        return $parsed;
    }
    
    /**
     * Generate content outlines for topic clusters
     */
    public function generateContentOutline($topic, $target_audience, $content_type = 'blog_post', $provider = null) {
        $prompt = "Create a comprehensive content outline for:

Topic: {$topic}
Target Audience: {$target_audience}
Content Type: {$content_type}

Generate:
1. SEO-optimized title suggestions
2. Detailed outline with H2, H3 sections
3. Key points for each section
4. Internal linking opportunities
5. CTA placement suggestions
6. FAQ section ideas

Return JSON format:
{
  \"title_suggestions\": [\"title1\", \"title2\", \"title3\"],
  \"outline\": [
    {
      \"heading\": \"H2 heading\",
      \"subheadings\": [\"H3 items\"],
      \"key_points\": [\"important points to cover\"],
      \"word_count_target\": 200
    }
  ],
  \"internal_links\": [\"suggested link anchor texts\"],
  \"cta_suggestions\": [\"call to action ideas\"],
  \"faq_questions\": [\"frequently asked questions\"],
  \"meta_description\": \"SEO optimized meta description\"
}";
        
        $system_prompt = 'You are a content strategist expert in creating comprehensive, SEO-optimized content outlines.';
        
        $selected_provider = $this->selectAIProvider($provider);
        
        $response = $this->makeAIRequest($prompt, $system_prompt, $selected_provider);
        
        if (is_wp_error($response)) {
            // Generate a basic outline if AI fails
            return $this->generateBasicContentOutline($topic, $target_audience, $content_type);
        }
        
        // Try to parse as JSON
        $parsed = json_decode($response, true);
        
        // If direct parsing fails, try to extract JSON from the response
        if (!$parsed) {
            preg_match('/```json\s*(.*?)\s*```/s', $response, $matches);
            if (!empty($matches[1])) {
                $parsed = json_decode($matches[1], true);
            }
            
            if (!$parsed) {
                // Fall back to basic outline
                return $this->generateBasicContentOutline($topic, $target_audience, $content_type);
            }
        }
        
        return $parsed;
    }
    
    /**
     * Generate a basic content outline without AI
     */
    private function generateBasicContentOutline($topic, $target_audience, $content_type) {
        $outline = [];
        
        // Generate title suggestions
        $outline['title_suggestions'] = [
            "Complete Guide to " . $topic,
            "How to Master " . $topic . " in " . date('Y'),
            $topic . ": Everything You Need to Know",
            "The Ultimate " . $topic . " Guide for " . $target_audience,
            "Essential " . $topic . " Strategies That Work"
        ];
        
        // Generate basic outline structure
        $outline['outline'] = [
            [
                "heading" => "Introduction to " . $topic,
                "subheadings" => ["Why " . $topic . " Matters", "Common Challenges"],
                "key_points" => ["Define the concept", "Explain importance", "Preview main points"],
                "word_count_target" => 200
            ],
            [
                "heading" => "Understanding " . $topic . " Fundamentals",
                "subheadings" => ["Core Concepts", "Key Terminology"],
                "key_points" => ["Explain basic principles", "Define important terms"],
                "word_count_target" => 300
            ],
            [
                "heading" => $topic . " Best Practices",
                "subheadings" => ["Strategy #1", "Strategy #2", "Strategy #3"],
                "key_points" => ["Practical advice", "Real examples", "Step-by-step guidance"],
                "word_count_target" => 400
            ],
            [
                "heading" => "Common " . $topic . " Mistakes to Avoid",
                "subheadings" => ["Mistake #1", "Mistake #2", "Mistake #3"],
                "key_points" => ["What goes wrong", "How to avoid issues", "Solutions"],
                "word_count_target" => 300
            ],
            [
                "heading" => $topic . " for " . $target_audience,
                "subheadings" => ["Specific Needs", "Tailored Approaches"],
                "key_points" => ["Customize advice for audience", "Address specific challenges"],
                "word_count_target" => 250
            ],
            [
                "heading" => "Conclusion",
                "subheadings" => ["Key Takeaways", "Next Steps"],
                "key_points" => ["Summarize main points", "Call to action"],
                "word_count_target" => 150
            ]
        ];
        
        // Add FAQs
        $outline['faq_questions'] = [
            "What is " . $topic . "?",
            "Why is " . $topic . " important?",
            "How can " . $target_audience . " get started with " . $topic . "?",
            "What are the benefits of " . $topic . "?",
            "How long does it take to see results from " . $topic . "?"
        ];
        
        // Add meta description
        $outline['meta_description'] = "Learn everything about " . $topic . " with our comprehensive guide. Perfect for " . $target_audience . " looking to master " . $topic . " strategies and best practices.";
        
        return $outline;
    }
    
    /**
     * Parse enhanced content analysis response
     */
    private function parseEnhancedContentAnalysis($response) {
        $result = json_decode($response, true);
        
        if (isset($result['choices'][0]['message']['content'])) {
            $content = $result['choices'][0]['message']['content'];
            
            // Try to parse as JSON first
            $parsed = json_decode($content, true);
            if ($parsed) {
                return $parsed;
            }
            
            // Fallback to text parsing
            return array(
                'analysis' => $content,
                'seo_score' => $this->extractScoreFromText($content),
                'suggestions' => $this->extractSuggestions($content)
            );
        }
        
        return new WP_Error('invalid_response', __('Invalid AI response', 'autonomous-ai-seo'));
    }
    
    /**
     * Extract score from text content
     */
    private function extractScoreFromText($content) {
        if (preg_match('/seo[_\s]*score[:\s]*(\d+)/i', $content, $matches)) {
            return intval($matches[1]);
        }
        return 70; // Default score
    }
    
    /**
     * Extract suggestions from text content
     */
    private function extractSuggestions($content) {
        $suggestions = array();
        
        $patterns = array(
            '/improve[s]?\s+([^.]+)/i',
            '/suggest[s]?\s+([^.]+)/i',
            '/recommend[s]?\s+([^.]+)/i',
            '/should\s+([^.]+)/i',
            '/consider\s+([^.]+)/i'
        );
        
        foreach ($patterns as $pattern) {
            if (preg_match_all($pattern, $content, $matches)) {
                $suggestions = array_merge($suggestions, $matches[1]);
            }
        }
        
        return array_unique(array_slice($suggestions, 0, 10));
    }
    
    /**
    /**
     * Generate article content
     */
    public function generateArticleContent($prompt) {
        // Get active provider
        $provider_status = $this->getAPIProviderStatus();
        $provider = $provider_status['active_provider'];
        
        // If using internal, use simplified generation
        if ($provider === 'internal') {
            return $this->generateInternalContent($prompt);
        }
        
        return $this->makeAIRequest(
            $provider, 
            $prompt, 
            'You are an expert SEO content writer who creates engaging, informative, and well-structured articles. You will output content in clean HTML format that can be used in WordPress.',
            4000,
            0.7
        );
    }
    
    /**
     * Generate internal content (fallback when no API keys are available)
     */
    private function generateInternalContent($prompt) {
        // Extract key information from the prompt
        preg_match('/Article Title: (.*?)(\n|$)/', $prompt, $title_matches);
        $title = !empty($title_matches[1]) ? trim($title_matches[1]) : 'Untitled Article';
        
        preg_match('/Target Keywords: (.*?)(\n|$)/', $prompt, $keyword_matches);
        $keywords = !empty($keyword_matches[1]) ? explode(',', trim($keyword_matches[1])) : array();
        
        // Generate a simple article structure
        $content = "<!-- wp:heading -->\n<h2>Introduction to " . esc_html($title) . "</h2>\n<!-- /wp:heading -->\n\n";
        $content .= "<!-- wp:paragraph -->\n<p>Welcome to this comprehensive guide about " . esc_html($title) . ". In this article, we'll explore the key aspects of this topic and provide valuable insights to help you understand it better.</p>\n<!-- /wp:paragraph -->\n\n";
        
        if (!empty($keywords)) {
            $content .= "<!-- wp:paragraph -->\n<p>When it comes to " . esc_html(implode(' and ', $keywords)) . ", there are several important factors to consider. Let's dive into the details.</p>\n<!-- /wp:paragraph -->\n\n";
        }
        
        $content .= "<!-- wp:heading -->\n<h2>Key Points to Understand</h2>\n<!-- /wp:heading -->\n\n";
        $content .= "<!-- wp:paragraph -->\n<p>The most important aspects of this topic include understanding the fundamentals, applying best practices, and staying updated with the latest trends.</p>\n<!-- /wp:paragraph -->\n\n";
        
        $content .= "<!-- wp:heading {\"level\":3} -->\n<h3>1. Understanding the Basics</h3>\n<!-- /wp:heading -->\n\n";
        $content .= "<!-- wp:paragraph -->\n<p>To fully grasp this subject, it's essential to start with the foundational concepts. This provides a solid base for more advanced knowledge.</p>\n<!-- /wp:paragraph -->\n\n";
        
        $content .= "<!-- wp:heading {\"level\":3} -->\n<h3>2. Best Practices for Success</h3>\n<!-- /wp:heading -->\n\n";
        $content .= "<!-- wp:paragraph -->\n<p>Following industry best practices can significantly improve your results. These time-tested approaches have proven effective in various scenarios.</p>\n<!-- /wp:paragraph -->\n\n";
        
        $content .= "<!-- wp:heading {\"level\":3} -->\n<h3>3. Latest Trends and Developments</h3>\n<!-- /wp:heading -->\n\n";
        $content .= "<!-- wp:paragraph -->\n<p>Staying current with emerging trends is crucial in today's fast-changing environment. Being aware of recent developments gives you a competitive advantage.</p>\n<!-- /wp:paragraph -->\n\n";
        
        $content .= "<!-- wp:heading -->\n<h2>Conclusion</h2>\n<!-- /wp:heading -->\n\n";
        $content .= "<!-- wp:paragraph -->\n<p>In conclusion, " . esc_html($title) . " is a fascinating subject with many important applications. By understanding the core concepts and following best practices, you can achieve excellent results.</p>\n<!-- /wp:paragraph -->\n\n";
        
        return $content;
    }
    
    /**
     * Generate recommendations based on prompt
     */
    public function generateRecommendations($prompt) {
        // Get active provider
        $provider_status = $this->getAPIProviderStatus();
        $provider = $provider_status['active_provider'];
        
        // If using internal, return generic recommendations
        if ($provider === 'internal') {
            return array(
                'recommendations' => array(
                    array(
                        'title' => 'Improve Content Structure',
                        'description' => 'Break content into smaller, more digestible sections with clear headings and subheadings.'
                    ),
                    array(
                        'title' => 'Enhance Call-to-Action',
                        'description' => 'Make your CTAs more prominent and use action-oriented language to encourage clicks.'
                    ),
                    array(
                        'title' => 'Optimize for Mobile Users',
                        'description' => 'Ensure all elements are properly sized for mobile screens and touch interactions.'
                    ),
                    array(
                        'title' => 'Improve Page Load Speed',
                        'description' => 'Optimize images and minimize unnecessary scripts to improve page load times.'
                    )
                )
            );
        }
        
        $response = $this->makeAIRequest(
            $provider, 
            $prompt, 
            'You are an expert in user experience and conversion rate optimization. Provide specific, actionable recommendations to improve engagement and conversion rates.',
            2000,
            0.7
        );
        
        if (is_wp_error($response)) {
            return array('recommendations' => array());
        }
        
        // Try to parse JSON response
        $parsed = json_decode($response, true);
        if ($parsed && isset($parsed['recommendations'])) {
            return $parsed;
        }
        
        // Fallback to text parsing
        preg_match_all('/\d+\.\s+(.*?)(?=\d+\.|$)/s', $response, $matches);
        if (!empty($matches[1])) {
            $recommendations = array();
            foreach ($matches[1] as $rec) {
                $parts = explode(':', $rec, 2);
                if (count($parts) === 2) {
                    $recommendations[] = array(
                        'title' => trim($parts[0]),
                        'description' => trim($parts[1])
                    );
                } else {
                    $recommendations[] = array(
                        'title' => 'Recommendation',
                        'description' => trim($rec)
                    );
                }
            }
            return array('recommendations' => $recommendations);
        }
        
        return array('recommendations' => array());
    }
    
    /**
     * Make Gemini API request
     */
    private function makeGeminiRequest($prompt, $system_prompt = '', $max_tokens = 2000, $temperature = 0.7) {
        if (empty($this->api_keys['gemini'])) {
            return new WP_Error('no_api_key', __('Gemini API key not configured', 'autonomous-ai-seo'));
        }
        
        $api_key = $this->api_keys['gemini'];
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=' . urlencode($api_key);
        
        $data = array(
            'contents' => array(
                array(
                    'role' => 'user',
                    'parts' => array(
                        array('text' => ($system_prompt ? $system_prompt . "\n\n" : '') . $prompt)
                    )
                )
            ),
            'generationConfig' => array(
                'temperature' => $temperature,
                'maxOutputTokens' => $max_tokens,
                'topP' => 0.8,
                'topK' => 40
            )
        );
        
        $args = array(
            'method' => 'POST',
            'headers' => array('Content-Type' => 'application/json'),
            'body' => json_encode($data),
            'timeout' => 60
        );
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200) {
            $error_data = json_decode($response_body, true);
            $error_message = isset($error_data['error']['message']) ? $error_data['error']['message'] : 'API request failed';
            return new WP_Error('api_error', $error_message);
        }
        
        $data = json_decode($response_body, true);
        
        if (!isset($data['candidates'][0]['content']['parts'][0]['text'])) {
            return new WP_Error('invalid_response', __('Invalid Gemini response format', 'autonomous-ai-seo'));
        }
        
        return $data['candidates'][0]['content']['parts'][0]['text'];
    }
    
    /**
     * Make Grok API request (placeholder implementation)
     */
    private function makeGrokRequest($prompt, $system_prompt = '', $max_tokens = 2000, $temperature = 0.7) {
        if (empty($this->api_keys['grok'])) {
            return new WP_Error('no_api_key', __('Grok API key not configured', 'autonomous-ai-seo'));
        }
        
        // Note: This is a placeholder implementation since Grok API is not yet publicly available
        // This should be updated when Grok API is released
        
        // For now, fall back to OpenAI if available, or internal
        if (!empty($this->api_keys['openai'])) {
            return $this->makeOpenAIRequest('chat/completions', array(
                'model' => 'gpt-3.5-turbo',
                'messages' => array(
                    array(
                        'role' => 'system',
                        'content' => $system_prompt
                    ),
                    array(
                        'role' => 'user',
                        'content' => $prompt
                    )
                ),
                'max_tokens' => $max_tokens,
                'temperature' => $temperature
            ));
        }
        
        return $this->makeInternalRequest($prompt, $system_prompt);
    }
    
    /**
     * Make DeepSeek API request (placeholder implementation)
     */
    private function makeDeepSeekRequest($prompt, $system_prompt = '', $max_tokens = 2000, $temperature = 0.7) {
        if (empty($this->api_keys['deepseek'])) {
            return new WP_Error('no_api_key', __('DeepSeek API key not configured', 'autonomous-ai-seo'));
        }
        
        // Note: Update this implementation when DeepSeek API details are available
        // For now, fall back to OpenAI or internal
        
        if (!empty($this->api_keys['openai'])) {
            return $this->makeOpenAIRequest('chat/completions', array(
                'model' => 'gpt-3.5-turbo',
                'messages' => array(
                    array(
                        'role' => 'system',
                        'content' => $system_prompt
                    ),
                    array(
                        'role' => 'user',
                        'content' => $prompt
                    )
                ),
                'max_tokens' => $max_tokens,
                'temperature' => $temperature
            ));
        }
        
        return $this->makeInternalRequest($prompt, $system_prompt);
    }
    
    /**
     * Make internal request (no API required)
     */
    private function makeInternalRequest($prompt, $system_prompt = '') {
        // Extract key information from the prompt
        if (stripos($prompt, 'json') !== false || stripos($system_prompt, 'json') !== false) {
            // Generate simplified JSON response
            return $this->generateSimpleJSONResponse($prompt, $system_prompt);
        }
        
        // Generate simple text response
        return $this->generateSimpleTextResponse($prompt, $system_prompt);
    }
    
    /**
     * Generate simple JSON response for internal AI
     */
    private function generateSimpleJSONResponse($prompt, $system_prompt) {
        // Try to determine what type of analysis is being requested
        $is_seo_analysis = stripos($prompt, 'SEO') !== false || stripos($system_prompt, 'SEO') !== false;
        $is_content_quality = stripos($prompt, 'quality') !== false || stripos($prompt, 'content analysis') !== false;
        $is_recommendations = stripos($prompt, 'recommend') !== false || stripos($prompt, 'suggestions') !== false;
        
        if ($is_seo_analysis) {
            return json_encode(array(
                'seo_score' => rand(65, 90),
                'sentiment_analysis' => array(
                    'tone' => 'neutral',
                    'emotion' => 'informative',
                    'confidence' => 0.85,
                    'recommendations' => 'Consider adding more emotional language for engagement.'
                ),
                'content_quality' => array(
                    'readability_score' => rand(70, 90),
                    'keyword_density' => 'within optimal range',
                    'semantic_relevance' => rand(75, 95),
                    'content_depth' => rand(65, 90)
                ),
                'plagiarism_indicators' => array(
                    'uniqueness_score' => rand(90, 100),
                    'potential_issues' => 'No significant concerns detected'
                ),
                'technical_seo' => array(
                    'header_structure' => 'Good H1-H6 hierarchy',
                    'meta_opportunities' => 'Consider enhancing meta description',
                    'internal_linking' => 'Add 2-3 more internal links'
                ),
                'improvement_suggestions' => [
                    'Add more specific examples to improve engagement',
                    'Consider including statistical data for credibility',
                    'Break long paragraphs into smaller chunks for readability'
                ],
                'content_gaps' => [
                    'Consider addressing user objections',
                    'Add FAQ section for better SERP visibility',
                    'Include more expert quotes for authority'
                ],
                'analysis_note' => 'Generated by internal engine (no API)'
            ));
        } elseif ($is_content_quality) {
            return json_encode(array(
                'overall_quality_score' => rand(70, 90),
                'readability_score' => rand(65, 90),
                'seo_score' => rand(60, 85),
                'estimated_reading_time' => rand(3, 7),
                'strengths' => [
                    'Good overall structure',
                    'Clear topic coverage',
                    'Appropriate tone for target audience'
                ],
                'improvements' => [
                    'Add more engaging examples',
                    'Enhance introduction to hook readers faster',
                    'Include more specific action steps'
                ],
                'keyword_analysis' => [
                    'Primary keyword appears in appropriate density',
                    'Consider adding more LSI keywords',
                    'Add keyword in more H2/H3 headings'
                ],
                'recommendations' => [
                    'Break content into more digestible sections',
                    'Add multimedia elements like images or videos',
                    'Include a clear call to action at the end'
                ],
                'analysis_note' => 'Generated by internal engine (no API)'
            ));
        } elseif ($is_recommendations) {
            return json_encode(array(
                'recommendations' => [
                    array(
                        'title' => 'Improve Content Structure',
                        'description' => 'Break content into smaller, more digestible sections with clear headings and subheadings.'
                    ),
                    array(
                        'title' => 'Enhance Call-to-Action',
                        'description' => 'Make your CTAs more prominent and use action-oriented language to encourage clicks.'
                    ),
                    array(
                        'title' => 'Optimize for Mobile Users',
                        'description' => 'Ensure all elements are properly sized for mobile screens and touch interactions.'
                    ),
                    array(
                        'title' => 'Improve Page Load Speed',
                        'description' => 'Optimize images and minimize unnecessary scripts to improve page load times.'
                    )
                ]
            ));
        } else {
            // Generic response
            return json_encode(array(
                'analysis' => 'Generic content analysis provided by internal system without API',
                'score' => rand(70, 85),
                'recommendations' => [
                    'Improve content structure',
                    'Add more specific examples',
                    'Enhance readability with shorter paragraphs'
                ],
                'analysis_note' => 'Generated by internal engine (no API)'
            ));
        }
    }
    
    /**
     * Generate simple text response for internal AI
     */
    private function generateSimpleTextResponse($prompt, $system_prompt) {
        // Extract key information from the prompt
        preg_match('/Article Title: (.*?)(\n|$)/', $prompt, $title_matches);
        $title = !empty($title_matches[1]) ? trim($title_matches[1]) : 'Article';
        
        preg_match('/Target Keywords: (.*?)(\n|$)/', $prompt, $keyword_matches);
        $keywords = !empty($keyword_matches[1]) ? explode(',', trim($keyword_matches[1])) : array();
        
        // Generate a generic response
        return "The analysis of \"$title\" shows it has good overall structure and covers the main topics well. " .
               "To improve SEO performance, consider increasing keyword density for " . implode(', ', $keywords) . " and adding more internal links. " .
               "The content could benefit from more specific examples and a stronger call-to-action at the end. " .
               "Consider breaking longer paragraphs into shorter ones for better readability on mobile devices. " .
               "Overall score: 78/100";
    }
    
    /**
     * Make OpenAI API request with retry logic
     */
    private function makeOpenAIRequest($endpoint, $data, $retry_count = 0) {
        if (empty($this->api_keys['openai'])) {
            return new WP_Error('no_api_key', __('OpenAI API key not configured', 'autonomous-ai-seo'));
        }
        
        $url = $this->api_base_url . $endpoint;
        
        $args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->api_keys['openai']
            ),
            'body' => json_encode($data),
            'timeout' => 60
        );
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            // Retry up to 3 times for network errors
            if ($retry_count < 3) {
                sleep(1); // Wait 1 second before retry
                return $this->makeOpenAIRequest($endpoint, $data, $retry_count + 1);
            }
            return $response;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code === 429 && $retry_count < 3) {
            // Rate limit - wait and retry
            sleep(2);
            return $this->makeOpenAIRequest($endpoint, $data, $retry_count + 1);
        }
        
        if ($response_code !== 200) {
            $error_data = json_decode($response_body, true);
            $error_message = isset($error_data['error']['message']) ? $error_data['error']['message'] : 'API request failed';
            return new WP_Error('api_error', $error_message);
        }
        
        return $response_body;
    }
    
    /**
     * Generate AI recommendations based on data
     */
    public function generateRecommendations($prompt) {
        if (empty($this->openai_api_key)) {
            return new WP_Error('no_api_key', __('OpenAI API key not configured', 'autonomous-ai-seo'));
        }
        
        $response = $this->makeOpenAIRequest('chat/completions', array(
            'model' => 'gpt-4',
            'messages' => array(
                array(
                    'role' => 'system',
                    'content' => 'You are an expert in SEO, user experience, and conversion rate optimization. Analyze the data and provide specific, actionable recommendations in JSON format.'
                ),
                array(
                    'role' => 'user',
                    'content' => $prompt
                )
            ),
            'max_tokens' => 2000,
            'temperature' => 0.4
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $result = json_decode($response, true);
        
        if (isset($result['choices'][0]['message']['content'])) {
            $content = $result['choices'][0]['message']['content'];
            $parsed = json_decode($content, true);
            return $parsed ?: array('error' => 'Failed to parse AI response');
        }
        
        return new WP_Error('invalid_response', __('Invalid AI response', 'autonomous-ai-seo'));
    }
    
    /**
     * Generate long-form article content
     */
    public function generateArticleContent($prompt) {
        if (empty($this->openai_api_key)) {
            return new WP_Error('no_api_key', __('OpenAI API key not configured', 'autonomous-ai-seo'));
        }
        
        $response = $this->makeOpenAIRequest('chat/completions', array(
            'model' => 'gpt-4',
            'messages' => array(
                array(
                    'role' => 'system',
                    'content' => 'You are an expert content creator who specializes in writing high-quality, SEO-optimized content. Follow the instructions carefully and focus on creating valuable content for readers.'
                ),
                array(
                    'role' => 'user',
                    'content' => $prompt
                )
            ),
            'max_tokens' => 4000,
            'temperature' => 0.7
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $result = json_decode($response, true);
        
        if (isset($result['choices'][0]['message']['content'])) {
            return $result['choices'][0]['message']['content'];
        }
        
        return new WP_Error('invalid_response', __('Invalid AI response', 'autonomous-ai-seo'));
    }
    
    /**
     * Check content for potential plagiarism indicators
     */
    public function checkContentUniqueness($content) {
        // This would integrate with a plagiarism detection service
        // For now, implement basic checks
        
        $uniqueness_indicators = array(
            'unique_phrases' => $this->countUniquePhrases($content),
            'common_patterns' => $this->detectCommonPatterns($content),
            'sentence_variety' => $this->analyzeSentenceVariety($content),
            'uniqueness_score' => $this->calculateUniquenessScore($content)
        );
        
        return $uniqueness_indicators;
    }
    
    /**
     * Count unique phrases in content
     */
    private function countUniquePhrases($content) {
        $sentences = preg_split('/[.!?]+/', $content);
        $unique_phrases = array();
        
        foreach ($sentences as $sentence) {
            $words = str_word_count(trim($sentence), 1);
            if (count($words) >= 5) {
                $phrase = implode(' ', array_slice($words, 0, 5));
                $unique_phrases[] = strtolower($phrase);
            }
        }
        
        return count(array_unique($unique_phrases));
    }
    
    /**
     * Detect common patterns that might indicate copied content
     */
    private function detectCommonPatterns($content) {
        $patterns = array(
            'excessive_quotes' => substr_count($content, '"') > strlen($content) / 50,
            'list_heavy' => substr_count($content, "\n-") > 10,
            'repetitive_structure' => $this->hasRepetitiveStructure($content)
        );
        
        return array_filter($patterns);
    }
    
    /**
     * Check for repetitive sentence structures
     */
    private function hasRepetitiveStructure($content) {
        $sentences = preg_split('/[.!?]+/', $content);
        $structures = array();
        
        foreach ($sentences as $sentence) {
            $words = str_word_count(trim($sentence), 1);
            if (count($words) >= 3) {
                $structure = strtolower($words[0] . ' ' . $words[1]);
                $structures[] = $structure;
            }
        }
        
        $structure_counts = array_count_values($structures);
        $max_repetition = max($structure_counts);
        
        return $max_repetition > 3;
    }
    
    /**
     * Analyze sentence variety
     */
    private function analyzeSentenceVariety($content) {
        $sentences = preg_split('/[.!?]+/', $content);
        $lengths = array();
        
        foreach ($sentences as $sentence) {
            $lengths[] = str_word_count(trim($sentence));
        }
        
        $avg_length = array_sum($lengths) / count($lengths);
        $variance = $this->calculateVariance($lengths, $avg_length);
        
        return array(
            'average_length' => round($avg_length, 1),
            'variance' => round($variance, 1),
            'variety_score' => min(100, $variance * 2)
        );
    }
    
    /**
     * Calculate statistical variance
     */
    private function calculateVariance($values, $mean) {
        $sum_squares = 0;
        foreach ($values as $value) {
            $sum_squares += pow($value - $mean, 2);
        }
        return $sum_squares / count($values);
    }
    
    /**
     * Calculate overall uniqueness score
     */
    private function calculateUniquenessScore($content) {
        $word_count = str_word_count($content);
        $unique_words = count(array_unique(str_word_count(strtolower($content), 1)));
        
        $uniqueness_ratio = $unique_words / $word_count;
        $base_score = $uniqueness_ratio * 100;
        
        // Adjust based on content length
        if ($word_count < 300) {
            $base_score *= 0.8; // Penalty for short content
        }
        
        return min(100, max(0, round($base_score)));
    }
    
    /**
     * Generate meta description with multiple variations
     */
    public function generateMetaDescription($title, $content, $target_keywords = array(), $provider = null) {
        $keywords_text = !empty($target_keywords) ? implode(', ', $target_keywords) : '';
        
        $prompt = "Create 3 different SEO-optimized meta descriptions (150-160 characters each) for:

Title: {$title}
Target Keywords: {$keywords_text}
Content excerpt: " . wp_trim_words($content, 50) . "

Each variation should:
- Include primary keyword naturally
- Be compelling and click-worthy
- Exactly 150-160 characters
- Have clear value proposition
- Use different emotional appeals (logical, emotional, urgency)

Return JSON format:
{
  \"variations\": [
    {
      \"description\": \"meta description text\",
      \"approach\": \"logical/emotional/urgency\",
      \"character_count\": 155,
      \"click_appeal_score\": 0-10
    }
  ]
}";
        
        $system_prompt = 'You are an expert SEO copywriter specializing in meta descriptions that drive clicks and rankings.';
        
        $selected_provider = $this->selectAIProvider($provider);
        
        $response = $this->makeAIRequest($prompt, $system_prompt, $selected_provider);
        
        if (is_wp_error($response)) {
            // Generate basic meta description if AI fails
            $basic_meta = $this->generateBasicMetaDescription($title, $content, $target_keywords);
            
            // Return in the expected format
            return [
                'variations' => [
                    [
                        'description' => $basic_meta,
                        'approach' => 'neutral',
                        'character_count' => strlen($basic_meta),
                        'click_appeal_score' => 7
                    ]
                ]
            ];
        }
        
        // Try to parse the response
        $parsed = json_decode($response, true);
        
        // If direct parsing fails, try to extract JSON
        if (!$parsed) {
            preg_match('/```json\s*(.*?)\s*```/s', $response, $matches);
            if (!empty($matches[1])) {
                $parsed = json_decode($matches[1], true);
            }
            
            if (!$parsed) {
                // Generate basic meta description
                $basic_meta = $this->generateBasicMetaDescription($title, $content, $target_keywords);
                
                return [
                    'variations' => [
                        [
                            'description' => $basic_meta,
                            'approach' => 'neutral',
                            'character_count' => strlen($basic_meta),
                            'click_appeal_score' => 7
                        ]
                    ]
                ];
            }
        }
        
        return $parsed;
    }
    
    /**
     * Generate a basic meta description without AI
     */
    private function generateBasicMetaDescription($title, $content, $target_keywords) {
        // Extract first paragraph for basis of meta description
        $first_paragraph = '';
        if (preg_match('/<p>(.*?)<\/p>/s', $content, $matches)) {
            $first_paragraph = strip_tags($matches[1]);
        } else {
            // Fallback to first 200 characters of content
            $first_paragraph = substr(strip_tags($content), 0, 200);
        }
        
        // Truncate to appropriate length
        $meta = substr($first_paragraph, 0, 150);
        
        // Add ellipsis if truncated
        if (strlen($first_paragraph) > 150) {
            $meta = rtrim($meta, ".,; ") . '...';
        }
        
        // Ensure primary keyword is included
        if (!empty($target_keywords) && strpos(strtolower($meta), strtolower($target_keywords[0])) === false) {
            $meta = $target_keywords[0] . ': ' . $meta;
            
            // Re-truncate if necessary
            if (strlen($meta) > 160) {
                $meta = substr($meta, 0, 157) . '...';
            }
        }
        
        return $meta;
    }
    
    /**
     * Generate FAQ content based on topic
     */
    public function generateFAQContent($topic, $target_keywords = array(), $provider = null) {
        $keywords_text = !empty($target_keywords) ? 'Related keywords: ' . implode(', ', $target_keywords) : '';
        
        $prompt = "Generate a comprehensive FAQ section for the topic: {$topic}

{$keywords_text}

Create 8-10 frequently asked questions with detailed answers that:
- Address common user concerns
- Include target keywords naturally
- Provide actionable information
- Are optimized for featured snippets
- Cover beginner to advanced questions

Return JSON format:
{
  \"faqs\": [
    {
      \"question\": \"Question text\",
      \"answer\": \"Detailed answer (100-200 words)\",
      \"keywords_used\": [\"keyword1\", \"keyword2\"],
      \"snippet_optimized\": true/false
    }
  ]
}";
        
        $system_prompt = 'You are an expert content creator specializing in FAQ content that ranks well in search engines.';
        
        $selected_provider = $this->selectAIProvider($provider);
        
        $response = $this->makeAIRequest($prompt, $system_prompt, $selected_provider);
        
        if (is_wp_error($response)) {
            // Generate basic FAQs if AI fails
            return $this->generateBasicFAQs($topic, $target_keywords);
        }
        
        // Try to parse the response
        $parsed = json_decode($response, true);
        
        // If direct parsing fails, try to extract JSON
        if (!$parsed) {
            preg_match('/```json\s*(.*?)\s*```/s', $response, $matches);
            if (!empty($matches[1])) {
                $parsed = json_decode($matches[1], true);
            }
            
            if (!$parsed) {
                return $this->generateBasicFAQs($topic, $target_keywords);
            }
        }
        
        return $parsed;
    }
    
    /**
     * Generate basic FAQs without AI
     */
    private function generateBasicFAQs($topic, $target_keywords) {
        $faqs = [
            'faqs' => [
                [
                    'question' => 'What is ' . $topic . '?',
                    'answer' => 'This is a comprehensive definition of ' . $topic . ' covering its key aspects and importance.',
                    'keywords_used' => !empty($target_keywords) ? [$target_keywords[0]] : [$topic],
                    'snippet_optimized' => true
                ],
                [
                    'question' => 'Why is ' . $topic . ' important?',
                    'answer' => $topic . ' is important because it helps businesses improve their online presence, reach more customers, and achieve better results in their digital marketing efforts.',
                    'keywords_used' => !empty($target_keywords) ? [$target_keywords[0]] : [$topic],
                    'snippet_optimized' => true
                ],
                [
                    'question' => 'How can I get started with ' . $topic . '?',
                    'answer' => 'Getting started with ' . $topic . ' involves understanding the basic principles, setting clear goals, and following industry best practices. Begin by researching the fundamentals and creating a strategic plan.',
                    'keywords_used' => !empty($target_keywords) ? array_slice($target_keywords, 0, 2) : [$topic, 'getting started'],
                    'snippet_optimized' => true
                ],
                [
                    'question' => 'What are the best tools for ' . $topic . '?',
                    'answer' => 'Some of the best tools for ' . $topic . ' include comprehensive platforms that offer analytics, automation, and reporting features. Look for solutions that integrate with your existing systems and provide actionable insights.',
                    'keywords_used' => !empty($target_keywords) ? array_slice($target_keywords, 0, 2) : [$topic, 'tools'],
                    'snippet_optimized' => true
                ],
                [
                    'question' => 'How long does it take to see results from ' . $topic . '?',
                    'answer' => 'The timeline for seeing results from ' . $topic . ' varies depending on several factors, including your starting point, the competitiveness of your industry, and the consistency of your efforts. Generally, expect to see initial improvements within 3-6 months, with more significant results appearing after 6-12 months of consistent implementation.',
                    'keywords_used' => !empty($target_keywords) ? array_slice($target_keywords, 0, 2) : [$topic, 'results'],
                    'snippet_optimized' => true
                ]
            ]
        ];
        
        return $faqs;
    }
    
    /**
     * Get API provider information for admin
     */
    public function getAPIProviderStatus() {
        $providers = [
            'openai' => [
                'name' => 'OpenAI',
                'status' => !empty($this->openai_api_key) ? 'configured' : 'not_configured',
                'is_active' => $this->preferred_provider === 'openai' && !empty($this->openai_api_key)
            ],
            'grok' => [
                'name' => 'Grok',
                'status' => !empty($this->grok_api_key) ? 'configured' : 'not_configured',
                'is_active' => $this->preferred_provider === 'grok' && !empty($this->grok_api_key)
            ],
            'gemini' => [
                'name' => 'Google Gemini',
                'status' => !empty($this->gemini_api_key) ? 'configured' : 'not_configured',
                'is_active' => $this->preferred_provider === 'gemini' && !empty($this->gemini_api_key)
            ],
            'deepseek' => [
                'name' => 'DeepSeek',
                'status' => !empty($this->deepseek_api_key) ? 'configured' : 'not_configured',
                'is_active' => $this->preferred_provider === 'deepseek' && !empty($this->deepseek_api_key)
            ],
            'internal' => [
                'name' => 'Internal AI',
                'status' => 'always_available',
                'is_active' => $this->preferred_provider === 'internal'
            ]
        ];
        
        $active_provider = $this->selectAIProvider();
        
        return [
            'providers' => $providers,
            'active_provider' => $active_provider,
            'preferred_provider' => $this->preferred_provider,
            'has_external_provider' => $active_provider !== 'internal'
        ];
    }
}