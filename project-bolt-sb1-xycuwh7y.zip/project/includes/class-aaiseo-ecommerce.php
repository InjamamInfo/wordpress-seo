<?php
/**
 * E-commerce Integration for Autonomous AI SEO
 * 
 * Provides integration with e-commerce platforms like WooCommerce,
 * revenue tracking, and ROI calculation
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Ecommerce {
    
    private static $instance = null;
    private $settings;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->settings = get_option('aaiseo_settings', array());
        $this->initHooks();
        $this->createTables();
    }
    
    private function initHooks() {
        // WooCommerce integration
        if (class_exists('WooCommerce')) {
            add_action('woocommerce_checkout_order_processed', array($this, 'trackWooCommerceOrder'), 10, 3);
            add_action('woocommerce_order_status_completed', array($this, 'trackWooCommerceOrderCompleted'));
        }
        
        // Easy Digital Downloads integration
        if (class_exists('Easy_Digital_Downloads')) {
            add_action('edd_complete_purchase', array($this, 'trackEDDPurchase'));
        }
        
        // Admin dashboard
        add_action('admin_menu', array($this, 'addRevenueMenu'));
        
        // AJAX handlers
        add_action('wp_ajax_aaiseo_get_revenue_data', array($this, 'getRevenueDataAjax'));
        add_action('wp_ajax_aaiseo_get_roi_metrics', array($this, 'getROIMetricsAjax'));
        
        // Track form submissions
        add_action('wp_ajax_aaiseo_track_form_conversion', array($this, 'trackFormConversionAjax'));
        add_action('wp_ajax_nopriv_aaiseo_track_form_conversion', array($this, 'trackFormConversionAjax'));
        
        // Contact Form 7 integration
        add_action('wpcf7_submit', array($this, 'trackContactForm7Submission'), 10, 2);
        
        // Gravity Forms integration
        add_action('gform_after_submission', array($this, 'trackGravityFormSubmission'), 10, 2);
        
        // Frontend scripts for tracking
        add_action('wp_footer', array($this, 'addConversionTrackingScript'));
    }
    
    /**
     * Create necessary database tables
     */
    private function createTables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Table for revenue tracking
        $table_revenue = $wpdb->prefix . 'aaiseo_revenue';
        $sql_revenue = "CREATE TABLE IF NOT EXISTS $table_revenue (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            order_id varchar(50),
            source varchar(50) NOT NULL,
            amount decimal(10,2) NOT NULL,
            currency varchar(10) NOT NULL DEFAULT 'USD',
            customer_id bigint(20) unsigned,
            products longtext,
            session_id varchar(50),
            referrer varchar(500),
            landing_page varchar(500),
            utm_source varchar(100),
            utm_medium varchar(100),
            utm_campaign varchar(100),
            device_type varchar(20),
            user_id bigint(20) unsigned,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY order_id (order_id),
            KEY source (source),
            KEY created_at (created_at),
            KEY customer_id (customer_id)
        ) $charset_collate;";
        
        // Table for lead tracking
        $table_leads = $wpdb->prefix . 'aaiseo_leads';
        $sql_leads = "CREATE TABLE IF NOT EXISTS $table_leads (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            form_id varchar(50),
            form_name varchar(100),
            lead_value decimal(10,2) DEFAULT 0,
            form_data longtext,
            email varchar(100),
            name varchar(100),
            phone varchar(50),
            session_id varchar(50),
            referrer varchar(500),
            landing_page varchar(500),
            utm_source varchar(100),
            utm_medium varchar(100),
            utm_campaign varchar(100),
            device_type varchar(20),
            user_id bigint(20) unsigned,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY form_id (form_id),
            KEY email (email),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // Table for SEO ROI tracking
        $table_roi = $wpdb->prefix . 'aaiseo_roi_metrics';
        $sql_roi = "CREATE TABLE IF NOT EXISTS $table_roi (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            metric_type varchar(50) NOT NULL,
            metric_value decimal(10,2) NOT NULL,
            metric_date date NOT NULL,
            details longtext,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY metric_type (metric_type),
            KEY metric_date (metric_date)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        dbDelta($sql_revenue);
        dbDelta($sql_leads);
        dbDelta($sql_roi);
    }
    
    /**
     * Add Revenue menu to admin
     */
    public function addRevenueMenu() {
        add_submenu_page(
            'autonomous-ai-seo',
            __('Revenue & ROI', 'autonomous-ai-seo'),
            __('Revenue & ROI', 'autonomous-ai-seo'),
            'manage_options',
            'aaiseo-revenue',
            array($this, 'renderRevenuePage')
        );
    }
    
    /**
     * Render Revenue page
     */
    public function renderRevenuePage() {
        include AAISEO_PLUGIN_PATH . 'templates/admin/revenue.php';
    }
    
    /**
     * Track WooCommerce order
     */
    public function trackWooCommerceOrder($order_id, $posted_data, $order) {
        if (!$order) return;
        
        // Get session data
        $session_id = isset($_COOKIE['aaiseo_session']) ? sanitize_text_field($_COOKIE['aaiseo_session']) : '';
        
        // Get referrer and landing page from session if available
        $referrer = '';
        $landing_page = '';
        $utm_source = '';
        $utm_medium = '';
        $utm_campaign = '';
        
        if ($session_id) {
            // Get session data from our tracking table
            global $wpdb;
            $session_data = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT referrer, entry_page as landing_page FROM {$wpdb->prefix}aaiseo_user_sessions WHERE session_id = %s",
                    $session_id
                ),
                ARRAY_A
            );
            
            if ($session_data) {
                $referrer = $session_data['referrer'];
                $landing_page = $session_data['landing_page'];
            }
        }
        
        // Get UTM parameters from cookies if available
        $utm_source = isset($_COOKIE['aaiseo_utm_source']) ? sanitize_text_field($_COOKIE['aaiseo_utm_source']) : '';
        $utm_medium = isset($_COOKIE['aaiseo_utm_medium']) ? sanitize_text_field($_COOKIE['aaiseo_utm_medium']) : '';
        $utm_campaign = isset($_COOKIE['aaiseo_utm_campaign']) ? sanitize_text_field($_COOKIE['aaiseo_utm_campaign']) : '';
        
        // Get customer data
        $customer_id = $order->get_customer_id();
        
        // Get products
        $products = array();
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            $products[] = array(
                'id' => $product ? $product->get_id() : 0,
                'name' => $item->get_name(),
                'quantity' => $item->get_quantity(),
                'price' => $item->get_total()
            );
        }
        
        // Get order total
        $total = $order->get_total();
        $currency = $order->get_currency();
        
        // Insert revenue data
        $this->trackRevenue(
            'woocommerce',
            $order_id,
            $total,
            $currency,
            $customer_id,
            $products,
            $session_id,
            $referrer,
            $landing_page,
            $utm_source,
            $utm_medium,
            $utm_campaign
        );
    }
    
    /**
     * Track WooCommerce order completed
     */
    public function trackWooCommerceOrderCompleted($order_id) {
        // Update ROI metrics when an order is completed
        $order = wc_get_order($order_id);
        
        if (!$order) return;
        
        // Get order total
        $total = $order->get_total();
        
        // Add to ROI metrics
        $this->addROIMetric('revenue', $total, array(
            'source' => 'woocommerce',
            'order_id' => $order_id
        ));
    }
    
    /**
     * Track Easy Digital Downloads purchase
     */
    public function trackEDDPurchase($payment_id) {
        if (!function_exists('edd_get_payment_meta')) return;
        
        // Get payment data
        $payment_meta = edd_get_payment_meta($payment_id);
        $total = edd_get_payment_amount($payment_id);
        $currency = edd_get_currency();
        
        // Get customer data
        $customer_id = edd_get_payment_customer_id($payment_id);
        
        // Get cart items
        $cart_items = edd_get_payment_meta_cart_details($payment_id);
        $products = array();
        
        if ($cart_items) {
            foreach ($cart_items as $item) {
                $products[] = array(
                    'id' => $item['id'],
                    'name' => $item['name'],
                    'quantity' => $item['quantity'],
                    'price' => $item['price']
                );
            }
        }
        
        // Get session data
        $session_id = isset($_COOKIE['aaiseo_session']) ? sanitize_text_field($_COOKIE['aaiseo_session']) : '';
        
        // Get referrer and landing page from session if available
        $referrer = '';
        $landing_page = '';
        
        if ($session_id) {
            // Get session data from our tracking table
            global $wpdb;
            $session_data = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT referrer, entry_page as landing_page FROM {$wpdb->prefix}aaiseo_user_sessions WHERE session_id = %s",
                    $session_id
                ),
                ARRAY_A
            );
            
            if ($session_data) {
                $referrer = $session_data['referrer'];
                $landing_page = $session_data['landing_page'];
            }
        }
        
        // Get UTM parameters from cookies if available
        $utm_source = isset($_COOKIE['aaiseo_utm_source']) ? sanitize_text_field($_COOKIE['aaiseo_utm_source']) : '';
        $utm_medium = isset($_COOKIE['aaiseo_utm_medium']) ? sanitize_text_field($_COOKIE['aaiseo_utm_medium']) : '';
        $utm_campaign = isset($_COOKIE['aaiseo_utm_campaign']) ? sanitize_text_field($_COOKIE['aaiseo_utm_campaign']) : '';
        
        // Insert revenue data
        $this->trackRevenue(
            'edd',
            $payment_id,
            $total,
            $currency,
            $customer_id,
            $products,
            $session_id,
            $referrer,
            $landing_page,
            $utm_source,
            $utm_medium,
            $utm_campaign
        );
        
        // Add to ROI metrics
        $this->addROIMetric('revenue', $total, array(
            'source' => 'edd',
            'payment_id' => $payment_id
        ));
    }
    
    /**
     * Track Contact Form 7 submission
     */
    public function trackContactForm7Submission($form, $result) {
        if ($result['status'] !== 'mail_sent') {
            return;
        }
        
        // Get form data
        $form_id = $form->id();
        $form_title = $form->title();
        
        // Get form fields
        $submission = WPCF7_Submission::get_instance();
        if (!$submission) return;
        
        $form_data = $submission->get_posted_data();
        
        // Extract relevant fields
        $email = isset($form_data['your-email']) ? $form_data['your-email'] : '';
        $name = isset($form_data['your-name']) ? $form_data['your-name'] : '';
        $phone = isset($form_data['your-phone']) ? $form_data['your-phone'] : '';
        
        // Calculate lead value based on form type
        $lead_value = $this->calculateLeadValue($form_title);
        
        // Track the lead
        $this->trackLead(
            'cf7',
            $form_id,
            $form_title,
            $lead_value,
            $form_data,
            $email,
            $name,
            $phone
        );
    }
    
    /**
     * Track Gravity Form submission
     */
    public function trackGravityFormSubmission($entry, $form) {
        // Get form data
        $form_id = $form['id'];
        $form_title = $form['title'];
        
        // Extract relevant fields
        $email = '';
        $name = '';
        $phone = '';
        $form_data = array();
        
        foreach ($form['fields'] as $field) {
            $field_id = $field->id;
            $field_label = $field->label;
            $field_value = rgar($entry, $field_id);
            
            $form_data[$field_label] = $field_value;
            
            // Try to identify email, name, and phone fields
            if ($field->type === 'email') {
                $email = $field_value;
            } elseif ($field->type === 'name') {
                $name = $field_value;
            } elseif ($field->type === 'phone') {
                $phone = $field_value;
            } elseif (stripos($field_label, 'email') !== false) {
                $email = $field_value;
            } elseif (stripos($field_label, 'name') !== false) {
                $name = $field_value;
            } elseif (stripos($field_label, 'phone') !== false) {
                $phone = $field_value;
            }
        }
        
        // Calculate lead value based on form type
        $lead_value = $this->calculateLeadValue($form_title);
        
        // Track the lead
        $this->trackLead(
            'gravity_forms',
            $form_id,
            $form_title,
            $lead_value,
            $form_data,
            $email,
            $name,
            $phone
        );
    }
    
    /**
     * Add conversion tracking script to footer
     */
    public function addConversionTrackingScript() {
        // Skip for admin or login pages
        if (is_admin() || $GLOBALS['pagenow'] === 'wp-login.php') {
            return;
        }
        
        // Track UTM parameters
        ?>
        <script>
        (function() {
            // UTM parameter tracking
            function getParameterByName(name) {
                var url = window.location.href;
                name = name.replace(/[\[\]]/g, '\\$&');
                var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
                    results = regex.exec(url);
                if (!results) return null;
                if (!results[2]) return '';
                return decodeURIComponent(results[2].replace(/\+/g, ' '));
            }
            
            // Get UTM parameters
            var utmSource = getParameterByName('utm_source');
            var utmMedium = getParameterByName('utm_medium');
            var utmCampaign = getParameterByName('utm_campaign');
            
            // Set cookies if UTM parameters exist
            if (utmSource) {
                document.cookie = 'aaiseo_utm_source=' + utmSource + ';path=/;max-age=2592000'; // 30 days
            }
            if (utmMedium) {
                document.cookie = 'aaiseo_utm_medium=' + utmMedium + ';path=/;max-age=2592000'; // 30 days
            }
            if (utmCampaign) {
                document.cookie = 'aaiseo_utm_campaign=' + utmCampaign + ';path=/;max-age=2592000'; // 30 days
            }
            
            // Form tracking
            document.addEventListener('submit', function(e) {
                if (e.target.tagName === 'FORM') {
                    // Don't track admin forms or search forms
                    if (e.target.classList.contains('admin-form') || e.target.classList.contains('search-form')) {
                        return;
                    }
                    
                    // Get form information
                    var formId = e.target.id || e.target.getAttribute('name') || 'unknown_form';
                    var formName = e.target.getAttribute('data-form-name') || formId;
                    
                    // Gather form data
                    var formData = {};
                    var formElements = e.target.elements;
                    
                    for (var i = 0; i < formElements.length; i++) {
                        var element = formElements[i];
                        if (element.name && element.value && element.type !== 'password' && element.type !== 'submit') {
                            formData[element.name] = element.value;
                        }
                    }
                    
                    // Find email, name, and phone fields
                    var email = '';
                    var name = '';
                    var phone = '';
                    
                    for (var field in formData) {
                        if (field.indexOf('email') !== -1 || field.indexOf('mail') !== -1) {
                            email = formData[field];
                        } else if (field.indexOf('name') !== -1 || field.indexOf('first') !== -1) {
                            name = formData[field];
                        } else if (field.indexOf('phone') !== -1 || field.indexOf('tel') !== -1) {
                            phone = formData[field];
                        }
                    }
                    
                    // Get session ID
                    var sessionId = '';
                    var cookies = document.cookie.split(';');
                    for (var i = 0; i < cookies.length; i++) {
                        var cookie = cookies[i].trim();
                        if (cookie.indexOf('aaiseo_session=') === 0) {
                            sessionId = cookie.substring('aaiseo_session='.length, cookie.length);
                            break;
                        }
                    }
                    
                    // Track the form submission
                    fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: new URLSearchParams({
                            action: 'aaiseo_track_form_conversion',
                            form_id: formId,
                            form_name: formName,
                            form_data: JSON.stringify(formData),
                            email: email,
                            name: name,
                            phone: phone,
                            session_id: sessionId,
                            referrer: document.referrer,
                            url: window.location.href,
                            nonce: '<?php echo wp_create_nonce('aaiseo_track_conversion'); ?>'
                        })
                    }).catch(console.error);
                }
            });
        })();
        </script>
        <?php
    }
    
    /**
     * Track form conversion via AJAX
     */
    public function trackFormConversionAjax() {
        check_ajax_referer('aaiseo_track_conversion', 'nonce');
        
        // Get form data
        $form_id = sanitize_text_field($_POST['form_id']);
        $form_name = sanitize_text_field($_POST['form_name']);
        $form_data = json_decode(stripslashes($_POST['form_data']), true);
        
        // Get lead data
        $email = sanitize_email($_POST['email']);
        $name = sanitize_text_field($_POST['name']);
        $phone = sanitize_text_field($_POST['phone']);
        
        // Get session data
        $session_id = sanitize_text_field($_POST['session_id']);
        $referrer = esc_url_raw($_POST['referrer']);
        $url = esc_url_raw($_POST['url']);
        
        // Calculate lead value based on form type
        $lead_value = $this->calculateLeadValue($form_name);
        
        // Track the lead
        $this->trackLead(
            'generic_form',
            $form_id,
            $form_name,
            $lead_value,
            $form_data,
            $email,
            $name,
            $phone,
            $session_id,
            $referrer,
            $url
        );
        
        wp_die();
    }
    
    /**
     * Track revenue
     */
    public function trackRevenue($source, $order_id, $amount, $currency, $customer_id, $products, $session_id = '', $referrer = '', $landing_page = '', $utm_source = '', $utm_medium = '', $utm_campaign = '') {
        global $wpdb;
        
        // Get user data
        $user_id = get_current_user_id();
        $device_type = $this->getDeviceType();
        
        // Insert revenue data
        $wpdb->insert(
            "{$wpdb->prefix}aaiseo_revenue",
            array(
                'order_id' => $order_id,
                'source' => $source,
                'amount' => $amount,
                'currency' => $currency,
                'customer_id' => $customer_id,
                'products' => json_encode($products),
                'session_id' => $session_id,
                'referrer' => $referrer,
                'landing_page' => $landing_page,
                'utm_source' => $utm_source,
                'utm_medium' => $utm_medium,
                'utm_campaign' => $utm_campaign,
                'device_type' => $device_type,
                'user_id' => $user_id
            ),
            array(
                '%s', '%s', '%f', '%s', '%d', '%s', '%s', '%s', '%s', 
                '%s', '%s', '%s', '%s', '%d'
            )
        );
        
        // Update ROI metrics
        $this->addROIMetric('revenue', $amount, array(
            'source' => $source,
            'order_id' => $order_id,
            'products' => $products
        ));
        
        // Log activity
        AAISEO_Core::getInstance()->logActivity(
            'revenue_tracked',
            sprintf(__('Revenue of %s %s tracked from %s', 'autonomous-ai-seo'), $amount, $currency, $source),
            array('order_id' => $order_id, 'amount' => $amount, 'source' => $source)
        );
    }
    
    /**
     * Track lead
     */
    public function trackLead($source, $form_id, $form_name, $lead_value, $form_data, $email, $name, $phone, $session_id = '', $referrer = '', $landing_page = '') {
        global $wpdb;
        
        // If session ID not provided, try to get from cookie
        if (empty($session_id) && isset($_COOKIE['aaiseo_session'])) {
            $session_id = sanitize_text_field($_COOKIE['aaiseo_session']);
        }
        
        // If referrer and landing page not provided, try to get from session data
        if (($empty($referrer) || empty($landing_page)) && !empty($session_id)) {
            $session_data = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT referrer, entry_page as landing_page FROM {$wpdb->prefix}aaiseo_user_sessions WHERE session_id = %s",
                    $session_id
                ),
                ARRAY_A
            );
            
            if ($session_data) {
                if (empty($referrer)) {
                    $referrer = $session_data['referrer'];
                }
                if (empty($landing_page)) {
                    $landing_page = $session_data['landing_page'];
                }
            }
        }
        
        // Get UTM parameters from cookies if available
        $utm_source = isset($_COOKIE['aaiseo_utm_source']) ? sanitize_text_field($_COOKIE['aaiseo_utm_source']) : '';
        $utm_medium = isset($_COOKIE['aaiseo_utm_medium']) ? sanitize_text_field($_COOKIE['aaiseo_utm_medium']) : '';
        $utm_campaign = isset($_COOKIE['aaiseo_utm_campaign']) ? sanitize_text_field($_COOKIE['aaiseo_utm_campaign']) : '';
        
        // Get user data
        $user_id = get_current_user_id();
        $device_type = $this->getDeviceType();
        
        // Insert lead data
        $wpdb->insert(
            "{$wpdb->prefix}aaiseo_leads",
            array(
                'form_id' => $form_id,
                'form_name' => $form_name,
                'lead_value' => $lead_value,
                'form_data' => json_encode($form_data),
                'email' => $email,
                'name' => $name,
                'phone' => $phone,
                'session_id' => $session_id,
                'referrer' => $referrer,
                'landing_page' => $landing_page,
                'utm_source' => $utm_source,
                'utm_medium' => $utm_medium,
                'utm_campaign' => $utm_campaign,
                'device_type' => $device_type,
                'user_id' => $user_id
            ),
            array(
                '%s', '%s', '%f', '%s', '%s', '%s', '%s', '%s', '%s', 
                '%s', '%s', '%s', '%s', '%s', '%d'
            )
        );
        
        // Update ROI metrics
        $this->addROIMetric('leads', $lead_value, array(
            'source' => $source,
            'form_id' => $form_id,
            'form_name' => $form_name
        ));
        
        // Log activity
        AAISEO_Core::getInstance()->logActivity(
            'lead_captured',
            sprintf(__('Lead captured from %s form with value %s', 'autonomous-ai-seo'), $form_name, $lead_value),
            array('form_id' => $form_id, 'form_name' => $form_name, 'lead_value' => $lead_value)
        );
    }
    
    /**
     * Calculate lead value based on form type
     */
    private function calculateLeadValue($form_name) {
        // Default lead values by form type
        $default_values = array(
            'contact' => 50.00,
            'quote' => 100.00,
            'demo' => 150.00,
            'newsletter' => 10.00,
            'download' => 25.00,
            'signup' => 35.00,
            'trial' => 75.00,
            'consultation' => 125.00
        );
        
        // Get customized lead values from settings
        $lead_values = !empty($this->settings['lead_values']) ? $this->settings['lead_values'] : array();
        
        // Merge with defaults
        $lead_values = array_merge($default_values, $lead_values);
        
        // Check for matching form types in the form name
        $form_name_lower = strtolower($form_name);
        
        foreach ($lead_values as $type => $value) {
            if (strpos($form_name_lower, $type) !== false) {
                return floatval($value);
            }
        }
        
        // Default generic lead value
        return !empty($lead_values['default']) ? floatval($lead_values['default']) : 25.00;
    }
    
    /**
     * Get device type from user agent
     */
    private function getDeviceType() {
        if (!isset($_SERVER['HTTP_USER_AGENT'])) {
            return 'unknown';
        }
        
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        
        $mobile_patterns = array(
            'mobile', 'android', 'iphone', 'ipod', 'opera mobi', 'opera mini', 'blackberry', 'windows phone'
        );
        
        $tablet_patterns = array(
            'ipad', 'tablet', 'android', 'kindle'
        );
        
        $user_agent = strtolower($user_agent);
        
        // Check for tablet
        foreach ($tablet_patterns as $pattern) {
            if (strpos($user_agent, $pattern) !== false) {
                if ($pattern === 'android' && strpos($user_agent, 'mobile') !== false) {
                    continue; // This is an Android phone, not a tablet
                }
                return 'tablet';
            }
        }
        
        // Check for mobile
        foreach ($mobile_patterns as $pattern) {
            if (strpos($user_agent, $pattern) !== false) {
                return 'mobile';
            }
        }
        
        // Default to desktop
        return 'desktop';
    }
    
    /**
     * Add ROI metric
     */
    public function addROIMetric($metric_type, $value, $details = array()) {
        global $wpdb;
        
        $wpdb->insert(
            "{$wpdb->prefix}aaiseo_roi_metrics",
            array(
                'metric_type' => $metric_type,
                'metric_value' => $value,
                'metric_date' => current_time('Y-m-d'),
                'details' => json_encode($details)
            ),
            array('%s', '%f', '%s', '%s')
        );
    }
    
    /**
     * Get revenue data
     */
    public function getRevenueData($start_date = null, $end_date = null) {
        global $wpdb;
        
        // Set default date range if not specified
        if ($start_date === null) {
            $start_date = date('Y-m-d', strtotime('-30 days'));
        }
        
        if ($end_date === null) {
            $end_date = date('Y-m-d');
        }
        
        // Query revenue data
        $revenue_data = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DATE(created_at) as date, SUM(amount) as revenue, currency
                FROM {$wpdb->prefix}aaiseo_revenue
                WHERE DATE(created_at) BETWEEN %s AND %s
                GROUP BY DATE(created_at), currency
                ORDER BY date",
                $start_date, $end_date
            ),
            ARRAY_A
        );
        
        // Query lead data
        $lead_data = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DATE(created_at) as date, SUM(lead_value) as lead_value, COUNT(*) as lead_count
                FROM {$wpdb->prefix}aaiseo_leads
                WHERE DATE(created_at) BETWEEN %s AND %s
                GROUP BY DATE(created_at)
                ORDER BY date",
                $start_date, $end_date
            ),
            ARRAY_A
        );
        
        // Get source breakdown
        $source_breakdown = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT source, COUNT(*) as count, SUM(amount) as revenue
                FROM {$wpdb->prefix}aaiseo_revenue
                WHERE DATE(created_at) BETWEEN %s AND %s
                GROUP BY source",
                $start_date, $end_date
            ),
            ARRAY_A
        );
        
        // Get form breakdown
        $form_breakdown = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT form_name, COUNT(*) as count, SUM(lead_value) as value
                FROM {$wpdb->prefix}aaiseo_leads
                WHERE DATE(created_at) BETWEEN %s AND %s
                GROUP BY form_name",
                $start_date, $end_date
            ),
            ARRAY_A
        );
        
        // Calculate totals
        $total_revenue = 0;
        foreach ($revenue_data as $data) {
            $total_revenue += floatval($data['revenue']);
        }
        
        $total_leads = 0;
        $total_lead_value = 0;
        foreach ($lead_data as $data) {
            $total_leads += intval($data['lead_count']);
            $total_lead_value += floatval($data['lead_value']);
        }
        
        return array(
            'revenue_data' => $revenue_data,
            'lead_data' => $lead_data,
            'source_breakdown' => $source_breakdown,
            'form_breakdown' => $form_breakdown,
            'total_revenue' => $total_revenue,
            'total_leads' => $total_leads,
            'total_lead_value' => $total_lead_value
        );
    }
    
    /**
     * Get ROI metrics
     */
    public function getROIMetrics($start_date = null, $end_date = null) {
        global $wpdb;
        
        // Set default date range if not specified
        if ($start_date === null) {
            $start_date = date('Y-m-d', strtotime('-90 days'));
        }
        
        if ($end_date === null) {
            $end_date = date('Y-m-d');
        }
        
        // Get ROI data
        $roi_data = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT metric_type, SUM(metric_value) as total, AVG(metric_value) as average
                FROM {$wpdb->prefix}aaiseo_roi_metrics
                WHERE metric_date BETWEEN %s AND %s
                GROUP BY metric_type",
                $start_date, $end_date
            ),
            ARRAY_A
        );
        
        // Format data into an associative array
        $metrics = array();
        
        foreach ($roi_data as $data) {
            $metrics[$data['metric_type']] = array(
                'total' => floatval($data['total']),
                'average' => floatval($data['average'])
            );
        }
        
        // Get organic traffic from analytics for the period
        $analytics = AAISEO_Analytics::getInstance();
        $traffic_data = $analytics->getAnalytics('organic_traffic');
        
        $total_traffic = 0;
        
        if (!empty($traffic_data)) {
            $traffic_data = array_filter($traffic_data, function($item) use ($start_date, $end_date) {
                return $item['date_recorded'] >= $start_date && $item['date_recorded'] <= $end_date;
            });
            
            foreach ($traffic_data as $traffic) {
                $total_traffic += intval($traffic['metric_value']);
            }
        }
        
        // Calculate key metrics
        $total_revenue = isset($metrics['revenue']['total']) ? $metrics['revenue']['total'] : 0;
        $total_lead_value = isset($metrics['leads']['total']) ? $metrics['leads']['total'] : 0;
        
        // Calculate ROI
        $subscription_cost = $this->getSubscriptionCost();
        $time_investment = $this->calculateTimeInvestment();
        $total_cost = $subscription_cost + $time_investment;
        
        $roi = 0;
        if ($total_cost > 0) {
            $roi = (($total_revenue + $total_lead_value - $total_cost) / $total_cost) * 100;
        }
        
        // Calculate revenue per visit
        $revenue_per_visit = $total_traffic > 0 ? $total_revenue / $total_traffic : 0;
        
        // Calculate value per lead
        $lead_count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}aaiseo_leads 
                WHERE DATE(created_at) BETWEEN %s AND %s",
                $start_date, $end_date
            )
        );
        
        $value_per_lead = $lead_count > 0 ? $total_lead_value / $lead_count : 0;
        
        // Calculate lead conversion rate
        $lead_conversion_rate = $total_traffic > 0 ? ($lead_count / $total_traffic) * 100 : 0;
        
        return array(
            'metrics' => $metrics,
            'total_traffic' => $total_traffic,
            'roi' => $roi,
            'revenue_per_visit' => $revenue_per_visit,
            'value_per_lead' => $value_per_lead,
            'lead_conversion_rate' => $lead_conversion_rate,
            'total_cost' => $total_cost,
            'subscription_cost' => $subscription_cost,
            'time_investment' => $time_investment
        );
    }
    
    /**
     * Calculate time investment cost
     */
    private function calculateTimeInvestment() {
        // Get average number of hours spent on SEO per month
        $hours_per_month = !empty($this->settings['hours_per_month']) ? floatval($this->settings['hours_per_month']) : 10;
        
        // Get hourly rate
        $hourly_rate = !empty($this->settings['hourly_rate']) ? floatval($this->settings['hourly_rate']) : 50;
        
        // Calculate time investment
        return $hours_per_month * $hourly_rate;
    }
    
    /**
     * Get subscription cost
     */
    private function getSubscriptionCost() {
        return !empty($this->settings['subscription_cost']) ? floatval($this->settings['subscription_cost']) : 500;
    }
    
    /**
     * Get revenue data via AJAX
     */
    public function getRevenueDataAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $start_date = isset($_POST['start_date']) ? sanitize_text_field($_POST['start_date']) : null;
        $end_date = isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : null;
        
        $revenue_data = $this->getRevenueData($start_date, $end_date);
        
        wp_send_json_success($revenue_data);
    }
    
    /**
     * Get ROI metrics via AJAX
     */
    public function getROIMetricsAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $start_date = isset($_POST['start_date']) ? sanitize_text_field($_POST['start_date']) : null;
        $end_date = isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : null;
        
        $roi_metrics = $this->getROIMetrics($start_date, $end_date);
        
        wp_send_json_success($roi_metrics);
    }
    
    /**
     * Calculate projected ROI
     */
    public function calculateProjectedROI($current_traffic, $projected_traffic_increase, $conversion_rate, $average_order_value) {
        $new_traffic = $current_traffic + $projected_traffic_increase;
        $current_revenue = $current_traffic * $conversion_rate * $average_order_value;
        $projected_revenue = $new_traffic * $conversion_rate * $average_order_value;
        $revenue_increase = $projected_revenue - $current_revenue;
        
        $subscription_cost = $this->getSubscriptionCost();
        $time_investment = $this->calculateTimeInvestment();
        $total_cost = $subscription_cost + $time_investment;
        
        $roi = 0;
        if ($total_cost > 0) {
            $roi = ($revenue_increase / $total_cost) * 100;
        }
        
        return array(
            'current_revenue' => $current_revenue,
            'projected_revenue' => $projected_revenue,
            'revenue_increase' => $revenue_increase,
            'roi' => $roi,
            'subscription_cost' => $subscription_cost,
            'time_investment' => $time_investment,
            'total_cost' => $total_cost
        );
    }
}