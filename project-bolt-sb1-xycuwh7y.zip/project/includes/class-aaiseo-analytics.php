<?php
/**
 * Analytics and Reporting for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Analytics {
    
    private static $instance = null;
    private $database;
    private $api_manager;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->database = AAISEO_Database::getInstance();
        $this->api_manager = AAISEO_API_Manager::getInstance();
        
        $this->initHooks();
    }
    
    private function initHooks() {
        add_action('wp_ajax_aaiseo_refresh_analytics', array($this, 'refreshAnalyticsAjax'));
        add_action('wp_ajax_aaiseo_export_report', array($this, 'exportReportAjax'));
    }
    
    /**
     * Get dashboard data
     */
    public function getDashboardData() {
        $data = array();
        
        // Get basic metrics
        $data['metrics'] = $this->getBasicMetrics();
        
        // Get SEO score
        $data['seo_score'] = $this->calculateSEOScore();
        
        // Get recent activities
        $data['activities'] = AAISEO_Core::getInstance()->getActivityLog(10);
        
        // Get traffic trends
        $data['traffic_trends'] = $this->getTrafficTrends();
        
        // Get keyword rankings
        $data['keyword_rankings'] = $this->getKeywordRankings();
        
        // Get optimization status
        $data['optimization_status'] = $this->getOptimizationStatus();
        
        return $data;
    }
    
    /**
     * Get basic metrics
     */
    private function getBasicMetrics() {
        $metrics = array();
        
        // Get from Google Analytics if connected
        $ga_data = $this->api_manager->getGoogleAnalyticsData();
        
        if (!is_wp_error($ga_data)) {
            $metrics['organic_traffic'] = $ga_data['organic_traffic'];
            $metrics['page_views'] = $ga_data['page_views'];
            $metrics['bounce_rate'] = $ga_data['bounce_rate'];
            $metrics['avg_session_duration'] = $ga_data['avg_session_duration'];
        } else {
            // Fallback to estimated data
            $metrics = $this->getEstimatedMetrics();
        }
        
        // Get WordPress-specific metrics
        $metrics['total_posts'] = wp_count_posts()->publish;
        $metrics['total_pages'] = wp_count_posts('page')->publish;
        $metrics['total_comments'] = wp_count_comments()->approved;
        
        return $metrics;
    }
    
    /**
     * Get estimated metrics when GA is not available
     */
    private function getEstimatedMetrics() {
        // This would use alternative methods to estimate traffic
        // For now, return sample data
        return array(
            'organic_traffic' => 24567,
            'page_views' => 89432,
            'bounce_rate' => 45.2,
            'avg_session_duration' => 185
        );
    }
    
    /**
     * Calculate overall SEO score
     */
    private function calculateSEOScore() {
        $scores = array();
        
        // Technical SEO score
        $scores['technical'] = $this->calculateTechnicalScore();
        
        // Content quality score
        $scores['content'] = $this->calculateContentScore();
        
        // User experience score
        $scores['user_experience'] = $this->calculateUserExperienceScore();
        
        // Authority score
        $scores['authority'] = $this->calculateAuthorityScore();
        
        // Calculate weighted average
        $weights = array(
            'technical' => 0.3,
            'content' => 0.3,
            'user_experience' => 0.25,
            'authority' => 0.15
        );
        
        $overall_score = 0;
        foreach ($scores as $category => $score) {
            $overall_score += $score * $weights[$category];
        }
        
        return array(
            'overall' => round($overall_score),
            'breakdown' => $scores
        );
    }
    
    /**
     * Calculate technical SEO score
     */
    private function calculateTechnicalScore() {
        $score = 100;
        
        global $wpdb;
        $technical_table = $wpdb->prefix . 'aaiseo_technical_audits';
        
        // Get recent technical issues
        $issues = $wpdb->get_results(
            "SELECT severity, COUNT(*) as count 
            FROM $technical_table 
            WHERE status = 'open' 
            AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY severity",
            ARRAY_A
        );
        
        foreach ($issues as $issue) {
            switch ($issue['severity']) {
                case 'high':
                    $score -= $issue['count'] * 15;
                    break;
                case 'medium':
                    $score -= $issue['count'] * 8;
                    break;
                case 'low':
                    $score -= $issue['count'] * 3;
                    break;
            }
        }
        
        return max(0, min(100, $score));
    }
    
    /**
     * Calculate content quality score
     */
    private function calculateContentScore() {
        $score = 50; // Base score
        
        global $wpdb;
        
        // Check for optimized content
        $optimized_posts = $wpdb->get_var(
            "SELECT COUNT(DISTINCT post_id) 
            FROM {$wpdb->prefix}aaiseo_optimizations 
            WHERE status = 'applied'"
        );
        
        $total_posts = wp_count_posts()->publish;
        
        if ($total_posts > 0) {
            $optimization_ratio = $optimized_posts / $total_posts;
            $score += $optimization_ratio * 40; // Up to 40 points for optimization coverage
        }
        
        // Check for meta descriptions
        $posts_with_meta = $wpdb->get_var(
            "SELECT COUNT(*) 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = '_aaiseo_meta_description' 
            AND meta_value != ''"
        );
        
        if ($total_posts > 0) {
            $meta_ratio = $posts_with_meta / $total_posts;
            $score += $meta_ratio * 10; // Up to 10 points for meta descriptions
        }
        
        return max(0, min(100, round($score)));
    }
    
    /**
     * Calculate user experience score
     */
    private function calculateUserExperienceScore() {
        $score = 70; // Base score
        
        // Check Core Web Vitals
        $vitals = $this->getLatestCoreWebVitals();
        
        if ($vitals) {
            // LCP score (up to 15 points)
            if ($vitals['lcp_score'] <= 2.5) {
                $score += 15;
            } elseif ($vitals['lcp_score'] <= 4.0) {
                $score += 8;
            }
            
            // FID score (up to 10 points)
            if ($vitals['fid_score'] <= 100) {
                $score += 10;
            } elseif ($vitals['fid_score'] <= 300) {
                $score += 5;
            }
            
            // CLS score (up to 5 points)
            if ($vitals['cls_score'] <= 0.1) {
                $score += 5;
            } elseif ($vitals['cls_score'] <= 0.25) {
                $score += 2;
            }
        }
        
        return max(0, min(100, $score));
    }
    
    /**
     * Get latest Core Web Vitals data
     */
    private function getLatestCoreWebVitals() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_core_web_vitals';
        
        return $wpdb->get_row(
            "SELECT * FROM $table_name ORDER BY recorded_at DESC LIMIT 1",
            ARRAY_A
        );
    }
    
    /**
     * Calculate authority score
     */
    private function calculateAuthorityScore() {
        // This would typically involve backlink analysis
        // For now, use content age and quantity as proxy
        
        $score = 30; // Base score
        
        global $wpdb;
        
        // Age factor
        $oldest_post = $wpdb->get_var(
            "SELECT post_date FROM {$wpdb->posts} 
            WHERE post_status = 'publish' 
            AND post_type = 'post' 
            ORDER BY post_date ASC 
            LIMIT 1"
        );
        
        if ($oldest_post) {
            $site_age_years = (time() - strtotime($oldest_post)) / (365 * 24 * 3600);
            $score += min(30, $site_age_years * 5); // Up to 30 points for age
        }
        
        // Content quantity factor
        $post_count = wp_count_posts()->publish;
        $score += min(40, $post_count / 10); // Up to 40 points for content volume
        
        return max(0, min(100, round($score)));
    }
    
    /**
     * Get traffic trends
     */
    private function getTrafficTrends() {
        // Get traffic data for the last 30 days
        $trends = $this->database->getAnalytics('organic_traffic', 30);
        
        if (empty($trends)) {
            // Generate sample trend data
            $trends = $this->generateSampleTrends();
        }
        
        return $trends;
    }
    
    /**
     * Generate sample trend data
     */
    private function generateSampleTrends() {
        $trends = array();
        $base_traffic = 800;
        
        for ($i = 29; $i >= 0; $i--) {
            $date = date('Y-m-d', strtotime("-{$i} days"));
            $variation = rand(-100, 150);
            $traffic = $base_traffic + $variation;
            
            $trends[] = array(
                'date_recorded' => $date,
                'metric_value' => $traffic,
                'metric_type' => 'organic_traffic'
            );
        }
        
        return $trends;
    }
    
    /**
     * Get keyword rankings
     */
    private function getKeywordRankings() {
        global $wpdb;
        
        $keywords_table = $wpdb->prefix . 'aaiseo_keywords';
        
        $rankings = $wpdb->get_results(
            "SELECT k.*, p.post_title 
            FROM $keywords_table k
            LEFT JOIN {$wpdb->posts} p ON k.post_id = p.ID
            WHERE k.tracking_enabled = 1
            ORDER BY k.current_position ASC
            LIMIT 20",
            ARRAY_A
        );
        
        return $rankings;
    }
    
    /**
     * Get optimization status
     */
    private function getOptimizationStatus() {
        global $wpdb;
        
        $optimizations_table = $wpdb->prefix . 'aaiseo_optimizations';
        
        $status = $wpdb->get_row(
            "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'applied' THEN 1 ELSE 0 END) as applied,
                SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected
            FROM $optimizations_table
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)",
            ARRAY_A
        );
        
        return $status;
    }
    
    /**
     * Get predictive analytics data
     */
    public function getPredictiveAnalytics() {
        $data = array();
        
        // Traffic predictions
        $data['traffic_predictions'] = $this->generateTrafficPredictions();
        
        // Ranking predictions
        $data['ranking_predictions'] = $this->generateRankingPredictions();
        
        // Content opportunities
        $data['content_opportunities'] = $this->identifyContentOpportunities();
        
        // Algorithm impact predictions
        $data['algorithm_predictions'] = $this->predictAlgorithmImpact();
        
        return $data;
    }
    
    /**
     * Generate traffic predictions
     */
    private function generateTrafficPredictions() {
        $historical_data = $this->getTrafficTrends();
        
        if (empty($historical_data)) {
            return array();
        }
        
        // Simple linear regression for prediction
        $predictions = array();
        $current_traffic = end($historical_data)['metric_value'];
        
        // Predict next 90 days
        for ($i = 1; $i <= 90; $i++) {
            $date = date('Y-m-d', strtotime("+{$i} days"));
            $predicted_traffic = $current_traffic + ($i * 15); // Assume 15 visitors growth per day
            
            $predictions[] = array(
                'date' => $date,
                'predicted_traffic' => round($predicted_traffic),
                'confidence' => max(50, 95 - ($i * 0.5)) // Decreasing confidence over time
            );
        }
        
        return $predictions;
    }
    
    /**
     * Generate ranking predictions
     */
    private function generateRankingPredictions() {
        $keywords = $this->getKeywordRankings();
        $predictions = array();
        
        foreach ($keywords as $keyword) {
            if ($keyword['current_position'] > $keyword['target_position']) {
                $improvement_potential = $keyword['current_position'] - $keyword['target_position'];
                $time_to_target = ceil($improvement_potential / 2); // Assume 2 positions improvement per month
                
                $predictions[] = array(
                    'keyword' => $keyword['keyword'],
                    'current_position' => $keyword['current_position'],
                    'target_position' => $keyword['target_position'],
                    'predicted_timeframe' => $time_to_target . ' months',
                    'confidence' => 75
                );
            }
        }
        
        return array_slice($predictions, 0, 10);
    }
    
    /**
     * Identify content opportunities
     */
    private function identifyContentOpportunities() {
        // This would analyze competitor gaps and search trends
        // For now, return sample opportunities
        return array(
            array(
                'topic' => 'Voice Search Optimization',
                'opportunity_score' => 85,
                'estimated_traffic' => '2.3K',
                'competition_level' => 'Medium',
                'recommended_action' => 'Create comprehensive guide'
            ),
            array(
                'topic' => 'AI Content Marketing',
                'opportunity_score' => 78,
                'estimated_traffic' => '1.8K',
                'competition_level' => 'High',
                'recommended_action' => 'Develop case studies'
            ),
            array(
                'topic' => 'Local SEO Strategies',
                'opportunity_score' => 72,
                'estimated_traffic' => '1.5K',
                'competition_level' => 'Low',
                'recommended_action' => 'Create location-specific content'
            )
        );
    }
    
    /**
     * Predict algorithm impact
     */
    private function predictAlgorithmImpact() {
        // This would analyze current SEO health and predict algorithm impact
        $seo_score = $this->calculateSEOScore();
        
        $risk_level = 'low';
        if ($seo_score['overall'] < 60) {
            $risk_level = 'high';
        } elseif ($seo_score['overall'] < 80) {
            $risk_level = 'medium';
        }
        
        return array(
            'risk_level' => $risk_level,
            'confidence' => 82,
            'recommendations' => $this->getAlgorithmRecommendations($risk_level),
            'next_update_estimate' => date('Y-m-d', strtotime('+45 days'))
        );
    }
    
    /**
     * Get algorithm recommendations
     */
    private function getAlgorithmRecommendations($risk_level) {
        $recommendations = array(
            'low' => array(
                'Continue current optimization strategy',
                'Monitor Core Web Vitals regularly',
                'Maintain content quality standards'
            ),
            'medium' => array(
                'Improve page loading speed',
                'Enhance content depth and quality',
                'Fix technical SEO issues',
                'Strengthen internal linking'
            ),
            'high' => array(
                'Urgent: Fix critical technical issues',
                'Improve content quality and relevance',
                'Optimize Core Web Vitals immediately',
                'Review and update meta tags',
                'Strengthen E-A-T signals'
            )
        );
        
        return isset($recommendations[$risk_level]) ? $recommendations[$risk_level] : $recommendations['medium'];
    }
    
    /**
     * Update metrics from external sources
     */
    public function updateMetrics() {
        // Update Google Analytics data
        $ga_data = $this->api_manager->getGoogleAnalyticsData();
        if (!is_wp_error($ga_data)) {
            $this->storeAnalyticsData('google_analytics', $ga_data);
        }
        
        // Update Search Console data
        $gsc_data = $this->api_manager->getSearchConsoleData();
        if (!is_wp_error($gsc_data)) {
            $this->storeAnalyticsData('search_console', $gsc_data);
        }
        
        // Update Core Web Vitals
        $vitals_data = $this->api_manager->getCoreWebVitalsData();
        if (!is_wp_error($vitals_data)) {
            $this->storeCoreWebVitals($vitals_data);
        }
    }
    
    /**
     * Store analytics data
     */
    private function storeAnalyticsData($source, $data) {
        foreach ($data as $metric => $value) {
            $this->database->insertAnalytics($source . '_' . $metric, $value, array('source' => $source));
        }
    }
    
    /**
     * Store Core Web Vitals data
     */
    private function storeCoreWebVitals($data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_core_web_vitals';
        
        $wpdb->insert(
            $table_name,
            array(
                'url' => home_url(),
                'lcp_score' => floatval($data['lcp']),
                'fid_score' => floatval($data['fid']),
                'cls_score' => floatval($data['cls']),
                'overall_score' => intval($data['overall']),
                'device_type' => 'desktop'
            ),
            array('%s', '%f', '%f', '%f', '%d', '%s')
        );
    }
    
    /**
     * Generate analytics report
     */
    public function generateReport($period = '30days', $format = 'html') {
        $data = array();
        
        // Get date range
        $end_date = current_time('Y-m-d');
        $start_date = date('Y-m-d', strtotime("-{$period}", strtotime($end_date)));
        
        // Collect report data
        $data['period'] = array('start' => $start_date, 'end' => $end_date);
        $data['summary'] = $this->getReportSummary($start_date, $end_date);
        $data['traffic'] = $this->getTrafficReport($start_date, $end_date);
        $data['keywords'] = $this->getKeywordsReport($start_date, $end_date);
        $data['optimizations'] = $this->getOptimizationsReport($start_date, $end_date);
        $data['technical'] = $this->getTechnicalReport($start_date, $end_date);
        
        // Format report
        if ($format === 'pdf') {
            return $this->generatePDFReport($data);
        } elseif ($format === 'csv') {
            return $this->generateCSVReport($data);
        } else {
            return $this->generateHTMLReport($data);
        }
    }
    
    /**
     * Get report summary
     */
    private function getReportSummary($start_date, $end_date) {
        $summary = array();
        
        // Traffic summary
        $traffic_data = $this->database->getAnalytics('organic_traffic', 30);
        $summary['total_traffic'] = array_sum(array_column($traffic_data, 'metric_value'));
        
        // Optimizations summary
        global $wpdb;
        $optimizations_count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}aaiseo_optimizations 
                WHERE created_at BETWEEN %s AND %s",
                $start_date,
                $end_date
            )
        );
        $summary['optimizations_applied'] = $optimizations_count;
        
        // SEO score
        $summary['seo_score'] = $this->calculateSEOScore();
        
        return $summary;
    }
    
    /**
     * Get traffic report
     */
    private function getTrafficReport($start_date, $end_date) {
        return $this->database->getAnalytics('organic_traffic', 30);
    }
    
    /**
     * Get keywords report
     */
    private function getKeywordsReport($start_date, $end_date) {
        global $wpdb;
        
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT k.*, kh.position, kh.recorded_at
                FROM {$wpdb->prefix}aaiseo_keywords k
                LEFT JOIN {$wpdb->prefix}aaiseo_keyword_history kh ON k.id = kh.keyword_id
                WHERE kh.recorded_at BETWEEN %s AND %s
                ORDER BY k.search_volume DESC",
                $start_date,
                $end_date
            ),
            ARRAY_A
        );
    }
    
    /**
     * Get optimizations report
     */
    private function getOptimizationsReport($start_date, $end_date) {
        global $wpdb;
        
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT o.*, p.post_title
                FROM {$wpdb->prefix}aaiseo_optimizations o
                LEFT JOIN {$wpdb->posts} p ON o.post_id = p.ID
                WHERE o.created_at BETWEEN %s AND %s
                ORDER BY o.created_at DESC",
                $start_date,
                $end_date
            ),
            ARRAY_A
        );
    }
    
    /**
     * Get technical report
     */
    private function getTechnicalReport($start_date, $end_date) {
        global $wpdb;
        
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}aaiseo_technical_audits
                WHERE created_at BETWEEN %s AND %s
                ORDER BY severity DESC, created_at DESC",
                $start_date,
                $end_date
            ),
            ARRAY_A
        );
    }
    
    /**
     * Generate HTML report
     */
    private function generateHTMLReport($data) {
        ob_start();
        include AAISEO_PLUGIN_PATH . 'templates/reports/html-report.php';
        return ob_get_clean();
    }
    
    /**
     * Generate PDF report
     */
    private function generatePDFReport($data) {
        // This would use a PDF library like TCPDF or FPDF
        // For now, return HTML that can be converted to PDF
        return $this->generateHTMLReport($data);
    }
    
    /**
     * Generate CSV report
     */
    private function generateCSVReport($data) {
        $csv_data = array();
        
        // Add headers
        $csv_data[] = array('Date', 'Metric', 'Value', 'Type');
        
        // Add traffic data
        foreach ($data['traffic'] as $traffic) {
            $csv_data[] = array(
                $traffic['date_recorded'],
                'Organic Traffic',
                $traffic['metric_value'],
                'Traffic'
            );
        }
        
        // Add keyword data
        foreach ($data['keywords'] as $keyword) {
            $csv_data[] = array(
                $keyword['recorded_at'],
                $keyword['keyword'],
                $keyword['position'],
                'Keyword Ranking'
            );
        }
        
        // Convert to CSV string
        $output = '';
        foreach ($csv_data as $row) {
            $output .= implode(',', array_map(function($field) {
                return '"' . str_replace('"', '""', $field) . '"';
            }, $row)) . "\n";
        }
        
        return $output;
    }
    
    /**
     * Refresh analytics via AJAX
     */
    public function refreshAnalyticsAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $this->updateMetrics();
        
        wp_send_json_success(__('Analytics data refreshed successfully', 'autonomous-ai-seo'));
    }
    
    /**
     * Export report via AJAX
     */
    public function exportReportAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $period = sanitize_text_field($_POST['period']);
        $format = sanitize_text_field($_POST['format']);
        
        $report = $this->generateReport($period, $format);
        
        wp_send_json_success(array('report' => $report));
    }
}