<?php
/**
 * Database management for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Database {
    
    private static $instance = null;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Database initialization handled in createTables()
    }
    
    public static function createTables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Activity log table
        $table_activity = $wpdb->prefix . 'aaiseo_activity_log';
        $sql_activity = "CREATE TABLE $table_activity (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            activity_type varchar(100) NOT NULL,
            description text NOT NULL,
            data longtext,
            user_id bigint(20) unsigned,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY activity_type (activity_type),
            KEY user_id (user_id),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // Analytics data table
        $table_analytics = $wpdb->prefix . 'aaiseo_analytics';
        $sql_analytics = "CREATE TABLE $table_analytics (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            metric_type varchar(100) NOT NULL,
            metric_value text NOT NULL,
            date_recorded date NOT NULL,
            data longtext,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY metric_type (metric_type),
            KEY date_recorded (date_recorded)
        ) $charset_collate;";
        
        // SEO optimizations table
        $table_optimizations = $wpdb->prefix . 'aaiseo_optimizations';
        $sql_optimizations = "CREATE TABLE $table_optimizations (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            post_id bigint(20) unsigned NOT NULL,
            optimization_type varchar(100) NOT NULL,
            original_content longtext,
            optimized_content longtext,
            status varchar(50) DEFAULT 'pending',
            ai_confidence decimal(5,2),
            impact_score decimal(5,2),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            applied_at datetime NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY optimization_type (optimization_type),
            KEY status (status)
        ) $charset_collate;";
        
        // Competitive intelligence table
        $table_competitors = $wpdb->prefix . 'aaiseo_competitors';
        $sql_competitors = "CREATE TABLE $table_competitors (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            domain varchar(255) NOT NULL,
            competitor_name varchar(255),
            tracking_enabled tinyint(1) DEFAULT 1,
            last_analyzed datetime,
            data longtext,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY domain (domain)
        ) $charset_collate;";
        
        // Competitor analysis data table
        $table_competitor_data = $wpdb->prefix . 'aaiseo_competitor_data';
        $sql_competitor_data = "CREATE TABLE $table_competitor_data (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            competitor_id bigint(20) unsigned NOT NULL,
            analysis_type varchar(100) NOT NULL,
            data longtext NOT NULL,
            analyzed_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY competitor_id (competitor_id),
            KEY analysis_type (analysis_type),
            KEY analyzed_at (analyzed_at)
        ) $charset_collate;";
        
        // Keywords tracking table
        $table_keywords = $wpdb->prefix . 'aaiseo_keywords';
        $sql_keywords = "CREATE TABLE $table_keywords (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            keyword varchar(255) NOT NULL,
            post_id bigint(20) unsigned,
            current_position int,
            target_position int,
            search_volume int,
            difficulty decimal(5,2),
            tracking_enabled tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            last_updated datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY keyword (keyword),
            KEY post_id (post_id),
            KEY current_position (current_position)
        ) $charset_collate;";
        
        // Keyword ranking history table
        $table_keyword_history = $wpdb->prefix . 'aaiseo_keyword_history';
        $sql_keyword_history = "CREATE TABLE $table_keyword_history (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            keyword_id bigint(20) unsigned NOT NULL,
            position int,
            search_volume int,
            recorded_at date NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY keyword_id (keyword_id),
            KEY recorded_at (recorded_at)
        ) $charset_collate;";
        
        // Meta optimizations table
        $table_meta = $wpdb->prefix . 'aaiseo_meta_optimizations';
        $sql_meta = "CREATE TABLE $table_meta (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            post_id bigint(20) unsigned NOT NULL,
            meta_data longtext NOT NULL,
            version int DEFAULT 1,
            status varchar(50) DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY status (status)
        ) $charset_collate;";
        
        // A/B Testing tables
        $table_ab_tests = $wpdb->prefix . 'aaiseo_ab_tests';
        $sql_ab_tests = "CREATE TABLE $table_ab_tests (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            post_id bigint(20) unsigned NOT NULL,
            element_type varchar(100) NOT NULL,
            original_content longtext NOT NULL,
            variations longtext NOT NULL,
            test_config longtext,
            status varchar(50) DEFAULT 'active',
            winning_variation int,
            created_by bigint(20) unsigned,
            start_date datetime DEFAULT CURRENT_TIMESTAMP,
            end_date datetime NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY element_type (element_type),
            KEY status (status)
        ) $charset_collate;";
        
        $table_ab_results = $wpdb->prefix . 'aaiseo_ab_test_results';
        $sql_ab_results = "CREATE TABLE $table_ab_results (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            test_id bigint(20) unsigned NOT NULL,
            variation_id int NOT NULL,
            variation_content longtext,
            impressions bigint(20) unsigned DEFAULT 0,
            clicks bigint(20) unsigned DEFAULT 0,
            conversions bigint(20) unsigned DEFAULT 0,
            last_updated datetime NULL,
            PRIMARY KEY (id),
            UNIQUE KEY test_variation (test_id, variation_id),
            KEY test_id (test_id)
        ) $charset_collate;";

        // Content version control table
        $table_content_versions = $wpdb->prefix . 'aaiseo_content_versions';
        $sql_content_versions = "CREATE TABLE $table_content_versions (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            post_id bigint(20) unsigned NOT NULL,
            version_type varchar(100) NOT NULL,
            title text NOT NULL,
            content longtext NOT NULL,
            excerpt text,
            meta_data longtext,
            ai_metadata longtext,
            user_id bigint(20) unsigned,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            restored_at datetime NULL,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY version_type (version_type),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // Technical SEO audits table
        $table_technical = $wpdb->prefix . 'aaiseo_technical_audits';
        $sql_technical = "CREATE TABLE $table_technical (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            audit_type varchar(100) NOT NULL,
            url varchar(500),
            issue_type varchar(100),
            severity varchar(50),
            status varchar(50) DEFAULT 'open',
            description text,
            recommendation text,
            data longtext,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            resolved_at datetime NULL,
            PRIMARY KEY (id),
            KEY audit_type (audit_type),
            KEY issue_type (issue_type),
            KEY severity (severity),
            KEY status (status)
        ) $charset_collate;";
        
        // Core Web Vitals data table
        $table_vitals = $wpdb->prefix . 'aaiseo_core_web_vitals';
        $sql_vitals = "CREATE TABLE $table_vitals (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            url varchar(500) NOT NULL,
            lcp_score decimal(8,3),
            fid_score decimal(8,3),
            cls_score decimal(8,3),
            overall_score int,
            device_type varchar(20) DEFAULT 'desktop',
            recorded_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY url (url),
            KEY recorded_at (recorded_at),
            KEY device_type (device_type)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        dbDelta($sql_activity);
        dbDelta($sql_analytics);
        dbDelta($sql_optimizations);
        dbDelta($sql_competitors);
        dbDelta($sql_competitor_data);
        dbDelta($sql_keywords);
        dbDelta($sql_keyword_history);
        dbDelta($sql_meta);
        dbDelta($sql_technical);
        dbDelta($sql_vitals);
        dbDelta($sql_ab_tests);
        dbDelta($sql_ab_results);
        dbDelta($sql_content_versions);
        
        // Add version option
        add_option('aaiseo_db_version', AAISEO_PLUGIN_VERSION);
    }
    
    public static function dropTables() {
        global $wpdb;
        
        $tables = array(
            $wpdb->prefix . 'aaiseo_activity_log',
            $wpdb->prefix . 'aaiseo_analytics',
            $wpdb->prefix . 'aaiseo_optimizations',
            $wpdb->prefix . 'aaiseo_competitors',
            $wpdb->prefix . 'aaiseo_competitor_data',
            $wpdb->prefix . 'aaiseo_keywords',
            $wpdb->prefix . 'aaiseo_keyword_history',
            $wpdb->prefix . 'aaiseo_meta_optimizations',
            $wpdb->prefix . 'aaiseo_technical_audits',
            $wpdb->prefix . 'aaiseo_core_web_vitals',
            $wpdb->prefix . 'aaiseo_ab_tests',
            $wpdb->prefix . 'aaiseo_ab_test_results',
            $wpdb->prefix . 'aaiseo_content_versions'
        );
        
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS $table");
        }
        
        delete_option('aaiseo_db_version');
    }
    
    public function getTablePrefix() {
        global $wpdb;
        return $wpdb->prefix . 'aaiseo_';
    }
    
    public function insertAnalytics($metric_type, $metric_value, $data = array()) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_analytics';
        
        return $wpdb->insert(
            $table_name,
            array(
                'metric_type' => sanitize_text_field($metric_type),
                'metric_value' => sanitize_text_field($metric_value),
                'date_recorded' => current_time('Y-m-d'),
                'data' => json_encode($data)
            ),
            array('%s', '%s', '%s', '%s')
        );
    }
    
    public function getAnalytics($metric_type, $days = 30) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_analytics';
        
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table_name 
                WHERE metric_type = %s 
                AND date_recorded >= DATE_SUB(CURDATE(), INTERVAL %d DAY)
                ORDER BY date_recorded DESC",
                $metric_type,
                $days
            ),
            ARRAY_A
        );
    }
    
    public function insertOptimization($post_id, $optimization_type, $original_content, $optimized_content, $ai_confidence = 0, $impact_score = 0) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_optimizations';
        
        return $wpdb->insert(
            $table_name,
            array(
                'post_id' => intval($post_id),
                'optimization_type' => sanitize_text_field($optimization_type),
                'original_content' => $original_content,
                'optimized_content' => $optimized_content,
                'ai_confidence' => floatval($ai_confidence),
                'impact_score' => floatval($impact_score)
            ),
            array('%d', '%s', '%s', '%s', '%f', '%f')
        );
    }
    
    public function updateOptimizationStatus($optimization_id, $status) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_optimizations';
        
        $update_data = array('status' => sanitize_text_field($status));
        
        if ($status === 'applied') {
            $update_data['applied_at'] = current_time('mysql');
        }
        
        return $wpdb->update(
            $table_name,
            $update_data,
            array('id' => intval($optimization_id)),
            array('%s', '%s'),
            array('%d')
        );
    }
}