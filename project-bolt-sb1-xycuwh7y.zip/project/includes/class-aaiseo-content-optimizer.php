<?php
/**
 * Content Optimizer for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Content_Optimizer {
    
    private static $instance = null;
    private $ai_engine;
    private $database;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->ai_engine = AAISEO_AI_Engine::getInstance();
        $this->database = AAISEO_Database::getInstance();
        
        $this->initHooks();
    }
    
    private function initHooks() {
        add_action('save_post', array($this, 'analyzePostOnSave'), 10, 2);
        add_action('wp_ajax_aaiseo_apply_optimization', array($this, 'applyOptimization'));
        add_action('wp_ajax_aaiseo_reject_optimization', array($this, 'rejectOptimization'));
        add_action('wp_ajax_aaiseo_create_ab_test', array($this, 'createABTestAjax'));
        add_filter('the_content', array($this, 'enhanceContentOutput'), 999);
    }
    
    /**
     * Analyze post when saved and suggest optimizations
     */
    public function analyzePostOnSave($post_id, $post) {
        // Skip for revisions, autosaves, and non-public post types
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }
        
        if (!in_array($post->post_type, array('post', 'page'))) {
            return;
        }
        
        if ($post->post_status !== 'publish') {
            return;
        }
        
        // Get target keywords (you might want to add a meta box for this)
        $target_keywords = get_post_meta($post_id, '_aaiseo_target_keywords', true);
        $target_keywords = $target_keywords ? explode(',', $target_keywords) : array();
        
        // Analyze content
        $this->scheduleContentAnalysis($post_id, $post->post_content, $target_keywords);
    }
    
    /**
     * Schedule content analysis to run in background
     */
    public function scheduleContentAnalysis($post_id, $content, $target_keywords = array()) {
        wp_schedule_single_event(time() + 60, 'aaiseo_analyze_content', array($post_id, $content, $target_keywords));
        
        if (!wp_next_scheduled('aaiseo_analyze_content')) {
            add_action('aaiseo_analyze_content', array($this, 'runContentAnalysis'), 10, 3);
        }
    }
    
    /**
     * Run content analysis and store suggestions
     */
    public function runContentAnalysis($post_id, $content, $target_keywords = array()) {
        $context = array(
            'post_id' => $post_id,
            'post_type' => get_post_type($post_id),
            'post_title' => get_the_title($post_id)
        );
        
        $analysis = $this->ai_engine->analyzeContent($content, $target_keywords, $context);
        
        if (is_wp_error($analysis)) {
            error_log('AAISEO Content Analysis Error: ' . $analysis->get_error_message());
            return;
        }
        
        // Store analysis results
        $this->storeContentAnalysis($post_id, $analysis, $target_keywords);
        
        // Generate specific optimizations
        $this->generateOptimizations($post_id, $content, $analysis, $target_keywords);
    }
    
    /**
     * Store content analysis results
     */
    private function storeContentAnalysis($post_id, $analysis, $target_keywords) {
        $analysis_data = array(
            'analysis' => $analysis,
            'target_keywords' => $target_keywords,
            'analyzed_at' => current_time('mysql')
        );
        
        update_post_meta($post_id, '_aaiseo_content_analysis', $analysis_data);
        
        // Log activity
        AAISEO_Core::getInstance()->logActivity(
            'content_analysis',
            sprintf(__('Content analyzed for post: %s', 'autonomous-ai-seo'), get_the_title($post_id)),
            array('post_id' => $post_id, 'analysis_summary' => wp_trim_words($analysis['analysis'] ?? '', 20))
        );
    }
    
    /**
     * Generate specific optimizations based on analysis
     */
    private function generateOptimizations($post_id, $content, $analysis, $target_keywords) {
        $optimization_types = array(
            'meta_description',
            'title_optimization',
            'header_structure',
            'content_enhancement',
            'internal_linking'
        );
        
        foreach ($optimization_types as $type) {
            $this->generateSpecificOptimization($post_id, $content, $type, $target_keywords, $analysis);
        }
    }
    
    /**
     * Generate specific type of optimization
     */
    private function generateSpecificOptimization($post_id, $content, $type, $target_keywords, $analysis) {
        $original_content = '';
        $optimized_content = '';
        $ai_confidence = 0;
        
        switch ($type) {
            case 'meta_description':
                $title = get_the_title($post_id);
                $optimized_content = $this->ai_engine->generateMetaDescription($title, $content, $target_keywords);
                $original_content = get_post_meta($post_id, '_yoast_wpseo_metadesc', true); // Support for Yoast
                $ai_confidence = 0.85;
                break;
                
            case 'content_enhancement':
                $optimized_content = $this->ai_engine->generateContentImprovement($content, 'seo_optimization', $target_keywords);
                $original_content = $content;
                $ai_confidence = 0.75;
                break;
                
            case 'header_structure':
                $optimized_content = $this->ai_engine->generateContentImprovement($content, 'header_optimization', $target_keywords);
                $original_content = $content;
                $ai_confidence = 0.80;
                break;
        }
        
        if (!is_wp_error($optimized_content) && !empty($optimized_content)) {
            $impact_score = $this->calculateImpactScore($type, $analysis);
            
            $this->database->insertOptimization(
                $post_id,
                $type,
                $original_content,
                $optimized_content,
                $ai_confidence,
                $impact_score
            );
        }
    }
    
    /**
     * Calculate impact score for optimization
     */
    private function calculateImpactScore($type, $analysis) {
        $base_scores = array(
            'meta_description' => 70,
            'title_optimization' => 85,
            'header_structure' => 60,
            'content_enhancement' => 75,
            'internal_linking' => 55
        );
        
        $base_score = isset($base_scores[$type]) ? $base_scores[$type] : 50;
        
        // Adjust based on analysis if available
        if (isset($analysis['seo_score'])) {
            $seo_score = intval($analysis['seo_score']);
            if ($seo_score < 60) {
                $base_score += 20; // Higher impact for low-scoring content
            } elseif ($seo_score > 80) {
                $base_score -= 10; // Lower impact for already good content
            }
        }
        
        return min(100, max(0, $base_score));
    }
    
    /**
     * Run autonomous optimization
     */
    public function runAutonomousOptimization() {
        $settings = get_option('aaiseo_settings', array());
        
        if (empty($settings['auto_optimization_enabled'])) {
            return false;
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_optimizations';
        
        // Get pending optimizations with high confidence and impact
        $optimizations = $wpdb->get_results(
            "SELECT * FROM $table_name 
            WHERE status = 'pending' 
            AND ai_confidence >= 0.8 
            AND impact_score >= 70 
            ORDER BY impact_score DESC, ai_confidence DESC 
            LIMIT 10",
            ARRAY_A
        );
        
        $applied_count = 0;
        
        foreach ($optimizations as $optimization) {
            if ($this->applyOptimizationAutomatically($optimization)) {
                $applied_count++;
            }
        }
        
        // Log activity
        if ($applied_count > 0) {
            AAISEO_Core::getInstance()->logActivity(
                'autonomous_optimization',
                sprintf(__('Applied %d automatic optimizations', 'autonomous-ai-seo'), $applied_count),
                array('count' => $applied_count)
            );
        }
        
        return $applied_count;
    }
    
    /**
     * Apply optimization automatically
     */
    private function applyOptimizationAutomatically($optimization) {
        $post_id = intval($optimization['post_id']);
        $type = $optimization['optimization_type'];
        $optimized_content = $optimization['optimized_content'];
        
        $result = false;
        
        switch ($type) {
            case 'meta_description':
                $result = update_post_meta($post_id, '_aaiseo_meta_description', $optimized_content);
                break;
                
            case 'title_optimization':
                $result = wp_update_post(array(
                    'ID' => $post_id,
                    'post_title' => $optimized_content
                ));
                break;
                
            case 'content_enhancement':
                // Only apply if auto-apply is specifically enabled
                $settings = get_option('aaiseo_settings', array());
                if (!empty($settings['ai_suggestions_auto_apply'])) {
                    $result = wp_update_post(array(
                        'ID' => $post_id,
                        'post_content' => $optimized_content
                    ));
                }
                break;
        }
        
        if ($result) {
            $this->database->updateOptimizationStatus($optimization['id'], 'applied');
            return true;
        }
        
        return false;
    }
    
    /**
     * Get optimization status for admin interface
     */
    public function getOptimizationStatus() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_optimizations';
        
        $stats = $wpdb->get_row(
            "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'applied' THEN 1 ELSE 0 END) as applied,
                SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
                AVG(ai_confidence) as avg_confidence,
                AVG(impact_score) as avg_impact
            FROM $table_name
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)",
            ARRAY_A
        );
        
        $recent_optimizations = $wpdb->get_results(
            "SELECT o.*, p.post_title 
            FROM $table_name o
            LEFT JOIN {$wpdb->posts} p ON o.post_id = p.ID
            ORDER BY o.created_at DESC
            LIMIT 20",
            ARRAY_A
        );
        
        return array(
            'stats' => $stats,
            'recent' => $recent_optimizations
        );
    }
    
    /**
     * Get content strategy data
     */
    public function getContentStrategy() {
        // Implementation for content strategy dashboard
        return array(
            'content_gaps' => $this->identifyContentGaps(),
            'keyword_opportunities' => $this->getKeywordOpportunities(),
            'performance_metrics' => $this->getContentPerformanceMetrics()
        );
    }
    
    /**
     * Identify content gaps
     */
    private function identifyContentGaps() {
        // This would integrate with competitor analysis
        // For now, return sample data
        return array(
            array(
                'topic' => 'Voice Search Optimization',
                'opportunity_score' => 85,
                'competition_level' => 'Medium',
                'estimated_traffic' => '2.3K'
            ),
            array(
                'topic' => 'AI Content Marketing',
                'opportunity_score' => 78,
                'competition_level' => 'High',
                'estimated_traffic' => '1.8K'
            )
        );
    }
    
    /**
     * Get keyword opportunities
     */
    private function getKeywordOpportunities() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_keywords';
        
        return $wpdb->get_results(
            "SELECT * FROM $table_name 
            WHERE tracking_enabled = 1 
            AND current_position > target_position 
            ORDER BY search_volume DESC 
            LIMIT 20",
            ARRAY_A
        );
    }
    
    /**
     * Get content performance metrics
     */
    private function getContentPerformanceMetrics() {
        // Integration with analytics would go here
        return array(
            'total_posts' => wp_count_posts()->publish,
            'avg_word_count' => $this->getAverageWordCount(),
            'optimization_coverage' => $this->getOptimizationCoverage()
        );
    }
    
    /**
     * Get average word count
     */
    private function getAverageWordCount() {
        global $wpdb;
        
        $result = $wpdb->get_var(
            "SELECT AVG(CHAR_LENGTH(post_content) - CHAR_LENGTH(REPLACE(post_content, ' ', '')) + 1) 
            FROM {$wpdb->posts} 
            WHERE post_status = 'publish' 
            AND post_type IN ('post', 'page')
            AND post_content != ''"
        );
        
        return round($result);
    }
    
    /**
     * Get optimization coverage percentage
     */
    private function getOptimizationCoverage() {
        global $wpdb;
        
        $total_posts = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} 
            WHERE post_status = 'publish' 
            AND post_type IN ('post', 'page')"
        );
        
        $optimized_posts = $wpdb->get_var(
            "SELECT COUNT(DISTINCT post_id) 
            FROM {$wpdb->prefix}aaiseo_optimizations 
            WHERE status = 'applied'"
        );
        
        return $total_posts > 0 ? round(($optimized_posts / $total_posts) * 100) : 0;
    }
    
    /**
     * Apply optimization via AJAX
     */
    public function applyOptimization() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_die(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $optimization_id = intval($_POST['optimization_id']);
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_optimizations';
        
        $optimization = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $optimization_id),
            ARRAY_A
        );
        
        if (!$optimization) {
            wp_send_json_error(__('Optimization not found', 'autonomous-ai-seo'));
        }
        
        if ($this->applyOptimizationAutomatically($optimization)) {
            wp_send_json_success(__('Optimization applied successfully', 'autonomous-ai-seo'));
        } else {
            wp_send_json_error(__('Failed to apply optimization', 'autonomous-ai-seo'));
        }
    }
    
    /**
     * Reject optimization via AJAX
     */
    public function rejectOptimization() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_die(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $optimization_id = intval($_POST['optimization_id']);
        
        if ($this->database->updateOptimizationStatus($optimization_id, 'rejected')) {
            wp_send_json_success(__('Optimization rejected', 'autonomous-ai-seo'));
        } else {
            wp_send_json_error(__('Failed to reject optimization', 'autonomous-ai-seo'));
        }
    }
    
    /**
     * Enhance content output with optimizations
     */
    public function enhanceContentOutput($content) {
        if (!is_singular() || is_admin()) {
            return $content;
        }
        
        $post_id = get_the_ID();
        if (!$post_id) {
            return $content;
        }
        
        // Add internal links automatically
        $content = $this->addAutomaticInternalLinks($content, $post_id);
        
        // Add schema markup
        $content = $this->addContentSchemaMarkup($content, $post_id);
        
        return $content;
    }
    
    /**
     * Add automatic internal links
     */
    private function addAutomaticInternalLinks($content, $post_id) {
        $settings = get_option('aaiseo_settings', array());
        
        if (empty($settings['auto_internal_linking'])) {
            return $content;
        }
        
        // Get related posts
        $related_posts = $this->getRelatedPosts($post_id);
        
        foreach ($related_posts as $related_post) {
            $keyword = $related_post['keyword'];
            $url = get_permalink($related_post['post_id']);
            $title = get_the_title($related_post['post_id']);
            
            // Only link the first occurrence of the keyword
            $pattern = '/\b' . preg_quote($keyword, '/') . '\b/i';
            $replacement = '<a href="' . esc_url($url) . '" title="' . esc_attr($title) . '">' . $keyword . '</a>';
            
            $content = preg_replace($pattern, $replacement, $content, 1);
        }
        
        return $content;
    }
    
    /**
     * Get related posts for internal linking
     */
    private function getRelatedPosts($post_id, $limit = 3) {
        // This would analyze content and find relevant posts
        // For now, return sample data
        return array();
    }
    
    /**
     * Add content schema markup
     */
    private function addContentSchemaMarkup($content, $post_id) {
        $post = get_post($post_id);
        
        if ($post->post_type === 'post') {
            $schema = array(
                "@context" => "https://schema.org",
                "@type" => "BlogPosting",
                "headline" => get_the_title($post_id),
                "description" => get_the_excerpt($post_id),
                "author" => array(
                    "@type" => "Person",
                    "name" => get_the_author_meta('display_name', $post->post_author)
                ),
                "datePublished" => get_the_date('c', $post_id),
                "dateModified" => get_the_modified_date('c', $post_id)
            );
            
            $schema_json = '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES) . '</script>';
            $content .= $schema_json;
        }
        
        return $content;
    }
    
    /**
     * Create A/B test for content element
     */
    public function createABTest($post_id, $element_type, $original_content) {
        $ab_testing = AAISEO_AB_Testing::getInstance();
        
        // Get target keywords
        $target_keywords = get_post_meta($post_id, '_aaiseo_target_keywords', true);
        $target_keywords = $target_keywords ? explode(',', $target_keywords) : array();
        
        // Configure test parameters
        $test_config = array(
            'target_keywords' => $target_keywords,
            'variation_count' => 3,
            'auto_apply_winner' => true
        );
        
        // Create the test
        return $ab_testing->createABTest($post_id, $element_type, $original_content, $test_config);
    }
    
    /**
     * AJAX handler for creating A/B test
     */
    public function createABTestAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $post_id = intval($_POST['post_id']);
        $element_type = sanitize_text_field($_POST['element_type']);
        $original_content = sanitize_textarea_field($_POST['original_content']);
        
        $test_id = $this->createABTest($post_id, $element_type, $original_content);
        
        if (is_wp_error($test_id)) {
            wp_send_json_error($test_id->get_error_message());
        } elseif ($test_id) {
            wp_send_json_success(array(
                'test_id' => $test_id,
                'message' => __('A/B test created successfully', 'autonomous-ai-seo')
            ));
        } else {
            wp_send_json_error(__('Failed to create A/B test', 'autonomous-ai-seo'));
        }
    }
    
    /**
     * Run optimization and return result
     */
    public function runOptimization() {
        return $this->runAutonomousOptimization();
    }
}