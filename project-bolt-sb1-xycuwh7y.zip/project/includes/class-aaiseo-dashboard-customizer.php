<?php
/**
 * Dashboard Customizer for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Dashboard_Customizer {
    
    private static $instance = null;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->initHooks();
    }
    
    private function initHooks() {
        add_action('wp_ajax_aaiseo_save_dashboard_layout', array($this, 'saveDashboardLayoutAjax'));
        add_action('wp_ajax_aaiseo_get_dashboard_layout', array($this, 'getDashboardLayoutAjax'));
        add_action('wp_ajax_aaiseo_reset_dashboard_layout', array($this, 'resetDashboardLayoutAjax'));
        add_action('wp_ajax_aaiseo_add_custom_widget', array($this, 'addCustomWidgetAjax'));
        add_action('wp_ajax_aaiseo_remove_custom_widget', array($this, 'removeCustomWidgetAjax'));
    }
    
    /**
     * Get dashboard layout for current user
     */
    public function getDashboardLayout($user_id = null) {
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        
        $layout = get_user_meta($user_id, 'aaiseo_dashboard_layout', true);
        
        if (empty($layout)) {
            $layout = $this->getDefaultLayout();
        }
        
        return $layout;
    }
    
    /**
     * Get default dashboard layout
     */
    private function getDefaultLayout() {
        return array(
            'columns' => array(
                'column-1' => array(
                    'widgets' => array('seo-score', 'recent-activities'),
                    'width' => '33%'
                ),
                'column-2' => array(
                    'widgets' => array('traffic-trends', 'optimization-status'),
                    'width' => '33%'
                ),
                'column-3' => array(
                    'widgets' => array('top-keywords', 'quick-actions'),
                    'width' => '34%'
                )
            ),
            'widgets' => array(
                'seo-score' => array(
                    'title' => 'SEO Score',
                    'type' => 'seo-score',
                    'enabled' => true,
                    'settings' => array()
                ),
                'recent-activities' => array(
                    'title' => 'Recent Activities',
                    'type' => 'activities',
                    'enabled' => true,
                    'settings' => array('limit' => 10)
                ),
                'traffic-trends' => array(
                    'title' => 'Traffic Trends',
                    'type' => 'chart',
                    'enabled' => true,
                    'settings' => array('period' => '30d', 'chart_type' => 'line')
                ),
                'optimization-status' => array(
                    'title' => 'Optimization Status',
                    'type' => 'metrics',
                    'enabled' => true,
                    'settings' => array()
                ),
                'top-keywords' => array(
                    'title' => 'Top Keywords',
                    'type' => 'keywords',
                    'enabled' => true,
                    'settings' => array('limit' => 10)
                ),
                'quick-actions' => array(
                    'title' => 'Quick Actions',
                    'type' => 'actions',
                    'enabled' => true,
                    'settings' => array()
                )
            )
        );
    }
    
    /**
     * Save dashboard layout for user
     */
    public function saveDashboardLayout($layout, $user_id = null) {
        if ($user_id === null) {
            $user_id = get_current_user_id();
        }
        
        $validated_layout = $this->validateLayout($layout);
        
        if ($validated_layout) {
            update_user_meta($user_id, 'aaiseo_dashboard_layout', $validated_layout);
            
            // Log layout change
            AAISEO_Core::getInstance()->logActivity(
                'dashboard_layout_changed',
                __('Dashboard layout customized', 'autonomous-ai-seo'),
                array('user_id' => $user_id)
            );
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Validate dashboard layout structure
     */
    private function validateLayout($layout) {
        if (!is_array($layout) || !isset($layout['columns']) || !isset($layout['widgets'])) {
            return false;
        }
        
        $validated = array(
            'columns' => array(),
            'widgets' => array()
        );
        
        // Validate columns
        foreach ($layout['columns'] as $column_id => $column_data) {
            if (is_array($column_data) && isset($column_data['widgets'])) {
                $validated['columns'][$column_id] = array(
                    'widgets' => array_filter($column_data['widgets'], 'is_string'),
                    'width' => isset($column_data['width']) ? sanitize_text_field($column_data['width']) : '33%'
                );
            }
        }
        
        // Validate widgets
        foreach ($layout['widgets'] as $widget_id => $widget_data) {
            if (is_array($widget_data) && isset($widget_data['type'])) {
                $validated['widgets'][$widget_id] = array(
                    'title' => sanitize_text_field($widget_data['title'] ?? ''),
                    'type' => sanitize_text_field($widget_data['type']),
                    'enabled' => !empty($widget_data['enabled']),
                    'settings' => is_array($widget_data['settings']) ? $widget_data['settings'] : array()
                );
            }
        }
        
        return $validated;
    }
    
    /**
     * Get available widget types
     */
    public function getAvailableWidgets() {
        return array(
            'seo-score' => array(
                'title' => __('SEO Score', 'autonomous-ai-seo'),
                'description' => __('Overall SEO performance score', 'autonomous-ai-seo'),
                'icon' => 'dashicons-star-filled',
                'category' => 'performance'
            ),
            'activities' => array(
                'title' => __('Recent Activities', 'autonomous-ai-seo'),
                'description' => __('Latest AI optimization activities', 'autonomous-ai-seo'),
                'icon' => 'dashicons-admin-generic',
                'category' => 'activity'
            ),
            'chart' => array(
                'title' => __('Analytics Chart', 'autonomous-ai-seo'),
                'description' => __('Traffic and performance charts', 'autonomous-ai-seo'),
                'icon' => 'dashicons-chart-line',
                'category' => 'analytics'
            ),
            'metrics' => array(
                'title' => __('Key Metrics', 'autonomous-ai-seo'),
                'description' => __('Important SEO metrics', 'autonomous-ai-seo'),
                'icon' => 'dashicons-chart-bar',
                'category' => 'analytics'
            ),
            'keywords' => array(
                'title' => __('Keywords', 'autonomous-ai-seo'),
                'description' => __('Top performing keywords', 'autonomous-ai-seo'),
                'icon' => 'dashicons-search',
                'category' => 'seo'
            ),
            'actions' => array(
                'title' => __('Quick Actions', 'autonomous-ai-seo'),
                'description' => __('Frequently used actions', 'autonomous-ai-seo'),
                'icon' => 'dashicons-admin-tools',
                'category' => 'tools'
            ),
            'competitors' => array(
                'title' => __('Competitor Alerts', 'autonomous-ai-seo'),
                'description' => __('Latest competitor intelligence', 'autonomous-ai-seo'),
                'icon' => 'dashicons-visibility',
                'category' => 'competitive'
            ),
            'web-vitals' => array(
                'title' => __('Core Web Vitals', 'autonomous-ai-seo'),
                'description' => __('Performance metrics', 'autonomous-ai-seo'),
                'icon' => 'dashicons-performance',
                'category' => 'performance'
            ),
            'content-ideas' => array(
                'title' => __('Content Ideas', 'autonomous-ai-seo'),
                'description' => __('AI-generated content suggestions', 'autonomous-ai-seo'),
                'icon' => 'dashicons-lightbulb',
                'category' => 'content'
            ),
            'technical-issues' => array(
                'title' => __('Technical Issues', 'autonomous-ai-seo'),
                'description' => __('SEO issues that need attention', 'autonomous-ai-seo'),
                'icon' => 'dashicons-warning',
                'category' => 'technical'
            )
        );
    }
    
    /**
     * Render dashboard widget
     */
    public function renderWidget($widget_id, $widget_config) {
        $widget_type = $widget_config['type'];
        $settings = $widget_config['settings'] ?? array();
        
        switch ($widget_type) {
            case 'seo-score':
                return $this->renderSEOScoreWidget($settings);
                
            case 'activities':
                return $this->renderActivitiesWidget($settings);
                
            case 'chart':
                return $this->renderChartWidget($settings);
                
            case 'metrics':
                return $this->renderMetricsWidget($settings);
                
            case 'keywords':
                return $this->renderKeywordsWidget($settings);
                
            case 'actions':
                return $this->renderActionsWidget($settings);
                
            case 'competitors':
                return $this->renderCompetitorsWidget($settings);
                
            case 'web-vitals':
                return $this->renderWebVitalsWidget($settings);
                
            case 'content-ideas':
                return $this->renderContentIdeasWidget($settings);
                
            case 'technical-issues':
                return $this->renderTechnicalIssuesWidget($settings);
                
            default:
                return $this->renderCustomWidget($widget_id, $widget_config);
        }
    }
    
    /**
     * Render SEO Score widget
     */
    private function renderSEOScoreWidget($settings) {
        $analytics = AAISEO_Analytics::getInstance();
        $seo_score = $analytics->calculateSEOScore();
        
        ob_start();
        ?>
        <div class="aaiseo-widget seo-score-widget">
            <div class="widget-content">
                <div class="score-circle" data-score="<?php echo $seo_score['overall']; ?>">
                    <span class="score-number"><?php echo $seo_score['overall']; ?>%</span>
                </div>
                <div class="score-breakdown">
                    <?php foreach ($seo_score['breakdown'] as $category => $score): ?>
                        <div class="score-item">
                            <span class="category"><?php echo ucwords(str_replace('_', ' ', $category)); ?></span>
                            <span class="score"><?php echo $score; ?>%</span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Activities widget
     */
    private function renderActivitiesWidget($settings) {
        $limit = $settings['limit'] ?? 5;
        $core = AAISEO_Core::getInstance();
        $activities = $core->getActivityLog($limit);
        
        ob_start();
        ?>
        <div class="aaiseo-widget activities-widget">
            <div class="widget-content">
                <?php if (!empty($activities)): ?>
                    <div class="activities-list">
                        <?php foreach ($activities as $activity): ?>
                            <div class="activity-item">
                                <div class="activity-icon">
                                    <span class="status-dot <?php echo $this->getActivityStatusClass($activity['activity_type']); ?>"></span>
                                </div>
                                <div class="activity-content">
                                    <p class="activity-description"><?php echo esc_html($activity['description']); ?></p>
                                    <span class="activity-time"><?php echo human_time_diff(strtotime($activity['created_at'])); ?> ago</span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="no-activities">No recent activities</p>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Get activity status class
     */
    private function getActivityStatusClass($activity_type) {
        $status_classes = array(
            'content_analysis' => 'completed',
            'autonomous_optimization' => 'completed',
            'competitor_change' => 'attention',
            'technical_audit' => 'completed',
            'ab_test_created' => 'pending',
            'ab_test_completed' => 'completed'
        );
        
        return isset($status_classes[$activity_type]) ? $status_classes[$activity_type] : 'pending';
    }
    
    /**
     * Render Chart widget
     */
    private function renderChartWidget($settings) {
        $period = $settings['period'] ?? '30d';
        $chart_type = $settings['chart_type'] ?? 'line';
        
        ob_start();
        ?>
        <div class="aaiseo-widget chart-widget">
            <div class="widget-content">
                <div class="chart-container">
                    <canvas id="dashboard-chart-<?php echo uniqid(); ?>" width="400" height="200"></canvas>
                </div>
                <div class="chart-legend">
                    <div class="legend-item">
                        <span class="legend-color" style="background: #3b82f6;"></span>
                        <span>Organic Traffic</span>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Metrics widget
     */
    private function renderMetricsWidget($settings) {
        $analytics = AAISEO_Analytics::getInstance();
        $dashboard_data = $analytics->getDashboardData();
        
        ob_start();
        ?>
        <div class="aaiseo-widget metrics-widget">
            <div class="widget-content">
                <div class="metrics-grid">
                    <div class="metric-item">
                        <span class="metric-value"><?php echo number_format($dashboard_data['metrics']['organic_traffic'] ?? 0); ?></span>
                        <span class="metric-label">Organic Traffic</span>
                    </div>
                    <div class="metric-item">
                        <span class="metric-value"><?php echo number_format($dashboard_data['metrics']['page_views'] ?? 0); ?></span>
                        <span class="metric-label">Page Views</span>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Keywords widget
     */
    private function renderKeywordsWidget($settings) {
        $limit = $settings['limit'] ?? 5;
        $analytics = AAISEO_Analytics::getInstance();
        $keywords = $analytics->getKeywordRankings();
        
        ob_start();
        ?>
        <div class="aaiseo-widget keywords-widget">
            <div class="widget-content">
                <?php if (!empty($keywords)): ?>
                    <div class="keywords-list">
                        <?php foreach (array_slice($keywords, 0, $limit) as $keyword): ?>
                            <div class="keyword-item">
                                <span class="keyword"><?php echo esc_html($keyword['keyword']); ?></span>
                                <span class="position">#<?php echo $keyword['current_position']; ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="no-keywords">No keyword data available</p>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Actions widget
     */
    private function renderActionsWidget($settings) {
        ob_start();
        ?>
        <div class="aaiseo-widget actions-widget">
            <div class="widget-content">
                <div class="actions-grid">
                    <button class="action-btn" data-action="run-optimization">
                        <span class="dashicons dashicons-performance"></span>
                        <span>Run Optimization</span>
                    </button>
                    <button class="action-btn" data-action="technical-audit">
                        <span class="dashicons dashicons-admin-tools"></span>
                        <span>Technical Audit</span>
                    </button>
                    <button class="action-btn" data-action="generate-content">
                        <span class="dashicons dashicons-edit"></span>
                        <span>Generate Content</span>
                    </button>
                    <button class="action-btn" data-action="export-report">
                        <span class="dashicons dashicons-download"></span>
                        <span>Export Report</span>
                    </button>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Competitors widget
     */
    private function renderCompetitorsWidget($settings) {
        $competitive = AAISEO_Competitive_Intelligence::getInstance();
        $competitor_data = $competitive->getCompetitorData();
        
        ob_start();
        ?>
        <div class="aaiseo-widget competitors-widget">
            <div class="widget-content">
                <?php if (!empty($competitor_data)): ?>
                    <div class="competitors-list">
                        <?php foreach (array_slice($competitor_data, 0, 3) as $competitor): ?>
                            <div class="competitor-item">
                                <span class="competitor-name"><?php echo esc_html($competitor['domain']); ?></span>
                                <span class="threat-level <?php echo strtolower($this->getRandomThreatLevel()); ?>">
                                    <?php echo $this->getRandomThreatLevel(); ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="no-competitors">No competitors being monitored</p>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Get random threat level for demo
     */
    private function getRandomThreatLevel() {
        $levels = array('High', 'Medium', 'Low');
        return $levels[array_rand($levels)];
    }
    
    /**
     * Render Web Vitals widget
     */
    private function renderWebVitalsWidget($settings) {
        ob_start();
        ?>
        <div class="aaiseo-widget web-vitals-widget">
            <div class="widget-content">
                <div class="vitals-grid">
                    <div class="vital-item">
                        <span class="vital-label">LCP</span>
                        <span class="vital-value good">2.1s</span>
                    </div>
                    <div class="vital-item">
                        <span class="vital-label">FID</span>
                        <span class="vital-value good">85ms</span>
                    </div>
                    <div class="vital-item">
                        <span class="vital-label">CLS</span>
                        <span class="vital-value warning">0.08</span>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Content Ideas widget
     */
    private function renderContentIdeasWidget($settings) {
        ob_start();
        ?>
        <div class="aaiseo-widget content-ideas-widget">
            <div class="widget-content">
                <div class="ideas-list">
                    <div class="idea-item">
                        <span class="idea-title">Voice Search Optimization Guide</span>
                        <span class="idea-priority high">High Priority</span>
                    </div>
                    <div class="idea-item">
                        <span class="idea-title">AI Content Marketing Trends</span>
                        <span class="idea-priority medium">Medium Priority</span>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render Technical Issues widget
     */
    private function renderTechnicalIssuesWidget($settings) {
        ob_start();
        ?>
        <div class="aaiseo-widget technical-issues-widget">
            <div class="widget-content">
                <div class="issues-summary">
                    <div class="issue-count high">3 High Priority</div>
                    <div class="issue-count medium">7 Medium Priority</div>
                    <div class="issue-count low">12 Low Priority</div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render custom widget
     */
    private function renderCustomWidget($widget_id, $widget_config) {
        ob_start();
        ?>
        <div class="aaiseo-widget custom-widget" data-widget-id="<?php echo esc_attr($widget_id); ?>">
            <div class="widget-content">
                <p>Custom widget: <?php echo esc_html($widget_config['title']); ?></p>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * AJAX handlers
     */
    public function saveDashboardLayoutAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $layout = json_decode(stripslashes($_POST['layout']), true);
        
        if ($this->saveDashboardLayout($layout)) {
            wp_send_json_success(__('Dashboard layout saved successfully', 'autonomous-ai-seo'));
        } else {
            wp_send_json_error(__('Failed to save dashboard layout', 'autonomous-ai-seo'));
        }
    }
    
    public function getDashboardLayoutAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $layout = $this->getDashboardLayout();
        wp_send_json_success($layout);
    }
    
    public function resetDashboardLayoutAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $user_id = get_current_user_id();
        delete_user_meta($user_id, 'aaiseo_dashboard_layout');
        
        wp_send_json_success(__('Dashboard layout reset to default', 'autonomous-ai-seo'));
    }
    
    public function addCustomWidgetAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $widget_config = json_decode(stripslashes($_POST['widget_config']), true);
        $widget_id = sanitize_text_field($_POST['widget_id']);
        
        // Add to user's custom widgets
        $user_id = get_current_user_id();
        $custom_widgets = get_user_meta($user_id, 'aaiseo_custom_widgets', true) ?: array();
        $custom_widgets[$widget_id] = $widget_config;
        
        update_user_meta($user_id, 'aaiseo_custom_widgets', $custom_widgets);
        
        wp_send_json_success(__('Custom widget added successfully', 'autonomous-ai-seo'));
    }
    
    public function removeCustomWidgetAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $widget_id = sanitize_text_field($_POST['widget_id']);
        
        // Remove from user's custom widgets
        $user_id = get_current_user_id();
        $custom_widgets = get_user_meta($user_id, 'aaiseo_custom_widgets', true) ?: array();
        
        if (isset($custom_widgets[$widget_id])) {
            unset($custom_widgets[$widget_id]);
            update_user_meta($user_id, 'aaiseo_custom_widgets', $custom_widgets);
        }
        
        wp_send_json_success(__('Custom widget removed successfully', 'autonomous-ai-seo'));
    }
}