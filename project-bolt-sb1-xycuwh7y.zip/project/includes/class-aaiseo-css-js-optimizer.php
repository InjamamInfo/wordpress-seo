<?php
/**
 * CSS and JavaScript Optimizer for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_CSS_JS_Optimizer {
    
    private static $instance = null;
    private $settings;
    private $cache_dir;
    private $cache_url;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->settings = get_option('aaiseo_settings', array());
        $upload_dir = wp_upload_dir();
        $this->cache_dir = $upload_dir['basedir'] . '/aaiseo-cache';
        $this->cache_url = $upload_dir['baseurl'] . '/aaiseo-cache';
        
        $this->initHooks();
        $this->ensureCacheDir();
    }
    
    private function initHooks() {
        // Only run if optimization is enabled
        if (empty($this->settings['css_js_optimization_enabled'])) {
            return;
        }
        
        // CSS optimization
        add_filter('style_loader_tag', array($this, 'optimizeStyleTag'), 10, 4);
        add_action('wp_head', array($this, 'injectCriticalCSS'), 1);
        
        // JavaScript optimization
        add_filter('script_loader_tag', array($this, 'optimizeScriptTag'), 10, 3);
        
        // Combined optimization
        add_action('wp_enqueue_scripts', array($this, 'optimizeEnqueuedAssets'), 999);
        
        // Admin hooks
        add_action('wp_ajax_aaiseo_generate_critical_css', array($this, 'generateCriticalCSSAjax'));
        add_action('wp_ajax_aaiseo_clear_asset_cache', array($this, 'clearAssetCacheAjax'));
    }
    
    /**
     * Ensure cache directory exists
     */
    private function ensureCacheDir() {
        if (!file_exists($this->cache_dir)) {
            wp_mkdir_p($this->cache_dir);
            
            // Create .htaccess to set proper caching headers
            $htaccess_content = "
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/css \"access plus 1 year\"
    ExpiresByType application/javascript \"access plus 1 year\"
</IfModule>

<IfModule mod_headers.c>
    <FilesMatch \"\.(css|js)$\">
        Header set Cache-Control \"public, max-age=31536000\"
    </FilesMatch>
</IfModule>
";
            file_put_contents($this->cache_dir . '/.htaccess', $htaccess_content);
        }
    }
    
    /**
     * Optimize style tag loading
     */
    public function optimizeStyleTag($tag, $handle, $href, $media) {
        // Skip optimization for admin or login pages
        if (is_admin() || $GLOBALS['pagenow'] === 'wp-login.php') {
            return $tag;
        }
        
        // Skip critical CSS (handled separately)
        if (strpos($handle, 'aaiseo-critical') !== false) {
            return $tag;
        }
        
        // Skip optimization for specific handles
        $excluded_handles = array('admin-bar', 'dashicons');
        if (in_array($handle, $excluded_handles)) {
            return $tag;
        }
        
        // Check if this is a critical stylesheet
        $critical_styles = $this->getCriticalStylesheets();
        if (in_array($handle, $critical_styles)) {
            // For critical styles, we'll inline them in injectCriticalCSS()
            return ''; // Don't output the tag
        }
        
        // For non-critical styles, add preload or defer
        if (!empty($this->settings['preload_css'])) {
            // Preload CSS
            $preload_tag = "<link rel='preload' href='$href' as='style' onload=\"this.onload=null;this.rel='stylesheet'\" id='$handle-css' media='$media'>\n";
            $preload_tag .= "<noscript><link rel='stylesheet' href='$href' id='$handle-css' media='$media'></noscript>\n";
            return $preload_tag;
        } else {
            // Add defer attribute using loadCSS polyfill
            $defer_tag = "<link rel='stylesheet' href='$href' id='$handle-css' media='print' onload=\"this.media='$media'\" />\n";
            $defer_tag .= "<noscript><link rel='stylesheet' href='$href' id='$handle-css' media='$media'></noscript>\n";
            return $defer_tag;
        }
    }
    
    /**
     * Inject critical CSS
     */
    public function injectCriticalCSS() {
        // Skip for admin or login pages
        if (is_admin() || $GLOBALS['pagenow'] === 'wp-login.php') {
            return;
        }
        
        $critical_css = $this->getCriticalCSS();
        
        if (!empty($critical_css)) {
            echo "<!-- AAISEO Critical CSS -->\n";
            echo "<style id='aaiseo-critical-css'>\n";
            echo $critical_css;
            echo "\n</style>\n";
        }
        
        // Add loadCSS polyfill if needed
        if (!empty($this->settings['preload_css'])) {
            echo "<!-- AAISEO CSS Loader -->\n";
            echo "<script id='aaiseo-cssloader'>\n";
            echo $this->getLoadCSSPolyfill();
            echo "\n</script>\n";
        }
    }
    
    /**
     * Get critical CSS for current page
     */
    private function getCriticalCSS() {
        $page_type = $this->getPageType();
        $critical_css_file = $this->cache_dir . '/critical-' . $page_type . '.css';
        
        if (file_exists($critical_css_file)) {
            return file_get_contents($critical_css_file);
        }
        
        // Fallback to generic critical CSS
        $generic_file = $this->cache_dir . '/critical-generic.css';
        if (file_exists($generic_file)) {
            return file_get_contents($generic_file);
        }
        
        // Default minimal critical CSS
        return "
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif; }
            a { color: #0073aa; text-decoration: none; }
            img { max-width: 100%; height: auto; }
        ";
    }
    
    /**
     * Get critical stylesheets that should be inlined
     */
    private function getCriticalStylesheets() {
        // These are the handles of stylesheets that should be considered critical
        return array(
            'wp-block-library', // Gutenberg blocks
            'aaiseo-critical-styles'
        );
    }
    
    /**
     * Get current page type
     */
    private function getPageType() {
        if (is_front_page()) {
            return 'home';
        } elseif (is_single()) {
            return 'single';
        } elseif (is_page()) {
            return 'page';
        } elseif (is_archive()) {
            return 'archive';
        } else {
            return 'generic';
        }
    }
    
    /**
     * Get loadCSS polyfill
     */
    private function getLoadCSSPolyfill() {
        return "
            /* loadCSS. [c]2017 Filament Group, Inc. MIT License */
            !function(e){var n=function(n,t,o){function i(e){return a.body?e():void setTimeout(function(){i(e)})}function r(){l.addEventListener&&l.removeEventListener('load',r),l.media=o||'all'}var d,a=e.document,l=a.createElement('link');if(t)d=t;else{var s=(a.body||a.getElementsByTagName('head')[0]).childNodes;d=s[s.length-1]}var f=a.styleSheets;l.rel='stylesheet',l.href=n,l.media='only x',i(function(){d.parentNode.insertBefore(l,t?d:d.nextSibling)});var u=function(e){for(var n=l.href,t=f.length;t--;)if(f[t].href===n)return e();setTimeout(function(){u(e)})};return l.addEventListener&&l.addEventListener('load',r),l.onloadcssdefined=u,u(r),l};'undefined'!=typeof exports?exports.loadCSS=n:e.loadCSS=n}('undefined'!=typeof global?global:this);
            /* onloadCSS. [c]2017 Filament Group, Inc. MIT License */
            function onloadCSS(n,t){function i(){!o&&t&&(o=!0,t.call(n))}var o;n.addEventListener&&n.addEventListener('load',i),n.attachEvent&&n.attachEvent('onload',i),'isApplicationInstalled'in navigator&&'onloadcssdefined'in n&&n.onloadcssdefined(i)}
        ";
    }
    
    /**
     * Optimize script tag loading
     */
    public function optimizeScriptTag($tag, $handle, $src) {
        // Skip optimization for admin or login pages
        if (is_admin() || $GLOBALS['pagenow'] === 'wp-login.php') {
            return $tag;
        }
        
        // Skip optimization for specific handles
        $excluded_handles = array('jquery', 'jquery-core', 'jquery-migrate', 'admin-bar');
        if (in_array($handle, $excluded_handles)) {
            return $tag;
        }
        
        // Check if this is a critical script
        $critical_scripts = $this->getCriticalScripts();
        if (in_array($handle, $critical_scripts)) {
            return $tag; // Keep critical scripts as is
        }
        
        // Add defer attribute to non-critical scripts
        if (strpos($tag, 'defer') === false && strpos($tag, 'async') === false) {
            $tag = str_replace(' src=', ' defer src=', $tag);
        }
        
        return $tag;
    }
    
    /**
     * Get critical scripts that should not be deferred
     */
    private function getCriticalScripts() {
        // These are the handles of scripts that should load normally
        return array(
            'aaiseo-critical-js'
        );
    }
    
    /**
     * Optimize enqueued assets by combining and minifying
     */
    public function optimizeEnqueuedAssets() {
        // Skip for admin or login pages
        if (is_admin() || $GLOBALS['pagenow'] === 'wp-login.php') {
            return;
        }
        
        // Check if asset combination is enabled
        if (empty($this->settings['combine_assets'])) {
            return;
        }
        
        global $wp_styles, $wp_scripts;
        
        // Combine CSS files
        if (!empty($wp_styles->queue)) {
            $this->combineCSS($wp_styles);
        }
        
        // Combine JavaScript files
        if (!empty($wp_scripts->queue)) {
            $this->combineJS($wp_scripts);
        }
    }
    
    /**
     * Combine CSS files
     */
    private function combineCSS($wp_styles) {
        $to_combine = array();
        $excluded_handles = array('admin-bar', 'dashicons');
        $critical_styles = $this->getCriticalStylesheets();
        
        // Group stylesheets for combination
        foreach ($wp_styles->queue as $handle) {
            // Skip excluded handles and critical styles
            if (in_array($handle, $excluded_handles) || in_array($handle, $critical_styles)) {
                continue;
            }
            
            $to_combine[] = $handle;
        }
        
        if (count($to_combine) < 2) {
            return; // No need to combine if there's only one stylesheet
        }
        
        // Generate a unique hash for this combination
        $handles_string = implode('-', $to_combine);
        $hash = md5($handles_string . $this->getStylesVersion($to_combine, $wp_styles));
        $combined_filename = 'combined-' . $hash . '.css';
        $combined_file_path = $this->cache_dir . '/' . $combined_filename;
        $combined_file_url = $this->cache_url . '/' . $combined_filename;
        
        // Check if combined file already exists
        if (!file_exists($combined_file_path)) {
            $combined_content = '';
            
            foreach ($to_combine as $handle) {
                $src = $wp_styles->registered[$handle]->src;
                
                // Convert relative URL to absolute
                if (strpos($src, '//') === 0) {
                    $src = 'https:' . $src;
                } elseif (strpos($src, '/') === 0) {
                    $src = site_url($src);
                }
                
                $css_content = $this->fetchRemoteContent($src);
                
                if ($css_content) {
                    // Fix relative URLs in CSS
                    $css_dir_url = dirname($src);
                    $css_content = $this->fixCSSRelativeUrls($css_content, $css_dir_url);
                    
                    // Minify if enabled
                    if (!empty($this->settings['minify_css'])) {
                        $css_content = $this->minifyCSS($css_content);
                    }
                    
                    $combined_content .= "/* {$handle} */\n" . $css_content . "\n\n";
                }
            }
            
            // Save combined file
            file_put_contents($combined_file_path, $combined_content);
        }
        
        // Deregister individual stylesheets and register combined one
        foreach ($to_combine as $handle) {
            wp_dequeue_style($handle);
        }
        
        wp_enqueue_style('aaiseo-combined-css', $combined_file_url, array(), null);
    }
    
    /**
     * Combine JavaScript files
     */
    private function combineJS($wp_scripts) {
        $to_combine = array();
        $excluded_handles = array('jquery', 'jquery-core', 'jquery-migrate', 'admin-bar');
        $critical_scripts = $this->getCriticalScripts();
        
        // Group scripts for combination
        foreach ($wp_scripts->queue as $handle) {
            // Skip excluded handles and critical scripts
            if (in_array($handle, $excluded_handles) || in_array($handle, $critical_scripts)) {
                continue;
            }
            
            $to_combine[] = $handle;
        }
        
        if (count($to_combine) < 2) {
            return; // No need to combine if there's only one script
        }
        
        // Generate a unique hash for this combination
        $handles_string = implode('-', $to_combine);
        $hash = md5($handles_string . $this->getScriptsVersion($to_combine, $wp_scripts));
        $combined_filename = 'combined-' . $hash . '.js';
        $combined_file_path = $this->cache_dir . '/' . $combined_filename;
        $combined_file_url = $this->cache_url . '/' . $combined_filename;
        
        // Check if combined file already exists
        if (!file_exists($combined_file_path)) {
            $combined_content = '';
            
            foreach ($to_combine as $handle) {
                $src = $wp_scripts->registered[$handle]->src;
                
                // Convert relative URL to absolute
                if (strpos($src, '//') === 0) {
                    $src = 'https:' . $src;
                } elseif (strpos($src, '/') === 0) {
                    $src = site_url($src);
                }
                
                $js_content = $this->fetchRemoteContent($src);
                
                if ($js_content) {
                    // Minify if enabled
                    if (!empty($this->settings['minify_js'])) {
                        $js_content = $this->minifyJS($js_content);
                    }
                    
                    $combined_content .= "/* {$handle} */\n" . $js_content . ";\n\n";
                }
            }
            
            // Save combined file
            file_put_contents($combined_file_path, $combined_content);
        }
        
        // Deregister individual scripts and register combined one
        foreach ($to_combine as $handle) {
            wp_dequeue_script($handle);
        }
        
        wp_enqueue_script('aaiseo-combined-js', $combined_file_url, array('jquery'), null, true);
    }
    
    /**
     * Get combined version string for styles
     */
    private function getStylesVersion($handles, $wp_styles) {
        $versions = array();
        
        foreach ($handles as $handle) {
            if (isset($wp_styles->registered[$handle])) {
                $versions[] = $handle . '-' . ($wp_styles->registered[$handle]->ver ?: '1.0');
            }
        }
        
        return implode('-', $versions);
    }
    
    /**
     * Get combined version string for scripts
     */
    private function getScriptsVersion($handles, $wp_scripts) {
        $versions = array();
        
        foreach ($handles as $handle) {
            if (isset($wp_scripts->registered[$handle])) {
                $versions[] = $handle . '-' . ($wp_scripts->registered[$handle]->ver ?: '1.0');
            }
        }
        
        return implode('-', $versions);
    }
    
    /**
     * Fix relative URLs in CSS
     */
    private function fixCSSRelativeUrls($css, $base_url) {
        // Find all url() references
        return preg_replace_callback(
            '/url\s*\(\s*[\'"]?([^\'")]+)[\'"]?\s*\)/i',
            function($matches) use ($base_url) {
                $url = $matches[1];
                
                // Skip data URIs and absolute URLs
                if (strpos($url, 'data:') === 0 || strpos($url, 'http') === 0 || strpos($url, '//') === 0) {
                    return $matches[0];
                }
                
                // Make URL absolute
                $absolute_url = $base_url . '/' . $url;
                
                return "url('{$absolute_url}')";
            },
            $css
        );
    }
    
    /**
     * Fetch remote content with caching
     */
    private function fetchRemoteContent($url) {
        $cache_key = 'aaiseo_asset_' . md5($url);
        $cached = get_transient($cache_key);
        
        if ($cached !== false) {
            return $cached;
        }
        
        $response = wp_remote_get($url);
        
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return '';
        }
        
        $content = wp_remote_retrieve_body($response);
        
        // Cache for 1 week
        set_transient($cache_key, $content, 7 * DAY_IN_SECONDS);
        
        return $content;
    }
    
    /**
     * Minify CSS
     */
    private function minifyCSS($css) {
        // Remove comments
        $css = preg_replace('!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $css);
        
        // Remove whitespace
        $css = preg_replace('/\s+/', ' ', $css);
        
        // Remove unnecessary spaces
        $css = str_replace(array(' {', '{ ', ' }', '} ', '( ', ' )', ': ', ' :', '; ', ' ;', ', ', ' ,'), array('{', '{', '}', '}', '(', ')', ':', ':', ';', ';', ',', ','), $css);
        
        return trim($css);
    }
    
    /**
     * Minify JavaScript
     */
    private function minifyJS($js) {
        // Basic minification - remove comments and whitespace
        $js = preg_replace('/((?:\/\*(?:[^*]|(?:\*+[^*\/]))*\*+\/)|(?:\/\/.*))/', '', $js);
        $js = preg_replace('/\s+/', ' ', $js);
        $js = str_replace(array('{ ', ' {', '} ', ' }', '( ', ' )', ': ', ' :', '; ', ' ;', ', ', ' ,'), array('{', '{', '}', '}', '(', ')', ':', ':', ';', ';', ',', ','), $js);
        
        return trim($js);
    }
    
    /**
     * Generate critical CSS for a page
     */
    public function generateCriticalCSS($url, $page_type = 'generic') {
        // This would typically use a headless browser or service
        // For now, we'll create a basic version with common elements
        
        $critical_css = "
            /* AAISEO Auto-generated Critical CSS */
            body, html { margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, 'Helvetica Neue', sans-serif; }
            header, .header, .site-header { display: block; width: 100%; }
            .main-navigation, nav, .nav, .menu { display: block; }
            h1, h2, h3 { margin-top: 0; }
            a { color: inherit; text-decoration: none; }
            .container, .content, main, article { display: block; }
            img { max-width: 100%; height: auto; }
            .entry-title, .post-title { font-weight: bold; }
            p { margin-bottom: 1em; }
        ";
        
        // Save to file
        $critical_file = $this->cache_dir . '/critical-' . $page_type . '.css';
        file_put_contents($critical_file, $critical_css);
        
        return true;
    }
    
    /**
     * Clear asset cache
     */
    public function clearAssetCache() {
        $files = glob($this->cache_dir . '/*');
        
        foreach ($files as $file) {
            if (is_file($file) && basename($file) !== '.htaccess') {
                unlink($file);
            }
        }
        
        // Clear transients
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '%_transient_aaiseo_asset_%'");
        
        return true;
    }
    
    /**
     * AJAX handlers
     */
    public function generateCriticalCSSAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $url = isset($_POST['url']) ? esc_url_raw($_POST['url']) : home_url();
        $page_type = isset($_POST['page_type']) ? sanitize_text_field($_POST['page_type']) : 'generic';
        
        if ($this->generateCriticalCSS($url, $page_type)) {
            wp_send_json_success(__('Critical CSS generated successfully', 'autonomous-ai-seo'));
        } else {
            wp_send_json_error(__('Failed to generate critical CSS', 'autonomous-ai-seo'));
        }
    }
    
    public function clearAssetCacheAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        if ($this->clearAssetCache()) {
            wp_send_json_success(__('Asset cache cleared successfully', 'autonomous-ai-seo'));
        } else {
            wp_send_json_error(__('Failed to clear asset cache', 'autonomous-ai-seo'));
        }
    }
}