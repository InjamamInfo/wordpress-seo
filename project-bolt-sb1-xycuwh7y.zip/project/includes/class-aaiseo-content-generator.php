<?php
/**
 * Advanced Content Generator for Autonomous AI SEO
 * 
 * Provides AI-powered content generation capabilities including complete articles,
 * brand voice training, and advanced optimization
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Content_Generator {
    
    private static $instance = null;
    private $ai_engine;
    private $settings;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->ai_engine = AAISEO_AI_Engine::getInstance();
        $this->settings = get_option('aaiseo_settings', array());
        $this->initHooks();
    }
    
    private function initHooks() {
        // Admin AJAX hooks
        add_action('wp_ajax_aaiseo_generate_article', array($this, 'generateArticleAjax'));
        add_action('wp_ajax_aaiseo_generate_product_description', array($this, 'generateProductDescriptionAjax'));
        add_action('wp_ajax_aaiseo_train_brand_voice', array($this, 'trainBrandVoiceAjax'));
        add_action('wp_ajax_aaiseo_check_content_quality', array($this, 'checkContentQualityAjax'));
        
        // Admin interface hooks
        add_action('admin_menu', array($this, 'addContentGeneratorMenu'));
        
        // Post editor integration
        add_action('add_meta_boxes', array($this, 'addContentGeneratorMetaBox'));
        
        // TinyMCE integration
        add_action('admin_init', array($this, 'initializeTinyMCEButtons'));
    }
    
    /**
     * Add Content Generator menu to admin
     */
    public function addContentGeneratorMenu() {
        add_submenu_page(
            'autonomous-ai-seo',
            __('Content Generator', 'autonomous-ai-seo'),
            __('Content Generator', 'autonomous-ai-seo'),
            'edit_posts',
            'aaiseo-content-generator',
            array($this, 'renderContentGeneratorPage')
        );
    }
    
    /**
     * Render Content Generator page
     */
    public function renderContentGeneratorPage() {
        include AAISEO_PLUGIN_PATH . 'templates/admin/content-generator.php';
    }
    
    /**
     * Add Content Generator meta box to post editor
     */
    public function addContentGeneratorMetaBox() {
        add_meta_box(
            'aaiseo_content_generator',
            __('AI Content Generator', 'autonomous-ai-seo'),
            array($this, 'renderContentGeneratorMetaBox'),
            array('post', 'page', 'product'),
            'side',
            'high'
        );
    }
    
    /**
     * Render Content Generator meta box
     */
    public function renderContentGeneratorMetaBox($post) {
        ?>
        <div class="aaiseo-content-generator-metabox">
            <p><?php _e('Use AI to enhance your content:', 'autonomous-ai-seo'); ?></p>
            
            <div class="aaiseo-generator-actions">
                <button type="button" class="button" id="aaiseo-expand-content">
                    <?php _e('Expand Content', 'autonomous-ai-seo'); ?>
                </button>
                
                <button type="button" class="button" id="aaiseo-improve-seo">
                    <?php _e('Improve SEO', 'autonomous-ai-seo'); ?>
                </button>
                
                <button type="button" class="button" id="aaiseo-generate-section">
                    <?php _e('Generate Section', 'autonomous-ai-seo'); ?>
                </button>
            </div>
            
            <div class="aaiseo-brand-voice">
                <label for="aaiseo-voice-style"><?php _e('Brand Voice:', 'autonomous-ai-seo'); ?></label>
                <select id="aaiseo-voice-style">
                    <option value="default"><?php _e('Default', 'autonomous-ai-seo'); ?></option>
                    <?php
                    $voices = $this->getStoredBrandVoices();
                    foreach ($voices as $key => $voice) {
                        echo '<option value="' . esc_attr($key) . '">' . esc_html($voice['name']) . '</option>';
                    }
                    ?>
                </select>
            </div>
        </div>
        
        <div id="aaiseo-section-modal" style="display: none;">
            <div class="aaiseo-modal-content">
                <h2><?php _e('Generate Content Section', 'autonomous-ai-seo'); ?></h2>
                
                <div class="aaiseo-form-group">
                    <label for="aaiseo-section-type"><?php _e('Section Type:', 'autonomous-ai-seo'); ?></label>
                    <select id="aaiseo-section-type">
                        <option value="introduction"><?php _e('Introduction', 'autonomous-ai-seo'); ?></option>
                        <option value="how_to"><?php _e('How-To Steps', 'autonomous-ai-seo'); ?></option>
                        <option value="benefits"><?php _e('Benefits/Features', 'autonomous-ai-seo'); ?></option>
                        <option value="faq"><?php _e('FAQ Section', 'autonomous-ai-seo'); ?></option>
                        <option value="conclusion"><?php _e('Conclusion', 'autonomous-ai-seo'); ?></option>
                    </select>
                </div>
                
                <div class="aaiseo-form-group">
                    <label for="aaiseo-section-topic"><?php _e('Topic/Focus:', 'autonomous-ai-seo'); ?></label>
                    <input type="text" id="aaiseo-section-topic" class="widefat" 
                           value="<?php echo esc_attr($post->post_title); ?>">
                </div>
                
                <div class="aaiseo-modal-actions">
                    <button type="button" class="button button-secondary" id="aaiseo-cancel-section">
                        <?php _e('Cancel', 'autonomous-ai-seo'); ?>
                    </button>
                    <button type="button" class="button button-primary" id="aaiseo-generate-section-content">
                        <?php _e('Generate', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Expand content button
            $('#aaiseo-expand-content').on('click', function() {
                const content = wp.data.select('core/editor').getEditedPostContent();
                if (!content) {
                    alert('<?php _e('Please add some content first to expand upon.', 'autonomous-ai-seo'); ?>');
                    return;
                }
                
                const button = $(this);
                const originalText = button.text();
                button.prop('disabled', true).text('<?php _e('Expanding...', 'autonomous-ai-seo'); ?>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'aaiseo_generate_article',
                        operation: 'expand',
                        content: content,
                        voice_style: $('#aaiseo-voice-style').val(),
                        nonce: '<?php echo wp_create_nonce('aaiseo_content_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success && response.data.content) {
                            // Insert expanded content
                            const blocks = wp.data.select('core/block-editor').getBlocks();
                            const lastBlock = blocks[blocks.length - 1];
                            
                            if (lastBlock) {
                                wp.data.dispatch('core/block-editor').insertBlocks(
                                    wp.blocks.parse(response.data.content),
                                    blocks.length
                                );
                            }
                            
                            // Show success message
                            wp.data.dispatch('core/notices').createSuccessNotice(
                                '<?php _e('Content expanded successfully!', 'autonomous-ai-seo'); ?>',
                                { type: 'snackbar' }
                            );
                        } else {
                            // Show error message
                            wp.data.dispatch('core/notices').createErrorNotice(
                                response.data.message || '<?php _e('Error expanding content.', 'autonomous-ai-seo'); ?>',
                                { type: 'snackbar' }
                            );
                        }
                    },
                    error: function() {
                        wp.data.dispatch('core/notices').createErrorNotice(
                            '<?php _e('Error communicating with the server.', 'autonomous-ai-seo'); ?>',
                            { type: 'snackbar' }
                        );
                    },
                    complete: function() {
                        button.prop('disabled', false).text(originalText);
                    }
                });
            });
            
            // Improve SEO button
            $('#aaiseo-improve-seo').on('click', function() {
                const content = wp.data.select('core/editor').getEditedPostContent();
                if (!content) {
                    alert('<?php _e('Please add some content first to improve.', 'autonomous-ai-seo'); ?>');
                    return;
                }
                
                const button = $(this);
                const originalText = button.text();
                button.prop('disabled', true).text('<?php _e('Optimizing...', 'autonomous-ai-seo'); ?>');
                
                // Get target keywords if available
                let targetKeywords = '';
                if (typeof aaiseo_keywords !== 'undefined' && aaiseo_keywords) {
                    targetKeywords = aaiseo_keywords;
                }
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'aaiseo_generate_article',
                        operation: 'improve_seo',
                        content: content,
                        keywords: targetKeywords,
                        voice_style: $('#aaiseo-voice-style').val(),
                        post_id: <?php echo $post->ID; ?>,
                        nonce: '<?php echo wp_create_nonce('aaiseo_content_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success && response.data.content) {
                            // Replace entire content
                            wp.data.dispatch('core/block-editor').resetBlocks(
                                wp.blocks.parse(response.data.content)
                            );
                            
                            // Show success message
                            wp.data.dispatch('core/notices').createSuccessNotice(
                                '<?php _e('Content optimized for SEO!', 'autonomous-ai-seo'); ?>',
                                { type: 'snackbar' }
                            );
                        } else {
                            // Show error message
                            wp.data.dispatch('core/notices').createErrorNotice(
                                response.data.message || '<?php _e('Error optimizing content.', 'autonomous-ai-seo'); ?>',
                                { type: 'snackbar' }
                            );
                        }
                    },
                    error: function() {
                        wp.data.dispatch('core/notices').createErrorNotice(
                            '<?php _e('Error communicating with the server.', 'autonomous-ai-seo'); ?>',
                            { type: 'snackbar' }
                        );
                    },
                    complete: function() {
                        button.prop('disabled', false).text(originalText);
                    }
                });
            });
            
            // Generate section button
            $('#aaiseo-generate-section').on('click', function() {
                $('#aaiseo-section-modal').show();
            });
            
            // Cancel section generation
            $('#aaiseo-cancel-section').on('click', function() {
                $('#aaiseo-section-modal').hide();
            });
            
            // Generate section content
            $('#aaiseo-generate-section-content').on('click', function() {
                const sectionType = $('#aaiseo-section-type').val();
                const sectionTopic = $('#aaiseo-section-topic').val();
                
                if (!sectionTopic) {
                    alert('<?php _e('Please enter a topic for the section.', 'autonomous-ai-seo'); ?>');
                    return;
                }
                
                const button = $(this);
                const originalText = button.text();
                button.prop('disabled', true).text('<?php _e('Generating...', 'autonomous-ai-seo'); ?>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'aaiseo_generate_article',
                        operation: 'generate_section',
                        section_type: sectionType,
                        section_topic: sectionTopic,
                        voice_style: $('#aaiseo-voice-style').val(),
                        post_id: <?php echo $post->ID; ?>,
                        nonce: '<?php echo wp_create_nonce('aaiseo_content_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success && response.data.content) {
                            // Insert section content at cursor position
                            const selection = wp.data.select('core/block-editor').getSelectedBlock();
                            const insertionPoint = selection ? 
                                wp.data.select('core/block-editor').getBlockIndex(selection.clientId) + 1 : 
                                wp.data.select('core/block-editor').getBlocks().length;
                                
                            wp.data.dispatch('core/block-editor').insertBlocks(
                                wp.blocks.parse(response.data.content),
                                insertionPoint
                            );
                            
                            // Show success message
                            wp.data.dispatch('core/notices').createSuccessNotice(
                                '<?php _e('Section generated successfully!', 'autonomous-ai-seo'); ?>',
                                { type: 'snackbar' }
                            );
                            
                            // Hide modal
                            $('#aaiseo-section-modal').hide();
                        } else {
                            // Show error message
                            wp.data.dispatch('core/notices').createErrorNotice(
                                response.data.message || '<?php _e('Error generating section.', 'autonomous-ai-seo'); ?>',
                                { type: 'snackbar' }
                            );
                        }
                    },
                    error: function() {
                        wp.data.dispatch('core/notices').createErrorNotice(
                            '<?php _e('Error communicating with the server.', 'autonomous-ai-seo'); ?>',
                            { type: 'snackbar' }
                        );
                    },
                    complete: function() {
                        button.prop('disabled', false).text(originalText);
                    }
                });
            });
            
            // Close modal when clicking outside
            $(window).on('click', function(event) {
                if ($(event.target).hasClass('aaiseo-section-modal')) {
                    $('#aaiseo-section-modal').hide();
                }
            });
        });
        </script>
        
        <style>
        .aaiseo-content-generator-metabox {
            margin-bottom: 15px;
        }
        
        .aaiseo-generator-actions {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-bottom: 15px;
        }
        
        .aaiseo-brand-voice {
            margin-top: 10px;
        }
        
        #aaiseo-section-modal {
            position: fixed;
            z-index: 100000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .aaiseo-modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
        }
        
        .aaiseo-form-group {
            margin-bottom: 15px;
        }
        
        .aaiseo-form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }
        
        .aaiseo-modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }
        </style>
        <?php
    }
    
    /**
     * Initialize TinyMCE buttons for classic editor
     */
    public function initializeTinyMCEButtons() {
        // Only continue if user has permissions
        if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {
            return;
        }
        
        // Check if WYSIWYG is enabled
        if (get_user_option('rich_editing') !== 'true') {
            return;
        }
        
        // Add filter to add our button
        add_filter('mce_buttons', array($this, 'registerTinyMCEButton'));
        
        // Add filter to add our plugin JS
        add_filter('mce_external_plugins', array($this, 'addTinyMCEPlugin'));
    }
    
    /**
     * Register TinyMCE button
     */
    public function registerTinyMCEButton($buttons) {
        array_push($buttons, 'aaiseo_content_generator');
        return $buttons;
    }
    
    /**
     * Add TinyMCE plugin JS
     */
    public function addTinyMCEPlugin($plugin_array) {
        $plugin_array['aaiseo_content_generator'] = AAISEO_PLUGIN_URL . 'assets/js/tinymce-content-generator.js';
        return $plugin_array;
    }
    
    /**
     * Generate article AJAX handler
     */
    public function generateArticleAjax() {
        check_ajax_referer('aaiseo_content_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(array('message' => __('You do not have permission to generate content.', 'autonomous-ai-seo')));
        }
        
        $operation = sanitize_text_field($_POST['operation']);
        $content = isset($_POST['content']) ? wp_kses_post($_POST['content']) : '';
        $voice_style = sanitize_text_field($_POST['voice_style']);
        
        switch ($operation) {
            case 'expand':
                $result = $this->expandContent($content, $voice_style);
                break;
                
            case 'improve_seo':
                $keywords = sanitize_text_field($_POST['keywords']);
                $post_id = intval($_POST['post_id']);
                $result = $this->improveSEO($content, $keywords, $post_id, $voice_style);
                break;
                
            case 'generate_section':
                $section_type = sanitize_text_field($_POST['section_type']);
                $section_topic = sanitize_text_field($_POST['section_topic']);
                $post_id = intval($_POST['post_id']);
                $result = $this->generateSection($section_type, $section_topic, $post_id, $voice_style);
                break;
                
            case 'generate_full':
                $title = sanitize_text_field($_POST['title']);
                $keywords = sanitize_text_field($_POST['keywords']);
                $length = intval($_POST['length']);
                $result = $this->generateFullArticle($title, $keywords, $length, $voice_style);
                break;
                
            default:
                wp_send_json_error(array('message' => __('Invalid operation.', 'autonomous-ai-seo')));
                break;
        }
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        } else {
            wp_send_json_success($result);
        }
    }
    
    /**
     * Expand existing content
     */
    private function expandContent($content, $voice_style = 'default') {
        if (empty($content)) {
            return new WP_Error('empty_content', __('Content cannot be empty.', 'autonomous-ai-seo'));
        }
        
        // Get voice parameters
        $voice_params = $this->getVoiceParameters($voice_style);
        
        $prompt = "Expand and enhance the following content with more details, examples, and depth. {$voice_params}

Content to expand:
{$content}

Please provide an expanded version that:
1. Maintains the original meaning and intent
2. Adds relevant details, examples, and explanations
3. Improves flow and readability
4. Is at least 50% longer than the original
5. Is formatted with proper HTML for WordPress (paragraphs, headings, etc.)
6. Uses Gutenberg block format for WordPress

Return only the expanded content in WordPress Gutenberg block format.";
        
        $response = $this->ai_engine->generateArticleContent($prompt);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        // Clean up the response to ensure valid Gutenberg blocks
        $content = $this->formatContentForGutenberg($response);
        
        return array('content' => $content);
    }
    
    /**
     * Improve content for SEO
     */
    private function improveSEO($content, $keywords, $post_id, $voice_style = 'default') {
        if (empty($content)) {
            return new WP_Error('empty_content', __('Content cannot be empty.', 'autonomous-ai-seo'));
        }
        
        // Get target keywords if not provided
        if (empty($keywords)) {
            $keywords = get_post_meta($post_id, '_aaiseo_target_keywords', true);
        }
        
        // Get voice parameters
        $voice_params = $this->getVoiceParameters($voice_style);
        
        // Get post information
        $post = get_post($post_id);
        $title = $post ? $post->post_title : '';
        
        $prompt = "Optimize the following content for search engines while maintaining readability and user engagement. {$voice_params}

Post Title: {$title}
Target Keywords: {$keywords}

Original Content:
{$content}

Please optimize this content by:
1. Improving the heading structure (H2, H3, H4) for better hierarchy and keyword usage
2. Naturally incorporating target keywords at appropriate density
3. Enhancing readability with short paragraphs and transition words
4. Adding appropriate internal linking suggestions in [LINK:page-slug] format
5. Improving the introduction and conclusion
6. Adding a compelling call-to-action
7. Using semantic LSI keywords and related terms
8. Formatting with proper HTML for WordPress (paragraphs, headings, lists)
9. Using Gutenberg block format

Return the optimized content in WordPress Gutenberg block format.";
        
        $response = $this->ai_engine->generateArticleContent($prompt);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        // Clean up the response to ensure valid Gutenberg blocks
        $content = $this->formatContentForGutenberg($response);
        
        // Process internal linking suggestions
        $content = $this->processInternalLinkingSuggestions($content, $post_id);
        
        return array('content' => $content);
    }
    
    /**
     * Generate a specific section
     */
    private function generateSection($section_type, $section_topic, $post_id, $voice_style = 'default') {
        // Get voice parameters
        $voice_params = $this->getVoiceParameters($voice_style);
        
        // Get post information
        $post = get_post($post_id);
        $title = $post ? $post->post_title : $section_topic;
        
        // Define section-specific instructions
        $section_instructions = '';
        
        switch ($section_type) {
            case 'introduction':
                $section_instructions = "Create an engaging introduction for an article about \"{$section_topic}\". The introduction should:
1. Hook the reader with an interesting fact, question, or statement
2. Explain why the topic matters and what the reader will gain
3. Briefly outline what will be covered
4. Include at least one target keyword naturally
5. Be 3-5 paragraphs long";
                break;
                
            case 'how_to':
                $section_instructions = "Create a detailed how-to section about \"{$section_topic}\". The how-to section should:
1. Start with a brief introduction to the process
2. Include 5-7 clear steps with descriptive headings
3. Provide detailed instructions for each step
4. Include tips or warnings where appropriate
5. Use ordered lists for the steps
6. Include a concluding paragraph";
                break;
                
            case 'benefits':
                $section_instructions = "Create a benefits/features section about \"{$section_topic}\". The section should:
1. Start with a brief introduction to the features/benefits
2. Include 4-6 distinct benefits with descriptive subheadings
3. Explain each benefit clearly with examples or evidence
4. Use unordered lists where appropriate
5. Include a concluding paragraph that summarizes the value";
                break;
                
            case 'faq':
                $section_instructions = "Create a comprehensive FAQ section about \"{$section_topic}\". The FAQ section should:
1. Include 5-7 common questions with detailed answers
2. Start with basic questions and progress to more complex ones
3. Cover objections or concerns potential customers might have
4. Use proper HTML formatting for questions and answers
5. Include a brief introduction and conclusion for the FAQ section";
                break;
                
            case 'conclusion':
                $section_instructions = "Create a compelling conclusion for an article about \"{$section_topic}\". The conclusion should:
1. Summarize the key points covered in the article
2. Reinforce the main value proposition or lesson
3. Include a strong call-to-action
4. Leave the reader with a memorable final thought
5. Be 2-4 paragraphs long";
                break;
                
            default:
                $section_instructions = "Create a well-structured section about \"{$section_topic}\".";
                break;
        }
        
        $prompt = "Generate a high-quality content section for a WordPress article. {$voice_params}

Article Title: {$title}
Section Type: " . ucwords(str_replace('_', ' ', $section_type)) . "
Section Topic: {$section_topic}

Instructions:
{$section_instructions}

Return only the generated section content in WordPress Gutenberg block format.";
        
        $response = $this->ai_engine->generateArticleContent($prompt);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        // Clean up the response to ensure valid Gutenberg blocks
        $content = $this->formatContentForGutenberg($response);
        
        return array('content' => $content);
    }
    
    /**
     * Generate a full article
     */
    public function generateFullArticle($title, $keywords = '', $word_count = 1500, $voice_style = 'default') {
        if (empty($title)) {
            return new WP_Error('empty_title', __('Title cannot be empty.', 'autonomous-ai-seo'));
        }
        
        // Get voice parameters
        $voice_params = $this->getVoiceParameters($voice_style);
        
        // Default structure for article
        $structure = array(
            'introduction' => 'An engaging introduction that hooks the reader',
            'what_is' => 'Explanation of what ' . $title . ' is',
            'benefits' => 'The key benefits or advantages',
            'how_to' => 'Step-by-step guide or process',
            'examples' => 'Practical examples or case studies',
            'faq' => 'Frequently asked questions',
            'conclusion' => 'Conclusion with call-to-action'
        );
        
        // Adjust structure based on title
        if (strpos(strtolower($title), 'how') === 0) {
            // Likely a how-to article
            $structure = array(
                'introduction' => 'An engaging introduction that establishes the problem',
                'materials' => 'Required materials or prerequisites',
                'step_1' => 'First step in the process',
                'step_2' => 'Second step in the process',
                'step_3' => 'Third step in the process',
                'step_4' => 'Fourth step in the process',
                'step_5' => 'Fifth step in the process',
                'tips' => 'Tips for success and common mistakes to avoid',
                'conclusion' => 'Conclusion with benefits of completing the process'
            );
        } elseif (strpos(strtolower($title), 'vs') !== false || strpos(strtolower($title), 'versus') !== false) {
            // Likely a comparison article
            $structure = array(
                'introduction' => 'Introduction to the comparison',
                'overview' => 'Brief overview of both options',
                'key_differences' => 'Key differences highlighted',
                'feature_comparison' => 'Detailed feature-by-feature comparison',
                'pros_cons' => 'Pros and cons of each option',
                'use_cases' => 'Best use cases for each option',
                'conclusion' => 'Conclusion with recommendation'
            );
        } elseif (preg_match('/\b(\d+|\d+ best)\b/i', strtolower($title))) {
            // Likely a list-type article
            $structure = array(
                'introduction' => 'Introduction explaining the criteria for the list',
                'item_1' => 'First item in the list',
                'item_2' => 'Second item in the list',
                'item_3' => 'Third item in the list',
                'item_4' => 'Fourth item in the list',
                'item_5' => 'Fifth item in the list',
                'how_to_choose' => 'Guidelines for choosing between options',
                'conclusion' => 'Conclusion with final recommendations'
            );
        }
        
        // Create structure string
        $structure_string = '';
        foreach ($structure as $heading => $description) {
            $structure_string .= "- " . ucwords(str_replace('_', ' ', $heading)) . ": " . $description . "\n";
        }
        
        $prompt = "Generate a comprehensive, engaging article on the topic \"{$title}\". {$voice_params}

Article Title: {$title}
Target Keywords: {$keywords}
Target Length: approximately {$word_count} words

Article Structure:
{$structure_string}

Please create a high-quality, well-researched article that:
1. Is engaging and valuable to readers
2. Naturally incorporates target keywords without keyword stuffing
3. Uses proper heading structure (H2, H3, H4)
4. Includes relevant examples, statistics, or case studies
5. Follows the outlined structure but adapts as needed for flow
6. Is properly formatted with appropriate paragraphs, lists, and emphasis
7. Follows SEO best practices for content
8. Uses a professional, authoritative tone
9. Avoids fluff content and focuses on value
10. Is formatted in WordPress Gutenberg block format

Return only the generated article content in WordPress Gutenberg block format.";
        
        $response = $this->ai_engine->generateArticleContent($prompt);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        // Clean up the response to ensure valid Gutenberg blocks
        $content = $this->formatContentForGutenberg($response);
        
        return array(
            'content' => $content,
            'word_count' => str_word_count(strip_tags($content)),
            'title' => $title
        );
    }
    
    /**
     * Generate product description
     */
    public function generateProductDescription($product_name, $features = '', $target_audience = '', $voice_style = 'default') {
        if (empty($product_name)) {
            return new WP_Error('empty_product', __('Product name cannot be empty.', 'autonomous-ai-seo'));
        }
        
        // Get voice parameters
        $voice_params = $this->getVoiceParameters($voice_style);
        
        $prompt = "Generate a compelling product description for an e-commerce store. {$voice_params}

Product Name: {$product_name}
Key Features: {$features}
Target Audience: {$target_audience}

Create a product description that:
1. Starts with an attention-grabbing headline or introduction
2. Highlights the key features and benefits
3. Explains why the product is valuable to the target audience
4. Uses persuasive language without being overly sales-focused
5. Includes relevant technical specifications where appropriate
6. Is optimized for both conversion and SEO
7. Ends with a strong call-to-action
8. Is between 200-400 words
9. Is formatted in WordPress Gutenberg block format

Return only the generated product description in WordPress Gutenberg block format.";
        
        $response = $this->ai_engine->generateArticleContent($prompt);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        // Clean up the response to ensure valid Gutenberg blocks
        $content = $this->formatContentForGutenberg($response);
        
        return array(
            'content' => $content,
            'word_count' => str_word_count(strip_tags($content))
        );
    }
    
    /**
     * Format content for Gutenberg
     */
    private function formatContentForGutenberg($content) {
        // Remove any pre-existing block delimiters
        $content = preg_replace('/<!-- \/?wp:.*? -->/i', '', $content);
        
        // Split content into paragraphs
        $paragraphs = preg_split('/\n\s*\n/', $content);
        
        $formatted = '';
        
        foreach ($paragraphs as $paragraph) {
            $paragraph = trim($paragraph);
            if (empty($paragraph)) continue;
            
            // Check if it's a heading
            if (preg_match('/^(#{1,6})\s+(.*)$/m', $paragraph, $matches)) {
                $heading_level = strlen($matches[1]);
                $heading_text = $matches[2];
                $formatted .= "<!-- wp:heading {\"level\":{$heading_level}} -->\n";
                $formatted .= "<h{$heading_level}>{$heading_text}</h{$heading_level}>\n";
                $formatted .= "<!-- /wp:heading -->\n\n";
            } 
            // Check if it's an ordered list
            else if (preg_match('/^\d+\.\s+/m', $paragraph)) {
                $items = preg_split('/\n/', $paragraph);
                $formatted .= "<!-- wp:list {\"ordered\":true} -->\n<ol>";
                
                foreach ($items as $item) {
                    if (preg_match('/^\d+\.\s+(.*)$/m', $item, $matches)) {
                        $formatted .= "\n\t<li>{$matches[1]}</li>";
                    }
                }
                
                $formatted .= "\n</ol>\n<!-- /wp:list -->\n\n";
            }
            // Check if it's an unordered list
            else if (preg_match('/^[*\-•]\s+/m', $paragraph)) {
                $items = preg_split('/\n/', $paragraph);
                $formatted .= "<!-- wp:list -->\n<ul>";
                
                foreach ($items as $item) {
                    if (preg_match('/^[*\-•]\s+(.*)$/m', $item, $matches)) {
                        $formatted .= "\n\t<li>{$matches[1]}</li>";
                    }
                }
                
                $formatted .= "\n</ul>\n<!-- /wp:list -->\n\n";
            }
            // Regular paragraph
            else {
                $formatted .= "<!-- wp:paragraph -->\n";
                $formatted .= "<p>{$paragraph}</p>\n";
                $formatted .= "<!-- /wp:paragraph -->\n\n";
            }
        }
        
        return trim($formatted);
    }
    
    /**
     * Process internal linking suggestions
     */
    private function processInternalLinkingSuggestions($content, $post_id) {
        // Find all [LINK:slug] instances
        preg_match_all('/\[LINK:(.*?)\]/', $content, $matches);
        
        if (empty($matches[1])) {
            return $content;
        }
        
        foreach ($matches[1] as $index => $slug) {
            $linked_post_id = $this->getPostIdFromSlug($slug);
            
            if ($linked_post_id && $linked_post_id != $post_id) {
                $post_url = get_permalink($linked_post_id);
                $post_title = get_the_title($linked_post_id);
                
                if ($post_url && $post_title) {
                    $content = str_replace(
                        $matches[0][$index],
                        '<a href="' . esc_url($post_url) . '">' . esc_html($post_title) . '</a>',
                        $content
                    );
                }
            } else {
                // Remove the suggestion if post not found
                $content = str_replace($matches[0][$index], '', $content);
            }
        }
        
        return $content;
    }
    
    /**
     * Get post ID from slug
     */
    private function getPostIdFromSlug($slug) {
        $args = array(
            'name' => $slug,
            'post_type' => array('post', 'page'),
            'post_status' => 'publish',
            'numberposts' => 1
        );
        
        $posts = get_posts($args);
        
        if (!empty($posts)) {
            return $posts[0]->ID;
        }
        
        return null;
    }
    
    /**
     * Get voice parameters from stored brand voice
     */
    private function getVoiceParameters($voice_style) {
        if ($voice_style === 'default') {
            return '';
        }
        
        $voices = $this->getStoredBrandVoices();
        
        if (isset($voices[$voice_style])) {
            $voice = $voices[$voice_style];
            
            return "Use the following brand voice: 
Tone: {$voice['tone']}
Style: {$voice['style']}
Writing Level: {$voice['writing_level']}
Example: {$voice['example']}";
        }
        
        return '';
    }
    
    /**
     * Get stored brand voices
     */
    private function getStoredBrandVoices() {
        $voices = get_option('aaiseo_brand_voices', array());
        
        // Add default voices if none exist
        if (empty($voices)) {
            $voices = array(
                'professional' => array(
                    'name' => __('Professional', 'autonomous-ai-seo'),
                    'tone' => 'Professional, authoritative',
                    'style' => 'Formal, educational',
                    'writing_level' => 'Advanced',
                    'example' => 'This comprehensive guide provides industry-leading insights into effective strategic planning methodologies.'
                ),
                'conversational' => array(
                    'name' => __('Conversational', 'autonomous-ai-seo'),
                    'tone' => 'Friendly, approachable',
                    'style' => 'Informal, conversational',
                    'writing_level' => 'Intermediate',
                    'example' => 'Ready to get started? Great! Let\'s walk through this together so you can see just how easy it is.'
                ),
                'technical' => array(
                    'name' => __('Technical', 'autonomous-ai-seo'),
                    'tone' => 'Technical, precise',
                    'style' => 'Detailed, data-driven',
                    'writing_level' => 'Advanced',
                    'example' => 'The implementation utilizes advanced algorithms to optimize computational efficiency and minimize resource allocation.'
                )
            );
            
            update_option('aaiseo_brand_voices', $voices);
        }
        
        return $voices;
    }
    
    /**
     * Train brand voice
     */
    public function trainBrandVoiceAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $voice_name = sanitize_text_field($_POST['voice_name']);
        $example_content = wp_kses_post($_POST['example_content']);
        
        if (empty($voice_name) || empty($example_content)) {
            wp_send_json_error(__('Voice name and example content are required.', 'autonomous-ai-seo'));
        }
        
        // Analyze the content to extract voice characteristics
        $voice_analysis = $this->analyzeContentVoice($example_content);
        
        if (is_wp_error($voice_analysis)) {
            wp_send_json_error($voice_analysis->get_error_message());
        }
        
        // Save the brand voice
        $voices = get_option('aaiseo_brand_voices', array());
        
        $voice_id = sanitize_title($voice_name);
        
        $voices[$voice_id] = array(
            'name' => $voice_name,
            'tone' => $voice_analysis['tone'],
            'style' => $voice_analysis['style'],
            'writing_level' => $voice_analysis['writing_level'],
            'example' => wp_trim_words($example_content, 30)
        );
        
        update_option('aaiseo_brand_voices', $voices);
        
        wp_send_json_success(array(
            'message' => __('Brand voice trained successfully.', 'autonomous-ai-seo'),
            'voice' => $voices[$voice_id]
        ));
    }
    
    /**
     * Analyze content to extract voice characteristics
     */
    private function analyzeContentVoice($content) {
        $prompt = "Analyze the following content and identify its brand voice characteristics:

Content:
{$content}

Please identify:
1. Tone (e.g., formal, casual, authoritative, friendly)
2. Style (e.g., conversational, technical, educational, persuasive)
3. Writing level (e.g., basic, intermediate, advanced)

Return the analysis in JSON format with 'tone', 'style', and 'writing_level' properties.";
        
        $response = $this->ai_engine->analyzeContent($prompt);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        // Parse the response
        $response_data = json_decode($response, true);
        
        if (!$response_data || !isset($response_data['tone']) || !isset($response_data['style']) || !isset($response_data['writing_level'])) {
            return new WP_Error('invalid_response', __('Failed to analyze content voice.', 'autonomous-ai-seo'));
        }
        
        return $response_data;
    }
    
    /**
     * Check content quality
     */
    public function checkContentQualityAjax() {
        check_ajax_referer('aaiseo_content_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(array('message' => __('You do not have permission to check content quality.', 'autonomous-ai-seo')));
        }
        
        $content = wp_kses_post($_POST['content']);
        
        if (empty($content)) {
            wp_send_json_error(array('message' => __('Content cannot be empty.', 'autonomous-ai-seo')));
        }
        
        // Check content quality
        $quality_check = $this->checkContentQuality($content);
        
        if (is_wp_error($quality_check)) {
            wp_send_json_error(array('message' => $quality_check->get_error_message()));
        }
        
        wp_send_json_success($quality_check);
    }
    
    /**
     * Check content quality
     */
    public function checkContentQuality($content) {
        $prompt = "Analyze the following content for quality, readability, and SEO value:

Content:
{$content}

Please provide a comprehensive analysis including:
1. Overall quality score (0-100)
2. Readability score (0-100)
3. SEO score (0-100)
4. Content strengths (list at least 3)
5. Areas for improvement (list at least 3)
6. Estimated reading time in minutes
7. Keyword analysis (identify potential keywords)
8. Recommendations for improvement

Return the analysis in JSON format.";
        
        $response = $this->ai_engine->analyzeContent($prompt);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        // Parse the response
        $response_data = json_decode($response, true);
        
        if (!$response_data) {
            return new WP_Error('invalid_response', __('Failed to analyze content quality.', 'autonomous-ai-seo'));
        }
        
        return $response_data;
    }
    
    /**
     * Generate product description AJAX handler
     */
    public function generateProductDescriptionAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $product_name = sanitize_text_field($_POST['product_name']);
        $features = sanitize_textarea_field($_POST['features']);
        $target_audience = sanitize_text_field($_POST['target_audience']);
        $voice_style = sanitize_text_field($_POST['voice_style']);
        
        $result = $this->generateProductDescription($product_name, $features, $target_audience, $voice_style);
        
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        } else {
            wp_send_json_success($result);
        }
    }
}