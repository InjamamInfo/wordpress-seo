<?php
/**
 * Technical SEO handler for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Technical_SEO {
    
    private static $instance = null;
    private $database;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->database = AAISEO_Database::getInstance();
        $this->initHooks();
    }
    
    private function initHooks() {
        add_action('init', array($this, 'setupTechnicalSEO'));
        add_action('wp_ajax_aaiseo_run_technical_audit', array($this, 'runTechnicalAuditAjax'));
        add_action('template_redirect', array($this, 'handleRedirects'));
        add_action('wp_head', array($this, 'addTechnicalTags'), 1);
        add_filter('robots_txt', array($this, 'optimizeRobotsTxt'), 10, 2);
    }
    
    /**
     * Setup technical SEO optimizations
     */
    public function setupTechnicalSEO() {
        // Generate and manage sitemaps
        $this->manageSitemaps();
        
        // Handle canonical URLs
        add_action('wp_head', array($this, 'addCanonicalTags'));
        
        // Optimize images
        add_filter('wp_handle_upload_prefilter', array($this, 'optimizeImageOnUpload'));
        
        // Add structured data
        add_action('wp_footer', array($this, 'addStructuredData'));
    }
    
    /**
     * Run comprehensive technical audit
     */
    public function runTechnicalAudit() {
        $audit_results = array();
        
        // Check for common technical issues
        $audit_results['crawling'] = $this->auditCrawlingIssues();
        $audit_results['indexing'] = $this->auditIndexingIssues();
        $audit_results['performance'] = $this->auditPerformanceIssues();
        $audit_results['structure'] = $this->auditSiteStructure();
        $audit_results['meta'] = $this->auditMetaTags();
        
        // Store audit results
        $this->storeAuditResults($audit_results);
        
        // Auto-fix simple issues
        $this->autoFixIssues($audit_results);
        
        return $audit_results;
    }
    
    /**
     * Audit crawling issues
     */
    private function auditCrawlingIssues() {
        $issues = array();
        
        // Check robots.txt
        $robots_url = home_url('/robots.txt');
        $robots_response = wp_remote_get($robots_url);
        
        if (is_wp_error($robots_response) || wp_remote_retrieve_response_code($robots_response) !== 200) {
            $issues[] = array(
                'type' => 'robots_txt_missing',
                'severity' => 'medium',
                'description' => __('Robots.txt file is missing or inaccessible', 'autonomous-ai-seo'),
                'recommendation' => __('Create a proper robots.txt file', 'autonomous-ai-seo')
            );
        } else {
            $robots_content = wp_remote_retrieve_body($robots_response);
            if (strpos($robots_content, 'Disallow: /') !== false) {
                $issues[] = array(
                    'type' => 'robots_blocking_all',
                    'severity' => 'high',
                    'description' => __('Robots.txt is blocking all crawlers', 'autonomous-ai-seo'),
                    'recommendation' => __('Review and update robots.txt to allow proper crawling', 'autonomous-ai-seo')
                );
            }
        }
        
        // Check for XML sitemap
        $sitemap_url = home_url('/sitemap.xml');
        $sitemap_response = wp_remote_get($sitemap_url);
        
        if (is_wp_error($sitemap_response) || wp_remote_retrieve_response_code($sitemap_response) !== 200) {
            $issues[] = array(
                'type' => 'sitemap_missing',
                'severity' => 'high',
                'description' => __('XML sitemap is missing', 'autonomous-ai-seo'),
                'recommendation' => __('Generate and submit XML sitemap', 'autonomous-ai-seo')
            );
        }
        
        return $issues;
    }
    
    /**
     * Audit indexing issues
     */
    private function auditIndexingIssues() {
        $issues = array();
        
        // Check for noindex tags on important pages
        $important_pages = array(
            home_url() => 'Homepage',
            get_permalink(get_option('page_for_posts')) => 'Blog page'
        );
        
        foreach ($important_pages as $url => $page_name) {
            if (!$url) continue;
            
            $response = wp_remote_get($url);
            if (!is_wp_error($response)) {
                $content = wp_remote_retrieve_body($response);
                if (preg_match('/<meta[^>]*name=[\'"]robots[\'"][^>]*content=[\'"][^\'\"]*noindex[^\'\"]*[\'"][^>]*>/i', $content)) {
                    $issues[] = array(
                        'type' => 'noindex_important_page',
                        'severity' => 'high',
                        'description' => sprintf(__('%s has noindex meta tag', 'autonomous-ai-seo'), $page_name),
                        'recommendation' => __('Remove noindex tag from important pages', 'autonomous-ai-seo'),
                        'url' => $url
                    );
                }
            }
        }
        
        // Check for duplicate content
        $this->checkDuplicateContent($issues);
        
        return $issues;
    }
    
    /**
     * Check for duplicate content issues
     */
    private function checkDuplicateContent(&$issues) {
        global $wpdb;
        
        // Find posts with identical titles
        $duplicate_titles = $wpdb->get_results(
            "SELECT post_title, COUNT(*) as count 
            FROM {$wpdb->posts} 
            WHERE post_status = 'publish' 
            AND post_type IN ('post', 'page') 
            GROUP BY post_title 
            HAVING count > 1",
            ARRAY_A
        );
        
        if (!empty($duplicate_titles)) {
            $issues[] = array(
                'type' => 'duplicate_titles',
                'severity' => 'medium',
                'description' => sprintf(__('%d posts have duplicate titles', 'autonomous-ai-seo'), count($duplicate_titles)),
                'recommendation' => __('Review and update duplicate titles', 'autonomous-ai-seo'),
                'data' => $duplicate_titles
            );
        }
        
        // Find posts with identical meta descriptions (if using meta fields)
        $duplicate_meta = $wpdb->get_results(
            "SELECT meta_value, COUNT(*) as count 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = '_aaiseo_meta_description' 
            AND meta_value != '' 
            GROUP BY meta_value 
            HAVING count > 1",
            ARRAY_A
        );
        
        if (!empty($duplicate_meta)) {
            $issues[] = array(
                'type' => 'duplicate_meta_descriptions',
                'severity' => 'medium',
                'description' => sprintf(__('%d posts have duplicate meta descriptions', 'autonomous-ai-seo'), count($duplicate_meta)),
                'recommendation' => __('Create unique meta descriptions for each page', 'autonomous-ai-seo'),
                'data' => $duplicate_meta
            );
        }
    }
    
    /**
     * Audit performance issues
     */
    private function auditPerformanceIssues() {
        $issues = array();
        
        // Check image optimization
        $large_images = $this->findLargeImages();
        if (!empty($large_images)) {
            $issues[] = array(
                'type' => 'large_images',
                'severity' => 'medium',
                'description' => sprintf(__('%d images are larger than 1MB', 'autonomous-ai-seo'), count($large_images)),
                'recommendation' => __('Optimize large images to improve page speed', 'autonomous-ai-seo'),
                'data' => $large_images
            );
        }
        
        // Check for missing alt text
        $images_without_alt = $this->findImagesWithoutAlt();
        if (!empty($images_without_alt)) {
            $issues[] = array(
                'type' => 'missing_alt_text',
                'severity' => 'medium',
                'description' => sprintf(__('%d images are missing alt text', 'autonomous-ai-seo'), count($images_without_alt)),
                'recommendation' => __('Add descriptive alt text to all images', 'autonomous-ai-seo'),
                'data' => $images_without_alt
            );
        }
        
        return $issues;
    }
    
    /**
     * Find large images
     */
    private function findLargeImages() {
        global $wpdb;
        
        $large_images = $wpdb->get_results(
            "SELECT p.ID, p.post_title, pm.meta_value as file_path
            FROM {$wpdb->posts} p
            JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE p.post_type = 'attachment'
            AND p.post_mime_type LIKE 'image/%'
            AND pm.meta_key = '_wp_attached_file'",
            ARRAY_A
        );
        
        $large_files = array();
        
        foreach ($large_images as $image) {
            $file_path = wp_get_upload_dir()['basedir'] . '/' . $image['file_path'];
            if (file_exists($file_path) && filesize($file_path) > 1048576) { // 1MB
                $large_files[] = array(
                    'id' => $image['ID'],
                    'title' => $image['post_title'],
                    'size' => size_format(filesize($file_path))
                );
            }
        }
        
        return $large_files;
    }
    
    /**
     * Find images without alt text
     */
    private function findImagesWithoutAlt() {
        global $wpdb;
        
        return $wpdb->get_results(
            "SELECT p.ID, p.post_title
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_wp_attachment_image_alt'
            WHERE p.post_type = 'attachment'
            AND p.post_mime_type LIKE 'image/%'
            AND (pm.meta_value IS NULL OR pm.meta_value = '')",
            ARRAY_A
        );
    }
    
    /**
     * Audit site structure
     */
    private function auditSiteStructure() {
        $issues = array();
        
        // Check for orphaned pages
        $orphaned_pages = $this->findOrphanedPages();
        if (!empty($orphaned_pages)) {
            $issues[] = array(
                'type' => 'orphaned_pages',
                'severity' => 'medium',
                'description' => sprintf(__('%d pages have no internal links pointing to them', 'autonomous-ai-seo'), count($orphaned_pages)),
                'recommendation' => __('Add internal links to orphaned pages', 'autonomous-ai-seo'),
                'data' => $orphaned_pages
            );
        }
        
        // Check URL structure
        $long_urls = $this->findLongUrls();
        if (!empty($long_urls)) {
            $issues[] = array(
                'type' => 'long_urls',
                'severity' => 'low',
                'description' => sprintf(__('%d pages have URLs longer than 75 characters', 'autonomous-ai-seo'), count($long_urls)),
                'recommendation' => __('Consider shortening long URLs for better SEO', 'autonomous-ai-seo'),
                'data' => $long_urls
            );
        }
        
        return $issues;
    }
    
    /**
     * Find orphaned pages
     */
    private function findOrphanedPages() {
        global $wpdb;
        
        // This is a simplified check - in reality, you'd analyze actual internal links
        return $wpdb->get_results(
            "SELECT ID, post_title, post_name
            FROM {$wpdb->posts}
            WHERE post_status = 'publish'
            AND post_type = 'page'
            AND post_parent = 0
            AND ID NOT IN (SELECT DISTINCT object_id FROM {$wpdb->term_relationships})",
            ARRAY_A
        );
    }
    
    /**
     * Find long URLs
     */
    private function findLongUrls() {
        global $wpdb;
        
        return $wpdb->get_results(
            "SELECT ID, post_title, post_name
            FROM {$wpdb->posts}
            WHERE post_status = 'publish'
            AND post_type IN ('post', 'page')
            AND CHAR_LENGTH(post_name) > 75",
            ARRAY_A
        );
    }
    
    /**
     * Audit meta tags
     */
    private function auditMetaTags() {
        $issues = array();
        
        // Check for missing title tags
        $posts_without_titles = $this->findPostsWithoutTitles();
        if (!empty($posts_without_titles)) {
            $issues[] = array(
                'type' => 'missing_titles',
                'severity' => 'high',
                'description' => sprintf(__('%d posts have empty or very short titles', 'autonomous-ai-seo'), count($posts_without_titles)),
                'recommendation' => __('Add descriptive titles to all posts', 'autonomous-ai-seo'),
                'data' => $posts_without_titles
            );
        }
        
        // Check for missing meta descriptions
        $posts_without_meta = $this->findPostsWithoutMetaDescriptions();
        if (!empty($posts_without_meta)) {
            $issues[] = array(
                'type' => 'missing_meta_descriptions',
                'severity' => 'medium',
                'description' => sprintf(__('%d posts are missing meta descriptions', 'autonomous-ai-seo'), count($posts_without_meta)),
                'recommendation' => __('Add unique meta descriptions to improve click-through rates', 'autonomous-ai-seo'),
                'data' => $posts_without_meta
            );
        }
        
        return $issues;
    }
    
    /**
     * Find posts without proper titles
     */
    private function findPostsWithoutTitles() {
        global $wpdb;
        
        return $wpdb->get_results(
            "SELECT ID, post_title
            FROM {$wpdb->posts}
            WHERE post_status = 'publish'
            AND post_type IN ('post', 'page')
            AND (post_title = '' OR CHAR_LENGTH(post_title) < 10)",
            ARRAY_A
        );
    }
    
    /**
     * Find posts without meta descriptions
     */
    private function findPostsWithoutMetaDescriptions() {
        global $wpdb;
        
        return $wpdb->get_results(
            "SELECT p.ID, p.post_title
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_aaiseo_meta_description'
            WHERE p.post_status = 'publish'
            AND p.post_type IN ('post', 'page')
            AND (pm.meta_value IS NULL OR pm.meta_value = '')",
            ARRAY_A
        );
    }
    
    /**
     * Store audit results in database
     */
    private function storeAuditResults($audit_results) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_technical_audits';
        
        foreach ($audit_results as $category => $issues) {
            foreach ($issues as $issue) {
                $wpdb->insert(
                    $table_name,
                    array(
                        'audit_type' => sanitize_text_field($category),
                        'issue_type' => sanitize_text_field($issue['type']),
                        'severity' => sanitize_text_field($issue['severity']),
                        'description' => sanitize_text_field($issue['description']),
                        'recommendation' => sanitize_text_field($issue['recommendation']),
                        'url' => isset($issue['url']) ? esc_url_raw($issue['url']) : '',
                        'data' => json_encode(isset($issue['data']) ? $issue['data'] : array())
                    ),
                    array('%s', '%s', '%s', '%s', '%s', '%s', '%s')
                );
            }
        }
        
        // Log activity
        AAISEO_Core::getInstance()->logActivity(
            'technical_audit',
            __('Technical SEO audit completed', 'autonomous-ai-seo'),
            array('total_issues' => array_sum(array_map('count', $audit_results)))
        );
    }
    
    /**
     * Auto-fix simple issues
     */
    private function autoFixIssues($audit_results) {
        $settings = get_option('aaiseo_settings', array());
        
        if (empty($settings['technical_fixes_enabled'])) {
            return;
        }
        
        $fixed_count = 0;
        
        foreach ($audit_results as $category => $issues) {
            foreach ($issues as $issue) {
                if ($this->canAutoFix($issue['type'])) {
                    if ($this->autoFixIssue($issue)) {
                        $fixed_count++;
                    }
                }
            }
        }
        
        if ($fixed_count > 0) {
            AAISEO_Core::getInstance()->logActivity(
                'auto_fix',
                sprintf(__('Automatically fixed %d technical issues', 'autonomous-ai-seo'), $fixed_count),
                array('count' => $fixed_count)
            );
        }
    }
    
    /**
     * Check if issue can be auto-fixed
     */
    private function canAutoFix($issue_type) {
        $auto_fixable = array(
            'sitemap_missing',
            'missing_alt_text',
            'missing_meta_descriptions'
        );
        
        return in_array($issue_type, $auto_fixable);
    }
    
    /**
     * Auto-fix specific issue
     */
    private function autoFixIssue($issue) {
        switch ($issue['type']) {
            case 'sitemap_missing':
                return $this->generateSitemap();
                
            case 'missing_alt_text':
                return $this->addMissingAltText($issue['data']);
                
            case 'missing_meta_descriptions':
                return $this->generateMissingMetaDescriptions($issue['data']);
        }
        
        return false;
    }
    
    /**
     * Generate XML sitemap
     */
    private function generateSitemap() {
        $sitemap_content = $this->buildSitemapXML();
        
        $upload_dir = wp_upload_dir();
        $sitemap_path = ABSPATH . 'sitemap.xml';
        
        $result = file_put_contents($sitemap_path, $sitemap_content);
        
        if ($result !== false) {
            // Ping search engines
            $this->pingSitemapToSearchEngines();
            return true;
        }
        
        return false;
    }
    
    /**
     * Build sitemap XML content
     */
    private function buildSitemapXML() {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        
        // Add homepage
        $xml .= $this->addSitemapUrl(home_url(), date('c'), 'daily', '1.0');
        
        // Add posts and pages
        $posts = get_posts(array(
            'post_type' => array('post', 'page'),
            'post_status' => 'publish',
            'numberposts' => -1
        ));
        
        foreach ($posts as $post) {
            $url = get_permalink($post->ID);
            $modified = date('c', strtotime($post->post_modified));
            $priority = ($post->post_type === 'page') ? '0.8' : '0.6';
            
            $xml .= $this->addSitemapUrl($url, $modified, 'weekly', $priority);
        }
        
        $xml .= '</urlset>';
        
        return $xml;
    }
    
    /**
     * Add URL to sitemap
     */
    private function addSitemapUrl($url, $lastmod, $changefreq, $priority) {
        $xml = "\t<url>\n";
        $xml .= "\t\t<loc>" . esc_url($url) . "</loc>\n";
        $xml .= "\t\t<lastmod>" . $lastmod . "</lastmod>\n";
        $xml .= "\t\t<changefreq>" . $changefreq . "</changefreq>\n";
        $xml .= "\t\t<priority>" . $priority . "</priority>\n";
        $xml .= "\t</url>\n";
        
        return $xml;
    }
    
    /**
     * Ping sitemap to search engines
     */
    private function pingSitemapToSearchEngines() {
        $sitemap_url = home_url('/sitemap.xml');
        
        $ping_urls = array(
            'https://www.google.com/ping?sitemap=' . urlencode($sitemap_url),
            'https://www.bing.com/ping?sitemap=' . urlencode($sitemap_url)
        );
        
        foreach ($ping_urls as $ping_url) {
            wp_remote_get($ping_url, array('timeout' => 10));
        }
    }
    
    /**
     * Add missing alt text to images
     */
    private function addMissingAltText($images_data) {
        if (empty($images_data)) {
            return false;
        }
        
        $ai_engine = AAISEO_AI_Engine::getInstance();
        $fixed_count = 0;
        
        foreach ($images_data as $image) {
            $image_id = $image['ID'];
            $image_title = $image['post_title'];
            
            // Generate alt text using AI or use title as fallback
            $alt_text = !empty($image_title) ? $image_title : 'Image';
            
            // Try to get more context from the image
            $attachment_url = wp_get_attachment_url($image_id);
            if ($attachment_url) {
                $filename = basename($attachment_url);
                $alt_text = str_replace(array('-', '_'), ' ', pathinfo($filename, PATHINFO_FILENAME));
                $alt_text = ucwords($alt_text);
            }
            
            update_post_meta($image_id, '_wp_attachment_image_alt', $alt_text);
            $fixed_count++;
        }
        
        return $fixed_count > 0;
    }
    
    /**
     * Generate missing meta descriptions
     */
    private function generateMissingMetaDescriptions($posts_data) {
        if (empty($posts_data)) {
            return false;
        }
        
        $ai_engine = AAISEO_AI_Engine::getInstance();
        $fixed_count = 0;
        
        foreach ($posts_data as $post_data) {
            $post_id = $post_data['ID'];
            $post = get_post($post_id);
            
            if (!$post) continue;
            
            // Generate meta description using AI
            $meta_description = $ai_engine->generateMetaDescription(
                $post->post_title,
                $post->post_content
            );
            
            if (!is_wp_error($meta_description) && !empty($meta_description)) {
                update_post_meta($post_id, '_aaiseo_meta_description', $meta_description);
                $fixed_count++;
            }
        }
        
        return $fixed_count > 0;
    }
    
    /**
     * Get Core Web Vitals data
     */
    public function getCoreWebVitals() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_core_web_vitals';
        
        $latest_data = $wpdb->get_row(
            "SELECT * FROM $table_name ORDER BY recorded_at DESC LIMIT 1",
            ARRAY_A
        );
        
        $historical_data = $wpdb->get_results(
            "SELECT * FROM $table_name ORDER BY recorded_at DESC LIMIT 30",
            ARRAY_A
        );
        
        return array(
            'latest' => $latest_data,
            'historical' => $historical_data,
            'summary' => $this->calculateVitalsSummary($historical_data)
        );
    }
    
    /**
     * Calculate Core Web Vitals summary
     */
    private function calculateVitalsSummary($data) {
        if (empty($data)) {
            return array();
        }
        
        $lcp_scores = array_column($data, 'lcp_score');
        $fid_scores = array_column($data, 'fid_score');
        $cls_scores = array_column($data, 'cls_score');
        
        return array(
            'lcp_avg' => array_sum($lcp_scores) / count($lcp_scores),
            'fid_avg' => array_sum($fid_scores) / count($fid_scores),
            'cls_avg' => array_sum($cls_scores) / count($cls_scores),
            'trend' => $this->calculateTrend($data)
        );
    }
    
    /**
     * Calculate performance trend
     */
    private function calculateTrend($data) {
        if (count($data) < 2) {
            return 'stable';
        }
        
        $latest = $data[0]['overall_score'];
        $previous = $data[1]['overall_score'];
        
        if ($latest > $previous + 5) {
            return 'improving';
        } elseif ($latest < $previous - 5) {
            return 'declining';
        }
        
        return 'stable';
    }
    
    /**
     * Get technical audit data for admin
     */
    public function getTechnicalAudit() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_technical_audits';
        
        $recent_issues = $wpdb->get_results(
            "SELECT * FROM $table_name WHERE status = 'open' ORDER BY created_at DESC LIMIT 50",
            ARRAY_A
        );
        
        $issue_stats = $wpdb->get_row(
            "SELECT 
                COUNT(*) as total_issues,
                SUM(CASE WHEN severity = 'high' THEN 1 ELSE 0 END) as high_severity,
                SUM(CASE WHEN severity = 'medium' THEN 1 ELSE 0 END) as medium_severity,
                SUM(CASE WHEN severity = 'low' THEN 1 ELSE 0 END) as low_severity,
                SUM(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END) as resolved
            FROM $table_name
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)",
            ARRAY_A
        );
        
        return array(
            'issues' => $recent_issues,
            'stats' => $issue_stats
        );
    }
    
    /**
     * Manage sitemaps
     */
    private function manageSitemaps() {
        // Check if sitemap exists and is recent
        $sitemap_path = ABSPATH . 'sitemap.xml';
        
        if (!file_exists($sitemap_path) || (time() - filemtime($sitemap_path)) > DAY_IN_SECONDS) {
            $this->generateSitemap();
        }
    }
    
    /**
     * Add canonical tags
     */
    public function addCanonicalTags() {
        if (is_singular()) {
            $canonical_url = get_permalink();
            echo '<link rel="canonical" href="' . esc_url($canonical_url) . '" />' . "\n";
        } elseif (is_home() || is_front_page()) {
            echo '<link rel="canonical" href="' . esc_url(home_url()) . '" />' . "\n";
        }
    }
    
    /**
     * Optimize image on upload
     */
    public function optimizeImageOnUpload($file) {
        $settings = get_option('aaiseo_settings', array());
        
        if (empty($settings['auto_image_optimization'])) {
            return $file;
        }
        
        // Check if it's an image
        if (strpos($file['type'], 'image/') !== 0) {
            return $file;
        }
        
        // Add image optimization logic here
        // This could include resizing, compression, format conversion, etc.
        
        return $file;
    }
    
    /**
     * Add structured data
     */
    public function addStructuredData() {
        if (is_singular()) {
            $post_id = get_the_ID();
            $post = get_post($post_id);
            
            if ($post && $post->post_type === 'post') {
                $schema = array(
                    "@context" => "https://schema.org",
                    "@type" => "Article",
                    "headline" => get_the_title($post_id),
                    "description" => get_the_excerpt($post_id),
                    "author" => array(
                        "@type" => "Person",
                        "name" => get_the_author_meta('display_name', $post->post_author)
                    ),
                    "datePublished" => get_the_date('c', $post_id),
                    "dateModified" => get_the_modified_date('c', $post_id),
                    "publisher" => array(
                        "@type" => "Organization",
                        "name" => get_bloginfo('name'),
                        "url" => home_url()
                    )
                );
                
                echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
            }
        }
    }
    
    /**
     * Optimize robots.txt
     */
    public function optimizeRobotsTxt($output, $public) {
        if (!$public) {
            return $output;
        }
        
        $sitemap_url = home_url('/sitemap.xml');
        
        $optimized_robots = "User-agent: *\n";
        $optimized_robots .= "Disallow: /wp-admin/\n";
        $optimized_robots .= "Disallow: /wp-includes/\n";
        $optimized_robots .= "Disallow: /wp-content/plugins/\n";
        $optimized_robots .= "Disallow: /wp-content/themes/\n";
        $optimized_robots .= "Disallow: /trackback/\n";
        $optimized_robots .= "Disallow: /comments/\n";
        $optimized_robots .= "Disallow: /*?*\n";
        $optimized_robots .= "Disallow: /*?\n";
        $optimized_robots .= "\n";
        $optimized_robots .= "Sitemap: " . $sitemap_url . "\n";
        
        return $optimized_robots;
    }
    
    /**
     * Handle 301 redirects
     */
    public function handleRedirects() {
        // This would handle automatic redirect management
        // Implementation would check for broken links and create redirects
    }
    
    /**
     * Add technical meta tags
     */
    public function addTechnicalTags() {
        // Add various technical SEO tags
        echo '<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />' . "\n";
        
        // Add Open Graph tags
        if (is_singular()) {
            $post_id = get_the_ID();
            echo '<meta property="og:title" content="' . esc_attr(get_the_title($post_id)) . '" />' . "\n";
            echo '<meta property="og:description" content="' . esc_attr(get_the_excerpt($post_id)) . '" />' . "\n";
            echo '<meta property="og:url" content="' . esc_url(get_permalink($post_id)) . '" />' . "\n";
            echo '<meta property="og:type" content="article" />' . "\n";
            
            $thumbnail_id = get_post_thumbnail_id($post_id);
            if ($thumbnail_id) {
                $thumbnail_url = wp_get_attachment_image_url($thumbnail_id, 'large');
                if ($thumbnail_url) {
                    echo '<meta property="og:image" content="' . esc_url($thumbnail_url) . '" />' . "\n";
                }
            }
        }
        
        // Add Twitter Card tags
        echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
        
        // Add viewport meta tag
        echo '<meta name="viewport" content="width=device-width, initial-scale=1" />' . "\n";
    }
    
    /**
     * AJAX handler for technical audit
     */
    public function runTechnicalAuditAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $audit_results = $this->runTechnicalAudit();
        
        wp_send_json_success($audit_results);
    }
}