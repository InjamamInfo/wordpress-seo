<?php
/**
 * User Behavior Tracking and Analysis for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_User_Tracking {
    
    private static $instance = null;
    private $settings;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->settings = get_option('aaiseo_settings', array());
        $this->initHooks();
        $this->createTables();
    }
    
    private function initHooks() {
        // Only run if user tracking is enabled
        if (empty($this->settings['user_tracking_enabled'])) {
            return;
        }
        
        // Admin hooks
        add_action('wp_ajax_aaiseo_get_heatmap_data', array($this, 'getHeatmapDataAjax'));
        add_action('wp_ajax_aaiseo_get_user_journey', array($this, 'getUserJourneyAjax'));
        add_action('admin_menu', array($this, 'addHeatmapMenu'));
        
        // Frontend hooks
        add_action('wp_footer', array($this, 'addTrackingScript'));
        add_action('wp_ajax_aaiseo_track_user_behavior', array($this, 'trackUserBehaviorAjax'));
        add_action('wp_ajax_nopriv_aaiseo_track_user_behavior', array($this, 'trackUserBehaviorAjax'));
    }
    
    /**
     * Create necessary database tables
     */
    private function createTables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Table for tracking clicks
        $table_clicks = $wpdb->prefix . 'aaiseo_user_clicks';
        $sql_clicks = "CREATE TABLE IF NOT EXISTS $table_clicks (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_id varchar(50) NOT NULL,
            page_id bigint(20) unsigned,
            url varchar(500) NOT NULL,
            element_selector varchar(255) NOT NULL,
            element_text text,
            x_position int,
            y_position int,
            viewport_width int,
            viewport_height int,
            referrer varchar(500),
            user_agent varchar(500),
            ip_address varchar(50),
            user_id bigint(20) unsigned,
            device_type varchar(20),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY page_id (page_id),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // Table for tracking scroll depth
        $table_scroll = $wpdb->prefix . 'aaiseo_scroll_depth';
        $sql_scroll = "CREATE TABLE IF NOT EXISTS $table_scroll (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_id varchar(50) NOT NULL,
            page_id bigint(20) unsigned,
            url varchar(500) NOT NULL,
            max_scroll_depth int,
            time_on_page int, /* in seconds */
            fold_time int, /* time spent above the fold in seconds */
            read_percent int, /* estimated read percentage */
            referrer varchar(500),
            user_agent varchar(500),
            ip_address varchar(50),
            user_id bigint(20) unsigned,
            device_type varchar(20),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY page_id (page_id),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // Table for user sessions
        $table_sessions = $wpdb->prefix . 'aaiseo_user_sessions';
        $sql_sessions = "CREATE TABLE IF NOT EXISTS $table_sessions (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_id varchar(50) NOT NULL,
            user_id bigint(20) unsigned,
            start_time datetime DEFAULT CURRENT_TIMESTAMP,
            end_time datetime,
            pages_viewed int DEFAULT 1,
            total_time int, /* in seconds */
            entry_page varchar(500),
            exit_page varchar(500),
            referrer varchar(500),
            user_agent varchar(500),
            ip_address varchar(50),
            device_type varchar(20),
            country varchar(50),
            city varchar(100),
            conversion_type varchar(50),
            conversion_value decimal(10,2),
            PRIMARY KEY (id),
            UNIQUE KEY session_id (session_id),
            KEY user_id (user_id),
            KEY start_time (start_time)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        dbDelta($sql_clicks);
        dbDelta($sql_scroll);
        dbDelta($sql_sessions);
    }
    
    /**
     * Add heatmap menu to admin
     */
    public function addHeatmapMenu() {
        add_submenu_page(
            'autonomous-ai-seo', 
            __('User Behavior', 'autonomous-ai-seo'),
            __('User Behavior', 'autonomous-ai-seo'),
            'manage_options',
            'aaiseo-user-behavior',
            array($this, 'renderBehaviorPage')
        );
    }
    
    /**
     * Render behavior tracking page
     */
    public function renderBehaviorPage() {
        include AAISEO_PLUGIN_PATH . 'templates/admin/user-behavior.php';
    }
    
    /**
     * Add tracking script to footer
     */
    public function addTrackingScript() {
        // Skip for admin or login pages
        if (is_admin() || $GLOBALS['pagenow'] === 'wp-login.php') {
            return;
        }
        
        // Generate session ID if not exists
        $session_id = $this->getSessionId();
        
        // Add script for tracking
        ?>
        <script>
        (function() {
            // Session data
            const sessionData = {
                sessionId: '<?php echo esc_js($session_id); ?>',
                pageId: <?php echo is_singular() ? get_the_ID() : 0; ?>,
                url: '<?php echo esc_js(esc_url_raw(home_url($_SERVER['REQUEST_URI']))); ?>',
                referrer: document.referrer,
                viewportWidth: window.innerWidth,
                viewportHeight: window.innerHeight
            };
            
            // Track page view and start session
            trackPageView();
            
            // Track clicks
            document.addEventListener('click', function(e) {
                const target = e.target;
                let selector = '';
                let elementText = '';
                
                // Try to get a meaningful selector
                if (target.id) {
                    selector = '#' + target.id;
                } else if (target.className) {
                    selector = '.' + target.className.replace(/\s+/g, '.');
                } else {
                    selector = target.tagName.toLowerCase();
                }
                
                // Get element text
                elementText = target.textContent.trim().substring(0, 100);
                
                // Track the click
                trackClick({
                    selector: selector,
                    text: elementText,
                    x: e.clientX,
                    y: e.clientY
                });
            });
            
            // Track scroll depth
            let maxScrollDepth = 0;
            let startTime = Date.now();
            let timeAboveFold = 0;
            let lastScrollTime = Date.now();
            let isAboveFold = true;
            
            window.addEventListener('scroll', debounce(function() {
                const scrollTop = window.scrollY || document.documentElement.scrollTop;
                const documentHeight = Math.max(
                    document.body.scrollHeight,
                    document.documentElement.scrollHeight,
                    document.body.offsetHeight,
                    document.documentElement.offsetHeight
                );
                const windowHeight = window.innerHeight;
                
                const scrollPercent = (scrollTop / (documentHeight - windowHeight)) * 100;
                maxScrollDepth = Math.max(maxScrollDepth, scrollPercent);
                
                // Calculate time above the fold
                const now = Date.now();
                if (scrollTop <= windowHeight && isAboveFold) {
                    timeAboveFold += (now - lastScrollTime);
                }
                isAboveFold = (scrollTop <= windowHeight);
                lastScrollTime = now;
                
            }, 200));
            
            // Track when user leaves page
            window.addEventListener('beforeunload', function() {
                const now = Date.now();
                const timeOnPage = Math.round((now - startTime) / 1000);
                timeAboveFold += isAboveFold ? (now - lastScrollTime) : 0;
                const foldTimeSeconds = Math.round(timeAboveFold / 1000);
                
                // Calculate estimated read percentage based on average reading speed (250 words per minute)
                const content = document.querySelector('.entry-content, .post-content, article, main');
                let readPercent = 0;
                
                if (content) {
                    const words = content.textContent.trim().split(/\s+/).length;
                    const readingTimeSeconds = (words / 250) * 60; // Convert to seconds
                    readPercent = Math.min(100, Math.round((timeOnPage / readingTimeSeconds) * 100));
                }
                
                trackScrollDepth(maxScrollDepth, timeOnPage, foldTimeSeconds, readPercent);
            });
            
            // Function to track page view and start session
            function trackPageView() {
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'aaiseo_track_user_behavior',
                        type: 'page_view',
                        data: JSON.stringify(sessionData)
                    })
                }).catch(console.error);
            }
            
            // Function to track clicks
            function trackClick(clickData) {
                const data = {
                    ...sessionData,
                    selector: clickData.selector,
                    text: clickData.text,
                    xPosition: clickData.x,
                    yPosition: clickData.y
                };
                
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'aaiseo_track_user_behavior',
                        type: 'click',
                        data: JSON.stringify(data)
                    })
                }).catch(console.error);
            }
            
            // Function to track scroll depth
            function trackScrollDepth(scrollDepth, timeOnPage, foldTime, readPercent) {
                const data = {
                    ...sessionData,
                    maxScrollDepth: Math.round(scrollDepth),
                    timeOnPage: timeOnPage,
                    foldTime: foldTime,
                    readPercent: readPercent
                };
                
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'aaiseo_track_user_behavior',
                        type: 'scroll',
                        data: JSON.stringify(data)
                    })
                }).catch(console.error);
            }
            
            // Utility function to debounce events
            function debounce(func, wait) {
                let timeout;
                return function executedFunction(...args) {
                    const later = () => {
                        clearTimeout(timeout);
                        func(...args);
                    };
                    clearTimeout(timeout);
                    timeout = setTimeout(later, wait);
                };
            }
            
            // Track conversions
            document.addEventListener('submit', function(e) {
                if (e.target.tagName === 'FORM') {
                    const formData = {
                        ...sessionData,
                        conversionType: 'form_submission',
                        formId: e.target.id || e.target.name || 'unknown'
                    };
                    
                    trackConversion(formData);
                }
            });
            
            // Track purchases/checkout if WooCommerce is detected
            if (typeof wc_add_to_cart_params !== 'undefined') {
                const wooCheckoutButton = document.querySelector('.checkout-button, .woocommerce-checkout button[type="submit"]');
                if (wooCheckoutButton) {
                    wooCheckoutButton.addEventListener('click', function() {
                        const checkoutData = {
                            ...sessionData,
                            conversionType: 'checkout',
                            value: getCartTotal()
                        };
                        
                        trackConversion(checkoutData);
                    });
                }
            }
            
            // Function to track conversions
            function trackConversion(conversionData) {
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'aaiseo_track_user_behavior',
                        type: 'conversion',
                        data: JSON.stringify(conversionData)
                    })
                }).catch(console.error);
            }
            
            // Utility function to get WooCommerce cart total
            function getCartTotal() {
                const totalElement = document.querySelector('.order-total .amount, .woocommerce-Price-amount.amount');
                if (totalElement) {
                    const totalText = totalElement.textContent.replace(/[^\d.,]/g, '').replace(/,/g, '.');
                    return parseFloat(totalText);
                }
                return 0;
            }
        })();
        </script>
        <?php
    }
    
    /**
     * Get or create session ID
     */
    private function getSessionId() {
        if (!isset($_COOKIE['aaiseo_session'])) {
            $session_id = uniqid('aaiseo_', true);
            setcookie('aaiseo_session', $session_id, time() + (86400 * 30), '/'); // 30 days
            return $session_id;
        }
        
        return $_COOKIE['aaiseo_session'];
    }
    
    /**
     * AJAX handler for tracking user behavior
     */
    public function trackUserBehaviorAjax() {
        $type = sanitize_text_field($_POST['type']);
        $data = json_decode(stripslashes($_POST['data']), true);
        
        if (!$data) {
            wp_die();
        }
        
        switch ($type) {
            case 'page_view':
                $this->trackPageView($data);
                break;
            
            case 'click':
                $this->trackClick($data);
                break;
            
            case 'scroll':
                $this->trackScrollDepth($data);
                break;
            
            case 'conversion':
                $this->trackConversion($data);
                break;
        }
        
        wp_die();
    }
    
    /**
     * Track page view and start/update session
     */
    private function trackPageView($data) {
        global $wpdb;
        
        $session_id = sanitize_text_field($data['sessionId']);
        $page_id = intval($data['pageId']);
        $url = esc_url_raw($data['url']);
        $referrer = esc_url_raw($data['referrer']);
        
        // Get user data
        $user_id = get_current_user_id();
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $ip_address = $this->getClientIP();
        $device_type = $this->getDeviceType($user_agent);
        
        // Get geolocation data if possible
        $geo_data = $this->getGeolocation($ip_address);
        
        // Check if session exists
        $session_exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}aaiseo_user_sessions WHERE session_id = %s",
                $session_id
            )
        );
        
        if ($session_exists) {
            // Update existing session
            $wpdb->update(
                "{$wpdb->prefix}aaiseo_user_sessions",
                array(
                    'pages_viewed' => $wpdb->raw('pages_viewed + 1'),
                    'end_time' => current_time('mysql')
                ),
                array('session_id' => $session_id),
                array('%d', '%s'),
                array('%s')
            );
        } else {
            // Create new session
            $wpdb->insert(
                "{$wpdb->prefix}aaiseo_user_sessions",
                array(
                    'session_id' => $session_id,
                    'user_id' => $user_id ?: null,
                    'entry_page' => $url,
                    'referrer' => $referrer,
                    'user_agent' => $user_agent,
                    'ip_address' => $ip_address,
                    'device_type' => $device_type,
                    'country' => $geo_data['country'] ?? null,
                    'city' => $geo_data['city'] ?? null
                ),
                array('%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
            );
        }
    }
    
    /**
     * Track click event
     */
    private function trackClick($data) {
        global $wpdb;
        
        $wpdb->insert(
            "{$wpdb->prefix}aaiseo_user_clicks",
            array(
                'session_id' => sanitize_text_field($data['sessionId']),
                'page_id' => intval($data['pageId']),
                'url' => esc_url_raw($data['url']),
                'element_selector' => sanitize_text_field($data['selector']),
                'element_text' => sanitize_text_field($data['text']),
                'x_position' => intval($data['xPosition']),
                'y_position' => intval($data['yPosition']),
                'viewport_width' => intval($data['viewportWidth']),
                'viewport_height' => intval($data['viewportHeight']),
                'referrer' => esc_url_raw($data['referrer']),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'ip_address' => $this->getClientIP(),
                'user_id' => get_current_user_id() ?: null,
                'device_type' => $this->getDeviceType($_SERVER['HTTP_USER_AGENT'] ?? '')
            ),
            array('%s', '%d', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%d', '%s')
        );
    }
    
    /**
     * Track scroll depth
     */
    private function trackScrollDepth($data) {
        global $wpdb;
        
        $wpdb->insert(
            "{$wpdb->prefix}aaiseo_scroll_depth",
            array(
                'session_id' => sanitize_text_field($data['sessionId']),
                'page_id' => intval($data['pageId']),
                'url' => esc_url_raw($data['url']),
                'max_scroll_depth' => intval($data['maxScrollDepth']),
                'time_on_page' => intval($data['timeOnPage']),
                'fold_time' => intval($data['foldTime']),
                'read_percent' => intval($data['readPercent']),
                'referrer' => esc_url_raw($data['referrer']),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'ip_address' => $this->getClientIP(),
                'user_id' => get_current_user_id() ?: null,
                'device_type' => $this->getDeviceType($_SERVER['HTTP_USER_AGENT'] ?? '')
            ),
            array('%s', '%d', '%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%d', '%s')
        );
        
        // Update session end time and potentially update exit page
        $wpdb->update(
            "{$wpdb->prefix}aaiseo_user_sessions",
            array(
                'end_time' => current_time('mysql'),
                'exit_page' => esc_url_raw($data['url']),
                'total_time' => intval($data['timeOnPage'])
            ),
            array('session_id' => sanitize_text_field($data['sessionId'])),
            array('%s', '%s', '%d'),
            array('%s')
        );
    }
    
    /**
     * Track conversion event
     */
    private function trackConversion($data) {
        global $wpdb;
        
        $conversion_type = sanitize_text_field($data['conversionType']);
        $conversion_value = isset($data['value']) ? floatval($data['value']) : 0;
        
        // Update session with conversion data
        $wpdb->update(
            "{$wpdb->prefix}aaiseo_user_sessions",
            array(
                'conversion_type' => $conversion_type,
                'conversion_value' => $conversion_value,
                'end_time' => current_time('mysql')
            ),
            array('session_id' => sanitize_text_field($data['sessionId'])),
            array('%s', '%f', '%s'),
            array('%s')
        );
        
        // Log conversion event for A/B testing if applicable
        if (is_singular()) {
            $post_id = get_the_ID();
            if ($post_id) {
                $ab_testing = AAISEO_AB_Testing::getInstance();
                
                // Map conversion types to element types for A/B testing
                $element_type_map = array(
                    'form_submission' => 'content',
                    'checkout' => 'cta',
                    'purchase' => 'cta'
                );
                
                $element_type = $element_type_map[$conversion_type] ?? 'content';
                
                // Get active test for this element type
                $active_test = $ab_testing->getActiveTest($post_id, $element_type);
                
                if ($active_test) {
                    $variation_id = isset($_COOKIE['aaiseo_test_' . $active_test['id']]) ? 
                        intval($_COOKIE['aaiseo_test_' . $active_test['id']]) : 0;
                    
                    $ab_testing->trackConversion($active_test['id'], $variation_id);
                }
            }
        }
    }
    
    /**
     * Get client IP address
     */
    private function getClientIP() {
        if (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        
        return sanitize_text_field($ip);
    }
    
    /**
     * Determine device type from user agent
     */
    private function getDeviceType($user_agent) {
        $mobile_patterns = array(
            'mobile', 'android', 'iphone', 'ipod', 'ipad', 'windows phone', 'blackberry', 'palm'
        );
        
        $tablet_patterns = array(
            'ipad', 'android(?!.*mobile)', 'tablet'
        );
        
        $user_agent = strtolower($user_agent);
        
        foreach ($mobile_patterns as $pattern) {
            if (strpos($user_agent, $pattern) !== false) {
                // Check if it's a tablet
                foreach ($tablet_patterns as $tablet_pattern) {
                    if (preg_match('/' . $tablet_pattern . '/i', $user_agent)) {
                        return 'tablet';
                    }
                }
                return 'mobile';
            }
        }
        
        return 'desktop';
    }
    
    /**
     * Get geolocation data from IP address
     */
    private function getGeolocation($ip_address) {
        // This would ideally use a geolocation service API
        // For now, return empty data
        return array(
            'country' => null,
            'city' => null
        );
    }
    
    /**
     * Get heatmap data for a specific page
     */
    public function getHeatmapData($page_id, $days = 30) {
        global $wpdb;
        
        $clicks = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT x_position, y_position, viewport_width, viewport_height, count(*) as click_count 
                FROM {$wpdb->prefix}aaiseo_user_clicks 
                WHERE page_id = %d 
                AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
                GROUP BY x_position, y_position 
                ORDER BY click_count DESC",
                $page_id, $days
            ),
            ARRAY_A
        );
        
        return $clicks;
    }
    
    /**
     * Get user journey data
     */
    public function getUserJourneyData($days = 30) {
        global $wpdb;
        
        $journeys = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT s.session_id, s.entry_page, s.exit_page, s.pages_viewed, s.total_time, 
                s.conversion_type, s.conversion_value, s.device_type, s.country 
                FROM {$wpdb->prefix}aaiseo_user_sessions s 
                WHERE s.start_time >= DATE_SUB(NOW(), INTERVAL %d DAY)
                ORDER BY s.start_time DESC 
                LIMIT 1000",
                $days
            ),
            ARRAY_A
        );
        
        return $journeys;
    }
    
    /**
     * Get engagement metrics for a specific page
     */
    public function getPageEngagementMetrics($page_id, $days = 30) {
        global $wpdb;
        
        // Get scroll depth data
        $scroll_data = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT AVG(max_scroll_depth) as avg_scroll_depth, 
                AVG(time_on_page) as avg_time_on_page,
                AVG(read_percent) as avg_read_percent,
                COUNT(*) as view_count 
                FROM {$wpdb->prefix}aaiseo_scroll_depth 
                WHERE page_id = %d 
                AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
                $page_id, $days
            ),
            ARRAY_A
        );
        
        // Get click data
        $click_count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) 
                FROM {$wpdb->prefix}aaiseo_user_clicks 
                WHERE page_id = %d 
                AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
                $page_id, $days
            )
        );
        
        // Get conversion data
        $conversion_data = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT COUNT(*) as conversion_count, 
                SUM(conversion_value) as total_value 
                FROM {$wpdb->prefix}aaiseo_user_sessions 
                WHERE entry_page LIKE %s 
                AND conversion_type IS NOT NULL
                AND start_time >= DATE_SUB(NOW(), INTERVAL %d DAY)",
                '%p=' . $page_id . '%', $days
            ),
            ARRAY_A
        );
        
        return array(
            'scroll_data' => $scroll_data,
            'click_count' => (int)$click_count,
            'conversion_data' => $conversion_data,
            'engagement_score' => $this->calculateEngagementScore($scroll_data, $click_count, $conversion_data)
        );
    }
    
    /**
     * Calculate engagement score based on metrics
     */
    private function calculateEngagementScore($scroll_data, $click_count, $conversion_data) {
        // Simple weighted scoring algorithm
        $score = 0;
        
        // Scroll depth factor (up to 30 points)
        if (!empty($scroll_data['avg_scroll_depth'])) {
            $score += ($scroll_data['avg_scroll_depth'] / 100) * 30;
        }
        
        // Time on page factor (up to 30 points)
        if (!empty($scroll_data['avg_time_on_page'])) {
            // Max score at 3 minutes (180 seconds)
            $time_score = min(30, ($scroll_data['avg_time_on_page'] / 180) * 30);
            $score += $time_score;
        }
        
        // Click engagement factor (up to 20 points)
        if (!empty($scroll_data['view_count']) && $scroll_data['view_count'] > 0) {
            // Calculate clicks per view, capped at 4 clicks
            $clicks_per_view = min(4, $click_count / $scroll_data['view_count']);
            $score += ($clicks_per_view / 4) * 20;
        }
        
        // Conversion factor (up to 20 points)
        if (!empty($scroll_data['view_count']) && $scroll_data['view_count'] > 0 && !empty($conversion_data['conversion_count'])) {
            // Calculate conversion rate
            $conversion_rate = $conversion_data['conversion_count'] / $scroll_data['view_count'];
            $score += min(20, $conversion_rate * 1000); // Scaling factor
        }
        
        return round($score);
    }
    
    /**
     * Get heatmap data via AJAX
     */
    public function getHeatmapDataAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $page_id = intval($_POST['page_id']);
        $days = intval($_POST['days']) ?: 30;
        
        $heatmap_data = $this->getHeatmapData($page_id, $days);
        
        wp_send_json_success($heatmap_data);
    }
    
    /**
     * Get user journey data via AJAX
     */
    public function getUserJourneyAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $days = intval($_POST['days']) ?: 30;
        
        $journey_data = $this->getUserJourneyData($days);
        
        wp_send_json_success($journey_data);
    }
    
    /**
     * Generate insights from user behavior data
     */
    public function generateBehaviorInsights($page_id) {
        global $wpdb;
        
        $insights = array();
        
        // Get engagement metrics
        $metrics = $this->getPageEngagementMetrics($page_id);
        
        // Identify potential issues
        if ($metrics['scroll_data']['avg_scroll_depth'] < 50) {
            $insights[] = array(
                'type' => 'issue',
                'title' => 'Low Scroll Depth',
                'description' => 'Users are only scrolling through ' . round($metrics['scroll_data']['avg_scroll_depth']) . '% of your content on average. Consider adding more engaging elements above the fold.',
                'priority' => 'high'
            );
        }
        
        if ($metrics['scroll_data']['avg_time_on_page'] < 30) {
            $insights[] = array(
                'type' => 'issue',
                'title' => 'Short Time on Page',
                'description' => 'Users spend only ' . round($metrics['scroll_data']['avg_time_on_page']) . ' seconds on this page on average. This indicates they may not be finding what they need.',
                'priority' => 'high'
            );
        }
        
        // Get poorly performing CTAs
        $poor_ctas = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT element_selector, element_text, COUNT(*) as impressions,
                SUM(CASE WHEN c2.id IS NOT NULL THEN 1 ELSE 0 END) as clicks
                FROM {$wpdb->prefix}aaiseo_user_clicks c1
                LEFT JOIN {$wpdb->prefix}aaiseo_user_clicks c2 
                ON c1.session_id = c2.session_id AND c2.element_selector LIKE '%button%'
                WHERE c1.page_id = %d 
                AND c1.element_selector LIKE '%cta%' OR c1.element_selector LIKE '%button%'
                GROUP BY c1.element_selector
                HAVING clicks / impressions < 0.02",
                $page_id
            ),
            ARRAY_A
        );
        
        if (!empty($poor_ctas)) {
            foreach ($poor_ctas as $cta) {
                $insights[] = array(
                    'type' => 'issue',
                    'title' => 'Low-performing CTA',
                    'description' => 'The CTA "' . $cta['element_text'] . '" has a low click rate of ' . round(($cta['clicks'] / $cta['impressions']) * 100, 1) . '%. Consider testing different copy or design.',
                    'priority' => 'medium',
                    'selector' => $cta['element_selector']
                );
            }
        }
        
        // Find exit points
        $exit_points = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT element_selector, COUNT(*) as exit_count
                FROM {$wpdb->prefix}aaiseo_user_clicks c
                JOIN {$wpdb->prefix}aaiseo_user_sessions s
                ON c.session_id = s.session_id
                WHERE c.page_id = %d 
                AND c.created_at = (
                    SELECT MAX(created_at)
                    FROM {$wpdb->prefix}aaiseo_user_clicks
                    WHERE session_id = c.session_id
                )
                GROUP BY element_selector
                ORDER BY exit_count DESC
                LIMIT 5",
                $page_id
            ),
            ARRAY_A
        );
        
        if (!empty($exit_points)) {
            $insights[] = array(
                'type' => 'insight',
                'title' => 'Common Exit Points',
                'description' => 'Users frequently exit after interacting with these elements: ' . implode(', ', array_column($exit_points, 'element_selector')),
                'priority' => 'medium'
            );
        }
        
        return $insights;
    }
    
    /**
     * Get all pages with user behavior data
     */
    public function getPagesWithBehaviorData() {
        global $wpdb;
        
        return $wpdb->get_results(
            "SELECT p.ID, p.post_title, 
            COUNT(DISTINCT s.id) as view_count,
            AVG(s.max_scroll_depth) as avg_scroll_depth,
            AVG(s.time_on_page) as avg_time_on_page
            FROM {$wpdb->posts} p
            JOIN {$wpdb->prefix}aaiseo_scroll_depth s ON p.ID = s.page_id
            WHERE p.post_status = 'publish'
            GROUP BY p.ID
            ORDER BY view_count DESC",
            ARRAY_A
        );
    }
    
    /**
     * Generate AI recommendations for improving user engagement
     */
    public function getAIRecommendations($page_id) {
        // Get engagement metrics
        $metrics = $this->getPageEngagementMetrics($page_id);
        
        // Get content
        $post = get_post($page_id);
        
        if (!$post) {
            return array();
        }
        
        $ai_engine = AAISEO_AI_Engine::getInstance();
        
        $prompt = "Analyze this page's user engagement data and suggest improvements:

Page Title: {$post->post_title}

Engagement Metrics:
- Average scroll depth: {$metrics['scroll_data']['avg_scroll_depth']}%
- Average time on page: {$metrics['scroll_data']['avg_time_on_page']} seconds
- Estimated read percentage: {$metrics['scroll_data']['avg_read_percent']}%
- Click count: {$metrics['click_count']}
- Views: {$metrics['scroll_data']['view_count']}

Content Excerpt:
" . wp_trim_words($post->post_content, 100) . "

Based on these metrics, provide 3-5 specific recommendations to improve user engagement and conversion rates. Focus on:
1. Content structure improvements
2. Call-to-action optimization
3. Visual hierarchy enhancements
4. User experience improvements

Format as JSON with 'recommendations' array containing objects with 'title' and 'description' properties.";

        $response = $ai_engine->generateRecommendations($prompt);
        
        if (is_wp_error($response)) {
            return array();
        }
        
        return $response['recommendations'] ?? array();
    }
}