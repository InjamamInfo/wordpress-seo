<?php
/**
 * A/B Testing functionality for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_AB_Testing {
    
    private static $instance = null;
    private $database;
    private $ai_engine;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->database = AAISEO_Database::getInstance();
        $this->ai_engine = AAISEO_AI_Engine::getInstance();
        $this->initHooks();
    }
    
    private function initHooks() {
        add_action('wp_ajax_aaiseo_create_ab_test', array($this, 'createABTestAjax'));
        add_action('wp_ajax_aaiseo_stop_ab_test', array($this, 'stopABTestAjax'));
        add_action('wp_ajax_aaiseo_get_ab_test_results', array($this, 'getABTestResultsAjax'));
        add_action('wp_head', array($this, 'outputABTestContent'));
        add_action('wp_footer', array($this, 'trackABTestInteraction'));
    }
    
    /**
     * Create a new A/B test
     */
    public function createABTest($post_id, $element_type, $original_content, $test_config = array()) {
        // Generate AI variations
        $variations = $this->ai_engine->generateABTestVariations(
            $element_type,
            $original_content,
            $test_config['target_keywords'] ?? array(),
            $test_config['variation_count'] ?? 3
        );
        
        if (is_wp_error($variations)) {
            return $variations;
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_ab_tests';
        
        $test_data = array(
            'post_id' => $post_id,
            'element_type' => $element_type,
            'original_content' => $original_content,
            'variations' => json_encode($variations),
            'test_config' => json_encode($test_config),
            'status' => 'active',
            'start_date' => current_time('mysql'),
            'created_by' => get_current_user_id()
        );
        
        $result = $wpdb->insert($table_name, $test_data, array(
            '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d'
        ));
        
        if ($result) {
            $test_id = $wpdb->insert_id;
            
            // Initialize variation tracking
            $this->initializeVariationTracking($test_id, $variations);
            
            // Log test creation
            AAISEO_Core::getInstance()->logActivity(
                'ab_test_created',
                sprintf(__('A/B test created for %s on post %d', 'autonomous-ai-seo'), $element_type, $post_id),
                array('test_id' => $test_id, 'post_id' => $post_id, 'element_type' => $element_type)
            );
            
            return $test_id;
        }
        
        return false;
    }
    
    /**
     * Initialize tracking for each variation
     */
    private function initializeVariationTracking($test_id, $variations) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_ab_test_results';
        
        // Add original as variation 0
        $wpdb->insert($table_name, array(
            'test_id' => $test_id,
            'variation_id' => 0,
            'variation_content' => '', // Original content stored in main test table
            'impressions' => 0,
            'clicks' => 0,
            'conversions' => 0
        ), array('%d', '%d', '%s', '%d', '%d', '%d'));
        
        // Add AI-generated variations
        if (isset($variations['variations'])) {
            foreach ($variations['variations'] as $index => $variation) {
                $wpdb->insert($table_name, array(
                    'test_id' => $test_id,
                    'variation_id' => $index + 1,
                    'variation_content' => $variation['content'],
                    'impressions' => 0,
                    'clicks' => 0,
                    'conversions' => 0
                ), array('%d', '%d', '%s', '%d', '%d', '%d'));
            }
        }
    }
    
    /**
     * Get active A/B test for a post element
     */
    public function getActiveTest($post_id, $element_type) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_ab_tests';
        
        $test = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table_name 
                WHERE post_id = %d 
                AND element_type = %s 
                AND status = 'active' 
                ORDER BY created_at DESC 
                LIMIT 1",
                $post_id,
                $element_type
            ),
            ARRAY_A
        );
        
        if ($test) {
            $test['variations'] = json_decode($test['variations'], true);
            $test['test_config'] = json_decode($test['test_config'], true);
        }
        
        return $test;
    }
    
    /**
     * Select variation for user (with cookie-based consistency)
     */
    private function selectVariationForUser($test_id, $variation_count) {
        $cookie_name = 'aaiseo_test_' . $test_id;
        
        // Check if user already has a variation assigned
        if (isset($_COOKIE[$cookie_name])) {
            return intval($_COOKIE[$cookie_name]);
        }
        
        // Assign random variation
        $variation_id = mt_rand(0, $variation_count);
        
        // Set cookie for 30 days
        setcookie($cookie_name, $variation_id, time() + (30 * 24 * 60 * 60), '/');
        
        return $variation_id;
    }
    
    /**
     * Track impression for variation
     */
    public function trackImpression($test_id, $variation_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_ab_test_results';
        
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE $table_name 
                SET impressions = impressions + 1,
                    last_updated = %s
                WHERE test_id = %d AND variation_id = %d",
                current_time('mysql'),
                $test_id,
                $variation_id
            )
        );
    }
    
    /**
     * Track click for variation
     */
    public function trackClick($test_id, $variation_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_ab_test_results';
        
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE $table_name 
                SET clicks = clicks + 1,
                    last_updated = %s
                WHERE test_id = %d AND variation_id = %d",
                current_time('mysql'),
                $test_id,
                $variation_id
            )
        );
    }
    
    /**
     * Track conversion for variation
     */
    public function trackConversion($test_id, $variation_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_ab_test_results';
        
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE $table_name 
                SET conversions = conversions + 1,
                    last_updated = %s
                WHERE test_id = %d AND variation_id = %d",
                current_time('mysql'),
                $test_id,
                $variation_id
            )
        );
    }
    
    /**
     * Get A/B test results with statistical significance
     */
    public function getTestResults($test_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_ab_test_results';
        
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE test_id = %d ORDER BY variation_id",
                $test_id
            ),
            ARRAY_A
        );
        
        // Calculate metrics for each variation
        foreach ($results as &$result) {
            $result['ctr'] = $result['impressions'] > 0 ? 
                round(($result['clicks'] / $result['impressions']) * 100, 2) : 0;
            $result['conversion_rate'] = $result['clicks'] > 0 ? 
                round(($result['conversions'] / $result['clicks']) * 100, 2) : 0;
        }
        
        // Calculate statistical significance
        $results = $this->calculateStatisticalSignificance($results);
        
        return $results;
    }
    
    /**
     * Calculate statistical significance between variations
     */
    private function calculateStatisticalSignificance($results) {
        if (count($results) < 2) {
            return $results;
        }
        
        $control = $results[0]; // Original is always variation 0
        
        foreach ($results as &$variation) {
            if ($variation['variation_id'] === 0) {
                $variation['significance'] = 0;
                $variation['confidence'] = 0;
                continue;
            }
            
            // Simple z-test for proportions (click-through rate)
            $p1 = $control['impressions'] > 0 ? $control['clicks'] / $control['impressions'] : 0;
            $p2 = $variation['impressions'] > 0 ? $variation['clicks'] / $variation['impressions'] : 0;
            
            $n1 = $control['impressions'];
            $n2 = $variation['impressions'];
            
            if ($n1 > 30 && $n2 > 30) { // Minimum sample size for meaningful test
                $p_pool = ($control['clicks'] + $variation['clicks']) / ($n1 + $n2);
                $se = sqrt($p_pool * (1 - $p_pool) * (1/$n1 + 1/$n2));
                
                if ($se > 0) {
                    $z_score = abs($p2 - $p1) / $se;
                    $confidence = $this->getConfidenceFromZScore($z_score);
                    
                    $variation['significance'] = $z_score;
                    $variation['confidence'] = $confidence;
                    $variation['is_significant'] = $confidence >= 95;
                } else {
                    $variation['significance'] = 0;
                    $variation['confidence'] = 0;
                    $variation['is_significant'] = false;
                }
            } else {
                $variation['significance'] = 0;
                $variation['confidence'] = 0;
                $variation['is_significant'] = false;
                $variation['insufficient_data'] = true;
            }
        }
        
        return $results;
    }
    
    /**
     * Convert z-score to confidence percentage
     */
    private function getConfidenceFromZScore($z_score) {
        // Simplified mapping of z-scores to confidence levels
        if ($z_score >= 2.58) return 99;
        if ($z_score >= 2.33) return 98;
        if ($z_score >= 1.96) return 95;
        if ($z_score >= 1.65) return 90;
        if ($z_score >= 1.28) return 80;
        return round((1 - 2 * (1 - $this->normalCDF($z_score))) * 100);
    }
    
    /**
     * Normal cumulative distribution function (approximation)
     */
    private function normalCDF($x) {
        return 0.5 * (1 + $this->erf($x / sqrt(2)));
    }
    
    /**
     * Error function approximation
     */
    private function erf($x) {
        // Approximation of error function
        $a1 =  0.254829592;
        $a2 = -0.284496736;
        $a3 =  1.421413741;
        $a4 = -1.453152027;
        $a5 =  1.061405429;
        $p  =  0.3275911;
        
        $sign = $x >= 0 ? 1 : -1;
        $x = abs($x);
        
        $t = 1.0 / (1.0 + $p * $x);
        $y = 1.0 - ((((($a5 * $t + $a4) * $t) + $a3) * $t + $a2) * $t + $a1) * $t * exp(-$x * $x);
        
        return $sign * $y;
    }
    
    /**
     * Stop A/B test and declare winner
     */
    public function stopTest($test_id, $winning_variation_id = null) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_ab_tests';
        
        $test = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $test_id),
            ARRAY_A
        );
        
        if (!$test) {
            return new WP_Error('test_not_found', __('Test not found', 'autonomous-ai-seo'));
        }
        
        // If no winner specified, determine automatically
        if ($winning_variation_id === null) {
            $results = $this->getTestResults($test_id);
            $winning_variation_id = $this->determineWinner($results);
        }
        
        // Update test status
        $wpdb->update(
            $table_name,
            array(
                'status' => 'completed',
                'end_date' => current_time('mysql'),
                'winning_variation' => $winning_variation_id
            ),
            array('id' => $test_id),
            array('%s', '%s', '%d'),
            array('%d')
        );
        
        // Apply winning variation if it's not the original
        if ($winning_variation_id > 0) {
            $this->applyWinningVariation($test_id, $winning_variation_id);
        }
        
        // Log test completion
        AAISEO_Core::getInstance()->logActivity(
            'ab_test_completed',
            sprintf(__('A/B test completed. Winner: Variation %d', 'autonomous-ai-seo'), $winning_variation_id),
            array('test_id' => $test_id, 'winning_variation' => $winning_variation_id)
        );
        
        return true;
    }
    
    /**
     * Determine winner based on statistical significance and performance
     */
    private function determineWinner($results) {
        $best_performance = 0;
        $winner_id = 0;
        
        foreach ($results as $result) {
            // Consider both CTR and statistical significance
            $performance_score = $result['ctr'];
            
            // Boost score if statistically significant
            if (isset($result['is_significant']) && $result['is_significant']) {
                $performance_score *= 1.2;
            }
            
            // Require minimum sample size
            if ($result['impressions'] >= 100 && $performance_score > $best_performance) {
                $best_performance = $performance_score;
                $winner_id = $result['variation_id'];
            }
        }
        
        return $winner_id;
    }
    
    /**
     * Apply winning variation to the actual content
     */
    private function applyWinningVariation($test_id, $winning_variation_id) {
        global $wpdb;
        
        // Get test details
        $test = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}aaiseo_ab_tests WHERE id = %d", $test_id),
            ARRAY_A
        );
        
        // Get winning variation content
        $variation = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}aaiseo_ab_test_results 
                WHERE test_id = %d AND variation_id = %d",
                $test_id,
                $winning_variation_id
            ),
            ARRAY_A
        );
        
        if ($test && $variation) {
            $post_id = $test['post_id'];
            $element_type = $test['element_type'];
            $new_content = $variation['variation_content'];
            
            // Create content version backup before applying
            $version_control = AAISEO_Content_Version_Control::getInstance();
            $version_control->createContentVersion($post_id, 'ab_test_winner', array(
                'test_id' => $test_id,
                'winning_variation' => $winning_variation_id,
                'element_type' => $element_type
            ));
            
            // Apply the change based on element type
            switch ($element_type) {
                case 'title':
                    wp_update_post(array(
                        'ID' => $post_id,
                        'post_title' => $new_content
                    ));
                    break;
                    
                case 'meta_description':
                    update_post_meta($post_id, '_aaiseo_meta_description', $new_content);
                    break;
                    
                case 'excerpt':
                    wp_update_post(array(
                        'ID' => $post_id,
                        'post_excerpt' => $new_content
                    ));
                    break;
            }
        }
    }
    
    /**
     * Output A/B test content in frontend
     */
    public function outputABTestContent() {
        if (!is_singular()) {
            return;
        }
        
        $post_id = get_the_ID();
        
        // Check for active tests
        $meta_test = $this->getActiveTest($post_id, 'meta_description');
        
        if ($meta_test) {
            $variations = $meta_test['variations']['variations'] ?? array();
            $variation_count = count($variations);
            
            if ($variation_count > 0) {
                $selected_variation = $this->selectVariationForUser($meta_test['id'], $variation_count);
                
                // Track impression
                $this->trackImpression($meta_test['id'], $selected_variation);
                
                // Output the selected variation
                if ($selected_variation > 0 && isset($variations[$selected_variation - 1])) {
                    $meta_content = $variations[$selected_variation - 1]['content'];
                    echo '<meta name="description" content="' . esc_attr($meta_content) . '">' . "\n";
                }
            }
        }
    }
    
    /**
     * Track A/B test interactions
     */
    public function trackABTestInteraction() {
        if (!is_singular()) {
            return;
        }
        
        ?>
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Track clicks on elements being tested
            document.addEventListener('click', function(e) {
                // Track clicks for title tests
                if (e.target.matches('h1, .entry-title, .post-title')) {
                    trackABTestClick('title');
                }
                
                // Track CTA clicks
                if (e.target.matches('.cta, .button, .btn')) {
                    trackABTestConversion('cta');
                }
            });
            
            function trackABTestClick(elementType) {
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'aaiseo_track_ab_click',
                        post_id: '<?php echo get_the_ID(); ?>',
                        element_type: elementType,
                        nonce: '<?php echo wp_create_nonce('aaiseo_ab_track'); ?>'
                    })
                });
            }
            
            function trackABTestConversion(elementType) {
                fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: new URLSearchParams({
                        action: 'aaiseo_track_ab_conversion',
                        post_id: '<?php echo get_the_ID(); ?>',
                        element_type: elementType,
                        nonce: '<?php echo wp_create_nonce('aaiseo_ab_track'); ?>'
                    })
                });
            }
        });
        </script>
        <?php
    }
    
    /**
     * AJAX handlers
     */
    public function createABTestAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $post_id = intval($_POST['post_id']);
        $element_type = sanitize_text_field($_POST['element_type']);
        $original_content = sanitize_textarea_field($_POST['original_content']);
        $test_config = isset($_POST['test_config']) ? json_decode(stripslashes($_POST['test_config']), true) : array();
        
        $test_id = $this->createABTest($post_id, $element_type, $original_content, $test_config);
        
        if (is_wp_error($test_id)) {
            wp_send_json_error($test_id->get_error_message());
        } elseif ($test_id) {
            wp_send_json_success(array(
                'test_id' => $test_id,
                'message' => __('A/B test created successfully', 'autonomous-ai-seo')
            ));
        } else {
            wp_send_json_error(__('Failed to create A/B test', 'autonomous-ai-seo'));
        }
    }
    
    public function stopABTestAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $test_id = intval($_POST['test_id']);
        $winning_variation = isset($_POST['winning_variation']) ? intval($_POST['winning_variation']) : null;
        
        $result = $this->stopTest($test_id, $winning_variation);
        
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        } else {
            wp_send_json_success(__('A/B test stopped successfully', 'autonomous-ai-seo'));
        }
    }
    
    public function getABTestResultsAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $test_id = intval($_POST['test_id']);
        $results = $this->getTestResults($test_id);
        
        wp_send_json_success($results);
    }
}