<?php
/**
 * Content Version Control for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Content_Version_Control {
    
    private static $instance = null;
    private $database;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->database = AAISEO_Database::getInstance();
        $this->initHooks();
    }
    
    private function initHooks() {
        add_action('wp_ajax_aaiseo_create_content_version', array($this, 'createVersionAjax'));
        add_action('wp_ajax_aaiseo_restore_content_version', array($this, 'restoreVersionAjax'));
        add_action('wp_ajax_aaiseo_get_content_versions', array($this, 'getVersionsAjax'));
        add_action('wp_ajax_aaiseo_compare_versions', array($this, 'compareVersionsAjax'));
    }
    
    /**
     * Create a new content version before AI changes
     */
    public function createContentVersion($post_id, $version_type = 'ai_optimization', $metadata = array()) {
        $post = get_post($post_id);
        if (!$post) {
            return false;
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_content_versions';
        
        $version_data = array(
            'post_id' => $post_id,
            'version_type' => $version_type,
            'title' => $post->post_title,
            'content' => $post->post_content,
            'excerpt' => $post->post_excerpt,
            'meta_data' => json_encode($this->getPostMetaData($post_id)),
            'ai_metadata' => json_encode($metadata),
            'user_id' => get_current_user_id(),
            'created_at' => current_time('mysql')
        );
        
        $result = $wpdb->insert($table_name, $version_data, array(
            '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s'
        ));
        
        if ($result) {
            $version_id = $wpdb->insert_id;
            
            // Log the version creation
            AAISEO_Core::getInstance()->logActivity(
                'content_version_created',
                sprintf(__('Content version created for post: %s', 'autonomous-ai-seo'), $post->post_title),
                array('post_id' => $post_id, 'version_id' => $version_id, 'type' => $version_type)
            );
            
            return $version_id;
        }
        
        return false;
    }
    
    /**
     * Get post meta data for versioning
     */
    private function getPostMetaData($post_id) {
        $meta_keys = array(
            '_aaiseo_target_keywords',
            '_aaiseo_meta_description',
            '_aaiseo_focus_keyword',
            '_aaiseo_content_analysis',
            '_yoast_wpseo_title',
            '_yoast_wpseo_metadesc',
            '_yoast_wpseo_focuskw'
        );
        
        $meta_data = array();
        foreach ($meta_keys as $key) {
            $value = get_post_meta($post_id, $key, true);
            if (!empty($value)) {
                $meta_data[$key] = $value;
            }
        }
        
        return $meta_data;
    }
    
    /**
     * Restore a content version
     */
    public function restoreContentVersion($version_id, $create_backup = true) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_content_versions';
        
        $version = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $version_id),
            ARRAY_A
        );
        
        if (!$version) {
            return new WP_Error('version_not_found', __('Version not found', 'autonomous-ai-seo'));
        }
        
        $post_id = $version['post_id'];
        
        // Create backup of current content before restoring
        if ($create_backup) {
            $this->createContentVersion($post_id, 'manual_backup', array(
                'restored_from_version' => $version_id,
                'restore_timestamp' => current_time('mysql')
            ));
        }
        
        // Restore the content
        $updated_post = array(
            'ID' => $post_id,
            'post_title' => $version['title'],
            'post_content' => $version['content'],
            'post_excerpt' => $version['excerpt']
        );
        
        $result = wp_update_post($updated_post);
        
        if (!is_wp_error($result)) {
            // Restore meta data
            $meta_data = json_decode($version['meta_data'], true);
            if ($meta_data) {
                foreach ($meta_data as $key => $value) {
                    update_post_meta($post_id, $key, $value);
                }
            }
            
            // Update version status
            $wpdb->update(
                $table_name,
                array('restored_at' => current_time('mysql')),
                array('id' => $version_id),
                array('%s'),
                array('%d')
            );
            
            // Log the restoration
            AAISEO_Core::getInstance()->logActivity(
                'content_version_restored',
                sprintf(__('Content version restored for post ID: %d', 'autonomous-ai-seo'), $post_id),
                array('post_id' => $post_id, 'version_id' => $version_id)
            );
            
            return true;
        }
        
        return $result;
    }
    
    /**
     * Get content versions for a post
     */
    public function getContentVersions($post_id, $limit = 20) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_content_versions';
        
        $versions = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT v.*, u.display_name as author_name 
                FROM $table_name v
                LEFT JOIN {$wpdb->users} u ON v.user_id = u.ID
                WHERE v.post_id = %d 
                ORDER BY v.created_at DESC 
                LIMIT %d",
                $post_id,
                $limit
            ),
            ARRAY_A
        );
        
        // Add version statistics
        foreach ($versions as &$version) {
            $version['ai_metadata'] = json_decode($version['ai_metadata'], true);
            $version['meta_data'] = json_decode($version['meta_data'], true);
            $version['word_count'] = str_word_count($version['content']);
            $version['char_count'] = strlen($version['content']);
        }
        
        return $versions;
    }
    
    /**
     * Compare two content versions
     */
    public function compareVersions($version_id_1, $version_id_2) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_content_versions';
        
        $version1 = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $version_id_1),
            ARRAY_A
        );
        
        $version2 = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $version_id_2),
            ARRAY_A
        );
        
        if (!$version1 || !$version2) {
            return new WP_Error('version_not_found', __('One or both versions not found', 'autonomous-ai-seo'));
        }
        
        return array(
            'version1' => $version1,
            'version2' => $version2,
            'differences' => array(
                'title_changed' => $version1['title'] !== $version2['title'],
                'content_changed' => $version1['content'] !== $version2['content'],
                'excerpt_changed' => $version1['excerpt'] !== $version2['excerpt'],
                'word_count_diff' => str_word_count($version2['content']) - str_word_count($version1['content']),
                'char_count_diff' => strlen($version2['content']) - strlen($version1['content']),
                'meta_changes' => $this->compareMetaData(
                    json_decode($version1['meta_data'], true),
                    json_decode($version2['meta_data'], true)
                )
            ),
            'similarity_score' => $this->calculateSimilarityScore($version1['content'], $version2['content'])
        );
    }
    
    /**
     * Compare meta data between versions
     */
    private function compareMetaData($meta1, $meta2) {
        $changes = array();
        
        $all_keys = array_unique(array_merge(array_keys($meta1 ?: array()), array_keys($meta2 ?: array())));
        
        foreach ($all_keys as $key) {
            $value1 = isset($meta1[$key]) ? $meta1[$key] : '';
            $value2 = isset($meta2[$key]) ? $meta2[$key] : '';
            
            if ($value1 !== $value2) {
                $changes[$key] = array(
                    'old' => $value1,
                    'new' => $value2
                );
            }
        }
        
        return $changes;
    }
    
    /**
     * Calculate similarity score between two content versions
     */
    private function calculateSimilarityScore($content1, $content2) {
        // Simple similarity calculation using word overlap
        $words1 = array_unique(str_word_count(strtolower($content1), 1));
        $words2 = array_unique(str_word_count(strtolower($content2), 1));
        
        $intersection = array_intersect($words1, $words2);
        $union = array_unique(array_merge($words1, $words2));
        
        if (empty($union)) {
            return 0;
        }
        
        return round((count($intersection) / count($union)) * 100, 2);
    }
    
    /**
     * Clean up old versions
     */
    public function cleanupOldVersions($days_to_keep = 90, $max_versions_per_post = 50) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'aaiseo_content_versions';
        
        // Delete versions older than specified days
        $cutoff_date = date('Y-m-d H:i:s', strtotime("-{$days_to_keep} days"));
        
        $deleted_old = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM $table_name WHERE created_at < %s AND version_type != 'manual_backup'",
                $cutoff_date
            )
        );
        
        // Keep only the latest N versions per post
        $posts_with_excess_versions = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT post_id, COUNT(*) as version_count 
                FROM $table_name 
                GROUP BY post_id 
                HAVING version_count > %d",
                $max_versions_per_post
            ),
            ARRAY_A
        );
        
        $deleted_excess = 0;
        foreach ($posts_with_excess_versions as $post) {
            $versions_to_delete = $post['version_count'] - $max_versions_per_post;
            
            $deleted_excess += $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM $table_name 
                    WHERE post_id = %d 
                    AND version_type != 'manual_backup'
                    ORDER BY created_at ASC 
                    LIMIT %d",
                    $post['post_id'],
                    $versions_to_delete
                )
            );
        }
        
        return array(
            'deleted_old' => $deleted_old,
            'deleted_excess' => $deleted_excess
        );
    }
    
    /**
     * AJAX handler for creating versions
     */
    public function createVersionAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $post_id = intval($_POST['post_id']);
        $version_type = sanitize_text_field($_POST['version_type']);
        $metadata = isset($_POST['metadata']) ? json_decode(stripslashes($_POST['metadata']), true) : array();
        
        $version_id = $this->createContentVersion($post_id, $version_type, $metadata);
        
        if ($version_id) {
            wp_send_json_success(array(
                'version_id' => $version_id,
                'message' => __('Content version created successfully', 'autonomous-ai-seo')
            ));
        } else {
            wp_send_json_error(__('Failed to create content version', 'autonomous-ai-seo'));
        }
    }
    
    /**
     * AJAX handler for restoring versions
     */
    public function restoreVersionAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $version_id = intval($_POST['version_id']);
        $create_backup = !empty($_POST['create_backup']);
        
        $result = $this->restoreContentVersion($version_id, $create_backup);
        
        if ($result === true) {
            wp_send_json_success(__('Content version restored successfully', 'autonomous-ai-seo'));
        } else {
            wp_send_json_error(is_wp_error($result) ? $result->get_error_message() : __('Failed to restore version', 'autonomous-ai-seo'));
        }
    }
    
    /**
     * AJAX handler for getting versions
     */
    public function getVersionsAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $post_id = intval($_POST['post_id']);
        $limit = intval($_POST['limit']) ?: 20;
        
        $versions = $this->getContentVersions($post_id, $limit);
        
        wp_send_json_success($versions);
    }
    
    /**
     * AJAX handler for comparing versions
     */
    public function compareVersionsAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $version_id_1 = intval($_POST['version_id_1']);
        $version_id_2 = intval($_POST['version_id_2']);
        
        $comparison = $this->compareVersions($version_id_1, $version_id_2);
        
        if (is_wp_error($comparison)) {
            wp_send_json_error($comparison->get_error_message());
        } else {
            wp_send_json_success($comparison);
        }
    }
}