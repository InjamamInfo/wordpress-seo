<?php
/**
 * Core functionality for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Core {
    
    private static $instance = null;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->initHooks();
    }
    
    private function initHooks() {
        add_action('init', array($this, 'initSession'));
        add_action('wp_head', array($this, 'addMetaTags'));
        add_action('wp_footer', array($this, 'addTrackingCode'));
    }
    
    public function initSession() {
        if (!session_id()) {
            session_start();
        }
    }
    
    public function addMetaTags() {
        $post_id = get_the_ID();
        if (!$post_id) return;
        
        $meta_data = $this->getOptimizedMetaData($post_id);
        
        if (!empty($meta_data['description'])) {
            echo '<meta name="description" content="' . esc_attr($meta_data['description']) . '">' . "\n";
        }
        
        if (!empty($meta_data['keywords'])) {
            echo '<meta name="keywords" content="' . esc_attr($meta_data['keywords']) . '">' . "\n";
        }
        
        // Open Graph tags
        if (!empty($meta_data['og_title'])) {
            echo '<meta property="og:title" content="' . esc_attr($meta_data['og_title']) . '">' . "\n";
        }
        
        if (!empty($meta_data['og_description'])) {
            echo '<meta property="og:description" content="' . esc_attr($meta_data['og_description']) . '">' . "\n";
        }
        
        // Twitter Card tags
        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
        
        // Schema.org JSON-LD
        $this->addStructuredData($post_id);
    }
    
    private function getOptimizedMetaData($post_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_meta_optimizations';
        
        $meta_data = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE post_id = %d ORDER BY created_at DESC LIMIT 1",
                $post_id
            ),
            ARRAY_A
        );
        
        if ($meta_data) {
            return json_decode($meta_data['meta_data'], true);
        }
        
        return array();
    }
    
    private function addStructuredData($post_id) {
        $post = get_post($post_id);
        if (!$post) return;
        
        $schema = array(
            "@context" => "https://schema.org",
            "@type" => "Article",
            "headline" => get_the_title($post_id),
            "description" => get_the_excerpt($post_id),
            "author" => array(
                "@type" => "Person",
                "name" => get_the_author_meta('display_name', $post->post_author)
            ),
            "datePublished" => get_the_date('c', $post_id),
            "dateModified" => get_the_modified_date('c', $post_id),
            "publisher" => array(
                "@type" => "Organization",
                "name" => get_bloginfo('name'),
                "url" => home_url()
            )
        );
        
        // Add image if available
        $image_id = get_post_thumbnail_id($post_id);
        if ($image_id) {
            $image_url = wp_get_attachment_image_url($image_id, 'large');
            if ($image_url) {
                $schema["image"] = array(
                    "@type" => "ImageObject",
                    "url" => $image_url
                );
            }
        }
        
        echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES) . '</script>' . "\n";
    }
    
    public function addTrackingCode() {
        $settings = get_option('aaiseo_settings', array());
        
        if (!empty($settings['tracking_enabled'])) {
            // Add performance tracking
            ?>
            <script>
            (function() {
                // Track Core Web Vitals
                function trackWebVitals() {
                    if ('PerformanceObserver' in window) {
                        // Track LCP
                        new PerformanceObserver((entryList) => {
                            const entries = entryList.getEntries();
                            const lastEntry = entries[entries.length - 1];
                            console.log('LCP:', lastEntry.startTime);
                            // Send to analytics
                        }).observe({entryTypes: ['largest-contentful-paint']});
                        
                        // Track FID
                        new PerformanceObserver((entryList) => {
                            const entries = entryList.getEntries();
                            entries.forEach((entry) => {
                                console.log('FID:', entry.processingStart - entry.startTime);
                                // Send to analytics
                            });
                        }).observe({entryTypes: ['first-input']});
                        
                        // Track CLS
                        let clsValue = 0;
                        new PerformanceObserver((entryList) => {
                            for (const entry of entryList.getEntries()) {
                                if (!entry.hadRecentInput) {
                                    clsValue += entry.value;
                                }
                            }
                            console.log('CLS:', clsValue);
                            // Send to analytics
                        }).observe({entryTypes: ['layout-shift']});
                    }
                }
                
                // Initialize tracking
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', trackWebVitals);
                } else {
                    trackWebVitals();
                }
            })();
            </script>
            <?php
        }
    }
    
    public function getPluginSettings() {
        return get_option('aaiseo_settings', array());
    }
    
    public function updatePluginSettings($settings) {
        return update_option('aaiseo_settings', $settings);
    }
    
    public function logActivity($activity_type, $description, $data = array()) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_activity_log';
        
        $wpdb->insert(
            $table_name,
            array(
                'activity_type' => sanitize_text_field($activity_type),
                'description' => sanitize_text_field($description),
                'data' => json_encode($data),
                'user_id' => get_current_user_id(),
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%d', '%s')
        );
    }
    
    public function getActivityLog($limit = 50) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'aaiseo_activity_log';
        
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table_name ORDER BY created_at DESC LIMIT %d",
                $limit
            ),
            ARRAY_A
        );
        
        return $results;
    }
}