<?php
/**
 * API Manager for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_API_Manager {
    
    private static $instance = null;
    private $google_api_key;
    private $openai_api_key;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $settings = get_option('aaiseo_settings', array());
        $this->google_api_key = !empty($settings['google_api_key']) ? $settings['google_api_key'] : '';
        $this->openai_api_key = !empty($settings['openai_api_key']) ? $settings['openai_api_key'] : '';
    }
    
    /**
     * Get Google Analytics data
     */
    public function getGoogleAnalyticsData($days = 30) {
        if (empty($this->google_api_key)) {
            return new WP_Error('no_api_key', __('Google API key not configured', 'autonomous-ai-seo'));
        }
        
        // This would integrate with Google Analytics API
        // For now, return sample data
        return array(
            'organic_traffic' => rand(20000, 30000),
            'page_views' => rand(80000, 100000),
            'bounce_rate' => rand(40, 60),
            'avg_session_duration' => rand(120, 300)
        );
    }
    
    /**
     * Get Google Search Console data
     */
    public function getSearchConsoleData($days = 30) {
        if (empty($this->google_api_key)) {
            return new WP_Error('no_api_key', __('Google API key not configured', 'autonomous-ai-seo'));
        }
        
        // This would integrate with Google Search Console API
        // For now, return sample data
        return array(
            'total_clicks' => rand(15000, 25000),
            'total_impressions' => rand(150000, 250000),
            'average_ctr' => rand(8, 15),
            'average_position' => rand(8, 15)
        );
    }
    
    /**
     * Get Core Web Vitals data from PageSpeed Insights
     */
    public function getCoreWebVitalsData($url = null) {
        if (empty($this->google_api_key)) {
            return new WP_Error('no_api_key', __('Google API key not configured', 'autonomous-ai-seo'));
        }
        
        if (!$url) {
            $url = home_url();
        }
        
        $api_url = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';
        $api_url .= '?url=' . urlencode($url);
        $api_url .= '&key=' . $this->google_api_key;
        $api_url .= '&category=performance';
        $api_url .= '&strategy=desktop';
        
        $response = wp_remote_get($api_url, array('timeout' => 30));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            return new WP_Error('api_error', __('PageSpeed Insights API error', 'autonomous-ai-seo'));
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!$data || !isset($data['lighthouseResult'])) {
            return new WP_Error('invalid_response', __('Invalid PageSpeed Insights response', 'autonomous-ai-seo'));
        }
        
        $lighthouse = $data['lighthouseResult'];
        $audits = $lighthouse['audits'];
        
        return array(
            'lcp' => isset($audits['largest-contentful-paint']) ? $audits['largest-contentful-paint']['numericValue'] / 1000 : 0,
            'fid' => isset($audits['max-potential-fid']) ? $audits['max-potential-fid']['numericValue'] : 0,
            'cls' => isset($audits['cumulative-layout-shift']) ? $audits['cumulative-layout-shift']['numericValue'] : 0,
            'overall' => $lighthouse['categories']['performance']['score'] * 100
        );
    }
    
    /**
     * Get keyword ranking data
     */
    public function getKeywordRankings($keywords, $domain = null) {
        // This would integrate with a keyword tracking service
        // For now, return sample data
        $rankings = array();
        
        if (!$domain) {
            $domain = parse_url(home_url(), PHP_URL_HOST);
        }
        
        foreach ($keywords as $keyword) {
            $rankings[] = array(
                'keyword' => $keyword,
                'position' => rand(1, 50),
                'search_volume' => rand(100, 10000),
                'difficulty' => rand(1, 100),
                'url' => home_url(),
                'change' => rand(-5, 5)
            );
        }
        
        return $rankings;
    }
    
    /**
     * Get backlink data
     */
    public function getBacklinkData($domain = null) {
        // This would integrate with a backlink analysis service
        // For now, return sample data
        if (!$domain) {
            $domain = parse_url(home_url(), PHP_URL_HOST);
        }
        
        return array(
            'total_backlinks' => rand(500, 5000),
            'referring_domains' => rand(50, 500),
            'domain_authority' => rand(20, 80),
            'new_backlinks' => rand(5, 50),
            'lost_backlinks' => rand(2, 20)
        );
    }
    
    /**
     * Analyze competitor website
     */
    public function analyzeCompetitorWebsite($domain) {
        // This would use various APIs to analyze competitor websites
        // For now, return basic analysis
        
        $url = 'https://' . $domain;
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'user-agent' => 'AAISEO-Bot/1.0'
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $html = wp_remote_retrieve_body($response);
        
        return array(
            'title' => $this->extractTitle($html),
            'meta_description' => $this->extractMetaDescription($html),
            'h1_count' => $this->countH1Tags($html),
            'word_count' => $this->calculateWordCount($html),
            'images_count' => $this->countImages($html),
            'links_count' => $this->countLinks($html),
            'load_time' => $this->measureLoadTime($url),
            'mobile_friendly' => $this->checkMobileFriendly($html)
        );
    }
    
    /**
     * Extract title from HTML
     */
    private function extractTitle($html) {
        if (preg_match('/<title[^>]*>(.*?)<\/title>/i', $html, $matches)) {
            return trim(html_entity_decode($matches[1]));
        }
        return '';
    }
    
    /**
     * Extract meta description
     */
    private function extractMetaDescription($html) {
        if (preg_match('/<meta[^>]*name=[\'"]description[\'"][^>]*content=[\'"]([^\'"]*)[\'"][^>]*>/i', $html, $matches)) {
            return trim(html_entity_decode($matches[1]));
        }
        return '';
    }
    
    /**
     * Count H1 tags
     */
    private function countH1Tags($html) {
        return preg_match_all('/<h1[^>]*>/i', $html);
    }
    
    /**
     * Calculate word count
     */
    private function calculateWordCount($html) {
        $text = strip_tags($html);
        $text = preg_replace('/\s+/', ' ', $text);
        return str_word_count($text);
    }
    
    /**
     * Count images
     */
    private function countImages($html) {
        return preg_match_all('/<img[^>]*>/i', $html);
    }
    
    /**
     * Count links
     */
    private function countLinks($html) {
        return preg_match_all('/<a[^>]*href=[\'"][^\'"]*[\'"][^>]*>/i', $html);
    }
    
    /**
     * Measure load time
     */
    private function measureLoadTime($url) {
        $start_time = microtime(true);
        wp_remote_get($url, array('timeout' => 10));
        $end_time = microtime(true);
        
        return round(($end_time - $start_time) * 1000, 2); // milliseconds
    }
    
    /**
     * Check mobile friendliness
     */
    private function checkMobileFriendly($html) {
        // Check for viewport meta tag
        $has_viewport = preg_match('/<meta[^>]*name=[\'"]viewport[\'"][^>]*>/i', $html);
        
        // Check for responsive indicators
        $has_responsive = preg_match('/@media[^{]*\([^)]*max-width[^)]*\)/i', $html) || 
                         strpos($html, 'bootstrap') !== false ||
                         strpos($html, 'responsive') !== false;
        
        return $has_viewport && $has_responsive;
    }
    
    /**
     * Get social media metrics
     */
    public function getSocialMediaMetrics($url = null) {
        if (!$url) {
            $url = home_url();
        }
        
        // This would integrate with social media APIs
        // For now, return sample data
        return array(
            'facebook_shares' => rand(10, 1000),
            'twitter_shares' => rand(5, 500),
            'linkedin_shares' => rand(2, 200),
            'pinterest_shares' => rand(1, 100),
            'total_shares' => rand(20, 1800)
        );
    }
    
    /**
     * Check website health
     */
    public function checkWebsiteHealth($url = null) {
        if (!$url) {
            $url = home_url();
        }
        
        $health_checks = array();
        
        // Check if site is accessible
        $response = wp_remote_get($url, array('timeout' => 15));
        $health_checks['accessible'] = !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
        
        // Check SSL
        $health_checks['ssl_enabled'] = strpos($url, 'https://') === 0;
        
        // Check robots.txt
        $robots_response = wp_remote_get($url . '/robots.txt');
        $health_checks['robots_txt'] = !is_wp_error($robots_response) && wp_remote_retrieve_response_code($robots_response) === 200;
        
        // Check sitemap
        $sitemap_response = wp_remote_get($url . '/sitemap.xml');
        $health_checks['sitemap'] = !is_wp_error($sitemap_response) && wp_remote_retrieve_response_code($sitemap_response) === 200;
        
        // Calculate overall health score
        $passed_checks = array_sum($health_checks);
        $total_checks = count($health_checks);
        $health_checks['overall_score'] = round(($passed_checks / $total_checks) * 100);
        
        return $health_checks;
    }
    
    /**
     * Get trending keywords
     */
    public function getTrendingKeywords($industry = '', $location = '') {
        // This would integrate with Google Trends API or similar
        // For now, return sample trending keywords
        $trending_keywords = array(
            'ai marketing',
            'voice search optimization',
            'core web vitals',
            'local seo',
            'content marketing automation',
            'schema markup',
            'mobile-first indexing',
            'user experience optimization',
            'semantic search',
            'featured snippets'
        );
        
        $keywords_with_data = array();
        foreach ($trending_keywords as $keyword) {
            $keywords_with_data[] = array(
                'keyword' => $keyword,
                'search_volume' => rand(1000, 50000),
                'trend' => rand(-20, 100), // percentage change
                'difficulty' => rand(20, 90),
                'opportunity_score' => rand(40, 95)
            );
        }
        
        return $keywords_with_data;
    }
    
    /**
     * Submit sitemap to search engines
     */
    public function submitSitemap($sitemap_url = null) {
        if (!$sitemap_url) {
            $sitemap_url = home_url('/sitemap.xml');
        }
        
        $results = array();
        
        // Submit to Google
        $google_ping_url = 'https://www.google.com/ping?sitemap=' . urlencode($sitemap_url);
        $google_response = wp_remote_get($google_ping_url, array('timeout' => 10));
        $results['google'] = !is_wp_error($google_response) && wp_remote_retrieve_response_code($google_response) === 200;
        
        // Submit to Bing
        $bing_ping_url = 'https://www.bing.com/ping?sitemap=' . urlencode($sitemap_url);
        $bing_response = wp_remote_get($bing_ping_url, array('timeout' => 10));
        $results['bing'] = !is_wp_error($bing_response) && wp_remote_retrieve_response_code($bing_response) === 200;
        
        return $results;
    }
    
    /**
     * Get content suggestions
     */
    public function getContentSuggestions($topic, $target_audience = '') {
        // This would use AI APIs to generate content suggestions
        // For now, return sample suggestions
        return array(
            array(
                'title' => 'The Ultimate Guide to ' . $topic,
                'type' => 'comprehensive_guide',
                'estimated_words' => rand(2000, 5000),
                'difficulty' => 'medium',
                'potential_traffic' => rand(500, 5000)
            ),
            array(
                'title' => '10 Best Practices for ' . $topic,
                'type' => 'listicle',
                'estimated_words' => rand(1000, 2500),
                'difficulty' => 'easy',
                'potential_traffic' => rand(300, 3000)
            ),
            array(
                'title' => 'How to Master ' . $topic . ' in 2024',
                'type' => 'how_to_guide',
                'estimated_words' => rand(1500, 3000),
                'difficulty' => 'medium',
                'potential_traffic' => rand(400, 4000)
            )
        );
    }
    
    /**
     * Validate API keys
     */
    public function validateAPIKeys() {
        $validation_results = array();
        
        // Validate Google API key
        if (!empty($this->google_api_key)) {
            $test_url = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=' . urlencode(home_url()) . '&key=' . $this->google_api_key;
            $response = wp_remote_get($test_url, array('timeout' => 15));
            $validation_results['google'] = !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
        } else {
            $validation_results['google'] = false;
        }
        
        // Validate OpenAI API key
        if (!empty($this->openai_api_key)) {
            $test_url = 'https://api.openai.com/v1/models';
            $response = wp_remote_get($test_url, array(
                'timeout' => 15,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $this->openai_api_key
                )
            ));
            $validation_results['openai'] = !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
        } else {
            $validation_results['openai'] = false;
        }
        
        return $validation_results;
    }
    
    /**
     * Validate API keys
     */
    public function validateAPIKeys() {
        $settings = get_option('aaiseo_settings', array());
        $validation_results = array();
        
        // Validate Google API key
        if (!empty($settings['google_api_key'])) {
            $test_url = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=' . urlencode(home_url()) . '&key=' . $settings['google_api_key'];
            $response = wp_remote_get($test_url, array('timeout' => 15));
            $validation_results['google'] = !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
        } else {
            $validation_results['google'] = false;
        }
        
        // Validate OpenAI API key
        if (!empty($settings['openai_api_key'])) {
            $test_url = 'https://api.openai.com/v1/models';
            $response = wp_remote_get($test_url, array(
                'timeout' => 15,
                'headers' => array(
                    'Authorization' => 'Bearer ' . $settings['openai_api_key']
                )
            ));
            $validation_results['openai'] = !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
        } else {
            $validation_results['openai'] = false;
        }
        
        // Validate Grok API key (placeholder implementation)
        if (!empty($settings['grok_api_key'])) {
            // This is a placeholder since there's no public API yet
            $validation_results['grok'] = true;
        } else {
            $validation_results['grok'] = false;
        }
        
        // Validate Gemini API key
        if (!empty($settings['gemini_api_key'])) {
            $test_url = 'https://generativelanguage.googleapis.com/v1/models?key=' . $settings['gemini_api_key'];
            $response = wp_remote_get($test_url);
            $validation_results['gemini'] = !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
        } else {
            $validation_results['gemini'] = false;
        }
        
        // Validate DeepSeek API key (placeholder implementation)
        if (!empty($settings['deepseek_api_key'])) {
            // This is a placeholder since the API structure might differ
            $validation_results['deepseek'] = true;
        } else {
            $validation_results['deepseek'] = false;
        }
        
        return $validation_results;
    }
    
    /**
     * Get API usage statistics
     */
    public function getAPIUsageStats($provider = 'all') {
        // This would track API usage
        $settings = get_option('aaiseo_settings', array());
        $preferred_provider = $settings['preferred_ai_provider'] ?? 'openai';
        
        $usage = [
            'openai' => [
                'api_calls' => rand(50, 500),
                'monthly_limit' => 10000,
                'usage_percentage' => rand(10, 80),
                'is_preferred' => $preferred_provider === 'openai'
            ],
            'grok' => [
                'api_calls' => rand(20, 200),
                'monthly_limit' => 5000,
                'usage_percentage' => rand(10, 60),
                'is_preferred' => $preferred_provider === 'grok'
            ],
            'gemini' => [
                'api_calls' => rand(30, 300),
                'monthly_limit' => 8000,
                'usage_percentage' => rand(10, 70),
                'is_preferred' => $preferred_provider === 'gemini'
            ],
            'deepseek' => [
                'api_calls' => rand(10, 100),
                'monthly_limit' => 3000,
                'usage_percentage' => rand(10, 50),
                'is_preferred' => $preferred_provider === 'deepseek'
            ],
            'google' => [
                'api_calls' => rand(100, 1000),
                'monthly_limit' => 20000,
                'usage_percentage' => rand(10, 90),
                'is_preferred' => false
            ]
        ];
        
        if ($provider !== 'all' && isset($usage[$provider])) {
            return $usage[$provider];
        }
        
        return $usage;
    }
}