<?php
/**
 * Plugin Name: Autonomous AI SEO
 * Plugin URI: https://autonomous-ai-seo.com
 * Description: AI-powered WordPress SEO plugin that autonomously optimizes your website for search engines with predictive analytics and competitive intelligence.
 * Version: 1.0.0
 * Author: Autonomous AI SEO Team
 * Author URI: https://autonomous-ai-seo.com
 * License: GPL v2 or later
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Text Domain: autonomous-ai-seo
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('AAISEO_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AAISEO_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('AAISEO_PLUGIN_VERSION', '1.0.0');
define('AAISEO_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Include required files
require_once AAISEO_PLUGIN_PATH . 'includes/class-aaiseo-core.php';
require_once AAISEO_PLUGIN_PATH . 'includes/class-aaiseo-admin.php';
require_once AAISEO_PLUGIN_PATH . 'includes/class-aaiseo-database.php';
require_once AAISEO_PLUGIN_PATH . 'includes/class-aaiseo-ai-engine.php';
require_once AAISEO_PLUGIN_PATH . 'includes/class-aaiseo-content-optimizer.php';
require_once AAISEO_PLUGIN_PATH . 'includes/class-aaiseo-technical-seo.php';
require_once AAISEO_PLUGIN_PATH . 'includes/class-aaiseo-competitive-intelligence.php';
require_once AAISEO_PLUGIN_PATH . 'includes/class-aaiseo-ab-testing.php';
require_once AAISEO_PLUGIN_PATH . 'includes/class-aaiseo-content-version-control.php';
require_once AAISEO_PLUGIN_PATH . 'includes/class-aaiseo-analytics.php';
require_once AAISEO_PLUGIN_PATH . 'includes/class-aaiseo-api-manager.php';

/**
 * Main plugin class
 */
class AutonomousAISEO {
    
    private static $instance = null;
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('plugins_loaded', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        register_uninstall_hook(__FILE__, array('AutonomousAISEO', 'uninstall'));
    }
    
    public function init() {
        // Load text domain
        load_plugin_textdomain('autonomous-ai-seo', false, dirname(AAISEO_PLUGIN_BASENAME) . '/languages');
        
        // Initialize core components
        $this->initializeComponents();
        
        // Setup hooks
        $this->setupHooks();
        
        // Setup cron jobs
        $this->setupCronJobs();
    }
    
    private function initializeComponents() {
        try {
            // Initialize database
            AAISEO_Database::getInstance();
            
            // Initialize core
            AAISEO_Core::getInstance();
            
            // Initialize admin interface
            if (is_admin()) {
                AAISEO_Admin::getInstance();
            }
            
            // Initialize AI engine
            AAISEO_AI_Engine::getInstance();
            
            // Initialize content optimizer
            AAISEO_Content_Optimizer::getInstance();
            
            // Initialize AB testing
            AAISEO_AB_Testing::getInstance();
            
            // Initialize content version control
            AAISEO_Content_Version_Control::getInstance();
            
            // Initialize technical SEO
            AAISEO_Technical_SEO::getInstance();
            
            // Initialize competitive intelligence
            AAISEO_Competitive_Intelligence::getInstance();
            
            // Initialize analytics
            AAISEO_Analytics::getInstance();
            
            // Initialize API manager
            AAISEO_API_Manager::getInstance();
            
        } catch (Exception $e) {
            error_log('AAISEO Initialization Error: ' . $e->getMessage());
            add_action('admin_notices', function() use ($e) {
                echo '<div class="notice notice-error"><p>Autonomous AI SEO initialization failed: ' . esc_html($e->getMessage()) . '</p></div>';
            });
        }
    }
    
    private function setupHooks() {
        // Enqueue scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'enqueueAdminAssets'));
        add_action('wp_enqueue_scripts', array($this, 'enqueueFrontendAssets'));
        
        // AJAX handlers
        add_action('wp_ajax_aaiseo_get_analytics', array($this, 'handleAnalyticsAjax'));
        add_action('wp_ajax_aaiseo_run_optimization', array($this, 'handleOptimizationAjax'));
        add_action('wp_ajax_aaiseo_get_competitors', array($this, 'handleCompetitorsAjax'));
        add_action('wp_ajax_aaiseo_refresh_analytics', array($this, 'handleRefreshAnalyticsAjax'));
        add_action('wp_ajax_aaiseo_export_report', array($this, 'handleExportReportAjax'));
        add_action('wp_ajax_aaiseo_save_setting', array($this, 'handleSaveSettingAjax'));
        add_action('wp_ajax_aaiseo_get_activities', array($this, 'handleGetActivitiesAjax'));
        add_action('wp_ajax_aaiseo_track_ab_click', array($this, 'handleABClickAjax'));
        add_action('wp_ajax_aaiseo_track_ab_conversion', array($this, 'handleABConversionAjax')); 
        add_action('wp_ajax_nopriv_aaiseo_track_ab_click', array($this, 'handleABClickAjax'));
        add_action('wp_ajax_nopriv_aaiseo_track_ab_conversion', array($this, 'handleABConversionAjax'));
        add_action('wp_ajax_aaiseo_test_api_connection', array($this, 'handleTestAPIConnectionAjax'));
        
        // Content hooks
        add_action('save_post', array($this, 'handlePostSave'), 10, 2);
        add_action('wp_head', array($this, 'addMetaOutput'));
        
        // Admin hooks
        add_action('admin_notices', array($this, 'adminNotices'));
        add_action('admin_init', array($this, 'checkRequirements'));
    }
    
    private function setupCronJobs() {
        // Add custom cron intervals
        add_filter('cron_schedules', array($this, 'addCronIntervals'));
        
        // Cron job handlers
        add_action('aaiseo_daily_optimization', array($this, 'runDailyOptimization'));
        add_action('aaiseo_hourly_monitoring', array($this, 'runHourlyMonitoring'));
        add_action('aaiseo_analyze_content', array($this, 'runContentAnalysis'), 10, 3);
        add_action('aaiseo_analyze_competitor', array($this, 'runCompetitorAnalysis'), 10, 2);
    }
    
    public function addCronIntervals($schedules) {
        $schedules['aaiseo_hourly'] = array(
            'interval' => 3600,
            'display' => __('Every Hour', 'autonomous-ai-seo')
        );
        
        $schedules['aaiseo_daily'] = array(
            'interval' => 86400,
            'display' => __('Daily', 'autonomous-ai-seo')
        );
        
        return $schedules;
    }
    
    public function enqueueAdminAssets($hook) {
        if (strpos($hook, 'autonomous-ai-seo') === false && strpos($hook, 'aaiseo') === false) {
            return;
        }
        
        wp_enqueue_style(
            'aaiseo-admin-style',
            AAISEO_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            AAISEO_PLUGIN_VERSION
        );
        
        wp_enqueue_script(
            'aaiseo-admin-script',
            AAISEO_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery', 'wp-api'),
            AAISEO_PLUGIN_VERSION,
            true
        );
        
        wp_localize_script('aaiseo-admin-script', 'aaiseo_admin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('aaiseo_admin_nonce'),
            'api_url' => rest_url('aaiseo/v1/'),
            'plugin_url' => AAISEO_PLUGIN_URL,
        ));
        
        // Enqueue Chart.js for analytics
        wp_enqueue_script(
            'chart-js',
            'https://cdn.jsdelivr.net/npm/chart.js',
            array(),
            '3.9.1',
            true
        );
    }
    
    public function enqueueFrontendAssets() {
        wp_enqueue_style(
            'aaiseo-frontend-style',
            AAISEO_PLUGIN_URL . 'assets/css/frontend.css',
            array(),
            AAISEO_PLUGIN_VERSION
        );
        
        wp_enqueue_script(
            'aaiseo-frontend-script',
            AAISEO_PLUGIN_URL . 'assets/js/frontend.js',
            array('jquery'),
            AAISEO_PLUGIN_VERSION,
            true
        );
    }
    
    public function activate() {
        try {
            // Create database tables
            AAISEO_Database::createTables();
            
            // Schedule cron jobs
            if (!wp_next_scheduled('aaiseo_daily_optimization')) {
                wp_schedule_event(time(), 'aaiseo_daily', 'aaiseo_daily_optimization');
            }
            
            if (!wp_next_scheduled('aaiseo_hourly_monitoring')) {
                wp_schedule_event(time(), 'aaiseo_hourly', 'aaiseo_hourly_monitoring');
            }
            
            // Set default options
            $this->setDefaultOptions();
            
            // Flush rewrite rules
            flush_rewrite_rules();
            
            // Log activation
            error_log('Autonomous AI SEO plugin activated successfully');
            
        } catch (Exception $e) {
            error_log('AAISEO Activation Error: ' . $e->getMessage());
            wp_die('Plugin activation failed: ' . $e->getMessage());
        }
    }
    
    public function deactivate() {
        // Clear scheduled events
        wp_clear_scheduled_hook('aaiseo_daily_optimization');
        wp_clear_scheduled_hook('aaiseo_hourly_monitoring');
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        error_log('Autonomous AI SEO plugin deactivated');
    }
    
    public static function uninstall() {
        try {
            // Remove database tables
            AAISEO_Database::dropTables();
            
            // Remove options
            delete_option('aaiseo_settings');
            delete_option('aaiseo_license_key');
            delete_option('aaiseo_api_keys');
            delete_option('aaiseo_db_version');
            
            // Clear all scheduled events
            wp_clear_scheduled_hook('aaiseo_daily_optimization');
            wp_clear_scheduled_hook('aaiseo_hourly_monitoring');
            
            error_log('Autonomous AI SEO plugin uninstalled');
            
        } catch (Exception $e) {
            error_log('AAISEO Uninstall Error: ' . $e->getMessage());
        }
    }
    
    private function setDefaultOptions() {
        $default_settings = array(
            'auto_optimization_enabled' => true,
            'content_enhancement_enabled' => true,
            'technical_fixes_enabled' => true,
            'competitive_monitoring_enabled' => false,
            'ai_suggestions_auto_apply' => false,
            'notification_email' => get_option('admin_email'),
            'optimization_frequency' => 'daily',
            'performance_threshold' => 80,
            'tracking_enabled' => true,
            'auto_internal_linking' => true,
            'auto_image_optimization' => true,
            'competitor_notifications' => false,
            'google_api_key' => '',
            'openai_api_key' => '',
        );
        
        add_option('aaiseo_settings', $default_settings);
    }
    
    public function checkRequirements() {
        // Check PHP version
        if (version_compare(PHP_VERSION, '7.4', '<')) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error"><p>Autonomous AI SEO requires PHP 7.4 or higher. You are running ' . PHP_VERSION . '</p></div>';
            });
        }
        
        // Check WordPress version
        if (version_compare(get_bloginfo('version'), '5.0', '<')) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error"><p>Autonomous AI SEO requires WordPress 5.0 or higher.</p></div>';
            });
        }
        
        // Check required functions
        $required_functions = array('curl_init', 'json_encode', 'json_decode');
        foreach ($required_functions as $function) {
            if (!function_exists($function)) {
                add_action('admin_notices', function() use ($function) {
                    echo '<div class="notice notice-error"><p>Autonomous AI SEO requires the ' . $function . ' function.</p></div>';
                });
            }
        }
    }
    
    public function adminNotices() {
        $settings = get_option('aaiseo_settings', array());
        
        // Check if API keys are configured
        if (empty($settings['google_api_key']) || empty($settings['openai_api_key'])) {
            echo '<div class="notice notice-warning is-dismissible">';
            echo '<p>' . __('Autonomous AI SEO requires API keys to function properly.', 'autonomous-ai-seo') . ' ';
            echo '<a href="' . admin_url('admin.php?page=aaiseo-settings') . '">' . __('Configure API keys', 'autonomous-ai-seo') . '</a>';
            echo '</p></div>';
        }
        
        // Show optimization status
        if (!empty($_GET['aaiseo_optimization_complete'])) {
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p>' . __('AI optimization completed successfully!', 'autonomous-ai-seo') . '</p>';
            echo '</div>';
        }
    }
    
    public function handleAnalyticsAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        try {
            $analytics = AAISEO_Analytics::getInstance();
            $data = $analytics->getDashboardData();
            wp_send_json_success($data);
        } catch (Exception $e) {
            error_log('AAISEO Analytics Error: ' . $e->getMessage());
            wp_send_json_error(__('Failed to get analytics data', 'autonomous-ai-seo'));
        }
    }
    
    public function handleOptimizationAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        try {
            $optimizer = AAISEO_Content_Optimizer::getInstance();
            $result = $optimizer->runOptimization();
            
            if ($result !== false) {
                wp_send_json_success(__('Optimization completed successfully', 'autonomous-ai-seo'));
            } else {
                wp_send_json_error(__('Optimization failed', 'autonomous-ai-seo'));
            }
        } catch (Exception $e) {
            error_log('AAISEO Optimization Error: ' . $e->getMessage());
            wp_send_json_error(__('Optimization failed: ' . $e->getMessage(), 'autonomous-ai-seo'));
        }
    }
    
    public function handleCompetitorsAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        try {
            $competitive = AAISEO_Competitive_Intelligence::getInstance();
            $data = $competitive->getCompetitorData();
            wp_send_json_success($data);
        } catch (Exception $e) {
            error_log('AAISEO Competitors Error: ' . $e->getMessage());
            wp_send_json_error(__('Failed to get competitor data', 'autonomous-ai-seo'));
        }
    }
    
    public function handleRefreshAnalyticsAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        try {
            $analytics = AAISEO_Analytics::getInstance();
            $analytics->updateMetrics();
            wp_send_json_success(__('Analytics refreshed successfully', 'autonomous-ai-seo'));
        } catch (Exception $e) {
            error_log('AAISEO Refresh Analytics Error: ' . $e->getMessage());
            wp_send_json_error(__('Failed to refresh analytics', 'autonomous-ai-seo'));
        }
    }
    
    public function handleExportReportAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        try {
            $period = sanitize_text_field($_POST['period'] ?? '30days');
            $format = sanitize_text_field($_POST['format'] ?? 'html');
            
            $analytics = AAISEO_Analytics::getInstance();
            $report = $analytics->generateReport($period, $format);
            
            wp_send_json_success(array('report' => $report));
        } catch (Exception $e) {
            error_log('AAISEO Export Report Error: ' . $e->getMessage());
            wp_send_json_error(__('Failed to export report', 'autonomous-ai-seo'));
        }
    }
    
    public function handleSaveSettingAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        try {
            $setting_name = sanitize_text_field($_POST['setting_name'] ?? '');
            $setting_value = sanitize_text_field($_POST['setting_value'] ?? '');
            
            $settings = get_option('aaiseo_settings', array());
            $settings[$setting_name] = $setting_value;
            
            $result = update_option('aaiseo_settings', $settings);
            
            if ($result) {
                wp_send_json_success(__('Setting saved successfully', 'autonomous-ai-seo'));
            } else {
                wp_send_json_error(__('Failed to save setting', 'autonomous-ai-seo'));
            }
        } catch (Exception $e) {
            error_log('AAISEO Save Setting Error: ' . $e->getMessage());
            wp_send_json_error(__('Failed to save setting', 'autonomous-ai-seo'));
        }
    }
    
    public function handleGetActivitiesAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        try {
            $core = AAISEO_Core::getInstance();
            $activities = $core->getActivityLog(20);
            wp_send_json_success($activities);
        } catch (Exception $e) {
            error_log('AAISEO Get Activities Error: ' . $e->getMessage());
            wp_send_json_error(__('Failed to get activities', 'autonomous-ai-seo'));
        }
    }
    
    /**
     * Handle A/B test click tracking
     */
    public function handleABClickAjax() {
        check_ajax_referer('aaiseo_ab_track', 'nonce');
        
        $post_id = intval($_POST['post_id']);
        $element_type = sanitize_text_field($_POST['element_type']);
        
        // Get the active test for this element
        $ab_testing = AAISEO_AB_Testing::getInstance();
        $active_test = $ab_testing->getActiveTest($post_id, $element_type);
        
        if ($active_test) {
            $variation_id = isset($_COOKIE['aaiseo_test_' . $active_test['id']]) ? intval($_COOKIE['aaiseo_test_' . $active_test['id']]) : 0;
            $ab_testing->trackClick($active_test['id'], $variation_id);
        }
        
        wp_send_json_success();
    }
    
    /**
     * Handle A/B test conversion tracking
     */
    public function handleABConversionAjax() {
        check_ajax_referer('aaiseo_ab_track', 'nonce');
        
        $post_id = intval($_POST['post_id']);
        $element_type = sanitize_text_field($_POST['element_type']);
        
        // Get the active test for this element
        $ab_testing = AAISEO_AB_Testing::getInstance();
        $active_test = $ab_testing->getActiveTest($post_id, $element_type);
        
        if ($active_test) {
            $variation_id = isset($_COOKIE['aaiseo_test_' . $active_test['id']]) ? intval($_COOKIE['aaiseo_test_' . $active_test['id']]) : 0;
            $ab_testing->trackConversion($active_test['id'], $variation_id);
        }
        
        wp_send_json_success();
    }
    
    public function handlePostSave($post_id, $post) {
        try {
            if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
                return;
            }
            
            if (!in_array($post->post_type, array('post', 'page'))) {
                return;
            }
            
            if ($post->post_status !== 'publish') {
                return;
            }
            
            $optimizer = AAISEO_Content_Optimizer::getInstance();
            $target_keywords = get_post_meta($post_id, '_aaiseo_target_keywords', true);
            $target_keywords = $target_keywords ? explode(',', $target_keywords) : array();
            
            $optimizer->scheduleContentAnalysis($post_id, $post->post_content, $target_keywords);
            
        } catch (Exception $e) {
            error_log('AAISEO Post Save Error: ' . $e->getMessage());
        }
    }
    
    public function addMetaOutput() {
        try {
            $post_id = get_the_ID();
            if (!$post_id) return;
            
            $core = AAISEO_Core::getInstance();
            $core->addMetaTags();
            
        } catch (Exception $e) {
            error_log('AAISEO Meta Output Error: ' . $e->getMessage());
        }
    }
    
    public function runDailyOptimization() {
        try {
            $settings = get_option('aaiseo_settings', array());
            
            if (!empty($settings['auto_optimization_enabled'])) {
                $optimizer = AAISEO_Content_Optimizer::getInstance();
                $optimizer->runAutonomousOptimization();
                
                $technical = AAISEO_Technical_SEO::getInstance();
                $technical->runTechnicalAudit();
                
                error_log('AAISEO Daily optimization completed');
            }
        } catch (Exception $e) {
            error_log('AAISEO Daily Optimization Error: ' . $e->getMessage());
        }
    }
    
    public function runHourlyMonitoring() {
        try {
            $competitive = AAISEO_Competitive_Intelligence::getInstance();
            $competitive->monitorCompetitors();
            
            $analytics = AAISEO_Analytics::getInstance();
            $analytics->updateMetrics();
            
        } catch (Exception $e) {
            error_log('AAISEO Hourly Monitoring Error: ' . $e->getMessage());
        }
    }
    
    public function runContentAnalysis($post_id, $content, $target_keywords) {
        try {
            $optimizer = AAISEO_Content_Optimizer::getInstance();
            $optimizer->runContentAnalysis($post_id, $content, $target_keywords);
        } catch (Exception $e) {
            error_log('AAISEO Content Analysis Error: ' . $e->getMessage());
        }
    }
    
    public function runCompetitorAnalysis($competitor_id, $domain) {
        try {
            $competitive = AAISEO_Competitive_Intelligence::getInstance();
            $competitive->analyzeCompetitor($competitor_id, $domain);
        } catch (Exception $e) {
            error_log('AAISEO Competitor Analysis Error: ' . $e->getMessage());
        }
    }
    
    /**
     * Handle API connection test AJAX request
     */
    public function handleTestAPIConnectionAjax() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $api_type = sanitize_text_field($_POST['api_type']);
        $api_key = sanitize_text_field($_POST['api_key']);
        
        switch ($api_type) {
            case 'openai':
                $response = $this->testOpenAIConnection($api_key);
                break;
            case 'grok':
                $response = $this->testGrokConnection($api_key);
                break;
            case 'gemini':
                $response = $this->testGeminiConnection($api_key);
                break;
            case 'deepseek':
                $response = $this->testDeepSeekConnection($api_key);
                break;
            case 'google':
                $response = $this->testGoogleConnection($api_key);
                break;
            default:
                $response = false;
        }
        
        if ($response) {
            wp_send_json_success();
        } else {
            wp_send_json_error();
        }
    }
    
    /**
     * Test OpenAI API connection
     */
    private function testOpenAIConnection($api_key) {
        $url = 'https://api.openai.com/v1/models';
        
        $response = wp_remote_get($url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key
            ),
            'timeout' => 15
        ));
        
        return !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
    }
    
    /**
     * Test Grok API connection (placeholder implementation)
     */
    private function testGrokConnection($api_key) {
        // Since Grok API is not publicly available yet, we'll simulate a successful test
        // This should be updated with actual API validation once available
        return !empty($api_key);
    }
    
    /**
     * Test Gemini API connection
     */
    private function testGeminiConnection($api_key) {
        $url = 'https://generativelanguage.googleapis.com/v1/models?key=' . $api_key;
        
        $response = wp_remote_get($url, array(
            'timeout' => 15
        ));
        
        return !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
    }
    
    /**
     * Test DeepSeek API connection (placeholder implementation)
     */
    private function testDeepSeekConnection($api_key) {
        // This is a placeholder since the API structure might differ
        // Update with actual implementation when available
        return !empty($api_key);
    }
    
    /**
     * Test Google API connection
     */
    private function testGoogleConnection($api_key) {
        $url = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=' . urlencode(home_url()) . '&key=' . $api_key;
        
        $response = wp_remote_get($url, array(
            'timeout' => 15
        ));
        
        return !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
    }
}

// Initialize the plugin
AutonomousAISEO::getInstance();